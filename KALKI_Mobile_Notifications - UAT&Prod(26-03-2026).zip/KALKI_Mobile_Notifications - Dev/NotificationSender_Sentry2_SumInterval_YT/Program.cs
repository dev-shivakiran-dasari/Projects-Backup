﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Newtonsoft.Json.Linq;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.IO;
using System.Net;
using System.Threading;

namespace NotificationSender_Sentry2_SumInterval_YT
{
    class Program
    {
        static void Main(string[] args)
        {
            List<eAlerts_SummarisedInterval_YT> lst = new List<eAlerts_SummarisedInterval_YT>();

            Int32 PlatformID = Convert.ToInt32(System.Configuration.ConfigurationManager.AppSettings["PlatformID"]);
            Log("FetchAlerts_DB_SI_TWT Start", "");
            lst = FetchAlerts_DB_SI_YT(PlatformID);
            Log("FetchAlerts_DB_SI_TWT End", "");

            for (int i = 0; i < lst.Count; i++)
            {


                dynamic json = new JObject();
                json.incident_id = lst[i].TopicID;
                json.base_date = Convert.ToDateTime(lst[i].Base_Date);
                json.from_date = Convert.ToDateTime(lst[i].FromDate);
                json.to_date = Convert.ToDateTime(lst[i].ToDate);


                Log("FetchData Start", "");
                Log("FetchData Input", Convert.ToString(json));

                string output = FetchData(Convert.ToString(json));
                //string output = "{ " +
                //    "\"status\": \"200\", " +
                //    "\"message\": \"Success\", " +
                //    "\"data\": { " +
                //      "\"key_highlights_data\": [ " +
                //        "{ " +
                //          "\"type\": \"text\", " +
                //          "\"excerpt\": \"The Supreme Court has stayed the NCLAT order for insolvency proceedings against Byju\\\"s following a settlement with BCCI. Byju\\\"s has been dealing with financial troubles and legal disputes.\", " +
                //          "\"link\": \"\", " +
                //          "\"clickable\": \"false\" " +
                //        "} " +
                //      "] " +
                //    "} " +
                //  "}";
                Log("FetchData End", "");

                Log("FetchData OutPut", output);
                lst[i].summary = output;


                DataSet ds = Notification_FetchDetails_YouTube(lst[i].NLID, lst[i].TopicID, Convert.ToDateTime(lst[i].Base_Date), Convert.ToDateTime(lst[i].FromDate), Convert.ToDateTime(lst[i].ToDate));

                if (ds != null)
                {
                    if (ds.Tables.Count > 0)
                    {
                        if (ds.Tables[2] != null)
                        {
                            DataTable dt = ds.Tables[2];
                            lst[i].Volume = Convert.ToString(dt.Rows[0]["TotalVideos"]);

                            Log("Volume", Convert.ToString(lst[i].Volume));
                        }
                    }
                }

                //Log("Log_DB Start", "");
                //string strHTML = CreateHtml(lst[i]);
                //Log("Log_DB END", "");

                string TopicID = Convert.ToString(lst[i].TopicID);
                string UserID = Convert.ToString(lst[i].UserID);

                //Log("CreateImage Start For " + Convert.ToString(lst[i].TopicID + '_' + lst[i].UserID), "");
                //lst[i].ScreenShortImageURL = CreateImage(strHTML, "ap_" + YTSID + "_" + TopicID + "_" + UserID + "_" + DateTime.Now.ToString("yyyyMMddHHmmssfff"));
                //Log("CreateImage Start For " + Convert.ToString(lst[i].TopicID + '_' + lst[i].UserID), "");

                string actual_summary = string.Empty;

                Log("Summary", lst[i].summary);

                if (!string.IsNullOrEmpty(lst[i].summary))
                {
                    JObject jsonObj = JObject.Parse(lst[i].summary);

                    JArray keyHighlightsData = (JArray)jsonObj["data"]["key_highlights_data"];
                    actual_summary = Convert.ToString(keyHighlightsData);
                }

                if (Convert.ToInt32(lst[i].Volume) > 0)
                {
                    Log("Log_DB Start", "");
                    Int32 NLID = Log_DB(lst[i].YTSID, lst[i].UserID, lst[i].TopicID, lst[i].ScreenShortImageURL, lst[i].DeviceID, "", "", lst[i].FromDate, lst[i].ToDate, actual_summary, lst[i].Volume);
                    Log("Log_DB Start", "");

                    lst[i].NLID = NLID;

                    Log("SendNotification_News Start For " + Convert.ToString(TopicID + '_' + UserID), "");
                    bool IsResult = SendNotification_News(lst[i]);
                    Log("SendNotification_News Result Is " + IsResult.ToString() + " For " + TopicID + '_' + UserID, "");
                    Log("SendNotification_News End For " + TopicID + '_' + UserID, "");
                }
                else
                {
                    Log("total_volume is " + Convert.ToString(lst[i].Volume), "");
                    Log("Log_DB Start", "");
                    Log_DB(lst[i].YTSID, Convert.ToString(lst[i].UserID), lst[i].TopicID, lst[i].ScreenShortImageURL, lst[i].DeviceID, "", "", lst[i].FromDate, lst[i].ToDate, actual_summary, lst[i].Volume);
                    Log("Log_DB Start", "");
                }

                //string json = JsonConvert.SerializeObject(lstSI[i]);
                //FetchData(json);
            }
        }

        public static List<eAlerts_SummarisedInterval_YT> FetchAlerts_DB_SI_YT(Int32 PlatformID)
        {
            DataTable _dt = new DataTable();
            DataSet _dtSet = new DataSet();
            SqlCommand _sqlCommand = new SqlCommand();

            List<eAlerts_SummarisedInterval_YT> lst = new List<eAlerts_SummarisedInterval_YT>();
            try
            {
                SqlConnection _sqlConnection = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString_SahadevE"].ToString());

                _sqlCommand.Connection = _sqlConnection;
                _sqlCommand.Connection.Open();
                _sqlCommand.CommandText = "USP_Service_SentryV2_FetchUserTopics_SummarisedInterval_ByPlatformID";
                _sqlCommand.CommandType = CommandType.StoredProcedure;
                _sqlCommand.Parameters.AddWithValue("@PlatformID", PlatformID);
                SqlDataAdapter _sqlDataAdapter = new SqlDataAdapter(_sqlCommand);

                _sqlDataAdapter.Fill(_dtSet);

                if (_dtSet != null && _dtSet.Tables.Count > 0)
                {
                    DataTable dtReport = _dtSet.Tables[0];
                    foreach (DataRow dr in dtReport.Rows)
                    {
                        eAlerts_SummarisedInterval_YT eUser = new eAlerts_SummarisedInterval_YT();

                        eUser.TopicID = 0;
                        if (!dr["TopicID"].Equals(DBNull.Value))
                        {
                            eUser.TopicID = Convert.ToInt32(dr["TopicID"]);
                        }

                        eUser.TopicName = Convert.ToString("");
                        if (!dr["TopicName"].Equals(DBNull.Value))
                        {
                            eUser.TopicName = Convert.ToString(dr["TopicName"]);
                        }

                        eUser.UserID = Convert.ToString("");
                        if (!dr["UserID"].Equals(DBNull.Value))
                        {
                            eUser.UserID = Convert.ToString(dr["UserID"]);
                        }

                        eUser.Platform_SummarisedInterval = 0;
                        if (!dr["Platform_SummarisedInterval"].Equals(DBNull.Value))
                        {
                            eUser.Platform_SummarisedInterval = Convert.ToInt32(dr["Platform_SummarisedInterval"]);
                        }
                        eUser.FromDate = Convert.ToString("");
                        if (!dr["FromDate"].Equals(DBNull.Value))
                        {
                            //DateTime dateTime = DateTime.ParseExact(dr["FromDate"].ToString(), "dd-MM-yyyy HH:mm:ss", null);
                            //eUser.FromDate = dateTime.ToString("yyyy-MM-dd HH:mm:ss");
                            eUser.FromDate = Convert.ToString(dr["FromDate"]);
                        }

                        eUser.ToDate = Convert.ToString("");
                        if (!dr["ToDate"].Equals(DBNull.Value))
                        {
                            //DateTime dateTime = DateTime.ParseExact(dr["ToDate"].ToString(), "dd-MM-yyyy HH:mm:ss", null);
                            //eUser.ToDate = dateTime.ToString("yyyy-MM-dd HH:mm:ss");
                            eUser.ToDate = Convert.ToString(dr["ToDate"]);
                        }

                        eUser.DeviceID = Convert.ToString("");
                        if (!dr["DeviceID"].Equals(DBNull.Value))
                        {
                            eUser.DeviceID = Convert.ToString(dr["DeviceID"]);
                        }

                        if (!dr["Prev_FromDate"].Equals(DBNull.Value))
                        {
                            //DateTime dateTime = DateTime.ParseExact(dr["FromDate"].ToString(), "dd-MM-yyyy HH:mm:ss", null);
                            //eUser.FromDate = dateTime.ToString("yyyy-MM-dd HH:mm:ss");
                            eUser.Prev_FromDate = Convert.ToString(dr["Prev_FromDate"]);
                        }


                        if (!dr["Prev_ToDate"].Equals(DBNull.Value))
                        {
                            //DateTime dateTime = DateTime.ParseExact(dr["ToDate"].ToString(), "dd-MM-yyyy HH:mm:ss", null);
                            //eUser.ToDate = dateTime.ToString("yyyy-MM-dd HH:mm:ss");
                            eUser.Prev_ToDate = Convert.ToString(dr["Prev_ToDate"]);
                        }
                        if (!dr["Base_Date"].Equals(DBNull.Value))
                        {
                            //DateTime dateTime = DateTime.ParseExact(dr["ToDate"].ToString(), "dd-MM-yyyy HH:mm:ss", null);
                            //eUser.ToDate = dateTime.ToString("yyyy-MM-dd HH:mm:ss");
                            eUser.Base_Date = Convert.ToString(dr["Base_Date"]);
                        }

                        lst.Add(eUser);
                    }
                }

            }
            catch (Exception ex)
            {
                Log("FetchAlerts_DB", ex.Message + " ->> " + ex.StackTrace);
            }
            finally
            {
                _sqlCommand.Connection.Close();
                _sqlCommand.Connection.Dispose();
            }

            return lst;
        }

        public static string FetchData(string Json)
        {
            string strOutput = string.Empty;
            try
            {
                string strFinalURL = string.Empty;
                string strURL_Service = ConfigurationManager.AppSettings["Url_YouTube"].ToString();

                if (!String.IsNullOrEmpty(strURL_Service))
                {
                    //Create bytes array to send Input as parameter

                    byte[] bytes = bytes = Encoding.UTF8.GetBytes(Json.ToCharArray());//System.Text.Encoding.GetEncoding("ISO-8859-1").GetBytes(strParameters);
                    HttpWebRequest request = (HttpWebRequest)WebRequest.Create(strURL_Service);
                    request.Timeout = Convert.ToInt32(ConfigurationManager.AppSettings["TimeOutIntervalForOperation"]);
                    request.ContentType = "application/json; charset=utf8";
                    request.ContentLength = bytes.Length;
                    request.Method = "POST";
                    request.Headers["Token"] = Convert.ToString(ConfigurationManager.AppSettings["Token"]);
                    //Upload bytes array to request
                    using (Stream os = request.GetRequestStream())
                    {
                        os.Write(bytes, 0, bytes.Length);
                    }

                    //Get response from TextProcessingPipeline

                    using (System.Net.WebResponse resp = request.GetResponse())
                    {
                        using (StreamReader sr = new StreamReader(resp.GetResponseStream()))
                        {
                            strOutput = sr.ReadToEnd().Trim();
                        }
                    }
                    request = null;
                }
            }
            catch (Exception ex)
            {
                ErrorLog("FetchData " + Json, ex.Message + " ->> " + ex.StackTrace);
            }
            return strOutput;
        }

        private static Int32 Log_DB(Int32 APSID, string UserID, Int32 TopicID, string ImageURL, string DeviceID, string Request, string Response, string FromDate, string ToDate, string Summary, string Volume)
        {
            SqlCommand _sqlCommand = new SqlCommand();
            int NLID = 0;
            try
            {

                #region Logic for Notification Log Parameters
                List<eLog> lstLogDetails = new List<eLog>();
                //Response="{\"NotificationID\":29738,\"NotSend\":\"\"}";
                //Response = "{\"Code\": 417, \"Message\": \"NTS008: DeviceID is not provided. Please provide atleast one deviceID.\"}";

                JObject jsonobj = new JObject();
                string NotSentDeviceIds = string.Empty;
                string ErrorCode = string.Empty;
                string ErrorMessage = string.Empty;
                if (!string.IsNullOrEmpty(Response))
                {
                    jsonobj = JObject.Parse(Response);

                    if (!string.IsNullOrEmpty(Convert.ToString(jsonobj["NotSend"])))
                    {
                        NotSentDeviceIds = Convert.ToString(jsonobj["NotSend"]);
                    }
                    else if (!string.IsNullOrEmpty(Convert.ToString(jsonobj["Message"])))
                    {
                        ErrorCode = Convert.ToString(jsonobj["Code"]);
                        ErrorMessage = Convert.ToString(jsonobj["Message"]);
                    }
                }

                string[] FailedDeviceIds = null;

                if (!string.IsNullOrEmpty(NotSentDeviceIds))
                {
                    FailedDeviceIds = NotSentDeviceIds.Split(',');
                }

                if (!string.IsNullOrEmpty(UserID) && !string.IsNullOrEmpty(DeviceID))
                {
                    string[] userids = UserID.Split(',');

                    DeviceID = DeviceID.Replace("\"", "");
                    string[] deviceids = DeviceID.Split(',');
                    //List<string> deviceids = JsonConvert.DeserializeObject<List<string>>(DeviceID);

                    for (int i = 0; i < deviceids.Length; i++)
                    {
                        eLog obj = new eLog();
                        obj.UserID = Convert.ToString(userids[i]);
                        obj.DeviceID = Convert.ToString(deviceids[i]);

                        if (!string.IsNullOrEmpty(ErrorCode) && !string.IsNullOrEmpty(ErrorMessage))
                        {
                            obj.Status = "Failed";
                            obj.ErrorCode = ErrorCode;
                            obj.ErrorMessage = ErrorMessage;
                        }
                        else if (!string.IsNullOrEmpty(NotSentDeviceIds) && FailedDeviceIds.Any(deviceId => deviceId == Convert.ToString(deviceids[i])))
                        {
                            obj.Status = "Failed";
                        }
                        else
                        {
                            obj.Status = "Success";
                        }

                        lstLogDetails.Add(obj);
                    }
                }
                #endregion

                SqlConnection _sqlConnection = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString_SahadevC2"].ToString());
                DataSet _dtSet = new DataSet();

                _sqlCommand.Connection = _sqlConnection;
                _sqlCommand.Connection.Open();
                _sqlCommand.CommandText = "USP_Service_Insert_SentryV2_Notification_Log_SI";
                _sqlCommand.CommandType = CommandType.StoredProcedure;
                _sqlCommand.Parameters.AddWithValue("@RecordID", APSID);
                //_sqlCommand.Parameters.AddWithValue("@UserID", UserID);
                _sqlCommand.Parameters.AddWithValue("@TopicID", TopicID);
                _sqlCommand.Parameters.AddWithValue("@MediaTypeID", 4);
                _sqlCommand.Parameters.AddWithValue("@ImageURL", ImageURL);
                _sqlCommand.Parameters.AddWithValue("@lstDeviceID", DeviceID);
                _sqlCommand.Parameters.AddWithValue("@Request", Request);
                _sqlCommand.Parameters.AddWithValue("@Response", Response);
                _sqlCommand.Parameters.AddWithValue("@FromDate", Convert.ToDateTime(FromDate));
                _sqlCommand.Parameters.AddWithValue("@ToDate", Convert.ToDateTime(ToDate));
                _sqlCommand.Parameters.AddWithValue("@Summary", Summary);
                _sqlCommand.Parameters.AddWithValue("@Volume", Volume);

                //int NLID = Convert.ToInt32(_sqlCommand.ExecuteNonQuery());

                SqlDataAdapter _sqlDataAdapter = new SqlDataAdapter(_sqlCommand);

                _sqlDataAdapter.Fill(_dtSet);

                if (_dtSet != null && _dtSet.Tables.Count > 0)
                {
                    DataTable dtReport = _dtSet.Tables[0];
                    foreach (DataRow dr in dtReport.Rows)
                    {
                        if (!dr["NLID"].Equals(DBNull.Value))
                        {
                            NLID = Convert.ToInt32(dr["NLID"]);
                        }
                    }
                }
                //int NLID = Convert.ToInt32(_sqlCommand.ExecuteNonQuery());

                Log("NLID", Convert.ToString(NLID));
                _sqlCommand.Connection.Close();

                //Insert Into Notification Log Detail

                if (NLID > 0)
                {
                    for (int i = 0; i < lstLogDetails.Count; i++)
                    {
                        SqlCommand _sqlCommand1 = new SqlCommand();
                        _sqlCommand1.Connection = _sqlConnection;
                        _sqlCommand1.Connection.Open();
                        _sqlCommand1.CommandText = "USP_Service_Insert_SentryV2_Notification_Log_SI_Detail";
                        _sqlCommand1.CommandType = CommandType.StoredProcedure;
                        _sqlCommand1.Parameters.AddWithValue("@NLID", NLID);
                        _sqlCommand1.Parameters.AddWithValue("@RecordID", APSID);
                        //_sqlCommand.Parameters.AddWithValue("@UserID", UserID);
                        _sqlCommand1.Parameters.AddWithValue("@TopicID", TopicID);
                        _sqlCommand1.Parameters.AddWithValue("@MediaTypeID", 4);
                        _sqlCommand1.Parameters.AddWithValue("@UserID", lstLogDetails[i].UserID);
                        _sqlCommand1.Parameters.AddWithValue("@DeviceID", lstLogDetails[i].DeviceID);
                        _sqlCommand1.Parameters.AddWithValue("@Status", lstLogDetails[i].Status);
                        _sqlCommand1.Parameters.AddWithValue("@ErrorCode", lstLogDetails[i].ErrorCode);
                        _sqlCommand1.Parameters.AddWithValue("@ErrorMessage", lstLogDetails[i].ErrorMessage);

                        _sqlCommand1.ExecuteNonQuery();
                        _sqlCommand1.Connection.Close();
                    }
                }

            }
            catch (Exception ex)
            {
                Log("Log_DB", ex.Message + " ->> " + ex.StackTrace);
            }

            return NLID;

        }

        public static bool SendNotification_News(eAlerts_SummarisedInterval_YT obj)
        {
            bool IsResult = false;
            string strPost = string.Empty;
            try
            {
                HttpWebRequest request = (HttpWebRequest)WebRequest.Create(ConfigurationManager.AppSettings["URL_SendNotification"]);

                #region Device ID Array


                if (!string.IsNullOrEmpty(obj.DeviceID))
                {
                    string input = obj.DeviceID;
                    string[] values = input.Split(',');

                    List<string> outputList = new List<string>();
                    foreach (string value in values)
                    {
                        outputList.Add(value.Trim());
                    }

                    StringBuilder jsonBuilder = new StringBuilder();
                    jsonBuilder.Append("[");
                    for (int i = 0; i < outputList.Count; i++)
                    {
                        jsonBuilder.Append("\"").Append(outputList[i]).Append("\"");
                        if (i < outputList.Count - 1)
                        {
                            jsonBuilder.Append(",");
                        }
                    }
                    jsonBuilder.Append("]");

                    obj.DeviceID = jsonBuilder.ToString();
                }

                #endregion

                //string strPost = "{\"title\": \"" + obj.TopicName + "\",\"message\":\""
                //    + obj.summary + "\",\"image\":\"" + obj.ScreenShortImageURL
                //    + "\",\"payload\":{\"messageTypeID\":\"SUM\", \"channelID\":\"TW\", \"incidentID\":\"" + obj.YTSID + "\", \"data\":\"\"},\"deviceID\": " + obj.DeviceID + "}";

                int interval = Convert.ToInt32(obj.Platform_SummarisedInterval);
                string interval_text, message;

                if (interval > 0 && interval < 60)
                {
                    interval_text = Convert.ToString(interval) + " Minutes";
                }
                else
                {
                    double hours = interval / 60.0;
                    interval_text = hours.ToString() + " Hours";
                }

                message = "Summary of last " + interval_text;

                //string interval_text = string.Empty;
                //string message = string.Empty;
                //if ((Convert.ToInt32(obj.Platform_SummarisedInterval) > 0 && Convert.ToInt32(obj.Platform_SummarisedInterval) < 60))
                //{
                //    interval_text = Convert.ToString(obj.Platform_SummarisedInterval) + " Minutes";
                //    message = "Summary of last " + Convert.ToString(obj.Platform_SummarisedInterval) + " Minutes";
                //}
                //else if (Convert.ToInt32(obj.Platform_SummarisedInterval) == 60)
                //{
                //    interval_text = "1 Hours";
                //    message = "Summary of last 1 Hours";
                //}
                //else if (Convert.ToInt32(obj.Platform_SummarisedInterval) == 120)
                //{
                //    interval_text = "2 Hours";
                //    message = "Summary of last 2 Hours";
                //}
                //else if (Convert.ToInt32(obj.Platform_SummarisedInterval) == 180)
                //{
                //    interval_text = "3 Hours";
                //    message = "Summary of last 3 Hours";
                //}

                string Base_Date = string.Empty;
                if (obj.Base_Date != null)
                {
                    DateTime parsedDate = DateTime.Parse(obj.Base_Date);
                    Base_Date = parsedDate.ToString("yyyy-MM-dd HH:mm:ss");
                }


                //string strPost = "{\"title\": \"" + obj.TopicName + "\",\"message\":\""
                //    + obj.summary.Replace("\"", "'").Replace("/n", "'") + "\",\"image\":\"" + obj.ScreenShortImageURL
                //    + "\",\"payload\":{\"messageTypeID\":\"SUM\", \"channelID\":\"TW\", \"incidentID\":\""
                //    + obj.TopicID + "\", \"data\": { \"base_date\" : \"" + Base_Date + "\", \"interval\" : \""
                //    + obj.Platform_SummarisedInterval + "\", \"interval_text\" : \"" + interval_text + "\" }},\"deviceID\": " + obj.DeviceID + "}";

                strPost = "{\"title\": \"" + obj.TopicName + "\",\"message\":\""
                   + "YouTube - " + message + "\",\"image\":\"" + obj.ScreenShortImageURL
                   + "\",\"payload\":{\"messageTypeID\":\"SUM\", \"channelID\":\"YT\", \"incidentID\":\""
                   + obj.TopicID + "\", \"data\": { \"base_date\" : \"" + Base_Date + "\", \"interval\" : \""
                   + obj.Platform_SummarisedInterval + "\", \"interval_text\" : \"" + interval_text + "\", \"primary_key\" : \"" + obj.NLID + "\"   }},\"deviceID\": " + obj.DeviceID + "}";

                string SummaryDetail_Json = Create_NotificationDetailJson(obj);

                Log("Notification sent", strPost);

                //Create bytes array to send Input as parameter
                byte[] bytes = System.Text.Encoding.GetEncoding("ISO-8859-1").GetBytes(strPost);

                //Set request options
                request.ContentType = "application/json; charset=utf-8";
                request.ContentLength = bytes.Length;
                request.Method = "POST";
                request.Timeout = 900000;
                request.Headers["x-api-key"] = Convert.ToString(ConfigurationManager.AppSettings["x-api-key"]);
                //request.Headers["APPversion"] = "1.0.0";
                //request.Headers["APIVersion"] = "1.0.0";
                //request.Headers["DevicePlatform"] = "W";

                //Upload bytes array to request
                using (Stream os = request.GetRequestStream())
                {
                    os.Write(bytes, 0, bytes.Length);
                }

                //Get response from Request
                using (System.Net.WebResponse resp = request.GetResponse())
                {
                    using (StreamReader sr = new StreamReader(resp.GetResponseStream()))
                    {
                        string strOutput = sr.ReadToEnd().Trim();

                        Log(strOutput, "");
                        IsResult = true;

                        Log("Log_DB Start", "");
                        obj.DeviceID = obj.DeviceID.ToString().Replace("[", "").Replace("]", "");
                        Log_DB_Update(obj.UserID, obj.DeviceID, obj.NLID, strPost, strOutput, SummaryDetail_Json);
                        Log("Log_DB Start", "");
                    }
                }
            }
            catch (Exception ex)
            {
                Log("SendNotification_News", obj.TopicID + "|" + obj.UserID + "->" + ex.Message + " ->> " + ex.StackTrace);
                if (!string.IsNullOrEmpty(obj.DeviceID))
                {
                    obj.DeviceID = obj.DeviceID.ToString().Replace("[", "").Replace("]", "");
                }
                Log_DB_Update(obj.UserID, obj.DeviceID, obj.NLID, strPost, "{\"Code\": 417, \"Message\": \"NTS004: User or User Device Detail does not registered with us.\"}", "");
            }

            return IsResult;
        }

        public static string Create_NotificationDetailJson(eAlerts_SummarisedInterval_YT obj)
        {
            string Return = string.Empty;
            dynamic json = new JObject();
            json.status = "200";
            json.message = "Success";

            string SleepTime = Convert.ToString(ConfigurationManager.AppSettings["SleepTime"]);

            Thread.Sleep(Convert.ToInt32(SleepTime));

            DataSet ds = Notification_FetchDetails_YouTube(obj.NLID, obj.TopicID, Convert.ToDateTime(obj.Base_Date), Convert.ToDateTime(obj.FromDate), Convert.ToDateTime(obj.ToDate));
            if (ds != null)
            {
                if (ds.Tables.Count > 0)
                {
                    DataTable dt = ds.Tables[0];

                    json.data = new JObject();

                    json.data.incident_id = Convert.ToString(dt.Rows[0]["incident_id"]);
                    json.data.summary_title = Convert.ToString(dt.Rows[0]["summary_title"]);
                    json.data.summary_subtitle = Convert.ToString(dt.Rows[0]["summary_subtitle"]);
                    json.data.summary_sentdate = Convert.ToString(dt.Rows[0]["summary_sentdate"]);
                    json.data.event_span = Convert.ToString(dt.Rows[0]["event_span"]);

                    DataTable dt1 = ds.Tables[1];

                    json.data.stats = new JArray();

                    json.data.stats = JArray.FromObject(dt1);

                    if (!string.IsNullOrEmpty(obj.summary))
                    {
                        JObject jsonObj = JObject.Parse(obj.summary);

                        JArray keyHighlightsData = (JArray)jsonObj["data"]["key_highlights_data"];

                        json.data.key_highlights_data = keyHighlightsData;
                    }

                }

            }

            Return = Convert.ToString(json);

            return Return;
        }

        public static DataSet Notification_FetchDetails_YouTube(Int32 NLID, Int32 TopicID, DateTime BaseDate, DateTime FromDate, DateTime ToDate)
        {
            DataTable _dt = new DataTable();
            DataSet _dtSet = new DataSet();
            SqlCommand _sqlCommand = new SqlCommand();

            try
            {
                SqlConnection _sqlConnection = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString_SahadevE"].ToString());

                _sqlCommand.Connection = _sqlConnection;
                _sqlCommand.Connection.Open();
                _sqlCommand.CommandText = "USP_SentryV2_Notification_FetchDetails_YouTube";
                _sqlCommand.CommandType = CommandType.StoredProcedure;
                _sqlCommand.Parameters.AddWithValue("@NLID", NLID);
                _sqlCommand.Parameters.AddWithValue("@TopicID", TopicID);
                _sqlCommand.Parameters.AddWithValue("@BaseDate", BaseDate);
                _sqlCommand.Parameters.AddWithValue("@FromDate", FromDate);
                _sqlCommand.Parameters.AddWithValue("@ToDate", ToDate);
                SqlDataAdapter _sqlDataAdapter = new SqlDataAdapter(_sqlCommand);

                _sqlDataAdapter.Fill(_dtSet);

            }
            catch (Exception ex)
            {
                Log("FetchAlerts_DB", ex.Message + " ->> " + ex.StackTrace);
            }
            finally
            {
                _sqlCommand.Connection.Close();
                _sqlCommand.Connection.Dispose();
            }

            return _dtSet;
        }

        private static Int32 Log_DB_Update(string UserID, string DeviceID, Int32 NLID, string Request, string Response, string SummaryDetail_Json)
        {
            SqlCommand _sqlCommand = new SqlCommand();

            try
            {

                #region Logic for Notification Log Parameters
                List<eLog> lstLogDetails = new List<eLog>();
                //Response="{\"NotificationID\":29738,\"NotSend\":\"9829486ae2d7a82e,d76d1de010ac487a\"}";
                JObject jsonobj = new JObject();
                string NotSentDeviceIds = string.Empty;
                string ErrorCode = string.Empty;
                string ErrorMessage = string.Empty;
                string message_id = "";

                if (!string.IsNullOrEmpty(Response))
                {
                    jsonobj = JObject.Parse(Response);

                    if (!string.IsNullOrEmpty(Convert.ToString(jsonobj["NotSend"])))
                    {
                        NotSentDeviceIds = Convert.ToString(jsonobj["NotSend"]);
                    }
                    else if (!string.IsNullOrEmpty(Convert.ToString(jsonobj["Message"])))
                    {
                        ErrorCode = Convert.ToString(jsonobj["Code"]);
                        ErrorMessage = Convert.ToString(jsonobj["Message"]);
                    }

                    string id = jsonobj["data"]?["id"]?.ToString();

                    if (!string.IsNullOrEmpty(id))
                    {
                        message_id = id;
                    }
                }

                string[] FailedDeviceIds = null;

                if (!string.IsNullOrEmpty(NotSentDeviceIds))
                {
                    FailedDeviceIds = NotSentDeviceIds.Split(',');
                }

                if (!string.IsNullOrEmpty(UserID) && !string.IsNullOrEmpty(DeviceID))
                {
                    string[] userids = UserID.Split(',');

                    DeviceID = DeviceID.Replace("\"", "");
                    string[] deviceids = DeviceID.Split(',');
                    //List<string> deviceids = JsonConvert.DeserializeObject<List<string>>(DeviceID);

                    for (int i = 0; i < deviceids.Length; i++)
                    {
                        eLog obj = new eLog();
                        obj.UserID = Convert.ToString(userids[i]);
                        obj.DeviceID = Convert.ToString(deviceids[i]);

                        if (!string.IsNullOrEmpty(ErrorCode) && !string.IsNullOrEmpty(ErrorMessage))
                        {
                            obj.Status = "Failed";
                            obj.ErrorCode = ErrorCode;
                            obj.ErrorMessage = ErrorMessage;
                        }
                        else if (!string.IsNullOrEmpty(NotSentDeviceIds) && FailedDeviceIds.Any(deviceId => deviceId == Convert.ToString(deviceids[i])))
                        {
                            obj.Status = "Failed";
                        }
                        else
                        {
                            obj.Status = "Success";
                        }

                        lstLogDetails.Add(obj);
                    }
                }
                #endregion


                SqlConnection _sqlConnection = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString_SahadevC2"].ToString());
                DataSet _dtSet = new DataSet();

                _sqlCommand.Connection = _sqlConnection;
                _sqlCommand.Connection.Open();
                _sqlCommand.CommandText = "USP_Service_Update_SentryV2_Notification_Log_SI";
                _sqlCommand.CommandType = CommandType.StoredProcedure;
                _sqlCommand.Parameters.AddWithValue("@NLID", NLID);
                _sqlCommand.Parameters.AddWithValue("@SummaryDetail_Json", SummaryDetail_Json);
                _sqlCommand.Parameters.AddWithValue("@Request", Request);
                _sqlCommand.Parameters.AddWithValue("@Response", Response);
                _sqlCommand.Parameters.AddWithValue("@Message_ID", message_id);

                SqlDataAdapter _sqlDataAdapter = new SqlDataAdapter(_sqlCommand);

                _sqlDataAdapter.Fill(_dtSet);
                _sqlCommand.Connection.Close();

                for (int i = 0; i < lstLogDetails.Count; i++)
                {
                    SqlCommand _sqlCommand1 = new SqlCommand();
                    _sqlCommand1.Connection = _sqlConnection;
                    _sqlCommand1.Connection.Open();
                    _sqlCommand1.CommandText = "USP_Service_Update_SentryV2_Notification_Log_SI_Detail";
                    _sqlCommand1.CommandType = CommandType.StoredProcedure;
                    _sqlCommand1.Parameters.AddWithValue("@NLID", NLID);
                    _sqlCommand1.Parameters.AddWithValue("@UserID", lstLogDetails[i].UserID);
                    //_sqlCommand1.Parameters.AddWithValue("@DeviceID", lstLogDetails[i].DeviceID);
                    _sqlCommand1.Parameters.AddWithValue("@Status", lstLogDetails[i].Status);

                    _sqlCommand1.ExecuteNonQuery();
                    _sqlCommand1.Connection.Close();
                }
            }
            catch (Exception ex)
            {
                Log("Log_DB", ex.Message + " ->> " + ex.StackTrace);
            }

            return NLID;
        }

        #region LOGGING

        //For error logging
        private static void ErrorLog(string functionName, string error)
        {
            try
            {
                string LogPath = ConfigurationManager.AppSettings["ErrorLogPath"];
                using (TextWriter myWriter = File.AppendText(LogPath))
                {

                    TextWriter.Synchronized(myWriter).WriteLine("<--> :{0}", string.Empty);
                    TextWriter.Synchronized(myWriter).WriteLine("Function Name :{0}", functionName);
                    TextWriter.Synchronized(myWriter).WriteLine("Error :{0}", error);
                    TextWriter.Synchronized(myWriter).WriteLine("Date :{0}", DateTime.Now.ToString());
                    TextWriter.Synchronized(myWriter).WriteLine("<--> :{0}", string.Empty);
                    TextWriter.Synchronized(myWriter).Flush();
                    TextWriter.Synchronized(myWriter).Close();
                }
            }
            catch (Exception ex)
            {
            }
        }

        //For debugging purpose
        private static void TimeLog(string strtext)
        {
            try
            {
                string LogPath = ConfigurationManager.AppSettings["TimeLogPath"];
                using (TextWriter myWriter = File.AppendText(LogPath))
                {

                    TextWriter.Synchronized(myWriter).WriteLine("<--> :{0}", string.Empty);
                    TextWriter.Synchronized(myWriter).WriteLine("TimeLog :{0}", strtext);
                    TextWriter.Synchronized(myWriter).WriteLine("Date :{0}", DateTime.Now.ToString());
                    TextWriter.Synchronized(myWriter).WriteLine("<--> :{0}", string.Empty);
                    TextWriter.Synchronized(myWriter).Flush();
                    TextWriter.Synchronized(myWriter).Close();
                }
            }
            catch (Exception ex)
            {
                ErrorLog("TimeLog", ex.ToString());
            }
        }


        private static void Log(string functionName, string error)
        {
            try
            {
                string LogPath = ConfigurationManager.AppSettings["LogPath"].ToString();
                using (TextWriter myWriter = File.AppendText(LogPath))
                {

                    TextWriter.Synchronized(myWriter).WriteLine("<--> :{0}", string.Empty);
                    TextWriter.Synchronized(myWriter).WriteLine("Function Name :{0}", functionName);
                    if (!String.IsNullOrEmpty(error))
                    {
                        TextWriter.Synchronized(myWriter).WriteLine("Error :{0}", error);
                    }
                    TextWriter.Synchronized(myWriter).WriteLine("Date :{0}", DateTime.Now.ToString());
                    TextWriter.Synchronized(myWriter).WriteLine("<--> :{0}", string.Empty);
                    TextWriter.Synchronized(myWriter).Flush();
                    TextWriter.Synchronized(myWriter).Close();
                }

            }
            catch (Exception ex)
            {
            }
        }


        public class eLog
        {
            public string UserID { get; set; }
            public string DeviceID { get; set; }
            public string Status { get; set; }
            public string ErrorCode { get; set; }
            public string ErrorMessage { get; set; }
        }

        #endregion
    }
}
