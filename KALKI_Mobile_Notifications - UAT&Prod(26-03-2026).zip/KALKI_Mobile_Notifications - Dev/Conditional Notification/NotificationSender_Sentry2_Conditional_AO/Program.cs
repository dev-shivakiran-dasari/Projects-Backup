﻿// ============================================================
//  NotificationSender_Sentry2_Conditional_AO
//
//  New flow:
//    FetchEventIDs()  → get active EventIDs
//    FetchFromSP()    → per EventID, articles + raw CriteriaJSON conditions
//    FilterArticles() → filter in C# using ParseJson + Match
//    Send loop        → SendNotification_News + UpdateAlert_News
//
//  SP modification required — replace final section with:
//    SELECT * FROM #TempOutput;
//    SELECT DISTINCT e.UserID, e.EventID, e.ENSCDID, e.ConditionName, e.CriteriaJSON
//    FROM Event_NotificationSetting_ConditionalDetail e WITH(NOLOCK)
//    INNER JOIN #TempOutput t WITH(NOLOCK) ON e.EventID = t.incident_id AND e.UserID = t.UserID
//    WHERE e.PlatformID = 1 AND e.IsActive = 1 AND e.Is_Deleted = 0;
//    DROP TABLE #TempOutput;
// ============================================================

using System;
using System.Collections.Generic;
using System.Collections.Concurrent;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.IO;
using System.Net;
using System.Diagnostics;
using System.Threading.Tasks;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace NotificationSender_Sentry2_Conditional_AO
{
    // =========================================================================
    //  CriteriaJSON model
    //  is_tml_active is int? — DB sends null when TML is not configured
    // =========================================================================
    internal class CriteriaItem
    {
        [JsonProperty("condition_type")] public string ConditionType { get; set; }
        [JsonProperty("condition_value")] public string ConditionValue { get; set; }
        [JsonProperty("is_active")] public int IsActive { get; set; }
        [JsonProperty("is_tml_active")] public int? IsTmlActive { get; set; }
    }

    // All conditions AND'd together; keyword + datatag OR'd with each other
    internal class ParsedFilter
    {
        public List<string> Sentiments { get; set; }
        public long? TrafficMin { get; set; }
        public long? TrafficMax { get; set; }
        public List<string> SourceDomains { get; set; }
        public List<string> Keywords { get; set; }
        public List<string> DataTagIds { get; set; }

        public bool HasAny() =>
               (Sentiments != null && Sentiments.Count > 0)
            || TrafficMin.HasValue
            || (SourceDomains != null && SourceDomains.Count > 0)
            || (Keywords != null && Keywords.Count > 0)
            || (DataTagIds != null && DataTagIds.Count > 0);
    }

    public class eLog
    {
        public string UserID { get; set; }
        public string DeviceID { get; set; }
        public string Status { get; set; }
        public string ErrorCode { get; set; }
        public string ErrorMessage { get; set; }
    }

    class Program
    {
        static readonly string ConnE = ConfigurationManager.ConnectionStrings["ConnectionString_SahadevE"].ToString();
        static readonly string ConnC2 = ConfigurationManager.ConnectionStrings["ConnectionString_SahadevC2"].ToString();
        static readonly string ConnD = ConfigurationManager.ConnectionStrings["ConnectionString_SahadevD"].ToString();

        static readonly int MaxParallel = Convert.ToInt32(
            ConfigurationManager.AppSettings["MaxDegreeOfParallelism"]);

        static readonly ParallelOptions Po = new ParallelOptions
        {
            MaxDegreeOfParallelism = MaxParallel
        };

        // =====================================================================
        //  ENTRY POINT
        // =====================================================================
        static void Main(string[] args)
        {
            try
            {
                Log("Program Start", "");

                ServicePointManager.DefaultConnectionLimit = MaxParallel * 3;

                Log("FetchEventIDs Start", "");
                List<int> eventIds = FetchEventIDs();
                Log("FetchEventIDs End", $"Count={eventIds.Count}  IDs={string.Join(",", eventIds)}");

                if (eventIds.Count == 0) { Log("No active EventIDs found", ""); return; }

                var sw = Stopwatch.StartNew();

                // Level 1 — EventIDs in parallel
                Parallel.ForEach(eventIds, Po, eventId =>
                {
                    try { ProcessEvent(eventId); }
                    catch (Exception ex)
                    {
                        Log($"EventID={eventId} unhandled error", ex.Message + " >> " + ex.StackTrace);
                    }
                });

                sw.Stop();
                Log("Program End", $"Total time={sw.Elapsed:mm\\:ss\\.fff}");
            }
            catch (Exception ex) { Log("Main", ex.Message + " >> " + ex.StackTrace); }
        }

        // =====================================================================
        //  ProcessEvent — full pipeline for one EventID
        // =====================================================================
        static void ProcessEvent(int eventId)
        {
            Log($"EventID={eventId} Start", "");

            DataTable articles = null, conditions = null;
            FetchFromSP(eventId, out articles, out conditions);

            if (articles == null || articles.Rows.Count == 0)
            {
                Log($"EventID={eventId}", "No articles. Skipping."); return;
            }
            if (conditions == null || conditions.Rows.Count == 0)
            {
                Log($"EventID={eventId}", "No conditions. Skipping."); return;
            }

            // Level 2 — filter conditions in parallel
            var matched = FilterArticles(articles, conditions, eventId);

            Log($"EventID={eventId}", $"Matched={matched.Count}");
            if (matched.Count == 0) return;

            // Level 3 — send in parallel
            Parallel.For(0, matched.Count, Po, i =>
            {
                try
                {
                    Log($"Send Start article_id={matched[i].article_id}", "");
                    bool sent = SendNotification_News(matched[i]);
                    Log($"Send Result={sent} article_id={matched[i].article_id}", "");
                    if (sent)
                        UpdateAlert_News(matched[i].article_id, matched[i].MediaTypeID);
                }
                catch (Exception ex)
                {
                    Log($"Send error article_id={matched[i].article_id}",
                        ex.Message + " >> " + ex.StackTrace);
                }
            });

            Log($"EventID={eventId} Done", "");
        }

        // =====================================================================
        //  FetchEventIDs
        // =====================================================================
        static List<int> FetchEventIDs()
        {
            var list = new List<int>();
            var cmd = new SqlCommand();
            try
            {
                var conn = new SqlConnection(ConnE);
                cmd.Connection = conn;
                cmd.Connection.Open();
                cmd.CommandText = "USP_Notification_FtechEventIDs_Test";
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandTimeout = 60;
                cmd.Parameters.AddWithValue("@PlatformID", 1);
                cmd.Parameters.AddWithValue("@NotificationType", "CON");
                using (var rd = cmd.ExecuteReader())
                    while (rd.Read())
                        list.Add(Convert.ToInt32(rd["EventID"]));
            }
            catch (Exception ex) { Log("FetchEventIDs", ex.Message + " >> " + ex.StackTrace); }
            finally { cmd.Connection.Close(); cmd.Connection.Dispose(); }
            return list;
        }

        // =====================================================================
        //  FetchFromSP — returns two result sets:
        //    [0] articles   (article_id, title, url, …)
        //    [1] conditions (UserID, EventID, ENSCDID, ConditionName, CriteriaJSON)
        // =====================================================================
        static void FetchFromSP(int eventId, out DataTable articles, out DataTable conditions)
        {
            articles = conditions = null;
            var cmd = new SqlCommand();
            try
            {
                var conn = new SqlConnection(ConnE);
                cmd.Connection = conn;
                cmd.Connection.Open();
                cmd.CommandText = "USP_Notification_Conditional_Online_Test";
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandTimeout = 600;
                cmd.Parameters.AddWithValue("@EventID", eventId);

                var ds = new DataSet();
                new SqlDataAdapter(cmd).Fill(ds);

                if (ds.Tables.Count >= 1) articles = ds.Tables[0].Copy();
                if (ds.Tables.Count >= 2) conditions = ds.Tables[1].Copy();

                Log($"FetchFromSP EventID={eventId}",
                    $"Articles={(articles?.Rows.Count ?? 0)}  Conditions={(conditions?.Rows.Count ?? 0)}");
            }
            catch (Exception ex)
            {
                Log($"FetchFromSP EventID={eventId}", ex.Message + " >> " + ex.StackTrace);
            }
            finally { cmd.Connection.Close(); cmd.Connection.Dispose(); }
        }

        // =====================================================================
        //  FilterArticles — Level 2: conditions in parallel, thread-safe via ConcurrentBag
        // =====================================================================
        //static List<eAlerts_ArticleOnline> FilterArticles(
        //    DataTable articles, DataTable conditions, int eventId)
        //{
        //    var bag = new ConcurrentBag<eAlerts_ArticleOnline>();
        //    var condRows = conditions.Rows.Cast<DataRow>().ToArray();
        //    var artRows = articles.Rows.Cast<DataRow>().ToArray();

        //    Parallel.ForEach(condRows, Po, condRow =>
        //    {
        //        try
        //        {
        //            int userId = Convert.ToInt32(condRow["UserID"]);
        //            int enscdId = Convert.ToInt32(condRow["ENSCDID"]);
        //            string condName = condRow["ConditionName"].ToString();
        //            string json = condRow["CriteriaJSON"].ToString();

        //            ParsedFilter pf = ParseJson(json, userId, eventId);

        //            if (!pf.HasAny())
        //            {
        //                Log($"ENSCDID={enscdId} skipped — no active conditions", "");
        //                return;
        //            }

        //            foreach (DataRow art in artRows)
        //            {
        //                if (GetStr(art, "UserID") != userId.ToString()) continue;
        //                if (GetInt(art, "incident_id") != eventId) continue;
        //                if (!Match(art, pf)) continue;
        //                bag.Add(BuildAlert(art, enscdId, condName));
        //            }
        //        }
        //        catch (Exception ex)
        //        {
        //            Log($"FilterArticles EventID={eventId}", ex.Message + " >> " + ex.StackTrace);
        //        }
        //    });

        //    return bag.ToList();
        //}

        internal static List<eAlerts_ArticleOnline> FilterArticles(DataTable articles, DataTable conditions, int eventId)
        {
            var result = new ConcurrentDictionary<int, eAlerts_ArticleOnline>();

            var condRows = conditions.Rows.Cast<DataRow>().ToArray();
            var artRows = articles.Rows.Cast<DataRow>().ToArray();

            Parallel.ForEach(condRows, Po, condRow =>
            {
                try
                {
                    int userId = Convert.ToInt32(condRow["UserID"]);
                    int ConEventID = Convert.ToInt32(condRow["EventID"]);
                    int enscdId = Convert.ToInt32(condRow["ENSCDID"]);
                    string condName = condRow["ConditionName"].ToString();
                    string json = condRow["CriteriaJSON"].ToString();

                    ParsedFilter pf = ParseJson(json, userId, eventId);

                    if (!pf.HasAny())
                        return;

                    foreach (DataRow art in artRows)
                    {
                        if (GetInt(art, "incident_id") != ConEventID && ConEventID!=eventId) continue;
                        if (GetStr(art, "UserID") != userId.ToString()) continue;
                        if (!Match(art, pf)) continue;

                        int articleid = GetInt(art, "article_id");

                        result.AddOrUpdate(
                            articleid,
                            // If NOT exists → create new
                            key =>
                            {
                                var obj = BuildAlert(art, enscdId, condName);
                                return obj;
                            },
                            // If EXISTS → update aggregation
                            (key, existing) =>
                            {
                                string newUser = userId.ToString();
                                string newDevice = GetStr(art, "lstDeviceID");

                                // Avoid duplicate user
                                var users = existing.UserID?.Split(',').ToList() ?? new List<string>();
                                if (!users.Contains(newUser))
                                {
                                    users.Add(newUser);
                                    existing.UserID = string.Join(",", users);

                                    var devices = existing.lstDeviceID?.Split(',').ToList() ?? new List<string>();
                                    devices.Add(newDevice);
                                    existing.lstDeviceID = string.Join(",", devices);
                                }

                                return existing;
                            });
                    }
                }
                catch (Exception ex)
                {
                    Log($"FilterArticles EventID={eventId}", ex.Message + " >> " + ex.StackTrace);
                }
            });

            return result.Values.ToList();
        }

        // =====================================================================
        //  BuildAlert — DataRow → eAlerts_ArticleOnline
        // =====================================================================
        internal static eAlerts_ArticleOnline BuildAlert(DataRow dr, int enscdId, string condName)
        {
            var obj = new eAlerts_ArticleOnline
            {
                article_id = GetInt(dr, "article_id"),
                MediaTypeID = GetInt(dr, "MediaTypeID"),
                UserID = GetStr(dr, "UserID"),
                incident_id = GetInt(dr, "incident_id"),
                entity_name = GetStr(dr, "entity_name"),
                title = GetStr(dr, "title"),
                url = GetStr(dr, "url"),
                description = GetStr(dr, "description"),
                date_time = GetStr(dr, "date_time"),
                author = GetStr(dr, "author"),
                sentiment = GetStr(dr, "sentiment"),
                publication = GetStr(dr, "publication"),
                publication_traffic = GetStr(dr, "publication_traffic"),
                lstDeviceID = GetStr(dr, "lstDeviceID"),
                NotificationTypeID = GetStr(dr, "NotificationTypeID"),
                TopicName = GetStr(dr, "TopicName"),
                TopicDescription = GetStr(dr, "TopicDescription"),
                Matched_ENSCDID = enscdId.ToString(),
                Condition_Name = condName,
                ScreenShortImageURL = ""
            };

            if (!dr["date_sort"].Equals(DBNull.Value))
                obj.date_sort = string.Format("{0:d MMM yyyy | H:mm tt}",
                    Convert.ToDateTime(dr["date_sort"]));

            return obj;
        }

        // =====================================================================
        //  ParseJson — builds ParsedFilter from CriteriaJSON
        //  Only is_active == 1 items are processed. Unknown types silently skipped.
        // =====================================================================
        internal static ParsedFilter ParseJson(string json, int userId, int eventId)
        {
            var pf = new ParsedFilter();
            if (string.IsNullOrWhiteSpace(json)) return pf;

            List<CriteriaItem> items;
            try { items = JsonConvert.DeserializeObject<List<CriteriaItem>>(json); }
            catch (Exception ex)
            {
                Log($"ParseJson failed UserID={userId} EventID={eventId}", ex.Message);
                return pf;
            }
            if (items == null) return pf;

            foreach (var item in items.Where(i => i.IsActive == 1))
            {
                string type = (item.ConditionType ?? "").ToLower().Trim();
                string val = item.ConditionValue ?? "";

                switch (type)
                {
                    case "sentiment":
                        pf.Sentiments = CsvSplit(val);
                        break;

                    case "reach":
                        // Format: "min-max"  e.g. "0-10000"
                        int dash = val.IndexOf('-');
                        if (dash > 0)
                        {
                            long mn, mx;
                            if (long.TryParse(val.Substring(0, dash).Trim(), out mn)
                             && long.TryParse(val.Substring(dash + 1).Trim(), out mx))
                            { pf.TrafficMin = mn; pf.TrafficMax = mx; }
                        }
                        break;

                    case "source":
                        var src = CsvSplit(val);
                        // Merge TML domains when is_tml_active = 1
                        // Joined on UserID + EventID only (matches SQL CTE — no ENSCDID)
                        if (item.IsTmlActive == 1)
                            foreach (string d in FetchTmlDomains(userId, eventId))
                                if (!src.Any(s => string.Compare(s, d,
                                        StringComparison.OrdinalIgnoreCase) == 0))
                                    src.Add(d);
                        pf.SourceDomains = src;
                        break;

                    case "keyword":
                        pf.Keywords = CsvSplit(val)
                            .Distinct(StringComparer.OrdinalIgnoreCase).ToList();
                        break;

                    case "datatag":
                        pf.DataTagIds = CsvSplit(val);
                        break;

                    default:
                        // account_type and any future unknown types — silently ignored
                        break;
                }
            }
            return pf;
        }

        // =====================================================================
        //  FetchTmlDomains — joined on UserID + EventID only (no ENSCDID)
        // =====================================================================
        static List<string> FetchTmlDomains(int userId, int eventId)
        {
            var domains = new List<string>();
            var cmd = new SqlCommand();
            try
            {
                var conn = new SqlConnection(ConnE);
                cmd.Connection = conn;
                cmd.Connection.Open();
                cmd.CommandText = @"
                    SELECT DISTINCT Value_Url
                    FROM   TargetedMediaList WITH(NOLOCK)
                    WHERE  UserID     = @U
                      AND  EventID    = @E
                      AND  PlatformID = 1
                      AND  ValueType  = 'Publication'";
                cmd.CommandType = CommandType.Text;
                cmd.CommandTimeout = 30;
                cmd.Parameters.AddWithValue("@U", userId);
                cmd.Parameters.AddWithValue("@E", eventId);

                using (var rd = cmd.ExecuteReader())
                    while (rd.Read())
                        if (!rd.IsDBNull(0) && rd.GetString(0).Trim().Length > 0)
                            domains.Add(rd.GetString(0).Trim());

                if (domains.Count > 0)
                    Log($"TML UserID={userId} EventID={eventId}",
                        $"{domains.Count} pubs: {string.Join(", ", domains)}");
            }
            catch (Exception ex) { Log("FetchTmlDomains", ex.Message); }
            finally { cmd.Connection.Close(); cmd.Connection.Dispose(); }
            return domains;
        }

        // =====================================================================
        //  Match — AND across all condition types; keyword + datatag OR'd together
        // =====================================================================
        internal static bool Match(DataRow row, ParsedFilter pf)
        {
            // SENTIMENT
            if (pf.Sentiments != null && pf.Sentiments.Count > 0)
            {
                string s = GetStr(row, "sentiment");
                if (!pf.Sentiments.Any(x =>
                    string.Compare(x, s, StringComparison.OrdinalIgnoreCase) == 0))
                    return false;
            }

            // REACH
            if (pf.TrafficMin.HasValue && pf.TrafficMax.HasValue)
            {
                long t = row["publication_traffic"].Equals(DBNull.Value)
                    ? 0 : Convert.ToInt64(row["publication_traffic"]);
                if (t < pf.TrafficMin.Value || t > pf.TrafficMax.Value) return false;
            }

            // SOURCE
            if (pf.SourceDomains != null && pf.SourceDomains.Count > 0)
            {
                string pub = GetStr(row, "publication");
                if (!pf.SourceDomains.Any(d => MatchPublication(pub, d))) return false;
            }

            // KEYWORD + DATATAG (OR'd)
            bool hasKw = pf.Keywords != null && pf.Keywords.Count > 0;
            bool hasDt = pf.DataTagIds != null && pf.DataTagIds.Count > 0;

            if (hasKw || hasDt)
            {
                bool kwHit = false, dtHit = false;

                if (hasKw)
                {
                    string title = GetStr(row, "title");
                    string desc = GetStr(row, "Description");
                    kwHit = pf.Keywords.Any(kw =>
                        title.IndexOf(kw, StringComparison.OrdinalIgnoreCase) >= 0 ||
                        desc.IndexOf(kw, StringComparison.OrdinalIgnoreCase) >= 0);
                }

                if (hasDt)
                {
                    string raw = row["datatag_id"].Equals(DBNull.Value)
                        ? "" : row["datatag_id"].ToString();
                    if (!string.IsNullOrEmpty(raw))
                    {
                        var tags = raw.Split(',').Select(x => x.Trim()).ToList();
                        dtHit = pf.DataTagIds.Any(ct =>
                            tags.Any(at => string.Compare(at, ct,
                                StringComparison.OrdinalIgnoreCase) == 0));
                    }
                }

                if (!kwHit && !dtHit) return false;
            }

            return true;
        }

        // =====================================================================
        //  MatchPublication — mirrors SQL Source CTE CASE logic:
        //    economictimes domain → publication LIKE '%economictimes%'
        //    all others          → '.' + publication LIKE '%.domain%'
        // =====================================================================
        internal static bool MatchPublication(string publication, string domain)
        {
            domain = domain.Trim();
            if (domain.IndexOf("economictimes", StringComparison.OrdinalIgnoreCase) >= 0)
                return publication.IndexOf("economictimes", StringComparison.OrdinalIgnoreCase) >= 0;

            return ("." + publication).IndexOf("." + domain,
                StringComparison.OrdinalIgnoreCase) >= 0;
        }

        // =====================================================================
        //  SendNotification_News
        //
        //  FIX: cleanDeviceIds holds the original plain CSV string
        //       (e.g. "id1,id2,id3") and is passed directly to Log_DB.
        //       deviceIdJson is the JSON array ["id1","id2","id3"] used only
        //       in the HTTP POST body. obj.lstDeviceID is never mutated,
        //       so quotes never leak into the DB log.
        // =====================================================================
        public static bool SendNotification_News(eAlerts_ArticleOnline obj)
        {
            bool IsResult = false;
            try
            {
                // ── Device IDs ────────────────────────────────────────────
                // cleanDeviceIds  = "2640CF0E-...,73680b...,AFF6..."  (plain, no quotes)
                // deviceIdJson    = ["2640CF0E-...","73680b...","AFF6..."]  (for HTTP body only)
                //
                // We never touch cleanDeviceIds again — it goes straight to Log_DB.
                // This is the fix for device IDs being stored as "73680b0694be3c5f"
                // (with surrounding quotes) in the notification log table.
                string cleanDeviceIds = obj.lstDeviceID ?? "";
                string deviceIdJson = "[]";

                if (!string.IsNullOrEmpty(cleanDeviceIds))
                {
                    var sb = new StringBuilder("[");
                    var devices = cleanDeviceIds.Split(',');
                    for (int i = 0; i < devices.Length; i++)
                    {
                        sb.Append("\"").Append(devices[i].Trim()).Append("\"");
                        if (i < devices.Length - 1) sb.Append(",");
                    }
                    sb.Append("]");
                    deviceIdJson = sb.ToString();
                }

                // ── Message ───────────────────────────────────────────────
                string message = obj.title ?? "";
                foreach (char c in message.ToCharArray())
                {
                    if (!(c >= 'A' && c <= 'Z') && !(c >= 'a' && c <= 'z')
                        && !char.IsWhiteSpace(c) && !char.IsPunctuation(c) && !char.IsDigit(c))
                    {
                        message = "This content includes non-English characters. Tap here to view more details";
                        break;
                    }
                }
                message = message.Replace("\"", "").Replace("\r\n", "");

                // ── HTTP POST ─────────────────────────────────────────────
                string strPost = "{"
                    + $"\"title\":\"{obj.TopicName}\","
                    + $"\"message\":\"Online - {message}\r\n {obj.Condition_Name}\","
                    + $"\"image\":\"{obj.ScreenShortImageURL}\","
                    + "\"payload\":{"
                        + "\"messageTypeID\":\"CON\","
                        + "\"channelID\":\"ON\","
                        + $"\"incidentID\":\"{obj.incident_id}\","
                        + "\"data\":{"
                            + $"\"primary_key\":\"{obj.article_id}\""
                        + "}"
                    + "},"
                    + $"\"deviceID\":{deviceIdJson}}}";    // ← JSON array, not cleanDeviceIds

                var request = (HttpWebRequest)WebRequest.Create(
                    ConfigurationManager.AppSettings["URL_SendNotification"]);
                byte[] bytes = Encoding.GetEncoding("ISO-8859-1").GetBytes(strPost);
                request.ContentType = "application/json; charset=utf-8";
                request.ContentLength = bytes.Length;
                request.Method = "POST";
                request.Timeout = 900000;
                request.Headers["x-api-key"] = ConfigurationManager.AppSettings["x-api-key"];

                using (var stream = request.GetRequestStream())
                    stream.Write(bytes, 0, bytes.Length);

                using (var resp = request.GetResponse())
                using (var sr = new StreamReader(resp.GetResponseStream()))
                {
                    string strOutput = sr.ReadToEnd().Trim();
                    Log(strOutput, "");
                    IsResult = true;

                    Log("Log_DB Start", "");
                    Log_DB(obj.article_id, obj.incident_id, obj.UserID,
                           obj.ScreenShortImageURL,
                           cleanDeviceIds,          // ← plain CSV, no quotes, no brackets
                           strPost, strOutput, obj.Matched_ENSCDID, obj.Condition_Name);
                    Log("Log_DB End", "");
                }
            }
            catch (Exception ex)
            {
                Log("SendNotification_News",
                    $"{obj.article_id}|{obj.incident_id} -> {ex.Message} >> {ex.StackTrace}");
            }
            return IsResult;
        }

        // =====================================================================
        //  Log_DB — MediaTypeID = 1 (Online)
        //
        //  DeviceID arrives as plain CSV: "id1,id2,id3"
        //  No Replace("\"","") needed here anymore — cleanDeviceIds has no quotes.
        //  The .Replace("\"","") is kept as a safety guard only.
        // =====================================================================
        static void Log_DB(int AOSID, int TopicID, string UserID, string ImageURL,
            string DeviceID, string Request, string Response,
            string Matched_ENSCDID, string Condition_Name)
        {
            var cmd = new SqlCommand();
            try
            {
                string notSentIds = "", errorCode = "", errorMsg = "", messageId = "";

                if (!string.IsNullOrEmpty(Response))
                {
                    var json = JObject.Parse(Response);
                    notSentIds = Convert.ToString(json["NotSend"] ?? "");
                    if (string.IsNullOrEmpty(notSentIds))
                    {
                        errorCode = Convert.ToString(json["Code"] ?? "");
                        errorMsg = Convert.ToString(json["Message"] ?? "");
                    }
                    string id = json["data"]?["id"]?.ToString();
                    if (!string.IsNullOrEmpty(id)) messageId = id;
                }

                string[] failedDeviceIds = string.IsNullOrEmpty(notSentIds)
                    ? null : notSentIds.Split(',');

                // Build per-device log entries
                // DeviceID is plain CSV — split directly, no quote-stripping needed
                var logDetails = new List<eLog>();
                if (!string.IsNullOrEmpty(UserID) && !string.IsNullOrEmpty(DeviceID))
                {
                    string[] userIds = UserID.Split(',');
                    string[] deviceIds = DeviceID.Replace("\"", "").Split(',');  // safety guard

                    for (int i = 0; i < deviceIds.Length; i++)
                    {
                        string devId = deviceIds[i].Trim();
                        var entry = new eLog
                        {
                            UserID = i < userIds.Length ? userIds[i].Trim() : "",
                            DeviceID = devId
                        };

                        if (!string.IsNullOrEmpty(errorCode))
                        {
                            entry.Status = "Failed";
                            entry.ErrorCode = errorCode;
                            entry.ErrorMessage = errorMsg;
                        }
                        else if (failedDeviceIds != null &&
                                 failedDeviceIds.Any(d => d.Trim() == devId))
                        {
                            entry.Status = "Failed";
                        }
                        else
                        {
                            entry.Status = "Success";
                        }

                        logDetails.Add(entry);
                    }
                }

                // Insert log header
                var conn = new SqlConnection(ConnC2);
                cmd.Connection = conn;
                cmd.Connection.Open();
                cmd.CommandText = "USP_Service_Insert_SentryV2_Notification_Log_Conditional";
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@RecordID", AOSID);
                cmd.Parameters.AddWithValue("@TopicID", TopicID);
                cmd.Parameters.AddWithValue("@MediaTypeID", 1);
                cmd.Parameters.AddWithValue("@ImageURL", ImageURL);
                cmd.Parameters.AddWithValue("@lstDeviceID", DeviceID);
                cmd.Parameters.AddWithValue("@Request", Request);
                cmd.Parameters.AddWithValue("@Response", Response);
                cmd.Parameters.AddWithValue("@Message_ID", messageId);

                var ds = new DataSet();
                new SqlDataAdapter(cmd).Fill(ds);

                int NLID = 0;
                if (ds.Tables.Count > 0)
                    foreach (DataRow dr in ds.Tables[0].Rows)
                        if (!dr["NLID"].Equals(DBNull.Value))
                            NLID = Convert.ToInt32(dr["NLID"]);

                Log("NLID", NLID.ToString());
                cmd.Connection.Close();

                // Insert per-device log detail rows
                if (NLID > 0)
                {
                    foreach (var entry in logDetails)
                    {
                        var cmd2 = new SqlCommand();
                        cmd2.Connection = conn;
                        cmd2.Connection.Open();
                        cmd2.CommandText = "USP_Service_Insert_SentryV2_Notification_Log_Conditional_Detail_NewLogic";
                        cmd2.CommandType = CommandType.StoredProcedure;
                        cmd2.Parameters.AddWithValue("@NLID", NLID);
                        cmd2.Parameters.AddWithValue("@RecordID", AOSID);
                        cmd2.Parameters.AddWithValue("@TopicID", TopicID);
                        cmd2.Parameters.AddWithValue("@MediaTypeID", 1);
                        cmd2.Parameters.AddWithValue("@UserID", entry.UserID);
                        cmd2.Parameters.AddWithValue("@DeviceID", entry.DeviceID);
                        cmd2.Parameters.AddWithValue("@Status", entry.Status);
                        cmd2.Parameters.AddWithValue("@Matched_ENSCDID", Matched_ENSCDID);
                        cmd2.Parameters.AddWithValue("@Condition_Name", Condition_Name);
                        cmd2.ExecuteNonQuery();
                        cmd2.Connection.Close();
                    }
                }
            }
            catch (Exception ex) { Log("Log_DB", ex.Message + " >> " + ex.StackTrace); }
        }

        // =====================================================================
        //  UpdateAlert_News
        // =====================================================================
        public static bool UpdateAlert_News(int ArticleID, int MediaTypeID)
        {
            bool IsResult = false;
            var cmd = new SqlCommand();
            try
            {
                var conn = new SqlConnection(ConnD);
                cmd.Connection = conn;
                cmd.Connection.Open();
                cmd.CommandText = "USP_Service_UpdateAlerts_Article";
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@ArticleID", ArticleID);
                cmd.Parameters.AddWithValue("@MediaTypeID", MediaTypeID);
                if (Convert.ToInt32(cmd.ExecuteNonQuery()) > 0) IsResult = true;
            }
            catch (Exception ex) { Log("UpdateAlert_News", ex.Message); }
            finally { cmd.Connection.Close(); cmd.Connection.Dispose(); }
            return IsResult;
        }

        // =====================================================================
        //  HELPERS
        // =====================================================================
        internal static List<string> CsvSplit(string val) =>
            val.Split(',').Select(s => s.Trim()).Where(s => s.Length > 0).ToList();

        internal static string GetStr(DataRow dr, string col)
        {
            try { return dr[col].Equals(DBNull.Value) ? "" : Convert.ToString(dr[col]); }
            catch { return ""; }
        }

        internal static int GetInt(DataRow dr, string col)
        {
            try { return dr[col].Equals(DBNull.Value) ? 0 : Convert.ToInt32(dr[col]); }
            catch { return 0; }
        }

        // =====================================================================
        //  LOGGING
        // =====================================================================
        static void ErrorLog(string functionName, string error)
        {
            try
            {
                string path = ConfigurationManager.AppSettings["ErrorLogPath"];
                using (var w = File.AppendText(path))
                {
                    TextWriter.Synchronized(w).WriteLine("<-->");
                    TextWriter.Synchronized(w).WriteLine($"Function: {functionName}");
                    TextWriter.Synchronized(w).WriteLine($"Error: {error}");
                    TextWriter.Synchronized(w).WriteLine($"Date: {DateTime.Now}");
                    TextWriter.Synchronized(w).Flush();
                }
            }
            catch { }
        }

        static void TimeLog(string text)
        {
            try
            {
                string path = ConfigurationManager.AppSettings["TimeLogPath"];
                using (var w = File.AppendText(path))
                {
                    TextWriter.Synchronized(w).WriteLine("<-->");
                    TextWriter.Synchronized(w).WriteLine($"TimeLog: {text}");
                    TextWriter.Synchronized(w).WriteLine($"Date: {DateTime.Now}");
                    TextWriter.Synchronized(w).Flush();
                }
            }
            catch (Exception ex) { ErrorLog("TimeLog", ex.ToString()); }
        }

        static void Log(string functionName, string detail)
        {
            try
            {
                string path = ConfigurationManager.AppSettings["LogPath"];
                using (var w = File.AppendText(path))
                {
                    TextWriter.Synchronized(w).WriteLine("<-->");
                    TextWriter.Synchronized(w).WriteLine($"Function: {functionName}");
                    if (!string.IsNullOrEmpty(detail))
                        TextWriter.Synchronized(w).WriteLine($"Detail: {detail}");
                    TextWriter.Synchronized(w).WriteLine($"Date: {DateTime.Now}");
                    TextWriter.Synchronized(w).Flush();
                }
            }
            catch { }
        }
    }
}