﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Configuration;
using System.IO;
using System.Net;

namespace OneSignal_NotificationDetail
{
    internal class Program
    {

        public static string ConnectionString_C2 = ConfigurationManager.ConnectionStrings["ConnectionString_SahadevC2"]?.ConnectionString;
        static void Main(string[] args)
        {
            try
            {
                DataSet ds = new DataSet();

                ds = Fetch_PendingMessageIDs();

                if (ds != null)
                {
                    if (ds.Tables.Count > 0)
                    {
                        if (ds.Tables[0]!=null && ds.Tables[0].Rows.Count>0)
                        {
                            for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
                            {
                                string Message_ID = Convert.ToString(ds.Tables[0].Rows[i]["Message_ID"]);
                                Int32 NLID = Convert.ToInt32(Convert.ToString(ds.Tables[0].Rows[i]["NLID"]));
                                string Table_Name = "RealTime";

                                Fetch_Details(Message_ID, NLID, Table_Name);
                            }
                        }

                        if (ds.Tables[1] != null && ds.Tables[1].Rows.Count > 0)
                        {
                            for (int i = 0; i < ds.Tables[1].Rows.Count; i++)
                            {
                                string Message_ID = Convert.ToString(ds.Tables[1].Rows[i]["Message_ID"]);
                                Int32 NLID = Convert.ToInt32(Convert.ToString(ds.Tables[1].Rows[i]["NLID"]));
                                string Table_Name = "Conditional";

                                Fetch_Details(Message_ID, NLID, Table_Name);
                            }
                        }

                        if (ds.Tables[2] != null && ds.Tables[2].Rows.Count > 0)
                        {
                            for (int i = 0; i < ds.Tables[2].Rows.Count; i++)
                            {
                                string Message_ID = Convert.ToString(ds.Tables[2].Rows[i]["Message_ID"]);
                                Int32 NLID = Convert.ToInt32(Convert.ToString(ds.Tables[2].Rows[i]["NLID"]));
                                string Table_Name = "SUM";

                                Fetch_Details(Message_ID, NLID, Table_Name);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {

                Log("Main", ex.Message + " ->> " + ex.StackTrace);
            }
        }
        public static DataSet Fetch_PendingMessageIDs()
        {
            DataSet ds = new DataSet();
            using (SqlConnection conn = new SqlConnection(ConnectionString_C2))
            {
                using (SqlCommand cmd = new SqlCommand("USP_Fetch_OneSignal_PendingMessageIDs", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;

                    using (SqlDataAdapter da = new SqlDataAdapter(cmd))
                    {
                        da.Fill(ds);
                    }
                }
            }
            return ds;
        }
        private static void Log(string functionName, string error)
        {
            try
            {
                string LogPath = ConfigurationManager.AppSettings["LogPath"].ToString();
                using (TextWriter myWriter = File.AppendText(LogPath))
                {

                    TextWriter.Synchronized(myWriter).WriteLine("<--> :{0}", string.Empty);
                    TextWriter.Synchronized(myWriter).WriteLine("Function Name :{0}", functionName);
                    if (!String.IsNullOrEmpty(error))
                    {
                        TextWriter.Synchronized(myWriter).WriteLine("Error :{0}", error);
                    }
                    TextWriter.Synchronized(myWriter).WriteLine("Date :{0}", DateTime.Now.ToString());
                    TextWriter.Synchronized(myWriter).WriteLine("<--> :{0}", string.Empty);
                    TextWriter.Synchronized(myWriter).Flush();
                    TextWriter.Synchronized(myWriter).Close();
                }

            }
            catch (Exception ex)
            {
            }
        }
        public static bool Fetch_Details(string Message_ID, Int32 NLID, string Table_Name)
        {
            bool IsResult = false;
            try
            {
                ServicePointManager.SecurityProtocol = (SecurityProtocolType)3072;

                string URL = ConfigurationManager.AppSettings["URL_Fetch_Details"];
                URL = URL.Replace("#Message_ID#", Message_ID);

                HttpWebRequest request = (HttpWebRequest)WebRequest.Create(URL);
                request.Method = "GET";
                request.Timeout = 900000; // 15 minutes
                request.Accept = "application/json";
                request.Headers["Authorization"] = Convert.ToString(ConfigurationManager.AppSettings["Authorization"]);

                //Get response from Request
                using (System.Net.WebResponse resp = request.GetResponse())
                {
                    using (StreamReader sr = new StreamReader(resp.GetResponseStream()))
                    {
                        string strOutput = sr.ReadToEnd().Trim();
                        //Log(strOutput, "");
                        Update_Detail_Json(Message_ID, NLID, Table_Name, strOutput);
                        IsResult = true;
                    }
                }
            }
            catch (Exception ex)
            {
                Log("Fetch_Details", Table_Name + "|" + Message_ID + "|" + NLID + "->" + ex.Message + " ->> " + ex.StackTrace);
            }

            return IsResult;
        }
        public static void Update_Detail_Json(string Message_ID, Int32 NLID, string Table_Name,string OneSignal_DetailJson)
        {
            using (SqlConnection conn = new SqlConnection(ConnectionString_C2))
            {
                using (SqlCommand cmd = new SqlCommand("USP_Update_OneSignal_NotificationDetail_Json", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@NLID", NLID);
                    cmd.Parameters.AddWithValue("@Message_ID", Message_ID);
                    cmd.Parameters.AddWithValue("@Table_Name", Table_Name);
                    cmd.Parameters.AddWithValue("@OneSignal_DetailJson", OneSignal_DetailJson);
                    

                    conn.Open();
                    cmd.ExecuteNonQuery();
                }
            }
        }
    }
}
