﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace NotificationSender_Sentry2._0_AO
{
    
    [DataContract]
    public class eAlerts_ArticleOnline
    {
        [DataMember]
        public Int32 article_id { get; set; }

        [DataMember]
        public Int32 MediaTypeID { get; set; }

        [DataMember]
        public string UserID { get; set; }

        [DataMember]
        public string entity_name { get; set; }

        [DataMember]
        public Int32 incident_id { get; set; }

        [DataMember]
        public string title { get; set; }

        [DataMember]
        public string url { get; set; }

        [DataMember]
        public string description { get; set; }

        [DataMember]
        public string date_time { get; set; }

        [DataMember]
        public string author { get; set; }

        [DataMember]
        public string sentiment { get; set; }

        [DataMember]
        public string publication { get; set; }

        [DataMember]
        public string publication_icon { get; set; }

        [DataMember]
        public string publication_type { get; set; }

        [DataMember]
        public string publication_category { get; set; }

        [DataMember]
        public string publication_da { get; set; }

        [DataMember]
        public string publication_traffic { get; set; }

        [DataMember]
        public string pi_score { get; set; }

        [DataMember]
        public string date_sort { get; set; }

        [DataMember]
        public string da_sort { get; set; }

        [DataMember]
        public string traffic_sort { get; set; }

        [DataMember]
        public string mention_type { get; set; }

        [DataMember]
        public string lstDeviceID { get; set; }

        [DataMember]
        public string NotificationTypeID { get; set; }

        [DataMember]
        public string TopicName { get; set; }

        [DataMember]
        public string TopicDescription { get; set; }

        [DataMember]
        public string ScreenShortImageURL { get; set; }
    }
}
