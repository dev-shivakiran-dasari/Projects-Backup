﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace NotificationSender_Sentry2._0
{

    [Serializable]
    [DataContract]
    public class eAlerts_Twitter
    {
        [DataMember]
        public Int32 twitter_id { get; set; }

        [DataMember]
        public Int32 MediaTypeID { get; set; }

        [DataMember]
        public Int32 incident_id { get; set; }

        [DataMember]
        public string UserID { get; set; }

        [DataMember]
        public string entity_name { get; set; }

        [DataMember]
        public string url { get; set; }

        [DataMember]
        public string description { get; set; }

        [DataMember]
        public string date_time { get; set; }

        [DataMember]
        public string sentiment { get; set; }
        
        [DataMember]
        public string profile_handle { get; set; }

        [DataMember]
        public string profile_name { get; set; }        

        [DataMember]
        public string profile_followerscount { get; set; }

        [DataMember]
        public string profile_followingcount { get; set; }

        [DataMember]
        public string profile_tweetscount { get; set; }

        [DataMember]
        public string profile_listscount { get; set; }

        [DataMember]
        public string profile_isprotected { get; set; }
        
        [DataMember]
        public string profile_isverified { get; set; }

        [DataMember]
        public string profile_verifiedtype { get; set; }

        [DataMember]
        public string profile_category { get; set; }

        [DataMember]
        public string profile_profilepicurl { get; set; }

        [DataMember]
        public string engagement_retweetcount { get; set; }

        [DataMember]
        public string engagement_replycount { get; set; }

        [DataMember]
        public string engagement_likecount { get; set; }

        [DataMember]
        public string engagement_quotecount { get; set; }

        [DataMember]
        public string engagement_bookmarkcount { get; set; }

        [DataMember]
        public string engagement_viewcount { get; set; }

        [DataMember]
        public string tonality { get; set; }

        [DataMember]
        public string date_sort { get; set; }

        [DataMember]
        public string reach_sort { get; set; }

        [DataMember]
        public string engagement_sort { get; set; }

        [DataMember]
        public string views_sort { get; set; }

        [DataMember]
        public string lstDeviceID { get; set; }

        [DataMember]
        public string NotificationTypeID { get; set; }

        [DataMember]
        public string TopicName { get; set; }

        [DataMember]
        public string TopicDescription { get; set; }

        [DataMember]
        public string ScreenShortImageURL { get; set; }
    }
}
