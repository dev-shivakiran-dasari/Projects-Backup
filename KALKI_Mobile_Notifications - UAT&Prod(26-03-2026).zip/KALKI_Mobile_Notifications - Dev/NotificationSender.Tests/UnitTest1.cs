﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using NUnit.Framework;
using Newtonsoft.Json;

// Aliases MUST be at the top, outside the namespace
using AO = NotificationSender_Sentry2_Conditional_AO;
using AP = NotificationSender_Sentry2_Conditional_AP;
using TWT = NotificationSender_Sentry2_Conditional_TWT;
using YT = NotificationSender_Sentry2_Conditional_YT;

namespace NotificationSender.Tests
{
    // =========================================================================
    //  SHARED — CriteriaBuilder
    // =========================================================================
    internal static class CriteriaBuilder
    {
        public static string Single(string type, string value, int active = 1)
        {
            return JsonConvert.SerializeObject(new[]
            {
                new {
                    condition_type  = type,
                    condition_value = value,
                    is_active       = active,
                    is_tml_active   = (int?)null
                }
            });
        }
    }

    // =========================================================================
    //  SHARED — Conditions table
    // =========================================================================
    internal static class SharedMock
    {
        public static DataTable BuildConditionsTable()
        {
            var dt = new DataTable();
            dt.Columns.Add("UserID", typeof(string));
            dt.Columns.Add("EventID", typeof(int));
            dt.Columns.Add("ENSCDID", typeof(int));
            dt.Columns.Add("ConditionName", typeof(string));
            dt.Columns.Add("CriteriaJSON", typeof(string));
            return dt;
        }

        public static void AddCondition(DataTable dt,
            int userId, int eventId, int enscdId,
            string conditionName, string criteriaJson)
        {
            dt.Rows.Add(userId.ToString(), eventId, enscdId, conditionName, criteriaJson);
        }
    }

    // =========================================================================
    //  ONLINE (AO) — MockData
    // =========================================================================
    internal static class OnlineMockData
    {
        public static DataTable BuildArticlesTable()
        {
            var dt = new DataTable();
            dt.Columns.Add("article_id", typeof(int));
            dt.Columns.Add("MediaTypeID", typeof(int));
            dt.Columns.Add("UserID", typeof(string));
            dt.Columns.Add("incident_id", typeof(int));
            dt.Columns.Add("entity_name", typeof(string));
            dt.Columns.Add("title", typeof(string));
            dt.Columns.Add("url", typeof(string));
            dt.Columns.Add("description", typeof(string));
            dt.Columns.Add("Description", typeof(string));
            dt.Columns.Add("date_time", typeof(string));
            dt.Columns.Add("author", typeof(string));
            dt.Columns.Add("sentiment", typeof(string));
            dt.Columns.Add("publication", typeof(string));
            dt.Columns.Add("publication_traffic", typeof(long));
            dt.Columns.Add("lstDeviceID", typeof(string));
            dt.Columns.Add("NotificationTypeID", typeof(string));
            dt.Columns.Add("TopicName", typeof(string));
            dt.Columns.Add("TopicDescription", typeof(string));
            dt.Columns.Add("datatag_id", typeof(string));
            dt.Columns.Add("date_sort", typeof(DateTime));
            return dt;
        }

        public static void AddArticle(DataTable dt,
            int articleId, int userId, int incidentId,
            string title = "Online Test Title", string description = "Online Test Description",
            string sentiment = "Positive", string publication = "ndtv.com",
            long traffic = 5000, string deviceId = "DEVICE001", string datatagId = "")
        {
            dt.Rows.Add(
                articleId, 1, userId.ToString(), incidentId,
                "EntityName", title, "http://example.com",
                description, description,
                DateTime.Now.ToString(), "Author",
                sentiment, publication, traffic,
                deviceId, "CON", "TopicName", "TopicDesc",
                datatagId, DateTime.Now);
        }
    }

    // =========================================================================
    //  PRINT (AP) — MockData
    // =========================================================================
    internal static class PrintMockData
    {
        public static DataTable BuildArticlesTable()
        {
            var dt = new DataTable();
            dt.Columns.Add("article_id", typeof(int));
            dt.Columns.Add("MediaTypeID", typeof(int));
            dt.Columns.Add("UserID", typeof(string));
            dt.Columns.Add("incident_id", typeof(int));
            dt.Columns.Add("entity_name", typeof(string));
            dt.Columns.Add("title", typeof(string));
            dt.Columns.Add("url", typeof(string));
            dt.Columns.Add("description", typeof(string));
            dt.Columns.Add("Description", typeof(string));
            dt.Columns.Add("date_time", typeof(string));
            dt.Columns.Add("author", typeof(string));
            dt.Columns.Add("page_no", typeof(string));
            dt.Columns.Add("edition", typeof(string));
            dt.Columns.Add("sentiment", typeof(string));
            dt.Columns.Add("publication", typeof(string));
            dt.Columns.Add("publication_name", typeof(string));
            dt.Columns.Add("publication_icon", typeof(string));
            dt.Columns.Add("publication_type", typeof(string));
            dt.Columns.Add("publication_category", typeof(string));
            dt.Columns.Add("publication_circulation", typeof(long));
            dt.Columns.Add("pi_score", typeof(string));
            dt.Columns.Add("circulation_sort", typeof(string));
            dt.Columns.Add("ave_sort", typeof(string));
            dt.Columns.Add("mention_type", typeof(string));
            dt.Columns.Add("lstDeviceID", typeof(string));
            dt.Columns.Add("NotificationTypeID", typeof(string));
            dt.Columns.Add("TopicName", typeof(string));
            dt.Columns.Add("TopicDescription", typeof(string));
            dt.Columns.Add("datatag_id", typeof(string));
            dt.Columns.Add("date_sort", typeof(DateTime));
            return dt;
        }

        public static void AddArticle(DataTable dt,
            int articleId, int userId, int incidentId,
            string title = "Print Test Title", string description = "Print Test Description",
            string sentiment = "Positive", string publication = "hindustan times",
            long circulation = 50000, string deviceId = "DEVICE001", string datatagId = "")
        {
            dt.Rows.Add(
                articleId, 2, userId.ToString(), incidentId,
                "EntityName", title, "http://example.com",
                description, description,
                DateTime.Now.ToString(), "Author",
                "1", "Delhi",
                sentiment, publication, publication,
                "", "Newspaper", "National",
                circulation, "80", "50000", "10000", "Direct",
                deviceId, "CON", "TopicName", "TopicDesc",
                datatagId, DateTime.Now);
        }
    }

    // =========================================================================
    //  TWITTER (TWT) — MockData
    // =========================================================================
    internal static class TwitterMockData
    {
        public static DataTable BuildArticlesTable()
        {
            var dt = new DataTable();
            dt.Columns.Add("twitter_id", typeof(int));
            dt.Columns.Add("MediaTypeID", typeof(int));
            dt.Columns.Add("UserID", typeof(string));
            dt.Columns.Add("incident_id", typeof(int));
            dt.Columns.Add("entity_name", typeof(string));
            dt.Columns.Add("url", typeof(string));
            dt.Columns.Add("description", typeof(string));
            dt.Columns.Add("Description", typeof(string));
            dt.Columns.Add("date_time", typeof(string));
            dt.Columns.Add("sentiment", typeof(string));
            dt.Columns.Add("profile_handle", typeof(string));
            dt.Columns.Add("profile_name", typeof(string));
            dt.Columns.Add("profile_followerscount", typeof(long));
            dt.Columns.Add("profile_followingcount", typeof(string));
            dt.Columns.Add("profile_tweetscount", typeof(string));
            dt.Columns.Add("profile_listscount", typeof(string));
            dt.Columns.Add("profile_isprotected", typeof(string));
            dt.Columns.Add("profile_isverified", typeof(string));
            dt.Columns.Add("profile_verifiedtype", typeof(string));
            dt.Columns.Add("profile_category", typeof(string));
            dt.Columns.Add("profile_profilepicurl", typeof(string));
            dt.Columns.Add("engagement_retweetcount", typeof(string));
            dt.Columns.Add("engagement_replycount", typeof(string));
            dt.Columns.Add("engagement_likecount", typeof(string));
            dt.Columns.Add("engagement_quotecount", typeof(string));
            dt.Columns.Add("engagement_bookmarkcount", typeof(string));
            dt.Columns.Add("engagement_viewcount", typeof(string));
            dt.Columns.Add("tonality", typeof(string));
            dt.Columns.Add("reach_sort", typeof(string));
            dt.Columns.Add("engagement_sort", typeof(string));
            dt.Columns.Add("views_sort", typeof(string));
            dt.Columns.Add("lstDeviceID", typeof(string));
            dt.Columns.Add("NotificationTypeID", typeof(string));
            dt.Columns.Add("TopicName", typeof(string));
            dt.Columns.Add("TopicDescription", typeof(string));
            dt.Columns.Add("datatag_id", typeof(string));
            dt.Columns.Add("date_sort", typeof(DateTime));
            return dt;
        }

        public static void AddArticle(DataTable dt,
            int twitterId, int userId, int incidentId,
            string description = "Test tweet content", string sentiment = "Positive",
            string handle = "ndtvnews", long followers = 50000,
            string isVerified = "true", string deviceId = "DEVICE001", string datatagId = "")
        {
            dt.Rows.Add(
                twitterId, 3, userId.ToString(), incidentId,
                "EntityName", "http://twitter.com/test",
                description, description,
                DateTime.Now.ToString(), sentiment,
                handle, "NDTV News",
                followers, "500", "10000", "50",
                "false", isVerified, "blue", "News", "",
                "100", "20", "500", "10", "5", "10000",
                "Positive", "50000", "635", "10000",
                deviceId, "CON", "TopicName", "TopicDesc",
                datatagId, DateTime.Now);
        }
    }

    // =========================================================================
    //  YOUTUBE (YT) — MockData
    // =========================================================================
    internal static class YouTubeMockData
    {
        public static DataTable BuildArticlesTable()
        {
            var dt = new DataTable();
            dt.Columns.Add("video_id", typeof(int));
            dt.Columns.Add("MediaTypeID", typeof(int));
            dt.Columns.Add("UserID", typeof(string));
            dt.Columns.Add("incident_id", typeof(int));
            dt.Columns.Add("entity_name", typeof(string));
            dt.Columns.Add("title", typeof(string));
            dt.Columns.Add("url", typeof(string));
            dt.Columns.Add("description", typeof(string));
            dt.Columns.Add("Description", typeof(string));
            dt.Columns.Add("date_time", typeof(string));
            dt.Columns.Add("author", typeof(string));
            dt.Columns.Add("sentiment", typeof(string));
            dt.Columns.Add("channel_subscriber_count", typeof(long));
            dt.Columns.Add("lstDeviceID", typeof(string));
            dt.Columns.Add("NotificationTypeID", typeof(string));
            dt.Columns.Add("TopicName", typeof(string));
            dt.Columns.Add("TopicDescription", typeof(string));
            dt.Columns.Add("datatag_id", typeof(string));
            dt.Columns.Add("date_sort", typeof(DateTime));
            return dt;
        }

        public static void AddArticle(DataTable dt,
            int videoId, int userId, int incidentId,
            string title = "YouTube Test Video", string description = "Test video description",
            string sentiment = "Positive", string author = "NDTVChannel",
            long subscribers = 1000000, string deviceId = "DEVICE001", string datatagId = "")
        {
            dt.Rows.Add(
                videoId, 4, userId.ToString(), incidentId,
                "EntityName", title, "http://youtube.com/test",
                description, description,
                DateTime.Now.ToString(), author,
                sentiment, subscribers,
                deviceId, "CON", "TopicName", "TopicDesc",
                datatagId, DateTime.Now);
        }
    }

    // =========================================================================
    //  ONLINE (AO) — ParseJson Tests
    // =========================================================================
    [TestFixture]
    public class Online_ParseJsonTests
    {
        [Test]
        public void Sentiment_ParsedCorrectly()
        {
            var pf = AO.Program.ParseJson(CriteriaBuilder.Single("sentiment", "Positive,Negative"), 1, 100);
            Assert.IsTrue(pf.Sentiments.Contains("Positive"));
            Assert.IsTrue(pf.Sentiments.Contains("Negative"));
        }
        [Test]
        public void Reach_ParsedCorrectly()
        {
            var pf = AO.Program.ParseJson(CriteriaBuilder.Single("reach", "1000-50000"), 1, 100);
            Assert.AreEqual(1000L, pf.TrafficMin);
            Assert.AreEqual(50000L, pf.TrafficMax);
        }
        [Test]
        public void Source_ParsedCorrectly()
        {
            var pf = AO.Program.ParseJson(CriteriaBuilder.Single("source", "ndtv.com,bbc.com"), 1, 100);
            Assert.IsTrue(pf.SourceDomains.Contains("ndtv.com"));
            Assert.IsTrue(pf.SourceDomains.Contains("bbc.com"));
        }
        [Test]
        public void Keyword_ParsedCorrectly()
        {
            var pf = AO.Program.ParseJson(CriteriaBuilder.Single("keyword", "Mahindra,Thar"), 1, 100);
            Assert.IsTrue(pf.Keywords.Contains("Mahindra"));
        }
        [Test]
        public void DataTag_ParsedCorrectly()
        {
            var pf = AO.Program.ParseJson(CriteriaBuilder.Single("datatag", "5,12"), 1, 100);
            Assert.IsTrue(pf.DataTagIds.Contains("5"));
            Assert.IsTrue(pf.DataTagIds.Contains("12"));
        }
        [Test]
        public void InactiveCondition_Skipped()
        {
            var pf = AO.Program.ParseJson(CriteriaBuilder.Single("sentiment", "Positive", active: 0), 1, 100);
            Assert.IsTrue(pf.Sentiments == null || pf.Sentiments.Count == 0);
        }
        [Test]
        public void EmptyJson_ReturnsEmptyFilter()
        {
            Assert.IsFalse(AO.Program.ParseJson("", 1, 100).HasAny());
        }
        [Test]
        public void MalformedJson_ReturnsEmptyFilter()
        {
            Assert.IsFalse(AO.Program.ParseJson("NOT{{VALID", 1, 100).HasAny());
        }
    }

    // =========================================================================
    //  ONLINE (AO) — Match Tests
    // =========================================================================
    [TestFixture]
    public class Online_MatchTests
    {
        private DataTable _dt;
        [SetUp] public void SetUp() { _dt = OnlineMockData.BuildArticlesTable(); }

        private DataRow MakeRow(string sentiment = "Positive", long traffic = 5000,
            string pub = "ndtv.com", string title = "Mahindra Thar",
            string desc = "MRO launch", string datatag = "5")
        {
            _dt.Rows.Clear();
            OnlineMockData.AddArticle(_dt, 1, 10, 100,
                title: title, description: desc, sentiment: sentiment,
                publication: pub, traffic: traffic, datatagId: datatag);
            return _dt.Rows[0];
        }

        private AO.ParsedFilter PF() { return new AO.ParsedFilter(); }

        [Test]
        public void Sentiment_Match()
        {
            var pf = PF(); pf.Sentiments = new List<string> { "Positive" };
            Assert.IsTrue(AO.Program.Match(MakeRow(sentiment: "Positive"), pf));
        }
        [Test]
        public void Sentiment_NoMatch()
        {
            var pf = PF(); pf.Sentiments = new List<string> { "Positive" };
            Assert.IsFalse(AO.Program.Match(MakeRow(sentiment: "Negative"), pf));
        }
        [Test]
        public void Traffic_WithinRange()
        {
            var pf = PF(); pf.TrafficMin = 1000; pf.TrafficMax = 10000;
            Assert.IsTrue(AO.Program.Match(MakeRow(traffic: 5000), pf));
        }
        [Test]
        public void Traffic_BelowMin()
        {
            var pf = PF(); pf.TrafficMin = 1000; pf.TrafficMax = 10000;
            Assert.IsFalse(AO.Program.Match(MakeRow(traffic: 500), pf));
        }
        [Test]
        public void Traffic_AboveMax()
        {
            var pf = PF(); pf.TrafficMin = 1000; pf.TrafficMax = 10000;
            Assert.IsFalse(AO.Program.Match(MakeRow(traffic: 99999), pf));
        }
        [Test]
        public void Source_Match()
        {
            var pf = PF(); pf.SourceDomains = new List<string> { "ndtv.com" };
            Assert.IsTrue(AO.Program.Match(MakeRow(pub: "ndtv.com"), pf));
        }
        [Test]
        public void Source_NoMatch()
        {
            var pf = PF(); pf.SourceDomains = new List<string> { "ndtv.com" };
            Assert.IsFalse(AO.Program.Match(MakeRow(pub: "bbc.com"), pf));
        }
        [Test]
        public void Keyword_FoundInTitle()
        {
            var pf = PF(); pf.Keywords = new List<string> { "Thar" };
            Assert.IsTrue(AO.Program.Match(MakeRow(title: "Mahindra Thar launch"), pf));
        }
        [Test]
        public void Keyword_FoundInDescription()
        {
            var pf = PF(); pf.Keywords = new List<string> { "MRO" };
            Assert.IsTrue(AO.Program.Match(MakeRow(desc: "MRO division active"), pf));
        }
        [Test]
        public void Keyword_CaseInsensitive()
        {
            var pf = PF(); pf.Keywords = new List<string> { "MAHINDRA" };
            Assert.IsTrue(AO.Program.Match(MakeRow(title: "mahindra thar"), pf));
        }
        [Test]
        public void Keyword_NotFound()
        {
            var pf = PF(); pf.Keywords = new List<string> { "Thar" };
            Assert.IsFalse(AO.Program.Match(MakeRow(title: "Stock rally"), pf));
        }
        [Test]
        public void DataTag_Match()
        {
            var pf = PF(); pf.DataTagIds = new List<string> { "5" };
            Assert.IsTrue(AO.Program.Match(MakeRow(datatag: "5,12"), pf));
        }
        [Test]
        public void DataTag_NoMatch()
        {
            var pf = PF(); pf.DataTagIds = new List<string> { "99" };
            Assert.IsFalse(AO.Program.Match(MakeRow(datatag: "5,12"), pf));
        }
        [Test]
        public void KeywordMiss_DataTagHits()
        {
            var pf = PF();
            pf.Keywords = new List<string> { "Thar" };
            pf.DataTagIds = new List<string> { "5" };
            Assert.IsTrue(AO.Program.Match(MakeRow(title: "Unrelated", datatag: "5"), pf));
        }
        [Test]
        public void AllConditions_Pass()
        {
            var pf = PF();
            pf.Sentiments = new List<string> { "Positive" };
            pf.TrafficMin = 1000; pf.TrafficMax = 10000;
            pf.SourceDomains = new List<string> { "ndtv.com" };
            pf.Keywords = new List<string> { "Thar" };
            Assert.IsTrue(AO.Program.Match(
                MakeRow(sentiment: "Positive", traffic: 5000, pub: "ndtv.com", title: "Thar launch"), pf));
        }
        [Test]
        public void AllConditions_OneFails()
        {
            var pf = PF();
            pf.Sentiments = new List<string> { "Positive" };
            pf.TrafficMin = 1000; pf.TrafficMax = 10000;
            pf.SourceDomains = new List<string> { "ndtv.com" };
            pf.Keywords = new List<string> { "Thar" };
            Assert.IsFalse(AO.Program.Match(
                MakeRow(sentiment: "Negative", traffic: 5000, pub: "ndtv.com", title: "Thar launch"), pf));
        }
    }

    // =========================================================================
    //  ONLINE (AO) — MatchPublication Tests
    // =========================================================================
    [TestFixture]
    public class Online_MatchPublicationTests
    {
        [Test]
        public void ExactDomain_Matches()
        { Assert.IsTrue(AO.Program.MatchPublication("ndtv.com", "ndtv.com")); }
        [Test]
        public void CaseInsensitive_Matches()
        { Assert.IsTrue(AO.Program.MatchPublication("ndtv.com", "NDTV.COM")); }
        [Test]
        public void Subdomain_Matches()
        { Assert.IsTrue(AO.Program.MatchPublication("sub.ndtv.com", "ndtv.com")); }
        [Test]
        public void DifferentDomain_NoMatch()
        { Assert.IsFalse(AO.Program.MatchPublication("bbc.com", "ndtv.com")); }
        [Test]
        public void EconomicTimes_Matches()
        { Assert.IsTrue(AO.Program.MatchPublication("economictimes.com", "economictimes.com")); }
    }

    // =========================================================================
    //  ONLINE (AO) — FilterArticles Tests
    // =========================================================================
    [TestFixture]
    public class Online_FilterArticlesTests
    {
        private DataTable _articles;
        private DataTable _conditions;
        [SetUp]
        public void SetUp()
        {
            _articles = OnlineMockData.BuildArticlesTable();
            _conditions = SharedMock.BuildConditionsTable();
        }

        [Test]
        public void SentimentMatch_ReturnsArticle()
        {
            OnlineMockData.AddArticle(_articles, 1, 10, 100, sentiment: "Positive");
            SharedMock.AddCondition(_conditions, 10, 100, 1, "C", CriteriaBuilder.Single("sentiment", "Positive"));
            Assert.AreEqual(1, AO.Program.FilterArticles(_articles, _conditions, 100).Count);
        }
        [Test]
        public void SentimentNoMatch_ReturnsEmpty()
        {
            OnlineMockData.AddArticle(_articles, 1, 10, 100, sentiment: "Negative");
            SharedMock.AddCondition(_conditions, 10, 100, 1, "C", CriteriaBuilder.Single("sentiment", "Positive"));
            Assert.AreEqual(0, AO.Program.FilterArticles(_articles, _conditions, 100).Count);
        }
        [Test]
        public void KeywordInTitle_Matches()
        {
            OnlineMockData.AddArticle(_articles, 1, 10, 100, title: "Mahindra Thar review");
            SharedMock.AddCondition(_conditions, 10, 100, 1, "C", CriteriaBuilder.Single("keyword", "Thar"));
            Assert.AreEqual(1, AO.Program.FilterArticles(_articles, _conditions, 100).Count);
        }
        [Test]
        public void WrongEventId_ReturnsEmpty()
        {
            OnlineMockData.AddArticle(_articles, 1, 10, 100);
            SharedMock.AddCondition(_conditions, 10, 999, 1, "C", CriteriaBuilder.Single("sentiment", "Positive"));
            Assert.AreEqual(0, AO.Program.FilterArticles(_articles, _conditions, 100).Count);
        }
        [Test]
        public void MultipleUsers_SameArticle_Deduplicated()
        {
            OnlineMockData.AddArticle(_articles, 999, 10, 100, sentiment: "Positive", deviceId: "DEV_A");
            OnlineMockData.AddArticle(_articles, 999, 20, 100, sentiment: "Positive", deviceId: "DEV_B");
            SharedMock.AddCondition(_conditions, 10, 100, 1, "C1", CriteriaBuilder.Single("sentiment", "Positive"));
            SharedMock.AddCondition(_conditions, 20, 100, 2, "C2", CriteriaBuilder.Single("sentiment", "Positive"));
            var result = AO.Program.FilterArticles(_articles, _conditions, 100);
            Assert.AreEqual(1, result.Count);
            var users = new List<string>(result[0].UserID.Split(','));
            Assert.IsTrue(users.Contains("10"));
            Assert.IsTrue(users.Contains("20"));
        }
        [Test]
        public void InactiveCondition_Skipped()
        {
            OnlineMockData.AddArticle(_articles, 1, 10, 100, sentiment: "Positive");
            SharedMock.AddCondition(_conditions, 10, 100, 1, "C", CriteriaBuilder.Single("sentiment", "Positive", active: 0));
            Assert.AreEqual(0, AO.Program.FilterArticles(_articles, _conditions, 100).Count);
        }
        [Test]
        public void EmptyArticles_ReturnsEmpty()
        {
            SharedMock.AddCondition(_conditions, 10, 100, 1, "C", CriteriaBuilder.Single("sentiment", "Positive"));
            Assert.AreEqual(0, AO.Program.FilterArticles(_articles, _conditions, 100).Count);
        }
        [Test]
        public void EmptyConditions_ReturnsEmpty()
        {
            OnlineMockData.AddArticle(_articles, 1, 10, 100);
            Assert.AreEqual(0, AO.Program.FilterArticles(_articles, _conditions, 100).Count);
        }
    }

    // =========================================================================
    //  ONLINE (AO) — Helper Tests
    // =========================================================================
    [TestFixture]
    public class Online_HelperTests
    {
        [Test]
        public void CsvSplit_Three_CountIsThree()
        { Assert.AreEqual(3, AO.Program.CsvSplit("a,b,c").Count); }
        [Test]
        public void CsvSplit_TrimsWhitespace()
        {
            var r = AO.Program.CsvSplit("  hello , world  ");
            Assert.IsTrue(r.Contains("hello"));
            Assert.IsTrue(r.Contains("world"));
        }
        [Test]
        public void CsvSplit_Empty_ReturnsEmptyList()
        { Assert.AreEqual(0, AO.Program.CsvSplit("").Count); }
        [Test]
        public void CsvSplit_OnlyCommas_ReturnsEmpty()
        { Assert.AreEqual(0, AO.Program.CsvSplit(",,,").Count); }
        [Test]
        public void GetStr_DBNull_ReturnsEmpty()
        {
            var dt = OnlineMockData.BuildArticlesTable();
            OnlineMockData.AddArticle(dt, 1, 10, 100);
            dt.Rows[0]["author"] = DBNull.Value;
            Assert.AreEqual("", AO.Program.GetStr(dt.Rows[0], "author"));
        }
        [Test]
        public void GetStr_Valid_ReturnsValue()
        {
            var dt = OnlineMockData.BuildArticlesTable();
            OnlineMockData.AddArticle(dt, 1, 10, 100, title: "Hello World");
            Assert.AreEqual("Hello World", AO.Program.GetStr(dt.Rows[0], "title"));
        }
        [Test]
        public void GetStr_InvalidCol_ReturnsEmpty()
        {
            var dt = OnlineMockData.BuildArticlesTable();
            OnlineMockData.AddArticle(dt, 1, 10, 100);
            Assert.AreEqual("", AO.Program.GetStr(dt.Rows[0], "NON_EXISTENT"));
        }
        [Test]
        public void GetInt_DBNull_ReturnsZero()
        {
            var dt = OnlineMockData.BuildArticlesTable();
            OnlineMockData.AddArticle(dt, 1, 10, 100);
            dt.Rows[0]["MediaTypeID"] = DBNull.Value;
            Assert.AreEqual(0, AO.Program.GetInt(dt.Rows[0], "MediaTypeID"));
        }
        [Test]
        public void GetInt_Valid_ReturnsValue()
        {
            var dt = OnlineMockData.BuildArticlesTable();
            OnlineMockData.AddArticle(dt, 42, 10, 100);
            Assert.AreEqual(42, AO.Program.GetInt(dt.Rows[0], "article_id"));
        }
        [Test]
        public void GetInt_InvalidCol_ReturnsZero()
        {
            var dt = OnlineMockData.BuildArticlesTable();
            OnlineMockData.AddArticle(dt, 1, 10, 100);
            Assert.AreEqual(0, AO.Program.GetInt(dt.Rows[0], "NON_EXISTENT"));
        }
    }

    // =========================================================================
    //  ONLINE (AO) — BuildAlert Tests
    // =========================================================================
    [TestFixture]
    public class Online_BuildAlertTests
    {
        [Test]
        public void ArticleId_MappedCorrectly()
        {
            var dt = OnlineMockData.BuildArticlesTable();
            OnlineMockData.AddArticle(dt, 42, 10, 100);
            Assert.AreEqual(42, AO.Program.BuildAlert(dt.Rows[0], 7, "C").article_id);
        }
        [Test]
        public void EnscdId_MappedCorrectly()
        {
            var dt = OnlineMockData.BuildArticlesTable();
            OnlineMockData.AddArticle(dt, 1, 10, 100);
            Assert.AreEqual("7", AO.Program.BuildAlert(dt.Rows[0], 7, "C").Matched_ENSCDID);
        }
        [Test]
        public void ConditionName_MappedCorrectly()
        {
            var dt = OnlineMockData.BuildArticlesTable();
            OnlineMockData.AddArticle(dt, 1, 10, 100);
            Assert.AreEqual("MyCondition", AO.Program.BuildAlert(dt.Rows[0], 7, "MyCondition").Condition_Name);
        }
        [Test]
        public void Title_MappedCorrectly()
        {
            var dt = OnlineMockData.BuildArticlesTable();
            OnlineMockData.AddArticle(dt, 1, 10, 100, title: "Breaking News");
            Assert.AreEqual("Breaking News", AO.Program.BuildAlert(dt.Rows[0], 1, "C").title);
        }
        [Test]
        public void IncidentId_MappedCorrectly()
        {
            var dt = OnlineMockData.BuildArticlesTable();
            OnlineMockData.AddArticle(dt, 1, 10, 100);
            Assert.AreEqual(100, AO.Program.BuildAlert(dt.Rows[0], 1, "C").incident_id);
        }
    }

    // =========================================================================
    //  PRINT (AP) — ParseJson Tests
    // =========================================================================
    [TestFixture]
    public class Print_ParseJsonTests
    {
        [Test]
        public void Sentiment_ParsedCorrectly()
        {
            var pf = AP.Program.ParseJson(CriteriaBuilder.Single("sentiment", "Positive,Negative"), 1, 100);
            Assert.IsTrue(pf.Sentiments.Contains("Positive"));
        }
        [Test]
        public void Reach_ParsedCorrectly()
        {
            var pf = AP.Program.ParseJson(CriteriaBuilder.Single("reach", "10000-500000"), 1, 100);
            Assert.AreEqual(10000L, pf.TrafficMin);
            Assert.AreEqual(500000L, pf.TrafficMax);
        }
        [Test]
        public void Source_ParsedCorrectly()
        {
            var pf = AP.Program.ParseJson(CriteriaBuilder.Single("source", "hindustan times,times of india"), 1, 100);
            Assert.IsTrue(pf.SourceDomains.Contains("hindustan times"));
        }
        [Test]
        public void Keyword_ParsedCorrectly()
        {
            var pf = AP.Program.ParseJson(CriteriaBuilder.Single("keyword", "Budget,Economy"), 1, 100);
            Assert.IsTrue(pf.Keywords.Contains("Budget"));
        }
        [Test]
        public void InactiveCondition_Skipped()
        {
            var pf = AP.Program.ParseJson(CriteriaBuilder.Single("sentiment", "Positive", active: 0), 1, 100);
            Assert.IsTrue(pf.Sentiments == null || pf.Sentiments.Count == 0);
        }
        [Test]
        public void EmptyJson_ReturnsEmptyFilter()
        { Assert.IsFalse(AP.Program.ParseJson("", 1, 100).HasAny()); }
    }

    // =========================================================================
    //  PRINT (AP) — Match Tests
    // =========================================================================
    [TestFixture]
    public class Print_MatchTests
    {
        private DataTable _dt;
        [SetUp] public void SetUp() { _dt = PrintMockData.BuildArticlesTable(); }

        private DataRow MakeRow(string sentiment = "Positive", long circ = 50000,
            string pub = "hindustan times", string title = "Budget 2024",
            string desc = "Economy review", string datatag = "3")
        {
            _dt.Rows.Clear();
            PrintMockData.AddArticle(_dt, 1, 10, 100,
                title: title, description: desc, sentiment: sentiment,
                publication: pub, circulation: circ, datatagId: datatag);
            return _dt.Rows[0];
        }

        private AP.ParsedFilter PF() { return new AP.ParsedFilter(); }

        [Test]
        public void Sentiment_Match()
        {
            var pf = PF(); pf.Sentiments = new List<string> { "Positive" };
            Assert.IsTrue(AP.Program.Match(MakeRow(sentiment: "Positive"), pf));
        }
        [Test]
        public void Sentiment_NoMatch()
        {
            var pf = PF(); pf.Sentiments = new List<string> { "Positive" };
            Assert.IsFalse(AP.Program.Match(MakeRow(sentiment: "Negative"), pf));
        }
        [Test]
        public void Circulation_WithinRange()
        {
            var pf = PF(); pf.TrafficMin = 10000; pf.TrafficMax = 100000;
            Assert.IsTrue(AP.Program.Match(MakeRow(circ: 50000), pf));
        }
        [Test]
        public void Circulation_BelowMin()
        {
            var pf = PF(); pf.TrafficMin = 10000; pf.TrafficMax = 100000;
            Assert.IsFalse(AP.Program.Match(MakeRow(circ: 500), pf));
        }
        [Test]
        public void Publication_Match()
        {
            var pf = PF(); pf.SourceDomains = new List<string> { "hindustan times" };
            Assert.IsTrue(AP.Program.Match(MakeRow(pub: "hindustan times"), pf));
        }
        [Test]
        public void Publication_NoMatch()
        {
            var pf = PF(); pf.SourceDomains = new List<string> { "times of india" };
            Assert.IsFalse(AP.Program.Match(MakeRow(pub: "hindustan times"), pf));
        }
        [Test]
        public void Keyword_InTitle_Match()
        {
            var pf = PF(); pf.Keywords = new List<string> { "Budget" };
            Assert.IsTrue(AP.Program.Match(MakeRow(title: "Budget 2024"), pf));
        }
        [Test]
        public void Keyword_NotFound()
        {
            var pf = PF(); pf.Keywords = new List<string> { "Cricket" };
            Assert.IsFalse(AP.Program.Match(MakeRow(title: "Budget Analysis"), pf));
        }
        [Test]
        public void DataTag_Match()
        {
            var pf = PF(); pf.DataTagIds = new List<string> { "3" };
            Assert.IsTrue(AP.Program.Match(MakeRow(datatag: "3,7"), pf));
        }
        [Test]
        public void AllConditions_Pass()
        {
            var pf = PF();
            pf.Sentiments = new List<string> { "Positive" };
            pf.TrafficMin = 10000; pf.TrafficMax = 100000;
            pf.SourceDomains = new List<string> { "hindustan times" };
            pf.Keywords = new List<string> { "Budget" };
            Assert.IsTrue(AP.Program.Match(
                MakeRow(sentiment: "Positive", circ: 50000, pub: "hindustan times", title: "Budget Review"), pf));
        }
    }

    // =========================================================================
    //  PRINT (AP) — FilterArticles Tests
    // =========================================================================
    [TestFixture]
    public class Print_FilterArticlesTests
    {
        private DataTable _articles;
        private DataTable _conditions;
        [SetUp]
        public void SetUp()
        {
            _articles = PrintMockData.BuildArticlesTable();
            _conditions = SharedMock.BuildConditionsTable();
        }

        [Test]
        public void SentimentMatch_ReturnsArticle()
        {
            PrintMockData.AddArticle(_articles, 1, 10, 100, sentiment: "Positive");
            SharedMock.AddCondition(_conditions, 10, 100, 1, "C", CriteriaBuilder.Single("sentiment", "Positive"));
            Assert.AreEqual(1, AP.Program.FilterArticles(_articles, _conditions, 100).Count);
        }
        [Test]
        public void SentimentNoMatch_ReturnsEmpty()
        {
            PrintMockData.AddArticle(_articles, 1, 10, 100, sentiment: "Negative");
            SharedMock.AddCondition(_conditions, 10, 100, 1, "C", CriteriaBuilder.Single("sentiment", "Positive"));
            Assert.AreEqual(0, AP.Program.FilterArticles(_articles, _conditions, 100).Count);
        }
        [Test]
        public void KeywordInTitle_Matches()
        {
            PrintMockData.AddArticle(_articles, 1, 10, 100, title: "Budget 2024");
            SharedMock.AddCondition(_conditions, 10, 100, 1, "C", CriteriaBuilder.Single("keyword", "Budget"));
            Assert.AreEqual(1, AP.Program.FilterArticles(_articles, _conditions, 100).Count);
        }
        [Test]
        public void CirculationMatch_ReturnsArticle()
        {
            PrintMockData.AddArticle(_articles, 1, 10, 100, circulation: 50000);
            SharedMock.AddCondition(_conditions, 10, 100, 1, "C", CriteriaBuilder.Single("reach", "10000-100000"));
            Assert.AreEqual(1, AP.Program.FilterArticles(_articles, _conditions, 100).Count);
        }
        [Test]
        public void WrongEventId_ReturnsEmpty()
        {
            PrintMockData.AddArticle(_articles, 1, 10, 100);
            SharedMock.AddCondition(_conditions, 10, 999, 1, "C", CriteriaBuilder.Single("sentiment", "Positive"));
            Assert.AreEqual(0, AP.Program.FilterArticles(_articles, _conditions, 100).Count);
        }
        [Test]
        public void MultipleUsers_SameArticle_Deduplicated()
        {
            PrintMockData.AddArticle(_articles, 999, 10, 100, sentiment: "Positive", deviceId: "DEV_A");
            PrintMockData.AddArticle(_articles, 999, 20, 100, sentiment: "Positive", deviceId: "DEV_B");
            SharedMock.AddCondition(_conditions, 10, 100, 1, "C1", CriteriaBuilder.Single("sentiment", "Positive"));
            SharedMock.AddCondition(_conditions, 20, 100, 2, "C2", CriteriaBuilder.Single("sentiment", "Positive"));
            var result = AP.Program.FilterArticles(_articles, _conditions, 100);
            Assert.AreEqual(1, result.Count);
            var users = new List<string>(result[0].UserID.Split(','));
            Assert.IsTrue(users.Contains("10"));
            Assert.IsTrue(users.Contains("20"));
        }
        [Test]
        public void InactiveCondition_Skipped()
        {
            PrintMockData.AddArticle(_articles, 1, 10, 100, sentiment: "Positive");
            SharedMock.AddCondition(_conditions, 10, 100, 1, "C", CriteriaBuilder.Single("sentiment", "Positive", active: 0));
            Assert.AreEqual(0, AP.Program.FilterArticles(_articles, _conditions, 100).Count);
        }
    }

    // =========================================================================
    //  TWITTER (TWT) — ParseJson Tests
    // =========================================================================
    [TestFixture]
    public class Twitter_ParseJsonTests
    {
        [Test]
        public void Sentiment_ParsedCorrectly()
        {
            var pf = TWT.Program.ParseJson(CriteriaBuilder.Single("sentiment", "Positive"), 1, 100);
            Assert.IsTrue(pf.Sentiments.Contains("Positive"));
        }
        [Test]
        public void Reach_ParsedCorrectly()
        {
            var pf = TWT.Program.ParseJson(CriteriaBuilder.Single("reach", "5000-500000"), 1, 100);
            Assert.AreEqual(5000L, pf.TrafficMin);
            Assert.AreEqual(500000L, pf.TrafficMax);
        }
        [Test]
        public void Source_Handles_ParsedCorrectly()
        {
            var pf = TWT.Program.ParseJson(CriteriaBuilder.Single("source", "ndtvnews,aajtak"), 1, 100);
            Assert.IsTrue(pf.SourceHandles.Contains("ndtvnews"));
            Assert.IsTrue(pf.SourceHandles.Contains("aajtak"));
        }
        [Test]
        public void AccountType_ParsedCorrectly()
        {
            var pf = TWT.Program.ParseJson(CriteriaBuilder.Single("account_type", "true"), 1, 100);
            Assert.IsTrue(pf.AccountType.Contains("true"));
        }
        [Test]
        public void Keyword_ParsedCorrectly()
        {
            var pf = TWT.Program.ParseJson(CriteriaBuilder.Single("keyword", "Modi,BJP"), 1, 100);
            Assert.IsTrue(pf.Keywords.Contains("Modi"));
        }
        [Test]
        public void InactiveCondition_Skipped()
        {
            var pf = TWT.Program.ParseJson(CriteriaBuilder.Single("sentiment", "Positive", active: 0), 1, 100);
            Assert.IsTrue(pf.Sentiments == null || pf.Sentiments.Count == 0);
        }
        [Test]
        public void EmptyJson_ReturnsEmptyFilter()
        { Assert.IsFalse(TWT.Program.ParseJson("", 1, 100).HasAny()); }
    }

    // =========================================================================
    //  TWITTER (TWT) — Match Tests
    // =========================================================================
    [TestFixture]
    public class Twitter_MatchTests
    {
        private DataTable _dt;
        [SetUp] public void SetUp() { _dt = TwitterMockData.BuildArticlesTable(); }

        private DataRow MakeRow(string sentiment = "Positive", long followers = 50000,
            string handle = "ndtvnews", string desc = "Modi visits Delhi",
            string isVerified = "true", string datatag = "5")
        {
            _dt.Rows.Clear();
            TwitterMockData.AddArticle(_dt, 1, 10, 100,
                description: desc, sentiment: sentiment, handle: handle,
                followers: followers, isVerified: isVerified, datatagId: datatag);
            return _dt.Rows[0];
        }

        private TWT.ParsedFilter PF() { return new TWT.ParsedFilter(); }

        [Test]
        public void Sentiment_Match()
        {
            var pf = PF(); pf.Sentiments = new List<string> { "Positive" };
            Assert.IsTrue(TWT.Program.Match(MakeRow(sentiment: "Positive"), pf));
        }
        [Test]
        public void Sentiment_NoMatch()
        {
            var pf = PF(); pf.Sentiments = new List<string> { "Positive" };
            Assert.IsFalse(TWT.Program.Match(MakeRow(sentiment: "Negative"), pf));
        }
        [Test]
        public void Followers_WithinRange()
        {
            var pf = PF(); pf.TrafficMin = 10000; pf.TrafficMax = 100000;
            Assert.IsTrue(TWT.Program.Match(MakeRow(followers: 50000), pf));
        }
        [Test]
        public void Followers_BelowMin()
        {
            var pf = PF(); pf.TrafficMin = 10000; pf.TrafficMax = 100000;
            Assert.IsFalse(TWT.Program.Match(MakeRow(followers: 500), pf));
        }
        [Test]
        public void Handle_Match()
        {
            var pf = PF(); pf.SourceHandles = new List<string> { "ndtvnews" };
            Assert.IsTrue(TWT.Program.Match(MakeRow(handle: "ndtvnews"), pf));
        }
        [Test]
        public void Handle_NoMatch()
        {
            var pf = PF(); pf.SourceHandles = new List<string> { "aajtak" };
            Assert.IsFalse(TWT.Program.Match(MakeRow(handle: "ndtvnews"), pf));
        }
        [Test]
        public void AccountType_Verified_Match()
        {
            var pf = PF(); pf.AccountType = new List<string> { "true" };
            Assert.IsTrue(TWT.Program.Match(MakeRow(isVerified: "true"), pf));
        }
        [Test]
        public void AccountType_Unverified_NoMatch()
        {
            var pf = PF(); pf.AccountType = new List<string> { "true" };
            Assert.IsFalse(TWT.Program.Match(MakeRow(isVerified: "false"), pf));
        }
        [Test]
        public void Keyword_FoundInDescription()
        {
            var pf = PF(); pf.Keywords = new List<string> { "Modi" };
            Assert.IsTrue(TWT.Program.Match(MakeRow(desc: "Modi visits Delhi"), pf));
        }
        [Test]
        public void DataTag_Match()
        {
            var pf = PF(); pf.DataTagIds = new List<string> { "5" };
            Assert.IsTrue(TWT.Program.Match(MakeRow(datatag: "5,12"), pf));
        }
    }

    // =========================================================================
    //  TWITTER (TWT) — FilterArticles Tests
    // =========================================================================
    [TestFixture]
    public class Twitter_FilterArticlesTests
    {
        private DataTable _articles;
        private DataTable _conditions;
        [SetUp]
        public void SetUp()
        {
            _articles = TwitterMockData.BuildArticlesTable();
            _conditions = SharedMock.BuildConditionsTable();
        }

        [Test]
        public void SentimentMatch_ReturnsArticle()
        {
            TwitterMockData.AddArticle(_articles, 1, 10, 100, sentiment: "Positive");
            SharedMock.AddCondition(_conditions, 10, 100, 1, "C", CriteriaBuilder.Single("sentiment", "Positive"));
            Assert.AreEqual(1, TWT.Program.FilterArticles(_articles, _conditions, 100).Count);
        }
        [Test]
        public void AccountType_Verified_Matches()
        {
            TwitterMockData.AddArticle(_articles, 1, 10, 100, isVerified: "true");
            SharedMock.AddCondition(_conditions, 10, 100, 1, "C", CriteriaBuilder.Single("account_type", "true"));
            Assert.AreEqual(1, TWT.Program.FilterArticles(_articles, _conditions, 100).Count);
        }
        [Test]
        public void KeywordInDescription_Matches()
        {
            TwitterMockData.AddArticle(_articles, 1, 10, 100, description: "Modi visits Varanasi");
            SharedMock.AddCondition(_conditions, 10, 100, 1, "C", CriteriaBuilder.Single("keyword", "Modi"));
            Assert.AreEqual(1, TWT.Program.FilterArticles(_articles, _conditions, 100).Count);
        }
        [Test]
        public void WrongEventId_ReturnsEmpty()
        {
            TwitterMockData.AddArticle(_articles, 1, 10, 100);
            SharedMock.AddCondition(_conditions, 10, 999, 1, "C", CriteriaBuilder.Single("sentiment", "Positive"));
            Assert.AreEqual(0, TWT.Program.FilterArticles(_articles, _conditions, 100).Count);
        }
        [Test]
        public void MultipleUsers_SameTwitterId_Deduplicated()
        {
            TwitterMockData.AddArticle(_articles, 777, 10, 100, sentiment: "Positive", deviceId: "DEV_A");
            TwitterMockData.AddArticle(_articles, 777, 20, 100, sentiment: "Positive", deviceId: "DEV_B");
            SharedMock.AddCondition(_conditions, 10, 100, 1, "C1", CriteriaBuilder.Single("sentiment", "Positive"));
            SharedMock.AddCondition(_conditions, 20, 100, 2, "C2", CriteriaBuilder.Single("sentiment", "Positive"));
            var result = TWT.Program.FilterArticles(_articles, _conditions, 100);
            Assert.AreEqual(1, result.Count);
            var users = new List<string>(result[0].UserID.Split(','));
            Assert.IsTrue(users.Contains("10"));
            Assert.IsTrue(users.Contains("20"));
        }
        [Test]
        public void InactiveCondition_Skipped()
        {
            TwitterMockData.AddArticle(_articles, 1, 10, 100, sentiment: "Positive");
            SharedMock.AddCondition(_conditions, 10, 100, 1, "C", CriteriaBuilder.Single("sentiment", "Positive", active: 0));
            Assert.AreEqual(0, TWT.Program.FilterArticles(_articles, _conditions, 100).Count);
        }
    }

    // =========================================================================
    //  YOUTUBE (YT) — ParseJson Tests
    // =========================================================================
    [TestFixture]
    public class YouTube_ParseJsonTests
    {
        [Test]
        public void Sentiment_ParsedCorrectly()
        {
            var pf = YT.Program.ParseJson(CriteriaBuilder.Single("sentiment", "Positive,Neutral"), 1, 100);
            Assert.IsTrue(pf.Sentiments.Contains("Positive"));
        }
        [Test]
        public void Reach_ParsedCorrectly()
        {
            var pf = YT.Program.ParseJson(CriteriaBuilder.Single("reach", "100000-5000000"), 1, 100);
            Assert.AreEqual(100000L, pf.TrafficMin);
            Assert.AreEqual(5000000L, pf.TrafficMax);
        }
        [Test]
        public void Source_ParsedCorrectly()
        {
            var pf = YT.Program.ParseJson(CriteriaBuilder.Single("source", "NDTVChannel,ABPNews"), 1, 100);
            Assert.IsTrue(pf.SourceDomains.Contains("NDTVChannel"));
        }
        [Test]
        public void Keyword_ParsedCorrectly()
        {
            var pf = YT.Program.ParseJson(CriteriaBuilder.Single("keyword", "Election,Vote"), 1, 100);
            Assert.IsTrue(pf.Keywords.Contains("Election"));
        }
        [Test]
        public void InactiveCondition_Skipped()
        {
            var pf = YT.Program.ParseJson(CriteriaBuilder.Single("sentiment", "Positive", active: 0), 1, 100);
            Assert.IsTrue(pf.Sentiments == null || pf.Sentiments.Count == 0);
        }
        [Test]
        public void EmptyJson_ReturnsEmptyFilter()
        { Assert.IsFalse(YT.Program.ParseJson("", 1, 100).HasAny()); }
    }

    // =========================================================================
    //  YOUTUBE (YT) — Match Tests
    // =========================================================================
    [TestFixture]
    public class YouTube_MatchTests
    {
        private DataTable _dt;
        [SetUp] public void SetUp() { _dt = YouTubeMockData.BuildArticlesTable(); }

        private DataRow MakeRow(string sentiment = "Positive", long subscribers = 1000000,
            string author = "NDTVChannel", string title = "Election 2024",
            string desc = "Full coverage", string datatag = "8")
        {
            _dt.Rows.Clear();
            YouTubeMockData.AddArticle(_dt, 1, 10, 100,
                title: title, description: desc, sentiment: sentiment,
                author: author, subscribers: subscribers, datatagId: datatag);
            return _dt.Rows[0];
        }

        private YT.ParsedFilter PF() { return new YT.ParsedFilter(); }

        [Test]
        public void Sentiment_Match()
        {
            var pf = PF(); pf.Sentiments = new List<string> { "Positive" };
            Assert.IsTrue(YT.Program.Match(MakeRow(sentiment: "Positive"), pf));
        }
        [Test]
        public void Sentiment_NoMatch()
        {
            var pf = PF(); pf.Sentiments = new List<string> { "Positive" };
            Assert.IsFalse(YT.Program.Match(MakeRow(sentiment: "Negative"), pf));
        }
        [Test]
        public void Subscribers_WithinRange()
        {
            var pf = PF(); pf.TrafficMin = 500000; pf.TrafficMax = 5000000;
            Assert.IsTrue(YT.Program.Match(MakeRow(subscribers: 1000000), pf));
        }
        [Test]
        public void Subscribers_BelowMin()
        {
            var pf = PF(); pf.TrafficMin = 500000; pf.TrafficMax = 5000000;
            Assert.IsFalse(YT.Program.Match(MakeRow(subscribers: 1000), pf));
        }
        [Test]
        public void Author_Match()
        {
            var pf = PF(); pf.SourceDomains = new List<string> { "NDTVChannel" };
            Assert.IsTrue(YT.Program.Match(MakeRow(author: "NDTVChannel"), pf));
        }
        [Test]
        public void Author_NoMatch()
        {
            var pf = PF(); pf.SourceDomains = new List<string> { "ABPNews" };
            Assert.IsFalse(YT.Program.Match(MakeRow(author: "NDTVChannel"), pf));
        }
        [Test]
        public void Keyword_FoundInTitle()
        {
            var pf = PF(); pf.Keywords = new List<string> { "Election" };
            Assert.IsTrue(YT.Program.Match(MakeRow(title: "Election 2024"), pf));
        }
        [Test]
        public void Keyword_FoundInDescription()
        {
            var pf = PF(); pf.Keywords = new List<string> { "Vote" };
            Assert.IsTrue(YT.Program.Match(MakeRow(desc: "How to Vote guide"), pf));
        }
        [Test]
        public void DataTag_Match()
        {
            var pf = PF(); pf.DataTagIds = new List<string> { "8" };
            Assert.IsTrue(YT.Program.Match(MakeRow(datatag: "8,15"), pf));
        }
        [Test]
        public void AllConditions_Pass()
        {
            var pf = PF();
            pf.Sentiments = new List<string> { "Positive" };
            pf.TrafficMin = 500000; pf.TrafficMax = 5000000;
            pf.SourceDomains = new List<string> { "NDTVChannel" };
            pf.Keywords = new List<string> { "Election" };
            Assert.IsTrue(YT.Program.Match(
                MakeRow(sentiment: "Positive", subscribers: 1000000, author: "NDTVChannel", title: "Election Results"), pf));
        }
    }

    // =========================================================================
    //  YOUTUBE (YT) — FilterArticles Tests
    // =========================================================================
    [TestFixture]
    public class YouTube_FilterArticlesTests
    {
        private DataTable _articles;
        private DataTable _conditions;
        [SetUp]
        public void SetUp()
        {
            _articles = YouTubeMockData.BuildArticlesTable();
            _conditions = SharedMock.BuildConditionsTable();
        }

        [Test]
        public void SentimentMatch_ReturnsArticle()
        {
            YouTubeMockData.AddArticle(_articles, 1, 10, 100, sentiment: "Positive");
            SharedMock.AddCondition(_conditions, 10, 100, 1, "C", CriteriaBuilder.Single("sentiment", "Positive"));
            Assert.AreEqual(1, YT.Program.FilterArticles(_articles, _conditions, 100).Count);
        }
        [Test]
        public void KeywordInTitle_Matches()
        {
            YouTubeMockData.AddArticle(_articles, 1, 10, 100, title: "Election 2024 live");
            SharedMock.AddCondition(_conditions, 10, 100, 1, "C", CriteriaBuilder.Single("keyword", "Election"));
            Assert.AreEqual(1, YT.Program.FilterArticles(_articles, _conditions, 100).Count);
        }
        [Test]
        public void SubscriberRangeMatch_ReturnsArticle()
        {
            YouTubeMockData.AddArticle(_articles, 1, 10, 100, subscribers: 1000000);
            SharedMock.AddCondition(_conditions, 10, 100, 1, "C", CriteriaBuilder.Single("reach", "500000-5000000"));
            Assert.AreEqual(1, YT.Program.FilterArticles(_articles, _conditions, 100).Count);
        }
        [Test]
        public void WrongEventId_ReturnsEmpty()
        {
            YouTubeMockData.AddArticle(_articles, 1, 10, 100);
            SharedMock.AddCondition(_conditions, 10, 999, 1, "C", CriteriaBuilder.Single("sentiment", "Positive"));
            Assert.AreEqual(0, YT.Program.FilterArticles(_articles, _conditions, 100).Count);
        }
        [Test]
        public void MultipleUsers_SameVideoId_Deduplicated()
        {
            YouTubeMockData.AddArticle(_articles, 555, 10, 100, sentiment: "Positive", deviceId: "DEV_A");
            YouTubeMockData.AddArticle(_articles, 555, 20, 100, sentiment: "Positive", deviceId: "DEV_B");
            SharedMock.AddCondition(_conditions, 10, 100, 1, "C1", CriteriaBuilder.Single("sentiment", "Positive"));
            SharedMock.AddCondition(_conditions, 20, 100, 2, "C2", CriteriaBuilder.Single("sentiment", "Positive"));
            var result = YT.Program.FilterArticles(_articles, _conditions, 100);
            Assert.AreEqual(1, result.Count);
            var users = new List<string>(result[0].UserID.Split(','));
            Assert.IsTrue(users.Contains("10"));
            Assert.IsTrue(users.Contains("20"));
        }
        [Test]
        public void InactiveCondition_Skipped()
        {
            YouTubeMockData.AddArticle(_articles, 1, 10, 100, sentiment: "Positive");
            SharedMock.AddCondition(_conditions, 10, 100, 1, "C", CriteriaBuilder.Single("sentiment", "Positive", active: 0));
            Assert.AreEqual(0, YT.Program.FilterArticles(_articles, _conditions, 100).Count);
        }
        [Test]
        public void EmptyArticles_ReturnsEmpty()
        {
            SharedMock.AddCondition(_conditions, 10, 100, 1, "C", CriteriaBuilder.Single("sentiment", "Positive"));
            Assert.AreEqual(0, YT.Program.FilterArticles(_articles, _conditions, 100).Count);
        }
    }
}