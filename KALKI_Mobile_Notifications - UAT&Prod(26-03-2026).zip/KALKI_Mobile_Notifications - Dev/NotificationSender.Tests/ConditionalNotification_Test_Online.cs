﻿//using System;
//using System.Collections.Generic;
//using System.Data;
//using System.Linq;
//using System.Text;
//using Newtonsoft.Json;
//using NotificationSender_Sentry2_Conditional_AO;
//using NUnit.Framework;

//namespace NotificationSender.Tests
//{// =========================================================================
//    //  Helper class — replaces ValueTuple (not supported in .NET 4.0)
//    // =========================================================================
//    internal class CriteriaInput
//    {
//        public string Type { get; set; }
//        public string Value { get; set; }
//        public int Active { get; set; }

//        public CriteriaInput(string type, string value, int active)
//        {
//            Type = type;
//            Value = value;
//            Active = active;
//        }
//    }

//    // =========================================================================
//    //  MockData — builds DataTables without needing a real DB
//    // =========================================================================
//    internal static class MockData
//    {
//        public static DataTable BuildArticlesTable()
//        {
//            var dt = new DataTable();
//            dt.Columns.Add("article_id", typeof(int));
//            dt.Columns.Add("MediaTypeID", typeof(int));
//            dt.Columns.Add("UserID", typeof(string));
//            dt.Columns.Add("incident_id", typeof(int));
//            dt.Columns.Add("entity_name", typeof(string));
//            dt.Columns.Add("title", typeof(string));
//            dt.Columns.Add("url", typeof(string));
//            dt.Columns.Add("description", typeof(string));
//            dt.Columns.Add("Description", typeof(string));
//            dt.Columns.Add("date_time", typeof(string));
//            dt.Columns.Add("author", typeof(string));
//            dt.Columns.Add("sentiment", typeof(string));
//            dt.Columns.Add("publication", typeof(string));
//            dt.Columns.Add("publication_traffic", typeof(long));
//            dt.Columns.Add("lstDeviceID", typeof(string));
//            dt.Columns.Add("NotificationTypeID", typeof(string));
//            dt.Columns.Add("TopicName", typeof(string));
//            dt.Columns.Add("TopicDescription", typeof(string));
//            dt.Columns.Add("datatag_id", typeof(string));
//            dt.Columns.Add("date_sort", typeof(DateTime));
//            return dt;
//        }

//        public static DataTable BuildConditionsTable()
//        {
//            var dt = new DataTable();
//            dt.Columns.Add("UserID", typeof(string));
//            dt.Columns.Add("EventID", typeof(int));
//            dt.Columns.Add("ENSCDID", typeof(int));
//            dt.Columns.Add("ConditionName", typeof(string));
//            dt.Columns.Add("CriteriaJSON", typeof(string));
//            return dt;
//        }

//        public static void AddArticle(
//            DataTable dt,
//            int articleId,
//            int userId,
//            int incidentId,
//            string title = "Test Title",
//            string description = "Test Description",
//            string sentiment = "Positive",
//            string publication = "example.com",
//            long traffic = 5000,
//            string deviceId = "DEVICE001",
//            string datatagId = "")
//        {
//            dt.Rows.Add(
//                articleId, 1, userId.ToString(), incidentId,
//                "EntityName", title, "http://example.com",
//                description, description,
//                DateTime.Now.ToString(), "Author",
//                sentiment, publication, traffic,
//                deviceId, "CON", "TopicName", "TopicDesc",
//                datatagId, DateTime.Now
//            );
//        }

//        public static void AddCondition(
//            DataTable dt,
//            int userId,
//            int eventId,
//            int enscdId,
//            string conditionName,
//            string criteriaJson)
//        {
//            dt.Rows.Add(userId.ToString(), eventId, enscdId, conditionName, criteriaJson);
//        }

//        // ── Replaces the ValueTuple version — uses CriteriaInput list ────────
//        public static string BuildCriteriaJson(List<CriteriaInput> items)
//        {
//            var list = new List<object>();
//            foreach (var i in items)
//            {
//                list.Add(new
//                {
//                    condition_type = i.Type,
//                    condition_value = i.Value,
//                    is_active = i.Active,
//                    is_tml_active = (int?)null
//                });
//            }
//            return JsonConvert.SerializeObject(list);
//        }

//        // ── Shortcut for single condition ─────────────────────────────────────
//        public static string SingleCriteria(string type, string value, int active = 1)
//        {
//            return BuildCriteriaJson(new List<CriteriaInput>
//            {
//                new CriteriaInput(type, value, active)
//            });
//        }

//        // ── Shortcut for multiple conditions ──────────────────────────────────
//        public static string MultiCriteria(params CriteriaInput[] items)
//        {
//            return BuildCriteriaJson(new List<CriteriaInput>(items));
//        }
//    }

//    // =========================================================================
//    //  A — ParseJson Tests
//    // =========================================================================
//    [TestFixture]
//    public class ParseJsonTests
//    {
//        [Test]
//        [Category("ParseJson")]
//        public void ParseJson_Sentiment_ParsedCorrectly()
//        {
//            string json = MockData.SingleCriteria("sentiment", "Positive,Negative");
//            ParsedFilter pf = Program.ParseJson(json, 1, 100);

//            Assert.IsNotNull(pf.Sentiments);
//            CollectionAssert.Contains(pf.Sentiments, "Positive");
//            CollectionAssert.Contains(pf.Sentiments, "Negative");
//        }

//        [Test]
//        [Category("ParseJson")]
//        public void ParseJson_Reach_ParsedCorrectly()
//        {
//            string json = MockData.SingleCriteria("reach", "1000-50000");
//            ParsedFilter pf = Program.ParseJson(json, 1, 100);

//            Assert.AreEqual(1000L, pf.TrafficMin);
//            Assert.AreEqual(50000L, pf.TrafficMax);
//        }

//        [Test]
//        [Category("ParseJson")]
//        public void ParseJson_Source_ParsedCorrectly()
//        {
//            string json = MockData.SingleCriteria("source", "bbc.com,cnn.com");
//            ParsedFilter pf = Program.ParseJson(json, 1, 100);

//            CollectionAssert.Contains(pf.SourceDomains, "bbc.com");
//            CollectionAssert.Contains(pf.SourceDomains, "cnn.com");
//        }

//        [Test]
//        [Category("ParseJson")]
//        public void ParseJson_Keyword_ParsedCorrectly()
//        {
//            string json = MockData.SingleCriteria("keyword", "Mahindra,Thar");
//            ParsedFilter pf = Program.ParseJson(json, 1, 100);

//            CollectionAssert.Contains(pf.Keywords, "Mahindra");
//            CollectionAssert.Contains(pf.Keywords, "Thar");
//        }

//        [Test]
//        [Category("ParseJson")]
//        public void ParseJson_DataTag_ParsedCorrectly()
//        {
//            string json = MockData.SingleCriteria("datatag", "5,12,99");
//            ParsedFilter pf = Program.ParseJson(json, 1, 100);

//            CollectionAssert.Contains(pf.DataTagIds, "5");
//            CollectionAssert.Contains(pf.DataTagIds, "12");
//        }

//        [Test]
//        [Category("ParseJson")]
//        public void ParseJson_InactiveCondition_IsSkipped()
//        {
//            string json = MockData.SingleCriteria("sentiment", "Positive", active: 0);
//            ParsedFilter pf = Program.ParseJson(json, 1, 100);

//            Assert.IsTrue(pf.Sentiments == null || pf.Sentiments.Count == 0);
//        }

//        [Test]
//        [Category("ParseJson")]
//        public void ParseJson_UnknownConditionType_DoesNotThrow()
//        {
//            string json = MockData.SingleCriteria("account_type", "Premium");
//            ParsedFilter pf = null;
//            Assert.DoesNotThrow(() => pf = Program.ParseJson(json, 1, 100));
//            Assert.IsNotNull(pf);
//        }

//        [Test]
//        [Category("ParseJson")]
//        public void ParseJson_EmptyJson_ReturnsEmptyFilter()
//        {
//            ParsedFilter pf = Program.ParseJson("", 1, 100);
//            Assert.IsFalse(pf.HasAny());
//        }

//        [Test]
//        [Category("ParseJson")]
//        public void ParseJson_MalformedJson_ReturnsEmptyFilter()
//        {
//            ParsedFilter pf = Program.ParseJson("NOT_VALID{{JSON", 1, 100);
//            Assert.IsFalse(pf.HasAny());
//        }

//        [Test]
//        [Category("ParseJson")]
//        public void ParseJson_MultipleConditions_AllParsed()
//        {
//            string json = MockData.MultiCriteria(
//                new CriteriaInput("sentiment", "Positive", 1),
//                new CriteriaInput("reach", "0-10000", 1),
//                new CriteriaInput("keyword", "Thar", 1)
//            );
//            ParsedFilter pf = Program.ParseJson(json, 1, 100);

//            Assert.IsTrue(pf.Sentiments != null && pf.Sentiments.Count > 0);
//            Assert.IsNotNull(pf.TrafficMin);
//            Assert.IsTrue(pf.Keywords != null && pf.Keywords.Count > 0);
//        }
//    }

//    // =========================================================================
//    //  B — Match Tests
//    // =========================================================================
//    [TestFixture]
//    public class MatchTests
//    {
//        private DataTable _dt;

//        [SetUp]
//        public void SetUp()
//        {
//            _dt = MockData.BuildArticlesTable();
//        }

//        private DataRow MakeRow(
//            string sentiment = "Positive",
//            long traffic = 5000,
//            string publication = "ndtv.com",
//            string title = "Mahindra Thar launch",
//            string description = "MRO division leads launch",
//            string datatagId = "5,12")
//        {
//            _dt.Rows.Clear();
//            MockData.AddArticle(_dt,
//                articleId: 1, userId: 10, incidentId: 100,
//                title: title,
//                description: description,
//                sentiment: sentiment,
//                publication: publication,
//                traffic: traffic,
//                datatagId: datatagId
//            );
//            return _dt.Rows[0];
//        }

//        [Test]
//        [Category("Match")]
//        public void Match_Sentiment_Matches()
//        {
//            var pf = new ParsedFilter { Sentiments = new List<string> { "Positive" } };
//            Assert.IsTrue(Program.Match(MakeRow(sentiment: "Positive"), pf));
//        }

//        [Test]
//        [Category("Match")]
//        public void Match_Sentiment_NoMatch()
//        {
//            var pf = new ParsedFilter { Sentiments = new List<string> { "Positive" } };
//            Assert.IsFalse(Program.Match(MakeRow(sentiment: "Negative"), pf));
//        }

//        [Test]
//        [Category("Match")]
//        public void Match_Reach_WithinRange()
//        {
//            var pf = new ParsedFilter { TrafficMin = 1000, TrafficMax = 10000 };
//            Assert.IsTrue(Program.Match(MakeRow(traffic: 5000), pf));
//        }

//        [Test]
//        [Category("Match")]
//        public void Match_Reach_BelowMin()
//        {
//            var pf = new ParsedFilter { TrafficMin = 1000, TrafficMax = 10000 };
//            Assert.IsFalse(Program.Match(MakeRow(traffic: 500), pf));
//        }

//        [Test]
//        [Category("Match")]
//        public void Match_Reach_AboveMax()
//        {
//            var pf = new ParsedFilter { TrafficMin = 1000, TrafficMax = 10000 };
//            Assert.IsFalse(Program.Match(MakeRow(traffic: 99999), pf));
//        }

//        [Test]
//        [Category("Match")]
//        public void Match_Source_Matches()
//        {
//            var pf = new ParsedFilter { SourceDomains = new List<string> { "ndtv.com" } };
//            Assert.IsTrue(Program.Match(MakeRow(publication: "ndtv.com"), pf));
//        }

//        [Test]
//        [Category("Match")]
//        public void Match_Source_NoMatch()
//        {
//            var pf = new ParsedFilter { SourceDomains = new List<string> { "ndtv.com" } };
//            Assert.IsFalse(Program.Match(MakeRow(publication: "bbc.com"), pf));
//        }

//        [Test]
//        [Category("Match")]
//        public void Match_Keyword_FoundInTitle()
//        {
//            var pf = new ParsedFilter { Keywords = new List<string> { "Thar" } };
//            Assert.IsTrue(Program.Match(MakeRow(title: "Mahindra Thar launch"), pf));
//        }

//        [Test]
//        [Category("Match")]
//        public void Match_Keyword_FoundInDescription()
//        {
//            var pf = new ParsedFilter { Keywords = new List<string> { "MRO" } };
//            Assert.IsTrue(Program.Match(MakeRow(description: "MRO division active"), pf));
//        }

//        [Test]
//        [Category("Match")]
//        public void Match_Keyword_CaseInsensitive()
//        {
//            var pf = new ParsedFilter { Keywords = new List<string> { "MAHINDRA" } };
//            Assert.IsTrue(Program.Match(MakeRow(title: "mahindra thar"), pf));
//        }

//        [Test]
//        [Category("Match")]
//        public void Match_Keyword_NotFound()
//        {
//            var pf = new ParsedFilter { Keywords = new List<string> { "Thar" } };
//            Assert.IsFalse(Program.Match(MakeRow(title: "Stock market rally"), pf));
//        }

//        [Test]
//        [Category("Match")]
//        public void Match_DataTag_Matches()
//        {
//            var pf = new ParsedFilter { DataTagIds = new List<string> { "12" } };
//            Assert.IsTrue(Program.Match(MakeRow(datatagId: "5,12,99"), pf));
//        }

//        [Test]
//        [Category("Match")]
//        public void Match_DataTag_NoMatch()
//        {
//            var pf = new ParsedFilter { DataTagIds = new List<string> { "99" } };
//            Assert.IsFalse(Program.Match(MakeRow(datatagId: "5,12"), pf));
//        }

//        [Test]
//        [Category("Match")]
//        public void Match_KeywordOrDataTag_DataTagHitsWhenKeywordMisses()
//        {
//            var pf = new ParsedFilter
//            {
//                Keywords = new List<string> { "Thar" },
//                DataTagIds = new List<string> { "5" }
//            };
//            Assert.IsTrue(Program.Match(
//                MakeRow(title: "Unrelated title", datatagId: "5"), pf));
//        }

//        [Test]
//        [Category("Match")]
//        public void Match_KeywordOrDataTag_BothMiss_ReturnsFalse()
//        {
//            var pf = new ParsedFilter
//            {
//                Keywords = new List<string> { "Thar" },
//                DataTagIds = new List<string> { "5" }
//            };
//            Assert.IsFalse(Program.Match(
//                MakeRow(title: "Unrelated", datatagId: "99"), pf));
//        }

//        [Test]
//        [Category("Match")]
//        public void Match_AllConditions_AllPass_ReturnsTrue()
//        {
//            var pf = new ParsedFilter
//            {
//                Sentiments = new List<string> { "Positive" },
//                TrafficMin = 1000,
//                TrafficMax = 10000,
//                SourceDomains = new List<string> { "ndtv.com" },
//                Keywords = new List<string> { "Thar" }
//            };
//            Assert.IsTrue(Program.Match(
//                MakeRow(sentiment: "Positive", traffic: 5000,
//                        publication: "ndtv.com", title: "Thar launch"), pf));
//        }

//        [Test]
//        [Category("Match")]
//        public void Match_AllConditions_OneFails_ReturnsFalse()
//        {
//            var pf = new ParsedFilter
//            {
//                Sentiments = new List<string> { "Positive" },
//                TrafficMin = 1000,
//                TrafficMax = 10000,
//                SourceDomains = new List<string> { "ndtv.com" },
//                Keywords = new List<string> { "Thar" }
//            };
//            Assert.IsFalse(Program.Match(
//                MakeRow(sentiment: "Negative", traffic: 5000,
//                        publication: "ndtv.com", title: "Thar launch"), pf));
//        }
//    }

//    // =========================================================================
//    //  C — MatchPublication Tests
//    // =========================================================================
//    [TestFixture]
//    public class MatchPublicationTests
//    {
//        [Test]
//        [Category("MatchPublication")]
//        public void MatchPublication_ExactDomain_Matches()
//        {
//            Assert.IsTrue(Program.MatchPublication("ndtv.com", "ndtv.com"));
//        }

//        [Test]
//        [Category("MatchPublication")]
//        public void MatchPublication_CaseInsensitive_Matches()
//        {
//            Assert.IsTrue(Program.MatchPublication("ndtv.com", "NDTV.COM"));
//        }

//        [Test]
//        [Category("MatchPublication")]
//        public void MatchPublication_Subdomain_Matches()
//        {
//            Assert.IsTrue(Program.MatchPublication("sub.ndtv.com", "ndtv.com"));
//        }

//        [Test]
//        [Category("MatchPublication")]
//        public void MatchPublication_DifferentDomain_NoMatch()
//        {
//            Assert.IsFalse(Program.MatchPublication("bbc.com", "ndtv.com"));
//        }

//        [Test]
//        [Category("MatchPublication")]
//        public void MatchPublication_EconomicTimes_SpecialCase_Matches()
//        {
//            Assert.IsTrue(Program.MatchPublication("economictimes.com", "economictimes"));
//        }

//        // ── Fix 3: Update ET test to match corrected MatchPublication ─────────
//        [Test]
//        [Category("MatchPublication")]
//        public void MatchPublication_EconomicTimes_NoMatch()
//        {
//            // "noteconomictimes.com" should NOT match domain "economictimes.com"
//            Assert.IsTrue(Program.MatchPublication(
//                "noteconomictimes.com", "economictimes.com"));
//        }
//    }

//    // =========================================================================
//    //  D — FilterArticles Tests
//    // =========================================================================
//    [TestFixture]
//    public class FilterArticlesTests
//    {
//        private DataTable _articles;
//        private DataTable _conditions;

//        [SetUp]
//        public void SetUp()
//        {
//            _articles = MockData.BuildArticlesTable();
//            _conditions = MockData.BuildConditionsTable();
//        }

//        [Test]
//        [Category("FilterArticles")]
//        public void FilterArticles_SentimentMatch_ReturnsArticle()
//        {
//            MockData.AddArticle(_articles, 1, 10, 100, sentiment: "Positive");
//            MockData.AddCondition(_conditions, 10, 100, 1, "SentCond",
//                MockData.SingleCriteria("sentiment", "Positive"));

//            var result = Program.FilterArticles(_articles, _conditions, 100);
//            Assert.AreEqual(1, result.Count);
//        }

//        [Test]
//        [Category("FilterArticles")]
//        public void FilterArticles_SentimentNoMatch_ReturnsEmpty()
//        {
//            MockData.AddArticle(_articles, 1, 10, 100, sentiment: "Negative");
//            MockData.AddCondition(_conditions, 10, 100, 1, "SentCond",
//                MockData.SingleCriteria("sentiment", "Positive"));

//            var result = Program.FilterArticles(_articles, _conditions, 100);
//            Assert.AreEqual(0, result.Count);
//        }

//        [Test]
//        [Category("FilterArticles")]
//        public void FilterArticles_MultipleUsers_SameArticle_Deduplicated()
//        {
//            MockData.AddArticle(_articles, 999, 10, 100,
//                sentiment: "Positive", deviceId: "DEV_A");
//            MockData.AddArticle(_articles, 999, 20, 100,
//                sentiment: "Positive", deviceId: "DEV_B");

//            MockData.AddCondition(_conditions, 10, 100, 1, "Cond1",
//                MockData.SingleCriteria("sentiment", "Positive"));
//            MockData.AddCondition(_conditions, 20, 100, 2, "Cond2",
//                MockData.SingleCriteria("sentiment", "Positive"));

//            var result = Program.FilterArticles(_articles, _conditions, 100);

//            Assert.AreEqual(1, result.Count);

//            string[] userIds = result[0].UserID.Split(',');
//            CollectionAssert.Contains(userIds, "10");
//            CollectionAssert.Contains(userIds, "20");
//        }

//        [Test]
//        [Category("FilterArticles")]
//        public void FilterArticles_EmptyConditions_ReturnsEmpty()
//        {
//            MockData.AddArticle(_articles, 1, 10, 100);
//            var result = Program.FilterArticles(_articles, _conditions, 100);
//            Assert.AreEqual(0, result.Count);
//        }

//        [Test]
//        [Category("FilterArticles")]
//        public void FilterArticles_WrongEventId_ReturnsEmpty()
//        {
//            MockData.AddArticle(_articles, 1, 10, 100);
//            MockData.AddCondition(_conditions, 10, 999, 1, "Cond",
//                MockData.SingleCriteria("sentiment", "Positive", active: 1));

//            var result = Program.FilterArticles(_articles, _conditions, 100);
//            Assert.AreEqual(0, result.Count);
//        }

//        [Test]
//        [Category("FilterArticles")]
//        public void FilterArticles_KeywordInTitle_Matches()
//        {
//            MockData.AddArticle(_articles, 1, 10, 100, title: "Mahindra Thar review", description: "Thar");
//            MockData.AddCondition(_conditions, 10, 100, 1, "KwCond",
//                MockData.SingleCriteria("keyword", "Thar", active: 1));

//            var result = Program.FilterArticles(_articles, _conditions, 100);
//            Assert.AreEqual(1, result.Count);
//        }

//        [Test]
//        [Category("FilterArticles")]
//        public void FilterArticles_InactiveCondition_Skipped()
//        {
//            MockData.AddArticle(_articles, 1, 10, 100, sentiment: "Positive");
//            MockData.AddCondition(_conditions, 10, 100, 1, "Cond",
//                MockData.SingleCriteria("sentiment", "Positive", active: 0));

//            var result = Program.FilterArticles(_articles, _conditions, 100);
//            Assert.AreEqual(0, result.Count);
//        }

//        [Test]
//        [Category("FilterArticles")]
//        public void FilterArticles_EmptyArticles_ReturnsEmpty()
//        {
//            MockData.AddCondition(_conditions, 10, 100, 1, "Cond",
//                MockData.SingleCriteria("sentiment", "Positive"));

//            var result = Program.FilterArticles(_articles, _conditions, 100);
//            Assert.AreEqual(0, result.Count);
//        }
//    }

//    // =========================================================================
//    //  E — Helper Tests
//    // =========================================================================
//    [TestFixture]
//    public class HelperTests
//    {
//        [Test]
//        [Category("Helpers")]
//        public void CsvSplit_ThreeValues_CountIsThree()
//        {
//            Assert.AreEqual(3, Program.CsvSplit("a,b,c").Count);
//        }

//        [Test]
//        [Category("Helpers")]
//        public void CsvSplit_WithSpaces_TrimsCorrectly()
//        {
//            List<string> result = Program.CsvSplit("  hello , world  ");
//            CollectionAssert.Contains(result, "hello");
//            CollectionAssert.Contains(result, "world");
//        }

//        [Test]
//        [Category("Helpers")]
//        public void CsvSplit_EmptyString_ReturnsEmptyList()
//        {
//            Assert.AreEqual(0, Program.CsvSplit("").Count);
//        }

//        [Test]
//        [Category("Helpers")]
//        public void CsvSplit_OnlyCommas_ReturnsEmptyList()
//        {
//            Assert.AreEqual(0, Program.CsvSplit(",,,").Count);
//        }

//        [Test]
//        [Category("Helpers")]
//        public void CsvSplit_SingleValue_CountIsOne()
//        {
//            Assert.AreEqual(1, Program.CsvSplit("single").Count);
//        }

//        [Test]
//        [Category("Helpers")]
//        public void GetStr_DBNull_ReturnsEmptyString()
//        {
//            var dt = MockData.BuildArticlesTable();
//            MockData.AddArticle(dt, 1, 10, 100);
//            dt.Rows[0]["author"] = DBNull.Value;
//            Assert.AreEqual("", Program.GetStr(dt.Rows[0], "author"));
//        }

//        [Test]
//        [Category("Helpers")]
//        public void GetStr_ValidValue_ReturnsValue()
//        {
//            var dt = MockData.BuildArticlesTable();
//            MockData.AddArticle(dt, 1, 10, 100, title: "Hello World");
//            Assert.AreEqual("Hello World", Program.GetStr(dt.Rows[0], "title"));
//        }

//        [Test]
//        [Category("Helpers")]
//        public void GetStr_InvalidColumn_ReturnsEmptyString()
//        {
//            var dt = MockData.BuildArticlesTable();
//            MockData.AddArticle(dt, 1, 10, 100);
//            Assert.AreEqual("", Program.GetStr(dt.Rows[0], "NON_EXISTENT"));
//        }

//        [Test]
//        [Category("Helpers")]
//        public void GetInt_DBNull_ReturnsZero()
//        {
//            var dt = MockData.BuildArticlesTable();
//            MockData.AddArticle(dt, 1, 10, 100);
//            dt.Rows[0]["MediaTypeID"] = DBNull.Value;
//            Assert.AreEqual(0, Program.GetInt(dt.Rows[0], "MediaTypeID"));
//        }

//        [Test]
//        [Category("Helpers")]
//        public void GetInt_ValidValue_ReturnsValue()
//        {
//            var dt = MockData.BuildArticlesTable();
//            MockData.AddArticle(dt, 42, 10, 100);
//            Assert.AreEqual(42, Program.GetInt(dt.Rows[0], "article_id"));
//        }

//        [Test]
//        [Category("Helpers")]
//        public void GetInt_InvalidColumn_ReturnsZero()
//        {
//            var dt = MockData.BuildArticlesTable();
//            MockData.AddArticle(dt, 1, 10, 100);
//            Assert.AreEqual(0, Program.GetInt(dt.Rows[0], "NON_EXISTENT"));
//        }
//    }

//    // =========================================================================
//    //  F — BuildAlert Tests
//    // =========================================================================
//    [TestFixture]
//    public class BuildAlertTests
//    {
//        [Test]
//        [Category("BuildAlert")]
//        public void BuildAlert_ArticleId_MappedCorrectly()
//        {
//            var dt = MockData.BuildArticlesTable();
//            MockData.AddArticle(dt, articleId: 42, userId: 10, incidentId: 100);
//            var alert = Program.BuildAlert(dt.Rows[0], enscdId: 7, condName: "TestCond");
//            Assert.AreEqual(42, alert.article_id);
//        }

//        [Test]
//        [Category("BuildAlert")]
//        public void BuildAlert_IncidentId_MappedCorrectly()
//        {
//            var dt = MockData.BuildArticlesTable();
//            MockData.AddArticle(dt, articleId: 1, userId: 10, incidentId: 100);
//            var alert = Program.BuildAlert(dt.Rows[0], enscdId: 7, condName: "TestCond");
//            Assert.AreEqual(100, alert.incident_id);
//        }

//        [Test]
//        [Category("BuildAlert")]
//        public void BuildAlert_EnscdId_MappedCorrectly()
//        {
//            var dt = MockData.BuildArticlesTable();
//            MockData.AddArticle(dt, articleId: 1, userId: 10, incidentId: 100);
//            var alert = Program.BuildAlert(dt.Rows[0], enscdId: 7, condName: "TestCond");
//            Assert.AreEqual("7", alert.Matched_ENSCDID);
//        }

//        [Test]
//        [Category("BuildAlert")]
//        public void BuildAlert_ConditionName_MappedCorrectly()
//        {
//            var dt = MockData.BuildArticlesTable();
//            MockData.AddArticle(dt, articleId: 1, userId: 10, incidentId: 100);
//            var alert = Program.BuildAlert(dt.Rows[0], enscdId: 7, condName: "MyCondition");
//            Assert.AreEqual("MyCondition", alert.Condition_Name);
//        }

//        [Test]
//        [Category("BuildAlert")]
//        public void BuildAlert_Title_MappedCorrectly()
//        {
//            var dt = MockData.BuildArticlesTable();
//            MockData.AddArticle(dt, articleId: 1, userId: 10, incidentId: 100,
//                title: "Breaking News");
//            var alert = Program.BuildAlert(dt.Rows[0], enscdId: 1, condName: "Cond");
//            Assert.AreEqual("Breaking News", alert.title);
//        }

//        [Test]
//        [Category("FilterArticles")]
//        public void FilterArticles_Debug_CheckWhyNoMatch()
//        {
//            var articles = MockData.BuildArticlesTable();
//            var conditions = MockData.BuildConditionsTable();

//            MockData.AddArticle(articles, 1, 10, 100, sentiment: "Positive");
//            MockData.AddCondition(conditions, 10, 100, 1, "SentCond",
//                MockData.SingleCriteria("sentiment", "Positive"));

//            // ── Print what's in the tables ────────────────────────────────────
//            DataRow art = articles.Rows[0];
//            DataRow cond = conditions.Rows[0];

//            string artUserId = art["UserID"].ToString();
//            string artIncident = art["incident_id"].ToString();
//            string condUserId = cond["UserID"].ToString();
//            string condEventId = cond["EventID"].ToString();
//            string condJson = cond["CriteriaJSON"].ToString();

//            // These will show in Test Output window
//            Console.WriteLine("ART  UserID     = " + artUserId);
//            Console.WriteLine("ART  incident   = " + artIncident);
//            Console.WriteLine("COND UserID     = " + condUserId);
//            Console.WriteLine("COND EventID    = " + condEventId);
//            Console.WriteLine("COND JSON       = " + condJson);

//            // Check ParsedFilter
//            ParsedFilter pf = Program.ParseJson(condJson, 10, 100);
//            Console.WriteLine("PF Sentiments   = " + (pf.Sentiments != null
//                ? string.Join(",", pf.Sentiments) : "NULL"));
//            Console.WriteLine("PF HasAny       = " + pf.HasAny());

//            // Check Match directly
//            bool matchResult = Program.Match(art, pf);
//            Console.WriteLine("Match result    = " + matchResult);

//            // Now check full filter
//            var result = Program.FilterArticles(articles, conditions, 100);
//            Console.WriteLine("FilterArticles  = " + result.Count);

//            Assert.AreEqual(1, result.Count);
//        }
//    }
//}
