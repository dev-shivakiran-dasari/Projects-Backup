﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.IO;
using System.Diagnostics;
using System.Threading.Tasks;
using System.Net;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json;
using System.Collections.Concurrent;

namespace NotificationSender_Sentry2_Conditional_YT
{

    internal class CriteriaItem
    {
        [JsonProperty("condition_type")] public string ConditionType { get; set; }
        [JsonProperty("condition_value")] public string ConditionValue { get; set; }
        [JsonProperty("is_active")] public int IsActive { get; set; }
        [JsonProperty("is_tml_active")] public int? IsTmlActive { get; set; }
    }

    // All conditions AND'd together; keyword + datatag OR'd with each other
    internal class ParsedFilter
    {
        public List<string> Sentiments { get; set; }
        public long? TrafficMin { get; set; }
        public long? TrafficMax { get; set; }
        public List<string> SourceDomains { get; set; }
        public List<string> Keywords { get; set; }
        public List<string> DataTagIds { get; set; }

        public bool HasAny() =>
               (Sentiments != null && Sentiments.Count > 0)
            || TrafficMin.HasValue
            || (SourceDomains != null && SourceDomains.Count > 0)
            || (Keywords != null && Keywords.Count > 0)
            || (DataTagIds != null && DataTagIds.Count > 0);
    }

    public class eLog
    {
        public string UserID { get; set; }
        public string DeviceID { get; set; }
        public string Status { get; set; }
        public string ErrorCode { get; set; }
        public string ErrorMessage { get; set; }
    }

    class Program
    {
        static readonly string ConnE = ConfigurationManager.ConnectionStrings["ConnectionString_SahadevE"].ToString();
        static readonly string ConnC2 = ConfigurationManager.ConnectionStrings["ConnectionString_SahadevC2"].ToString();
        static readonly string ConnD = ConfigurationManager.ConnectionStrings["ConnectionString_SahadevD"].ToString();

        static readonly int MaxParallel = Convert.ToInt32(
            ConfigurationManager.AppSettings["MaxDegreeOfParallelism"]);

        static readonly ParallelOptions Po = new ParallelOptions
        {
            MaxDegreeOfParallelism = MaxParallel
        };



        static void Main(string[] args)
        {
            try
            {
                Log("Program Start", "");

                ServicePointManager.DefaultConnectionLimit = MaxParallel * 3;

                Log("FetchEventIDs Start", "");
                List<int> eventIds = FetchEventIDs();
                Log("FetchEventIDs End", $"Count={eventIds.Count}  IDs={string.Join(",", eventIds)}");

                if (eventIds.Count == 0) { Log("No active EventIDs found", ""); return; }

                var sw = Stopwatch.StartNew();

                // Level 1 — EventIDs in parallel
                Parallel.ForEach(eventIds, Po, eventId =>
                {
                    try { ProcessEvent(eventId); }
                    catch (Exception ex)
                    {
                        Log($"EventID={eventId} unhandled error", ex.Message + " >> " + ex.StackTrace);
                    }
                });

                sw.Stop();
                Log("Program End", $"Total time={sw.Elapsed:mm\\:ss\\.fff}");
            }
            catch (Exception ex) { Log("Main", ex.Message + " >> " + ex.StackTrace); }
        }

        static List<int> FetchEventIDs()
        {
            var list = new List<int>();
            var cmd = new SqlCommand();
            try
            {
                var conn = new SqlConnection(ConnE);
                cmd.Connection = conn;
                cmd.Connection.Open();
                cmd.CommandText = "USP_Notification_FtechEventIDs_Test";
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandTimeout = 60;
                cmd.Parameters.AddWithValue("@PlatformID", 4);
                cmd.Parameters.AddWithValue("@NotificationType", "CON");
                using (var rd = cmd.ExecuteReader())
                    while (rd.Read())
                        list.Add(Convert.ToInt32(rd["EventID"]));
            }
            catch (Exception ex) { Log("FetchEventIDs", ex.Message + " >> " + ex.StackTrace); }
            finally { cmd.Connection.Close(); cmd.Connection.Dispose(); }
            return list;
        }

        static void ProcessEvent(int eventId)
        {
            Log($"EventID={eventId} Start", "");

            DataTable articles = null, conditions = null;
            FetchFromSP(eventId, out articles, out conditions);

            if (articles == null || articles.Rows.Count == 0)
            {
                Log($"EventID={eventId}", "No articles. Skipping."); return;
            }
            if (conditions == null || conditions.Rows.Count == 0)
            {
                Log($"EventID={eventId}", "No conditions. Skipping."); return;
            }

            // Level 2 — filter conditions in parallel
            var matched = FilterArticles(articles, conditions, eventId);

            Log($"EventID={eventId}", $"Matched={matched.Count}");
            if (matched.Count == 0) return;

            // Level 3 — send in parallel
            Parallel.For(0, matched.Count, Po, i =>
            {
                try
                {
                    Log($"Send Start article_id={matched[i].video_id}", "");
                    bool sent = SendNotification_News(matched[i]);
                    Log($"Send Result={sent} article_id={matched[i].video_id}", "");
                    if (sent)
                        UpdateAlert_News(matched[i].video_id, matched[i].MediaTypeID);
                }
                catch (Exception ex)
                {
                    Log($"Send error article_id={matched[i].video_id}",
                        ex.Message + " >> " + ex.StackTrace);
                }
            });

            Log($"EventID={eventId} Done", "");
        }

        static void FetchFromSP(int eventId, out DataTable articles, out DataTable conditions)
        {
            articles = conditions = null;
            var cmd = new SqlCommand();
            try
            {
                var conn = new SqlConnection(ConnE);
                cmd.Connection = conn;
                cmd.Connection.Open();
                cmd.CommandText = "USP_Notification_Conditional_YouTube_Test";
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandTimeout = 600;
                cmd.Parameters.AddWithValue("@EventID", eventId);

                var ds = new DataSet();
                new SqlDataAdapter(cmd).Fill(ds);

                if (ds.Tables.Count >= 1) articles = ds.Tables[0].Copy();
                if (ds.Tables.Count >= 2) conditions = ds.Tables[1].Copy();

                Log($"FetchFromSP EventID={eventId}",
                    $"Articles={(articles?.Rows.Count ?? 0)}  Conditions={(conditions?.Rows.Count ?? 0)}");
            }
            catch (Exception ex)
            {
                Log($"FetchFromSP EventID={eventId}", ex.Message + " >> " + ex.StackTrace);
            }
            finally { cmd.Connection.Close(); cmd.Connection.Dispose(); }
        }

        internal static List<eAlerts_YouTube> FilterArticles(DataTable articles, DataTable conditions, int eventId)
        {
            var result = new ConcurrentDictionary<int, eAlerts_YouTube>();

            var condRows = conditions.Rows.Cast<DataRow>().ToArray();
            var artRows = articles.Rows.Cast<DataRow>().ToArray();

            Parallel.ForEach(condRows, Po, condRow =>
            {
                try
                {
                    int userId = Convert.ToInt32(condRow["UserID"]);
                    int ConEventID = Convert.ToInt32(condRow["EventID"]);
                    int enscdId = Convert.ToInt32(condRow["ENSCDID"]);
                    string condName = condRow["ConditionName"].ToString();
                    string json = condRow["CriteriaJSON"].ToString();

                    ParsedFilter pf = ParseJson(json, userId, eventId);

                    if (!pf.HasAny())
                        return;

                    foreach (DataRow art in artRows)
                    {
                        if (GetInt(art, "incident_id") != ConEventID && ConEventID != eventId) continue;
                        if (GetStr(art, "UserID") != userId.ToString()) continue;
                        if (!Match(art, pf)) continue;

                        int articleid = GetInt(art, "video_id");

                        result.AddOrUpdate(
                            articleid,
                            // If NOT exists → create new
                            key =>
                            {
                                var obj = BuildAlert(art, enscdId, condName);
                                return obj;
                            },
                            // If EXISTS → update aggregation
                            (key, existing) =>
                            {
                                string newUser = userId.ToString();
                                string newDevice = GetStr(art, "lstDeviceID");

                                // Avoid duplicate user
                                var users = existing.UserID?.Split(',').ToList() ?? new List<string>();
                                if (!users.Contains(newUser))
                                {
                                    users.Add(newUser);
                                    existing.UserID = string.Join(",", users);

                                    var devices = existing.lstDeviceID?.Split(',').ToList() ?? new List<string>();
                                    devices.Add(newDevice);
                                    existing.lstDeviceID = string.Join(",", devices);
                                }

                                return existing;
                            });
                    }
                }
                catch (Exception ex)
                {
                    Log($"FilterArticles EventID={eventId}", ex.Message + " >> " + ex.StackTrace);
                }
            });

            return result.Values.ToList();
        }

        // =====================================================================
        //  Match — AND across all condition types; keyword + datatag OR'd together
        // =====================================================================
        internal static bool Match(DataRow row, ParsedFilter pf)
        {
            // SENTIMENT
            if (pf.Sentiments != null && pf.Sentiments.Count > 0)
            {
                string s = GetStr(row, "sentiment");
                if (!pf.Sentiments.Any(x =>
                    string.Compare(x, s, StringComparison.OrdinalIgnoreCase) == 0))
                    return false;
            }

            // REACH
            if (pf.TrafficMin.HasValue && pf.TrafficMax.HasValue)
            {
                long t = row["channel_subscriber_count"].Equals(DBNull.Value)
                    ? 0 : Convert.ToInt64(row["channel_subscriber_count"]);
                if (t < pf.TrafficMin.Value || t > pf.TrafficMax.Value) return false;
            }

            // SOURCE
            if (pf.SourceDomains != null && pf.SourceDomains.Count > 0)
            {
                string pub = GetStr(row, "author");
                if (!pf.SourceDomains.Any(d => MatchPublication(pub, d))) return false;
            }

            // KEYWORD + DATATAG (OR'd)
            bool hasKw = pf.Keywords != null && pf.Keywords.Count > 0;
            bool hasDt = pf.DataTagIds != null && pf.DataTagIds.Count > 0;

            if (hasKw || hasDt)
            {
                bool kwHit = false, dtHit = false;

                if (hasKw)
                {
                    string title = GetStr(row, "title");
                    string desc = GetStr(row, "Description");
                    kwHit = pf.Keywords.Any(kw =>
                        title.IndexOf(kw, StringComparison.OrdinalIgnoreCase) >= 0 ||
                        desc.IndexOf(kw, StringComparison.OrdinalIgnoreCase) >= 0);
                }

                if (hasDt)
                {
                    string raw = row["datatag_id"].Equals(DBNull.Value)
                        ? "" : row["datatag_id"].ToString();
                    if (!string.IsNullOrEmpty(raw))
                    {
                        var tags = raw.Split(',').Select(x => x.Trim()).ToList();
                        dtHit = pf.DataTagIds.Any(ct =>
                            tags.Any(at => string.Compare(at, ct,
                                StringComparison.OrdinalIgnoreCase) == 0));
                    }
                }

                if (!kwHit && !dtHit) return false;
            }

            return true;
        }

        // =====================================================================
        //  MatchPublication — mirrors SQL Source CTE CASE logic:
        //    economictimes domain → publication LIKE '%economictimes%'
        //    all others          → '.' + publication LIKE '%.domain%'
        // =====================================================================
        internal static bool MatchPublication(string publication, string domain)
        {
            domain = domain.Trim();
            if (domain.IndexOf("economictimes", StringComparison.OrdinalIgnoreCase) >= 0)
                return publication.IndexOf("economictimes", StringComparison.OrdinalIgnoreCase) >= 0;

            return ("." + publication).IndexOf("." + domain,
                StringComparison.OrdinalIgnoreCase) >= 0;
        }

        // =====================================================================
        //  BuildAlert — DataRow → eAlerts_ArticlePrint
        // =====================================================================
        // =====================================================================
        //  BuildAlert — DataRow → eAlerts_YouTube
        // =====================================================================
        internal static eAlerts_YouTube BuildAlert(DataRow dr, int enscdId, string condName)
        {
            var obj = new eAlerts_YouTube
            {
                video_id = GetInt(dr, "video_id"),
                MediaTypeID = GetInt(dr, "MediaTypeID"),
                UserID = GetStr(dr, "UserID"),
                incident_id = GetInt(dr, "incident_id"),
                entity_name = GetStr(dr, "entity_name"),
                title = GetStr(dr, "title"),
                url = GetStr(dr, "url"),
                description = GetStr(dr, "description"),
                date_time = GetStr(dr, "date_time"),
                author = GetStr(dr, "author"),
                sentiment = GetStr(dr, "sentiment"),

                channel_subscriber_count = GetStr(dr, "channel_subscriber_count"),

                TopicName = GetStr(dr, "TopicName"),
                TopicDescription = GetStr(dr, "TopicDescription"),

                Matched_ENSCDID = enscdId.ToString(),
                Condition_Name = condName
            };

            return obj;
        }


        internal static ParsedFilter ParseJson(string json, int userId, int eventId)
        {
            var pf = new ParsedFilter();
            if (string.IsNullOrWhiteSpace(json)) return pf;

            List<CriteriaItem> items;
            try { items = JsonConvert.DeserializeObject<List<CriteriaItem>>(json); }
            catch (Exception ex)
            {
                Log($"ParseJson failed UserID={userId} EventID={eventId}", ex.Message);
                return pf;
            }
            if (items == null) return pf;

            foreach (var item in items.Where(i => i.IsActive == 1))
            {
                string type = (item.ConditionType ?? "").ToLower().Trim();
                string val = item.ConditionValue ?? "";

                switch (type)
                {
                    case "sentiment":
                        pf.Sentiments = CsvSplit(val);
                        break;

                    case "reach":
                        // Format: "min-max"  e.g. "0-10000"
                        int dash = val.IndexOf('-');
                        if (dash > 0)
                        {
                            long mn, mx;
                            if (long.TryParse(val.Substring(0, dash).Trim(), out mn)
                             && long.TryParse(val.Substring(dash + 1).Trim(), out mx))
                            { pf.TrafficMin = mn; pf.TrafficMax = mx; }
                        }
                        break;

                    case "source":
                        var src = CsvSplit(val);
                        // Merge TML domains when is_tml_active = 1
                        // Joined on UserID + EventID only (matches SQL CTE — no ENSCDID)
                        if (item.IsTmlActive == 1)
                            foreach (string d in FetchTmlDomains(userId, eventId))
                                if (!src.Any(s => string.Compare(s, d,
                                        StringComparison.OrdinalIgnoreCase) == 0))
                                    src.Add(d);
                        pf.SourceDomains = src;
                        break;

                    case "keyword":
                        pf.Keywords = CsvSplit(val)
                            .Distinct(StringComparer.OrdinalIgnoreCase).ToList();
                        break;

                    case "datatag":
                        pf.DataTagIds = CsvSplit(val);
                        break;

                    default:
                        // account_type and any future unknown types — silently ignored
                        break;
                }
            }
            return pf;
        }

        internal static List<string> CsvSplit(string val) =>
            val.Split(',').Select(s => s.Trim()).Where(s => s.Length > 0).ToList();

        static List<string> FetchTmlDomains(int userId, int eventId)
        {
            var handles = new List<string>();
            var cmd = new SqlCommand();
            try
            {
                var conn = new SqlConnection(ConnE);
                cmd.Connection = conn;
                cmd.Connection.Open();
                cmd.CommandText = @"
                    SELECT DISTINCT Value
                    FROM   TargetedMediaList WITH(NOLOCK)
                    WHERE  UserID     = @U
                      AND  EventID    = @E
                      AND  PlatformID = 4
                      AND  ValueType  = 'handle'";
                cmd.CommandType = CommandType.Text;
                cmd.CommandTimeout = 30;
                cmd.Parameters.AddWithValue("@U", userId);
                cmd.Parameters.AddWithValue("@E", eventId);

                using (var rd = cmd.ExecuteReader())
                    while (rd.Read())
                        if (!rd.IsDBNull(0) && rd.GetString(0).Trim().Length > 0)
                            handles.Add(rd.GetString(0).Trim());

                if (handles.Count > 0)
                    Log($"TML UserID={userId} EventID={eventId}",
                        $"{handles.Count} pubs: {string.Join(", ", handles)}");
            }
            catch (Exception ex) { Log("FetchTmlHandles", ex.Message); }
            finally { cmd.Connection.Close(); cmd.Connection.Dispose(); }
            return handles;
        }

        internal static string GetStr(DataRow dr, string col)
        {
            try { return dr[col].Equals(DBNull.Value) ? "" : Convert.ToString(dr[col]); }
            catch { return ""; }
        }

        internal static int GetInt(DataRow dr, string col)
        {
            try { return dr[col].Equals(DBNull.Value) ? 0 : Convert.ToInt32(dr[col]); }
            catch { return 0; }
        }


        /// <summary>
        /// Old method to fetch alerts for Print from DB - now replaced by FetchFromSP which calls a new SP with improved logic to fetch only relevant alerts based on EventID
        /// </summary>
        /// <returns></returns>


        //static void Main(string[] args)
        //{
        //    try
        //    {
        //        Log("Program Start", "");
        //        List<eAlerts_YouTube> lst = new List<eAlerts_YouTube>();
        //        Log("FetchAlerts_DB_YouTube Start", "");
        //        lst = FetchAlerts_DB_YouTube();
        //        Log("FetchAlerts_DB_YouTube End", "");


        //        #region Parallel

        //        var stopWatch = Stopwatch.StartNew();
        //        ParallelOptions po = new ParallelOptions();
        //        po.MaxDegreeOfParallelism = Convert.ToInt32(System.Configuration.ConfigurationManager.AppSettings["MaxDegreeOfParallelism"]);
        //        System.Net.ServicePointManager.DefaultConnectionLimit = Convert.ToInt32(System.Configuration.ConfigurationManager.AppSettings["MaxDegreeOfParallelism"]);
        //        Parallel.For(0, lst.Count, po, i =>
        //        {
        //            try
        //            {
        //                //string strHTML = CreateHtml(lst[i]);
        //                string article_id = Convert.ToString(lst[i].video_id);
        //                string incident_id = Convert.ToString(lst[i].incident_id);
        //                //HTMLCodeToImage(strHTML, Convert.ToString(lst[i].article_id));
        //                //Log("CreateImage Start For " + Convert.ToString(lst[i].article_id), "");
        //                //lst[i].ScreenShortImageURL = CreateImage(strHTML, "ao_" + incident_id + "_" + article_id);
        //                //Log("CreateImage Start For " + Convert.ToString(lst[i].article_id), "");
        //                //lst[i].ScreenShortImageURL = Convert.ToString(lst[i].article_id) + ".jpg";
        //                ////SendNotification_News(lst[i]);

        //                Log("SendNotification_News Start For " + Convert.ToString(lst[i].video_id), "");
        //                bool IsResult = SendNotification_News(lst[i]);
        //                Log("SendNotification_News Result Is " + IsResult.ToString() + " For " + lst[i].video_id, "");
        //                Log("SendNotification_News End For " + lst[i].video_id, "");

        //                if (IsResult)
        //                {
        //                    Log("UpdateAlert_News Start For " + lst[i].video_id, "");
        //                    IsResult = UpdateAlert_News(lst[i].video_id, lst[i].MediaTypeID);
        //                    Log("UpdateAlert_News End For " + lst[i].video_id, "");
        //                }

        //            }
        //            catch (Exception ex)
        //            {
        //                Log("Loop errror for " + lst[i].video_id, ex.Message + " ->> " + ex.StackTrace);
        //            }

        //        });
        //        #endregion
        //        Log("Program End", "");
        //    }
        //    catch (Exception ex)
        //    {

        //        throw ex;
        //    }
        //}

        public static List<eAlerts_YouTube> FetchAlerts_DB_YouTube()
        {
            DataTable _dt = new DataTable();
            DataSet _dtSet = new DataSet();
            SqlCommand _sqlCommand = new SqlCommand();

            List<eAlerts_YouTube> lst = new List<eAlerts_YouTube>();
            try
            {
                SqlConnection _sqlConnection = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString_SahadevE"].ToString());

                _sqlCommand.Connection = _sqlConnection;
                _sqlCommand.Connection.Open();
                _sqlCommand.CommandText = "USP_Notification_Conditional_YouTube";
                _sqlCommand.CommandType = CommandType.Text;
                //_sqlCommand.Parameters.AddWithValue("@MessageID", "Select");
                SqlDataAdapter _sqlDataAdapter = new SqlDataAdapter(_sqlCommand);

                _sqlDataAdapter.Fill(_dtSet);

                if (_dtSet != null && _dtSet.Tables.Count > 0)
                {
                    DataTable dtReport = _dtSet.Tables[0];
                    foreach (DataRow dr in dtReport.Rows)
                    {
                        eAlerts_YouTube eUser = new eAlerts_YouTube();

                        eUser.video_id = 0;
                        if (!dr["video_id"].Equals(DBNull.Value))
                        {
                            eUser.video_id = Convert.ToInt32(dr["video_id"]);
                        }

                        eUser.MediaTypeID = 0;
                        if (!dr["MediaTypeID"].Equals(DBNull.Value))
                        {
                            eUser.MediaTypeID = Convert.ToInt32(dr["MediaTypeID"]);
                        }

                        eUser.UserID = Convert.ToString("");
                        if (!dr["UserID"].Equals(DBNull.Value))
                        {
                            eUser.UserID = Convert.ToString(dr["UserID"]);
                        }

                        eUser.incident_id = 0;
                        if (!dr["incident_id"].Equals(DBNull.Value))
                        {
                            eUser.incident_id = Convert.ToInt32(dr["incident_id"]);
                        }

                        eUser.entity_name = Convert.ToString("");
                        if (!dr["entity_name"].Equals(DBNull.Value))
                        {
                            eUser.entity_name = Convert.ToString(dr["entity_name"]);
                        }

                        eUser.title = Convert.ToString("");
                        if (!dr["title"].Equals(DBNull.Value))
                        {
                            eUser.title = Convert.ToString(dr["title"]);
                        }

                        eUser.url = Convert.ToString("");
                        if (!dr["url"].Equals(DBNull.Value))
                        {
                            eUser.url = Convert.ToString(dr["url"]);
                        }

                        eUser.description = Convert.ToString("");
                        if (!dr["description"].Equals(DBNull.Value))
                        {
                            eUser.description = Convert.ToString(dr["description"]);
                        }

                        eUser.date_time = Convert.ToString("");
                        if (!dr["date_time"].Equals(DBNull.Value))
                        {
                            eUser.date_time = Convert.ToString(dr["date_time"]);
                        }

                        eUser.author = Convert.ToString("");
                        if (!dr["author"].Equals(DBNull.Value))
                        {
                            eUser.author = Convert.ToString(dr["author"]);
                        }

                        eUser.sentiment = Convert.ToString("");
                        if (!dr["sentiment"].Equals(DBNull.Value))
                        {
                            eUser.sentiment = Convert.ToString(dr["sentiment"]);
                        }

                        //eUser.publication = Convert.ToString("");
                        //if (!dr["publication"].Equals(DBNull.Value))
                        //{
                        //    eUser.publication = Convert.ToString(dr["publication"]);
                        //}

                        //eUser.publication_icon = Convert.ToString("");
                        //if (!dr["publication_icon"].Equals(DBNull.Value))
                        //{
                        //    eUser.publication_icon = Convert.ToString(dr["publication_icon"]);
                        //}

                        //eUser.publication_type = Convert.ToString("");
                        //if (!dr["publication_type"].Equals(DBNull.Value))
                        //{
                        //    eUser.publication_type = Convert.ToString(dr["publication_type"]);
                        //}

                        //eUser.publication_category = Convert.ToString("");
                        //if (!dr["publication_category"].Equals(DBNull.Value))
                        //{
                        //    eUser.publication_category = Convert.ToString(dr["publication_category"]);
                        //}

                        //eUser.publication_da = Convert.ToString("");
                        //if (!dr["publication_da"].Equals(DBNull.Value))
                        //{
                        //    eUser.publication_da = Convert.ToString(dr["publication_da"]);
                        //}

                        //eUser.publication_traffic = Convert.ToString("");
                        //if (!dr["publication_traffic"].Equals(DBNull.Value))
                        //{
                        //    eUser.publication_traffic = Convert.ToString(dr["publication_traffic"]);
                        //}

                        //eUser.pi_score = Convert.ToString("");
                        //if (!dr["pi_score"].Equals(DBNull.Value))
                        //{
                        //    eUser.pi_score = Convert.ToString(dr["pi_score"]);
                        //}

                        //eUser.date_sort = Convert.ToString("");
                        //if (!dr["date_sort"].Equals(DBNull.Value))
                        //{
                        //    eUser.date_sort = String.Format("{0:d MMM yyyy | H:mm tt}", Convert.ToDateTime(dr["date_sort"]));
                        //}

                        //eUser.da_sort = Convert.ToString("");
                        //if (!dr["da_sort"].Equals(DBNull.Value))
                        //{
                        //    eUser.da_sort = Convert.ToString(dr["da_sort"]);
                        //}

                        //eUser.traffic_sort = Convert.ToString("");
                        //if (!dr["traffic_sort"].Equals(DBNull.Value))
                        //{
                        //    eUser.traffic_sort = Convert.ToString(dr["traffic_sort"]);
                        //}

                        //eUser.mention_type = Convert.ToString("");
                        //if (!dr["mention_type"].Equals(DBNull.Value))
                        //{
                        //    eUser.mention_type = Convert.ToString(dr["mention_type"]);
                        //}

                        eUser.lstDeviceID = Convert.ToString("");
                        if (!dr["lstDeviceID"].Equals(DBNull.Value))
                        {
                            eUser.lstDeviceID = Convert.ToString(dr["lstDeviceID"]);
                        }

                        //eUser.NotificationTypeID = Convert.ToString("");
                        //if (!dr["NotificationTypeID"].Equals(DBNull.Value))
                        //{
                        //    eUser.NotificationTypeID = Convert.ToString(dr["NotificationTypeID"]);
                        //}

                        eUser.TopicName = Convert.ToString("");
                        if (!dr["TopicName"].Equals(DBNull.Value))
                        {
                            eUser.TopicName = Convert.ToString(dr["TopicName"]);
                        }

                        eUser.TopicDescription = Convert.ToString("");
                        if (!dr["TopicDescription"].Equals(DBNull.Value))
                        {
                            eUser.TopicDescription = Convert.ToString(dr["TopicDescription"]);
                        }

                        eUser.Condition_Name = Convert.ToString("");
                        if (!dr["condition_name"].Equals(DBNull.Value))
                        {
                            eUser.Condition_Name = Convert.ToString(dr["condition_name"]);
                        }

                        eUser.Matched_ENSCDID = Convert.ToString("");
                        if (!dr["Matched_ENSCDID"].Equals(DBNull.Value))
                        {
                            eUser.Matched_ENSCDID = Convert.ToString(dr["Matched_ENSCDID"]);
                        }

                        lst.Add(eUser);
                    }
                }

            }
            catch (Exception ex)
            {
                Log("FetchAlerts_DB", ex.Message + " ->> " + ex.StackTrace);
            }
            finally
            {
                _sqlCommand.Connection.Close();
                _sqlCommand.Connection.Dispose();
            }

            return lst;
        }

        public static bool SendNotification_News(eAlerts_YouTube obj)
        {
            bool IsResult = false;
            try
            {
                HttpWebRequest request = (HttpWebRequest)WebRequest.Create(ConfigurationManager.AppSettings["URL_SendNotification"]);

                #region Device ID Array

                string cleanDeviceIds = obj.lstDeviceID ?? "";
                string deviceIdJson = "[]";

                if (!string.IsNullOrEmpty(cleanDeviceIds))
                {
                    var sb = new StringBuilder("[");
                    var devices = cleanDeviceIds.Split(',');
                    for (int i = 0; i < devices.Length; i++)
                    {
                        sb.Append("\"").Append(devices[i].Trim()).Append("\"");
                        if (i < devices.Length - 1) sb.Append(",");
                    }
                    sb.Append("]");
                    deviceIdJson = sb.ToString();
                    obj.lstDeviceID = deviceIdJson;
                }

                #endregion

                string message = string.Empty;
                string s = Convert.ToString(obj.description);
                if (!string.IsNullOrEmpty(s))
                {
                    Char[] ca = s.ToCharArray();
                    foreach (Char c in ca)
                    {
                        //if (Char.IsSymbol(c))
                        if (!(c >= 'A' && c <= 'Z') && !(c >= 'a' && c <= 'z') && !Char.IsWhiteSpace(c) && !Char.IsPunctuation(c) && !Char.IsDigit(c))
                        {
                            message = "This content includes non-English characters. Tap here to view more details";
                            break;
                        }

                    }
                }
                if (string.IsNullOrEmpty(message))
                {
                    message = Convert.ToString(obj.description);
                }

                message = message.Replace("\"", "");
                message = message.Replace("\r\n", "");

                //string strPost = "{\"title\": \"" + obj.TopicName + "\",\"message\":\""
                //    + "Online - " + message + "\",\"image\":\"" + obj.ScreenShortImageURL
                //    + "\",\"payload\":{\"messageTypeID\":\"AIH\", \"channelID\":\"ON\", \"incidentID\":\"" + obj.incident_id + "\", \"data\":{ \"primary_key\" : \"" + obj.article_id + "\" }},\"deviceID\": " + obj.lstDeviceID + "}";

                //string strPost = "{\"title\": \"" + obj.TopicName + "\",\"message\":\""
                //    + "YouTube - " + message + "\",\"payload\":{\"messageTypeID\":\"CON\", \"channelID\":\"YT\", \"incidentID\":\"" + obj.incident_id + "\", \"data\":{ \"primary_key\" : \"" + obj.video_id + "\" }},\"deviceID\": " + obj.lstDeviceID + "}";

                string strPost = "{"
                    + "\"title\":\"" + obj.TopicName + "\","
                    + "\"message\":\"YouTube - " + message + "\r\n " + obj.Condition_Name + "\","
                    + "\"payload\":{"
                        + "\"messageTypeID\":\"CON\","
                        + "\"channelID\":\"YT\","
                        + "\"incidentID\":\"" + obj.incident_id + "\","
                        + "\"data\":{"
                            + "\"primary_key\":\"" + obj.video_id + "\""
                        //+ "\"condition_name\":\"" + obj.Condition_Name + "\""
                        + "}"
                    + "},"
                    + "\"deviceID\":" + obj.lstDeviceID
                + "}";


                //Create bytes array to send Input as parameter
                byte[] bytes = System.Text.Encoding.GetEncoding("ISO-8859-1").GetBytes(strPost);

                //Set request options
                request.ContentType = "application/json; charset=utf-8";
                request.ContentLength = bytes.Length;
                request.Method = "POST";
                request.Timeout = 900000;
                request.Headers["x-api-key"] = Convert.ToString(ConfigurationManager.AppSettings["x-api-key"]);
                //request.Headers["APPversion"] = "1.0.0";
                //request.Headers["APIVersion"] = "1.0.0";
                //request.Headers["DevicePlatform"] = "W";

                //Upload bytes array to request
                using (Stream os = request.GetRequestStream())
                {
                    os.Write(bytes, 0, bytes.Length);
                }

                //Get response from Request
                using (System.Net.WebResponse resp = request.GetResponse())
                {
                    using (StreamReader sr = new StreamReader(resp.GetResponseStream()))
                    {
                        string strOutput = sr.ReadToEnd().Trim();

                        Log(strOutput, "");
                        IsResult = true;

                        if (!string.IsNullOrEmpty(obj.lstDeviceID))
                        {
                            obj.lstDeviceID = obj.lstDeviceID.ToString().Replace("[", "").Replace("]", "");
                        }

                        Log("Log_DB Start", "");
                        Log_DB(obj.video_id, obj.incident_id, obj.UserID, "", obj.lstDeviceID, strPost, strOutput, obj.Matched_ENSCDID, obj.Condition_Name);
                        Log("Log_DB Start", "");
                    }
                }
            }
            catch (Exception ex)
            {
                Log("SendNotification_News", obj.video_id + "|" + obj.incident_id + "->" + ex.Message + " ->> " + ex.StackTrace);
            }

            return IsResult;
        }

        private static void Log_DB(Int32 AOSID, Int32 TopicID, string UserID, string ImageURL, string DeviceID, string Request, string Response, string Matched_ENSCDID, string Condition_Name)
        {
            SqlCommand _sqlCommand = new SqlCommand();

            try
            {
                #region Logic for Notification Log Parameters
                List<eLog> lstLogDetails = new List<eLog>();
                //Response="{\"NotificationID\":29738,\"NotSend\":\"9829486ae2d7a82e,d76d1de010ac487a\"}";
                JObject jsonobj = new JObject();
                string NotSentDeviceIds = string.Empty;
                string ErrorCode = string.Empty;
                string ErrorMessage = string.Empty;
                string message_id = "";

                if (!string.IsNullOrEmpty(Response))
                {
                    jsonobj = JObject.Parse(Response);

                    if (!string.IsNullOrEmpty(Convert.ToString(jsonobj["NotSend"])))
                    {
                        NotSentDeviceIds = Convert.ToString(jsonobj["NotSend"]);
                    }
                    else if (!string.IsNullOrEmpty(Convert.ToString(jsonobj["Message"])))
                    {
                        ErrorCode = Convert.ToString(jsonobj["Code"]);
                        ErrorMessage = Convert.ToString(jsonobj["Message"]);
                    }
                    string id = jsonobj["data"]?["id"]?.ToString();

                    if (!string.IsNullOrEmpty(id))
                    {
                        message_id = id;
                    }

                }

                string[] FailedDeviceIds = null;

                if (!string.IsNullOrEmpty(NotSentDeviceIds))
                {
                    FailedDeviceIds = NotSentDeviceIds.Split(',');
                }

                if (!string.IsNullOrEmpty(UserID) && !string.IsNullOrEmpty(DeviceID))
                {
                    string[] userids = UserID.Split(',');

                    DeviceID = DeviceID.Replace("\"", "");
                    string[] deviceids = DeviceID.Split(',');
                    //List<string> deviceids = JsonConvert.DeserializeObject<List<string>>(DeviceID);

                    for (int i = 0; i < deviceids.Length; i++)
                    {
                        eLog obj = new eLog();
                        obj.UserID = Convert.ToString(userids[i]);
                        obj.DeviceID = Convert.ToString(deviceids[i]);

                        if (!string.IsNullOrEmpty(ErrorCode) && !string.IsNullOrEmpty(ErrorMessage))
                        {
                            obj.Status = "Failed";
                            obj.ErrorCode = ErrorCode;
                            obj.ErrorMessage = ErrorMessage;
                        }
                        else if (!string.IsNullOrEmpty(NotSentDeviceIds) && FailedDeviceIds.Any(deviceId => deviceId == Convert.ToString(deviceids[i])))
                        {
                            obj.Status = "Failed";
                        }
                        else
                        {
                            obj.Status = "Success";
                        }

                        lstLogDetails.Add(obj);
                    }
                }
                #endregion



                SqlConnection _sqlConnection = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString_SahadevC2"].ToString());
                DataSet _dtSet = new DataSet();

                _sqlCommand.Connection = _sqlConnection;
                _sqlCommand.Connection.Open();
                _sqlCommand.CommandText = "USP_Service_Insert_SentryV2_Notification_Log_Conditional";
                _sqlCommand.CommandType = CommandType.StoredProcedure;
                _sqlCommand.Parameters.AddWithValue("@RecordID", AOSID);
                //_sqlCommand.Parameters.AddWithValue("@UserID", UserID);
                _sqlCommand.Parameters.AddWithValue("@TopicID", TopicID);
                _sqlCommand.Parameters.AddWithValue("@MediaTypeID", 4);
                _sqlCommand.Parameters.AddWithValue("@ImageURL", ImageURL);
                _sqlCommand.Parameters.AddWithValue("@lstDeviceID", DeviceID);
                _sqlCommand.Parameters.AddWithValue("@Request", Request);
                _sqlCommand.Parameters.AddWithValue("@Response", Response);
                _sqlCommand.Parameters.AddWithValue("@Message_ID", message_id);
                //_sqlCommand.Parameters.AddWithValue("@FromDate", Convert.ToDateTime(FromDate));
                //_sqlCommand.Parameters.AddWithValue("@ToDate", Convert.ToDateTime(ToDate));

                SqlDataAdapter _sqlDataAdapter = new SqlDataAdapter(_sqlCommand);

                _sqlDataAdapter.Fill(_dtSet);
                int NLID = 0;
                if (_dtSet != null && _dtSet.Tables.Count > 0)
                {
                    DataTable dtReport = _dtSet.Tables[0];
                    foreach (DataRow dr in dtReport.Rows)
                    {
                        if (!dr["NLID"].Equals(DBNull.Value))
                        {
                            NLID = Convert.ToInt32(dr["NLID"]);
                        }
                    }
                }
                //int NLID = Convert.ToInt32(_sqlCommand.ExecuteNonQuery());

                Log("NLID", Convert.ToString(NLID));
                _sqlCommand.Connection.Close();

                //Insert Into Notification Log Detail

                if (NLID > 0)
                {
                    for (int i = 0; i < lstLogDetails.Count; i++)
                    {
                        SqlCommand _sqlCommand1 = new SqlCommand();
                        _sqlCommand1.Connection = _sqlConnection;
                        _sqlCommand1.Connection.Open();
                        _sqlCommand1.CommandText = "USP_Service_Insert_SentryV2_Notification_Log_Conditional_Detail_NewLogic";
                        _sqlCommand1.CommandType = CommandType.StoredProcedure;
                        _sqlCommand1.Parameters.AddWithValue("@NLID", NLID);
                        _sqlCommand1.Parameters.AddWithValue("@RecordID", AOSID);
                        //_sqlCommand.Parameters.AddWithValue("@UserID", UserID);
                        _sqlCommand1.Parameters.AddWithValue("@TopicID", TopicID);
                        _sqlCommand1.Parameters.AddWithValue("@MediaTypeID", 4);
                        _sqlCommand1.Parameters.AddWithValue("@UserID", lstLogDetails[i].UserID);
                        _sqlCommand1.Parameters.AddWithValue("@DeviceID", lstLogDetails[i].DeviceID);
                        _sqlCommand1.Parameters.AddWithValue("@Status", lstLogDetails[i].Status);
                        _sqlCommand1.Parameters.AddWithValue("@Matched_ENSCDID", Matched_ENSCDID);
                        _sqlCommand1.Parameters.AddWithValue("@Condition_Name", Condition_Name);

                        _sqlCommand1.ExecuteNonQuery();
                        _sqlCommand1.Connection.Close();
                    }
                }

            }
            catch (Exception ex)
            {
                Log("Log_DB", ex.Message + " ->> " + ex.StackTrace);
            }

        }

        public static bool UpdateAlert_News(Int32 ArticleID, Int32 MediaTypeID)
        {
            bool IsResult = false;
            SqlCommand _sqlCommand = new SqlCommand();

            try
            {
                SqlConnection _sqlConnection = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString_SahadevD"].ToString());

                _sqlCommand.Connection = _sqlConnection;
                _sqlCommand.Connection.Open();
                _sqlCommand.CommandText = "USP_Service_UpdateAlerts_Article";
                _sqlCommand.CommandType = CommandType.StoredProcedure;
                //_sqlCommand.CommandText = "UPDATE [203.115.122.28].[ADF_SAHADEV].[dbo].[Sencheck] SET IsNotified=1 WHERE ArticleID ='" + ArticleID + "'";
                _sqlCommand.Parameters.AddWithValue("@ArticleID", ArticleID);
                _sqlCommand.Parameters.AddWithValue("@MediaTypeID", MediaTypeID);
                int result = Convert.ToInt32(_sqlCommand.ExecuteNonQuery());
                if (result > 0)
                {
                    IsResult = true;
                }
            }
            catch (Exception ex)
            {
                Log("UpdateAlert_News", ex.Message + " ->> " + ex.StackTrace);
            }
            finally
            {
                _sqlCommand.Connection.Close();
                _sqlCommand.Connection.Dispose();
            }

            return IsResult;
        }

        #region LOGGING

        //For error logging
        private static void ErrorLog(string functionName, string error)
        {
            try
            {
                string LogPath = ConfigurationManager.AppSettings["ErrorLogPath"];
                using (TextWriter myWriter = File.AppendText(LogPath))
                {

                    TextWriter.Synchronized(myWriter).WriteLine("<--> :{0}", string.Empty);
                    TextWriter.Synchronized(myWriter).WriteLine("Function Name :{0}", functionName);
                    TextWriter.Synchronized(myWriter).WriteLine("Error :{0}", error);
                    TextWriter.Synchronized(myWriter).WriteLine("Date :{0}", DateTime.Now.ToString());
                    TextWriter.Synchronized(myWriter).WriteLine("<--> :{0}", string.Empty);
                    TextWriter.Synchronized(myWriter).Flush();
                    TextWriter.Synchronized(myWriter).Close();
                }
            }
            catch (Exception ex)
            {
            }
        }

        //For debugging purpose
        private static void TimeLog(string strtext)
        {
            try
            {
                string LogPath = ConfigurationManager.AppSettings["TimeLogPath"];
                using (TextWriter myWriter = File.AppendText(LogPath))
                {

                    TextWriter.Synchronized(myWriter).WriteLine("<--> :{0}", string.Empty);
                    TextWriter.Synchronized(myWriter).WriteLine("TimeLog :{0}", strtext);
                    TextWriter.Synchronized(myWriter).WriteLine("Date :{0}", DateTime.Now.ToString());
                    TextWriter.Synchronized(myWriter).WriteLine("<--> :{0}", string.Empty);
                    TextWriter.Synchronized(myWriter).Flush();
                    TextWriter.Synchronized(myWriter).Close();
                }
            }
            catch (Exception ex)
            {
                ErrorLog("TimeLog", ex.ToString());
            }
        }


        private static void Log(string functionName, string error)
        {
            try
            {
                string LogPath = ConfigurationManager.AppSettings["LogPath"].ToString();
                using (TextWriter myWriter = File.AppendText(LogPath))
                {

                    TextWriter.Synchronized(myWriter).WriteLine("<--> :{0}", string.Empty);
                    TextWriter.Synchronized(myWriter).WriteLine("Function Name :{0}", functionName);
                    if (!String.IsNullOrEmpty(error))
                    {
                        TextWriter.Synchronized(myWriter).WriteLine("Error :{0}", error);
                    }
                    TextWriter.Synchronized(myWriter).WriteLine("Date :{0}", DateTime.Now.ToString());
                    TextWriter.Synchronized(myWriter).WriteLine("<--> :{0}", string.Empty);
                    TextWriter.Synchronized(myWriter).Flush();
                    TextWriter.Synchronized(myWriter).Close();
                }

            }
            catch (Exception ex)
            {
            }
        }

        #endregion
    }
}
