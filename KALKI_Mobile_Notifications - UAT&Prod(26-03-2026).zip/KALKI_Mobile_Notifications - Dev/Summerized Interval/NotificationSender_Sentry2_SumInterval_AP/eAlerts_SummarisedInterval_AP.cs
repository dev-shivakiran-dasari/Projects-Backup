﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace NotificationSender_Sentry2_SumInterval_AP
{

    [DataContract]
    public class eAlerts_SummarisedInterval_AP
    {
        [DataMember]
        public Int32 APSID { get; set; }

        [DataMember]
        public Int32 NLID { get; set; }

        [DataMember]
        public Int32 TopicID { get; set; }

        [DataMember]
        public string TopicName { get; set; }

        [DataMember]
        public string UserID { get; set; }

        [DataMember]
        public Int32 Platform_SummarisedInterval { get; set; }

        [DataMember]
        public string FromDate { get; set; }

        [DataMember]
        public string ToDate { get; set; }

        [DataMember]
        public string DeviceID { get; set; }

        [DataMember]
        public string Volume { get; set; }

        [DataMember]
        public string summary { get; set; }

        [DataMember]
        public string scheduled_qualitative_summary { get; set; }

        [DataMember]
        public string landing_summary { get; set; }

        [DataMember]
        public string error { get; set; }

        [DataMember]
        public string ScreenShortImageURL { get; set; }

        [DataMember]
        public string Prev_FromDate { get; set; }

        [DataMember]
        public string Prev_ToDate { get; set; }

        [DataMember]
        public string Base_Date { get; set; }
    }
}
