﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace NotificationSender_Sentry2_SumInterval_TWT
{
    public class DAL
    {
    }
}
