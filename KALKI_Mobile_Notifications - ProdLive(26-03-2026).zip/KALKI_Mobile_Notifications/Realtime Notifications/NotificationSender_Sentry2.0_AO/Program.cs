﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.IO;
using System.Net;
using System.Threading;
using System.Windows.Forms;
using System.Drawing;
using System.Web;
using System.Diagnostics;
using System.Threading.Tasks;
using Newtonsoft.Json.Linq;

namespace NotificationSender_Sentry2._0_AO
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                Log("Program Start", "");
                List<eAlerts_ArticleOnline> lst = new List<eAlerts_ArticleOnline>();
                Log("FetchAlerts_DB_Online Start", "");
                lst = FetchAlerts_DB_Online();
                Log("FetchAlerts_DB_Online End", "");
                //for (int i = 0; i < lst.Count; i++)
                //{
                //    string strHTML = CreateHtml(lst[i]);
                //    string article_id = Convert.ToString(lst[i].article_id);
                //    //HTMLCodeToImage(strHTML, Convert.ToString(lst[i].article_id));
                //    CreateImage(strHTML, article_id);
                //    lst[i].ScreenShortImageURL = Convert.ToString(lst[i].article_id) + ".jpg";
                //    //SendNotification_News(lst[i]);
                //}

                #region Parallel

                var stopWatch = Stopwatch.StartNew();
                ParallelOptions po = new ParallelOptions();
                po.MaxDegreeOfParallelism = Convert.ToInt32(System.Configuration.ConfigurationManager.AppSettings["MaxDegreeOfParallelism"]);
                System.Net.ServicePointManager.DefaultConnectionLimit = Convert.ToInt32(System.Configuration.ConfigurationManager.AppSettings["MaxDegreeOfParallelism"]);
                Parallel.For(0, lst.Count, po, i =>
                {
                    try
                    {
                        //string strHTML = CreateHtml(lst[i]);
                        string article_id = Convert.ToString(lst[i].article_id);
                        string incident_id = Convert.ToString(lst[i].incident_id);
                        ////HTMLCodeToImage(strHTML, Convert.ToString(lst[i].article_id));
                        //Log("CreateImage Start For " + Convert.ToString(lst[i].article_id), "");
                        //lst[i].ScreenShortImageURL = CreateImage(strHTML, "ao_" + incident_id + "_" + article_id);
                        //Log("CreateImage Start For " + Convert.ToString(lst[i].article_id), "");
                        ////lst[i].ScreenShortImageURL = Convert.ToString(lst[i].article_id) + ".jpg";
                        ////SendNotification_News(lst[i]);


                        Log("SendNotification_News Start For " + Convert.ToString(lst[i].article_id), "");
                        bool IsResult = SendNotification_News(lst[i]);
                        Log("SendNotification_News Result Is " + IsResult.ToString() + " For " + lst[i].article_id, "");
                        Log("SendNotification_News End For " + lst[i].article_id, "");

                        if (IsResult)
                        {
                            Log("UpdateAlert_News Start For " + lst[i].article_id, "");
                            IsResult = UpdateAlert_News(lst[i].article_id, lst[i].MediaTypeID);
                            Log("UpdateAlert_News End For " + lst[i].article_id, "");
                        }
                        

                    }
                    catch (Exception ex)
                    {
                        Log("Loop errror for " + lst[i].article_id, ex.Message + " ->> " + ex.StackTrace);
                    }

                });
                #endregion
                Log("Program End", "");
            }
            catch (Exception ex)
            {
                Log("Main", ex.Message + " ->> " + ex.StackTrace);
            }
        }

        public static List<eAlerts_ArticleOnline> FetchAlerts_DB_Online()
        {
            DataTable _dt = new DataTable();
            DataSet _dtSet = new DataSet();
            SqlCommand _sqlCommand = new SqlCommand();

            List<eAlerts_ArticleOnline> lst = new List<eAlerts_ArticleOnline>();
            try
            {
                SqlConnection _sqlConnection = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString_SahadevE"].ToString());

                _sqlCommand.Connection = _sqlConnection;
                _sqlCommand.Connection.Open();
                _sqlCommand.CommandText = "USP_Notification_RealTime_Online";
                _sqlCommand.CommandType = CommandType.Text;
                //_sqlCommand.Parameters.AddWithValue("@MessageID", "Select");
                SqlDataAdapter _sqlDataAdapter = new SqlDataAdapter(_sqlCommand);

                _sqlDataAdapter.Fill(_dtSet);

                if (_dtSet != null && _dtSet.Tables.Count > 0)
                {
                    DataTable dtReport = _dtSet.Tables[0];
                    foreach (DataRow dr in dtReport.Rows)
                    {
                        eAlerts_ArticleOnline eUser = new eAlerts_ArticleOnline();

                        eUser.article_id = 0;
                        if (!dr["article_id"].Equals(DBNull.Value))
                        {
                            eUser.article_id = Convert.ToInt32(dr["article_id"]);
                        }

                        eUser.MediaTypeID = 0;
                        if (!dr["MediaTypeID"].Equals(DBNull.Value))
                        {
                            eUser.MediaTypeID = Convert.ToInt32(dr["MediaTypeID"]);
                        }

                        eUser.UserID = Convert.ToString("");
                        if (!dr["UserID"].Equals(DBNull.Value))
                        {
                            eUser.UserID = Convert.ToString(dr["UserID"]);
                        }

                        eUser.incident_id = 0;
                        if (!dr["incident_id"].Equals(DBNull.Value))
                        {
                            eUser.incident_id = Convert.ToInt32(dr["incident_id"]);
                        }

                        eUser.entity_name = Convert.ToString("");
                        if (!dr["entity_name"].Equals(DBNull.Value))
                        {
                            eUser.entity_name = Convert.ToString(dr["entity_name"]);
                        }

                        eUser.title = Convert.ToString("");
                        if (!dr["title"].Equals(DBNull.Value))
                        {
                            eUser.title = Convert.ToString(dr["title"]);
                        }

                        eUser.url = Convert.ToString("");
                        if (!dr["url"].Equals(DBNull.Value))
                        {
                            eUser.url = Convert.ToString(dr["url"]);
                        }

                        eUser.description = Convert.ToString("");
                        if (!dr["description"].Equals(DBNull.Value))
                        {
                            eUser.description = Convert.ToString(dr["description"]);
                        }

                        eUser.date_time = Convert.ToString("");
                        if (!dr["date_time"].Equals(DBNull.Value))
                        {
                            eUser.date_time = Convert.ToString(dr["date_time"]);
                        }

                        eUser.author = Convert.ToString("");
                        if (!dr["author"].Equals(DBNull.Value))
                        {
                            eUser.author = Convert.ToString(dr["author"]);
                        }

                        eUser.sentiment = Convert.ToString("");
                        if (!dr["sentiment"].Equals(DBNull.Value))
                        {
                            eUser.sentiment = Convert.ToString(dr["sentiment"]);
                        }

                        eUser.publication = Convert.ToString("");
                        if (!dr["publication"].Equals(DBNull.Value))
                        {
                            eUser.publication = Convert.ToString(dr["publication"]);
                        }

                        eUser.publication_icon = Convert.ToString("");
                        if (!dr["publication_icon"].Equals(DBNull.Value))
                        {
                            eUser.publication_icon = Convert.ToString(dr["publication_icon"]);
                        }

                        eUser.publication_type = Convert.ToString("");
                        if (!dr["publication_type"].Equals(DBNull.Value))
                        {
                            eUser.publication_type = Convert.ToString(dr["publication_type"]);
                        }

                        eUser.publication_category = Convert.ToString("");
                        if (!dr["publication_category"].Equals(DBNull.Value))
                        {
                            eUser.publication_category = Convert.ToString(dr["publication_category"]);
                        }

                        eUser.publication_da = Convert.ToString("");
                        if (!dr["publication_da"].Equals(DBNull.Value))
                        {
                            eUser.publication_da = Convert.ToString(dr["publication_da"]);
                        }

                        eUser.publication_traffic = Convert.ToString("");
                        if (!dr["publication_traffic"].Equals(DBNull.Value))
                        {
                            eUser.publication_traffic = Convert.ToString(dr["publication_traffic"]);
                        }

                        eUser.pi_score = Convert.ToString("");
                        if (!dr["pi_score"].Equals(DBNull.Value))
                        {
                            eUser.pi_score = Convert.ToString(dr["pi_score"]);
                        }

                        eUser.date_sort = Convert.ToString("");
                        if (!dr["date_sort"].Equals(DBNull.Value))
                        {
                            eUser.date_sort = String.Format("{0:d MMM yyyy | H:mm tt}", Convert.ToDateTime(dr["date_sort"]));
                        }

                        eUser.da_sort = Convert.ToString("");
                        if (!dr["da_sort"].Equals(DBNull.Value))
                        {
                            eUser.da_sort = Convert.ToString(dr["da_sort"]);
                        }

                        eUser.traffic_sort = Convert.ToString("");
                        if (!dr["traffic_sort"].Equals(DBNull.Value))
                        {
                            eUser.traffic_sort = Convert.ToString(dr["traffic_sort"]);
                        }

                        eUser.mention_type = Convert.ToString("");
                        if (!dr["mention_type"].Equals(DBNull.Value))
                        {
                            eUser.mention_type = Convert.ToString(dr["mention_type"]);
                        }

                        eUser.lstDeviceID = Convert.ToString("");
                        if (!dr["lstDeviceID"].Equals(DBNull.Value))
                        {
                            eUser.lstDeviceID = Convert.ToString(dr["lstDeviceID"]);
                        }

                        eUser.NotificationTypeID = Convert.ToString("");
                        if (!dr["NotificationTypeID"].Equals(DBNull.Value))
                        {
                            eUser.NotificationTypeID = Convert.ToString(dr["NotificationTypeID"]);
                        }

                        eUser.TopicName = Convert.ToString("");
                        if (!dr["TopicName"].Equals(DBNull.Value))
                        {
                            eUser.TopicName = Convert.ToString(dr["TopicName"]);
                        }

                        eUser.TopicDescription = Convert.ToString("");
                        if (!dr["TopicDescription"].Equals(DBNull.Value))
                        {
                            eUser.TopicDescription = Convert.ToString(dr["TopicDescription"]);
                        }
                        lst.Add(eUser);
                    }
                }

            }
            catch (Exception ex)
            {
                Log("FetchAlerts_DB", ex.Message + " ->> " + ex.StackTrace);
            }
            finally
            {
                _sqlCommand.Connection.Close();
                _sqlCommand.Connection.Dispose();
            }

            return lst;
        }

        static string CreateHtml(eAlerts_ArticleOnline obj)
        {
            string strHTML = string.Empty;

            try
            {
                strHTML = System.IO.File.ReadAllText(Convert.ToString(ConfigurationManager.AppSettings["OnlineHTML"]));
                //strHTML = System.IO.File.ReadAllText(@"D:\Shivakiran\Notification Sender Sentry 2.0\TwitterHTML.txt");
                //strHTML = strHTML.Replace("#TopicName#", obj.TopicName);
                strHTML = strHTML.Replace("#date_time#", obj.date_time);
                strHTML = strHTML.Replace("#title#", obj.title);
                strHTML = strHTML.Replace("#date_time#", obj.date_time);
                strHTML = strHTML.Replace("#publication#", obj.publication);
                strHTML = strHTML.Replace("#da_sort#", Convert.ToString(obj.da_sort));
                strHTML = strHTML.Replace("#publication_type#", Convert.ToString(obj.publication_type));
                strHTML = strHTML.Replace("#pi_score#", Convert.ToString(obj.pi_score));
                strHTML = strHTML.Replace("#description#", obj.description);
                strHTML = strHTML.Replace("#traffic_sort#", Convert.ToString(obj.traffic_sort));
            }
            catch (Exception ex)
            {
                ErrorLog("CreateHtml", Convert.ToString(obj.article_id));
                throw ex;
            }

            return strHTML;
        }

        public static bool SendNotification_News(eAlerts_ArticleOnline obj)
        {
            bool IsResult = false;
            try
            {
                HttpWebRequest request = (HttpWebRequest)WebRequest.Create(ConfigurationManager.AppSettings["URL_SendNotification"]);

                #region Device ID Array


                if (!string.IsNullOrEmpty(obj.lstDeviceID))
                {
                    string input = obj.lstDeviceID;
                    string[] values = input.Split(',');

                    List<string> outputList = new List<string>();
                    foreach (string value in values)
                    {
                        outputList.Add(value.Trim());
                    }

                    StringBuilder jsonBuilder = new StringBuilder();
                    jsonBuilder.Append("[");
                    for (int i = 0; i < outputList.Count; i++)
                    {
                        jsonBuilder.Append("\"").Append(outputList[i]).Append("\"");
                        if (i < outputList.Count - 1)
                        {
                            jsonBuilder.Append(",");
                        }
                    }
                    jsonBuilder.Append("]");

                    obj.lstDeviceID = jsonBuilder.ToString();
                }

                #endregion

                string message = string.Empty;
                string s = Convert.ToString(obj.title);
                if (!string.IsNullOrEmpty(s))
                {
                    Char[] ca = s.ToCharArray();
                    foreach (Char c in ca)
                    {
                        //if (Char.IsSymbol(c))
                        if (!(c >= 'A' && c <= 'Z') && !(c >= 'a' && c <= 'z') && !Char.IsWhiteSpace(c) && !Char.IsPunctuation(c) && !Char.IsDigit(c))
                        {
                            message = "This content includes non-English characters. Tap here to view more details";
                            break;
                        }

                    }
                }
                if (string.IsNullOrEmpty(message))
                {
                    message = Convert.ToString(obj.title);
                }

                message = message.Replace("\"", "");

                string strPost = "{\"title\": \"" + obj.TopicName + "\",\"message\":\""
                    + "Online - "+message + "\",\"image\":\"" + obj.ScreenShortImageURL
                    + "\",\"payload\":{\"messageTypeID\":\"AIH\", \"channelID\":\"ON\", \"incidentID\":\"" + obj.incident_id + "\", \"data\":{ \"primary_key\" : \"" + obj.article_id + "\" }},\"deviceID\": " + obj.lstDeviceID + "}";

                //Create bytes array to send Input as parameter
                byte[] bytes = System.Text.Encoding.GetEncoding("ISO-8859-1").GetBytes(strPost);

                Log("strPost Start", Convert.ToString(strPost));

                //Set request options
                request.ContentType = "application/json; charset=utf-8";
                request.ContentLength = bytes.Length;
                request.Method = "POST";
                request.Timeout = 900000;
                request.Headers["x-api-key"] = Convert.ToString(ConfigurationManager.AppSettings["x-api-key"]);
                //request.Headers["APPversion"] = "1.0.0";
                //request.Headers["APIVersion"] = "1.0.0";
                //request.Headers["DevicePlatform"] = "W";

                //Upload bytes array to request
                using (Stream os = request.GetRequestStream())
                {
                    os.Write(bytes, 0, bytes.Length);
                }

                //Get response from Request
                using (System.Net.WebResponse resp = request.GetResponse())
                {
                    using (StreamReader sr = new StreamReader(resp.GetResponseStream()))
                    {
                        string strOutput = sr.ReadToEnd().Trim();

                        Log(strOutput, "");
                        IsResult = true;

                        if (!string.IsNullOrEmpty(obj.lstDeviceID))
                        {
                            obj.lstDeviceID = obj.lstDeviceID.ToString().Replace("[", "").Replace("]", "");
                        }

                        Log("Log_DB Start", "");
                        Log_DB(obj.article_id, obj.incident_id,obj.UserID, obj.ScreenShortImageURL, obj.lstDeviceID, strPost, strOutput);
                        Log("Log_DB Start", "");
                    }
                }
            }
            catch (Exception ex)
            {
                Log("SendNotification_News", obj.article_id + "|" + obj.incident_id + "->" + ex.Message + " ->> " + ex.StackTrace);
            }

            return IsResult;
        }


        private static void Log_DB(Int32 AOSID, Int32 TopicID, string UserID, string ImageURL, string DeviceID, string Request, string Response)
        {
            SqlCommand _sqlCommand = new SqlCommand();
            
            try
            {
                #region Logic for Notification Log Parameters
                List<eLog> lstLogDetails = new List<eLog>();
                //Response="{\"NotificationID\":29738,\"NotSend\":\"9829486ae2d7a82e,d76d1de010ac487a\"}";
                JObject jsonobj = new JObject();
                string NotSentDeviceIds = string.Empty;
                string ErrorCode = string.Empty;
                string ErrorMessage = string.Empty;
                string message_id = "";

                if (!string.IsNullOrEmpty(Response))
                {
                    jsonobj = JObject.Parse(Response);

                    if (!string.IsNullOrEmpty(Convert.ToString(jsonobj["NotSend"])))
                    {
                        NotSentDeviceIds = Convert.ToString(jsonobj["NotSend"]);
                    }
                    else if (!string.IsNullOrEmpty(Convert.ToString(jsonobj["Message"])))
                    {
                        ErrorCode = Convert.ToString(jsonobj["Code"]);
                        ErrorMessage = Convert.ToString(jsonobj["Message"]);
                    }

                    string id = jsonobj["data"]?["id"]?.ToString();

                    if (!string.IsNullOrEmpty(id))
                    {
                        message_id = id;
                    }
                }

                string[] FailedDeviceIds = null;

                if (!string.IsNullOrEmpty(NotSentDeviceIds))
                {
                    FailedDeviceIds = NotSentDeviceIds.Split(',');
                }

                if (!string.IsNullOrEmpty(UserID) && !string.IsNullOrEmpty(DeviceID))
                {
                    string[] userids = UserID.Split(',');

                    DeviceID = DeviceID.Replace("\"", "");
                    string[] deviceids = DeviceID.Split(',');
                    //List<string> deviceids = JsonConvert.DeserializeObject<List<string>>(DeviceID);

                    for (int i = 0; i < deviceids.Length; i++)
                    {
                        eLog obj = new eLog();
                        obj.UserID = Convert.ToString(userids[i]);
                        obj.DeviceID = Convert.ToString(deviceids[i]);

                        if (!string.IsNullOrEmpty(ErrorCode) && !string.IsNullOrEmpty(ErrorMessage))
                        {
                            obj.Status = "Failed";
                            obj.ErrorCode = ErrorCode;
                            obj.ErrorMessage = ErrorMessage;
                        }
                        else if (!string.IsNullOrEmpty(NotSentDeviceIds) && FailedDeviceIds.Any(deviceId => deviceId == Convert.ToString(deviceids[i])))
                        {
                            obj.Status = "Failed";
                        }
                        else
                        {
                            obj.Status = "Success";
                        }

                        lstLogDetails.Add(obj);
                    }
                }
                #endregion



                SqlConnection _sqlConnection = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString_SahadevC2"].ToString());
                DataSet _dtSet = new DataSet();

                _sqlCommand.Connection = _sqlConnection;
                _sqlCommand.Connection.Open();
                _sqlCommand.CommandText = "USP_Service_Insert_SentryV2_Notification_Log";
                _sqlCommand.CommandType = CommandType.StoredProcedure;
                _sqlCommand.Parameters.AddWithValue("@RecordID", AOSID);
                //_sqlCommand.Parameters.AddWithValue("@UserID", UserID);
                _sqlCommand.Parameters.AddWithValue("@TopicID", TopicID);
                _sqlCommand.Parameters.AddWithValue("@MediaTypeID", 1);
                _sqlCommand.Parameters.AddWithValue("@ImageURL", ImageURL);
                _sqlCommand.Parameters.AddWithValue("@lstDeviceID", DeviceID);
                _sqlCommand.Parameters.AddWithValue("@Request", Request);
                _sqlCommand.Parameters.AddWithValue("@Response", Response);
                _sqlCommand.Parameters.AddWithValue("@Message_ID", message_id);
                //_sqlCommand.Parameters.AddWithValue("@FromDate", Convert.ToDateTime(FromDate));
                //_sqlCommand.Parameters.AddWithValue("@ToDate", Convert.ToDateTime(ToDate));


                SqlDataAdapter _sqlDataAdapter = new SqlDataAdapter(_sqlCommand);

                _sqlDataAdapter.Fill(_dtSet);
                int NLID = 0;
                if (_dtSet != null && _dtSet.Tables.Count > 0)
                {
                    DataTable dtReport = _dtSet.Tables[0];
                    foreach (DataRow dr in dtReport.Rows)
                    {
                        if (!dr["NLID"].Equals(DBNull.Value))
                        {
                            NLID = Convert.ToInt32(dr["NLID"]);
                        }
                    }
                }
                //int NLID = Convert.ToInt32(_sqlCommand.ExecuteNonQuery());

                Log("NLID", Convert.ToString(NLID));
                _sqlCommand.Connection.Close();

                //Insert Into Notification Log Detail

                if (NLID > 0)
                {
                    for (int i = 0; i < lstLogDetails.Count; i++)
                    {
                        SqlCommand _sqlCommand1 = new SqlCommand();
                        _sqlCommand1.Connection = _sqlConnection;
                        _sqlCommand1.Connection.Open();
                        _sqlCommand1.CommandText = "USP_Service_Insert_SentryV2_Notification_Log_Detail";
                        _sqlCommand1.CommandType = CommandType.StoredProcedure;
                        _sqlCommand1.Parameters.AddWithValue("@NLID", NLID);
                        _sqlCommand1.Parameters.AddWithValue("@RecordID", AOSID);
                        //_sqlCommand.Parameters.AddWithValue("@UserID", UserID);
                        _sqlCommand1.Parameters.AddWithValue("@TopicID", TopicID);
                        _sqlCommand1.Parameters.AddWithValue("@MediaTypeID", 1);
                        _sqlCommand1.Parameters.AddWithValue("@UserID", lstLogDetails[i].UserID);
                        _sqlCommand1.Parameters.AddWithValue("@DeviceID", lstLogDetails[i].DeviceID);
                        _sqlCommand1.Parameters.AddWithValue("@Status", lstLogDetails[i].Status);
                        _sqlCommand.Parameters.AddWithValue("@Message_ID", message_id);

                        _sqlCommand1.ExecuteNonQuery();
                        _sqlCommand1.Connection.Close();
                    }
                }

            }
            catch (Exception ex)
            {
                Log("Log_DB", ex.Message + " ->> " + ex.StackTrace);
            }

        }

        //private static void Log_DB(Int32 article_id, Int32 incident_id, string ImageURL, string lstDeviceID, string Request, string Response)
        //{
        //    SqlCommand _sqlCommand = new SqlCommand();

        //    try
        //    {
        //        SqlConnection _sqlConnection = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ToString());

        //        _sqlCommand.Connection = _sqlConnection;
        //        _sqlCommand.Connection.Open();
        //        _sqlCommand.CommandText = "USP_Service_Insert_SentryV2_Notification_Log";
        //        _sqlCommand.CommandType = CommandType.StoredProcedure;
        //        _sqlCommand.Parameters.AddWithValue("@RecordID", article_id);
        //        _sqlCommand.Parameters.AddWithValue("@TopicID", incident_id);
        //        _sqlCommand.Parameters.AddWithValue("@MediaTypeID", 1);
        //        _sqlCommand.Parameters.AddWithValue("@ImageURL", ImageURL);
        //        _sqlCommand.Parameters.AddWithValue("@lstDeviceID", lstDeviceID);
        //        _sqlCommand.Parameters.AddWithValue("@Request", Request);
        //        _sqlCommand.Parameters.AddWithValue("@Response", Response);

        //        int result = Convert.ToInt32(_sqlCommand.ExecuteNonQuery());

        //    }
        //    catch (Exception ex)
        //    {
        //        Log("Log_DB", ex.Message + " ->> " + ex.StackTrace);
        //    }

        //}

        public static void HTMLCodeToImage(string strHTML, string ImageName)
        {
            //Create a new thread for each WebBrowser instance
            Thread thread = new Thread(() =>
            {
                try
                {
                    //Ensure that the thread is in STA mode
                    if (Thread.CurrentThread.GetApartmentState() != ApartmentState.STA)
                    {
                        Thread.CurrentThread.SetApartmentState(ApartmentState.STA);
                    }

                    //Create a new WebBrowser control
                    WebBrowser webBrowser = new WebBrowser();

                    //Set the size of the WebBrowser control
                    webBrowser.Width = 800; // Set the desired width
                    webBrowser.Height = 600; // Set the desired height

                    //Navigate the WebBrowser control to a blank page
                    webBrowser.Navigate("about:blank");

                    //Wait for the WebBrowser control to finish loading
                    webBrowser.DocumentCompleted += (sender, e) =>
                    {
                        try
                        {
                            //Set the HTML content of the WebBrowser control
                            webBrowser.Document.Write(strHTML);

                            //Create a Bitmap object to store the rendered image
                            Bitmap bitmap = new Bitmap(webBrowser.Width, webBrowser.Height);

                            //Render the WebBrowser control to the bitmap
                            webBrowser.DrawToBitmap(bitmap, new Rectangle(0, 0, webBrowser.Width, webBrowser.Height));

                            //Save the image to a file
                            string outputPath = ConfigurationManager.AppSettings["ImageSavePath"].ToString() + ImageName + ".jpg";
                            bitmap.Save(outputPath, System.Drawing.Imaging.ImageFormat.Png);

                            //Console.WriteLine("Image saved as: " + System.IO.Path.GetFullPath(outputPath));
                            Log("Success", "Image saved as: " + System.IO.Path.GetFullPath(outputPath));

                            bitmap.Dispose();
                            webBrowser.Dispose();

                        }
                        catch (Exception ex)
                        {
                            Log("Failure", "Exception occurred while processing HTML " + ImageName + ": " + ex.Message);
                        }
                        finally
                        {
                            Log("Processed", "HTML Processed");
                            // Exit the application once the process is complete
                            Application.ExitThread();
                        }
                    };

                    //Run the application
                    Application.Run();
                }
                catch (Exception ex)
                {
                    Console.WriteLine("Exception occurred: " + ex.Message);
                }
            });

            //Start the thread
            thread.SetApartmentState(ApartmentState.STA); // Ensure that the thread is in STA mode
            thread.Start();
        }

        public static bool UpdateAlert_News(Int32 ArticleID, Int32 MediaTypeID)
        {
            bool IsResult = false;
            SqlCommand _sqlCommand = new SqlCommand();

            try
            {
                SqlConnection _sqlConnection = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString_SahadevD"].ToString());

                _sqlCommand.Connection = _sqlConnection;
                _sqlCommand.Connection.Open();
                _sqlCommand.CommandText = "USP_Service_UpdateAlerts_Article";
                _sqlCommand.CommandType = CommandType.StoredProcedure;
                //_sqlCommand.CommandText = "UPDATE [203.115.122.28].[ADF_SAHADEV].[dbo].[Sencheck] SET IsNotified=1 WHERE ArticleID ='" + ArticleID + "'";
                _sqlCommand.Parameters.AddWithValue("@ArticleID", ArticleID);
                _sqlCommand.Parameters.AddWithValue("@MediaTypeID", MediaTypeID);
                int result = Convert.ToInt32(_sqlCommand.ExecuteNonQuery());
                if (result > 0)
                {
                    IsResult = true;
                }
            }
            catch (Exception ex)
            {
                Log("UpdateAlert_News", ex.Message + " ->> " + ex.StackTrace);
            }
            finally
            {
                _sqlCommand.Connection.Close();
                _sqlCommand.Connection.Dispose();
            }

            return IsResult;
        }

        #region Images

        private static string CreateImage(string strUrl, string strFileName)
        {
            string strFileNameReturn = string.Empty;
            try
            {
                ServicePointManager.SecurityProtocol = (SecurityProtocolType)3072;
                string strFetchurl = System.Configuration.ConfigurationManager.AppSettings["Screenshot_APIUrl"].Replace("&amp;", "&").Replace("myurl", HttpUtility.UrlEncode(strUrl));
                strFetchurl = strFetchurl.Replace("\r\n", "");

                TimeLog(strFetchurl);

                WebRequest request = WebRequest.Create(strFetchurl);

                //// Get the response. 
                WebResponse response = request.GetResponse();


                // Get the stream containing content returned by the server.
                Stream dataStream = response.GetResponseStream();
                System.Drawing.Image image = System.Drawing.Image.FromStream(dataStream);
                string strPath = System.Configuration.ConfigurationManager.AppSettings["ImageSavePath"] + strFileName + ".jpg";//ConfigurationManager.AppSettings["ScreenshotExtension"];
                //string strPath = System.Configuration.ConfigurationManager.AppSettings["ScreenshotSavePath_Online"] + strFileName + ".jpg";//ConfigurationManager.AppSettings["ScreenshotExtension"];
                image.Save(strPath);
                strFileNameReturn =System.Configuration.ConfigurationManager.AppSettings["ScreenshotUrl"]+ strFileName + ".jpg";
            }
            catch (Exception ex)
            {
                ErrorLog("CreateImage", strUrl + " ->" + ex.ToString());
            }

            return strFileNameReturn;
        }
        #endregion

        #region LOGGING

        //For error logging
        private static void ErrorLog(string functionName, string error)
        {
            try
            {
                string LogPath = ConfigurationManager.AppSettings["ErrorLogPath"];
                using (TextWriter myWriter = File.AppendText(LogPath))
                {

                    TextWriter.Synchronized(myWriter).WriteLine("<--> :{0}", string.Empty);
                    TextWriter.Synchronized(myWriter).WriteLine("Function Name :{0}", functionName);
                    TextWriter.Synchronized(myWriter).WriteLine("Error :{0}", error);
                    TextWriter.Synchronized(myWriter).WriteLine("Date :{0}", DateTime.Now.ToString());
                    TextWriter.Synchronized(myWriter).WriteLine("<--> :{0}", string.Empty);
                    TextWriter.Synchronized(myWriter).Flush();
                    TextWriter.Synchronized(myWriter).Close();
                }
            }
            catch (Exception ex)
            {
            }
        }

        //For debugging purpose
        private static void TimeLog(string strtext)
        {
            try
            {
                string LogPath = ConfigurationManager.AppSettings["TimeLogPath"];
                using (TextWriter myWriter = File.AppendText(LogPath))
                {

                    TextWriter.Synchronized(myWriter).WriteLine("<--> :{0}", string.Empty);
                    TextWriter.Synchronized(myWriter).WriteLine("TimeLog :{0}", strtext);
                    TextWriter.Synchronized(myWriter).WriteLine("Date :{0}", DateTime.Now.ToString());
                    TextWriter.Synchronized(myWriter).WriteLine("<--> :{0}", string.Empty);
                    TextWriter.Synchronized(myWriter).Flush();
                    TextWriter.Synchronized(myWriter).Close();
                }
            }
            catch (Exception ex)
            {
                ErrorLog("TimeLog", ex.ToString());
            }
        }


        private static void Log(string functionName, string error)
        {
            try
            {
                string LogPath = ConfigurationManager.AppSettings["LogPath"].ToString();
                using (TextWriter myWriter = File.AppendText(LogPath))
                {

                    TextWriter.Synchronized(myWriter).WriteLine("<--> :{0}", string.Empty);
                    TextWriter.Synchronized(myWriter).WriteLine("Function Name :{0}", functionName);
                    if (!String.IsNullOrEmpty(error))
                    {
                        TextWriter.Synchronized(myWriter).WriteLine("Error :{0}", error);
                    }
                    TextWriter.Synchronized(myWriter).WriteLine("Date :{0}", DateTime.Now.ToString());
                    TextWriter.Synchronized(myWriter).WriteLine("<--> :{0}", string.Empty);
                    TextWriter.Synchronized(myWriter).Flush();
                    TextWriter.Synchronized(myWriter).Close();
                }

            }
            catch (Exception ex)
            {
            }
        }

        #endregion

        public class eLog
        {
            public string UserID { get; set; }
            public string DeviceID { get; set; }
            public string Status { get; set; }
            public string ErrorCode { get; set; }
            public string ErrorMessage { get; set; }
        }
    }
}
