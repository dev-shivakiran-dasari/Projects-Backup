﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace NotificationSender_Sentry2_Conditional_YT
{
    [DataContract]
    public class eAlerts_YouTube
    {
        [DataMember]
        public Int32 video_id { get; set; }

        [DataMember]
        public Int32 MediaTypeID { get; set; }

        [DataMember]
        public string UserID { get; set; }

        [DataMember]
        public string entity_name { get; set; }

        [DataMember]
        public Int32 incident_id { get; set; }

        [DataMember]
        public string title { get; set; }

        [DataMember]
        public string url { get; set; }

        [DataMember]
        public string description { get; set; }

        [DataMember]
        public string date_time { get; set; }

        [DataMember]
        public string author { get; set; }

        [DataMember]
        public string sentiment { get; set; }

        [DataMember]
        public string lstDeviceID { get; set; }

        [DataMember]
        public string TopicName { get; set; }

        [DataMember]
        public string TopicDescription { get; set; }

        [DataMember]
        public string Condition_Name { get; set; }

    }
}
