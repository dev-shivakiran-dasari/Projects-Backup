﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Windows.Forms;
using System.Drawing;
using System.Diagnostics;
using System.Threading.Tasks;
using System.Threading;
using System.Configuration;
using System.IO;
using System.Net;
using System.Data;
using System.Net.Mail;
using System.Web;
using System.Reflection;
using System.IO.Compression;
using System.Globalization;
using System.Drawing;
using Newtonsoft.Json.Linq;

namespace NotificationSender_Sentry2_Conditional_TWT
{
    class Program
    {
        static void Main(string[] args)
        {
            ErrorLog("Start", "");

            try
            {
                Log("Program Start", "");


                List<eAlerts_Twitter> lst = new List<eAlerts_Twitter>();
                Log("FetchAlerts_DB_Twitter Start", "");
                lst = FetchAlerts_DB_Twitter();
                Log("FetchAlerts_DB_Twitter End", "");
                //for (int i = 0; i < lst.Count; i++)
                //{
                //    string strHTML = CreateHtml(lst[i]);
                //    string twitter_id = Convert.ToString(lst[i].twitter_id);
                //    //HTMLCodeToImage(strHTML, Convert.ToString(lst[i].twitter_id));
                //    CreateImage(strHTML, twitter_id);
                //    lst[i].ScreenShortImageURL = Convert.ToString(lst[i].twitter_id) + ".jpg";
                //    SendNotification_News(lst[i]);
                //}

                #region Parallel

                var stopWatch = Stopwatch.StartNew();
                ParallelOptions po = new ParallelOptions();
                po.MaxDegreeOfParallelism = Convert.ToInt32(System.Configuration.ConfigurationManager.AppSettings["MaxDegreeOfParallelism"]);
                System.Net.ServicePointManager.DefaultConnectionLimit = Convert.ToInt32(System.Configuration.ConfigurationManager.AppSettings["MaxDegreeOfParallelism"]);
                Parallel.For(0, lst.Count, po, i =>
                {
                    try
                    {
                        //string strHTML = CreateHtml(lst[i]);
                        string twitter_id = Convert.ToString(lst[i].twitter_id);
                        string incident_id = Convert.ToString(lst[i].incident_id);
                        ////HTMLCodeToImage(strHTML, Convert.ToString(lst[i].twitter_id)); 
                        //Log("CreateImage Start For " + Convert.ToString(lst[i].twitter_id), "");
                        //lst[i].ScreenShortImageURL = CreateImage(strHTML, "twt_" + incident_id + "_" + twitter_id);
                        //Log("CreateImage End For " + Convert.ToString(lst[i].twitter_id), "");
                        ////SendNotification_News(lst[i]);

                        Log("SendNotification_News Start For " + Convert.ToString(lst[i].twitter_id), "");
                        bool IsResult = SendNotification_News(lst[i]);
                        Log("SendNotification_News Result Is " + IsResult.ToString() + " For " + lst[i].twitter_id, "");
                        Log("SendNotification_News End For " + lst[i].twitter_id, "");

                        if (IsResult)
                        {
                            Log("UpdateAlert_News Start For " + Convert.ToString(lst[i].twitter_id) + "," + Convert.ToString(lst[i].MediaTypeID), "");
                            IsResult = UpdateAlert_News(lst[i].twitter_id, lst[i].MediaTypeID);
                            Log("UpdateAlert_News End For " + lst[i].twitter_id, "");
                        }
                    }
                    catch (Exception ex)
                    {
                        Log("Loop errror for " + lst[i].twitter_id, ex.Message + " ->> " + ex.StackTrace);
                    }

                });
                #endregion

                Log("Program End", "");
            }
            catch (Exception ex)
            {
                Log("Main", ex.Message + " ->> " + ex.StackTrace);
            }

        }

        public static List<eAlerts_Twitter> FetchAlerts_DB_Twitter()
        {
            DataTable _dt = new DataTable();
            DataSet _dtSet = new DataSet();
            SqlCommand _sqlCommand = new SqlCommand();

            List<eAlerts_Twitter> lst = new List<eAlerts_Twitter>();
            try
            {
                SqlConnection _sqlConnection = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString_SahadevE"].ToString());

                _sqlCommand.Connection = _sqlConnection;
                _sqlCommand.Connection.Open();
                _sqlCommand.CommandText = "USP_Notification_Conditional_Twitter_New";
                _sqlCommand.CommandType = CommandType.Text;
                //_sqlCommand.Parameters.AddWithValue("@MessageID", "Select");
                SqlDataAdapter _sqlDataAdapter = new SqlDataAdapter(_sqlCommand);

                _sqlDataAdapter.Fill(_dtSet);

                if (_dtSet != null && _dtSet.Tables.Count > 0)
                {
                    DataTable dtReport = _dtSet.Tables[0];
                    foreach (DataRow dr in dtReport.Rows)
                    {
                        eAlerts_Twitter eUser = new eAlerts_Twitter();

                        eUser.twitter_id = 0;
                        if (!dr["twitter_id"].Equals(DBNull.Value))
                        {
                            eUser.twitter_id = Convert.ToInt32(dr["twitter_id"]);
                        }

                        eUser.incident_id = 0;
                        if (!dr["incident_id"].Equals(DBNull.Value))
                        {
                            eUser.incident_id = Convert.ToInt32(dr["incident_id"]);
                        }

                        eUser.UserID = Convert.ToString("");
                        if (!dr["UserID"].Equals(DBNull.Value))
                        {
                            eUser.UserID = Convert.ToString(dr["UserID"]);
                        }

                        eUser.MediaTypeID = 0;
                        if (!dr["MediaTypeID"].Equals(DBNull.Value))
                        {
                            eUser.MediaTypeID = Convert.ToInt32(dr["MediaTypeID"]);
                        }

                        eUser.entity_name = Convert.ToString("");
                        if (!dr["entity_name"].Equals(DBNull.Value))
                        {
                            eUser.entity_name = Convert.ToString(dr["entity_name"]);
                        }

                        eUser.url = Convert.ToString("");
                        if (!dr["url"].Equals(DBNull.Value))
                        {
                            eUser.url = Convert.ToString(dr["url"]);
                        }

                        eUser.description = Convert.ToString("");
                        if (!dr["description"].Equals(DBNull.Value))
                        {
                            eUser.description = Convert.ToString(dr["description"]);
                        }

                        eUser.date_time = Convert.ToString("");
                        if (!dr["date_time"].Equals(DBNull.Value))
                        {
                            eUser.date_time = String.Format("{0:d MMM yyyy | H:mm tt}", Convert.ToDateTime(dr["date_sort"]));
                        }

                        eUser.sentiment = Convert.ToString("");
                        if (!dr["sentiment"].Equals(DBNull.Value))
                        {
                            eUser.sentiment = Convert.ToString(dr["sentiment"]);
                        }

                        eUser.profile_handle = Convert.ToString("");
                        if (!dr["profile_handle"].Equals(DBNull.Value))
                        {
                            eUser.profile_handle = Convert.ToString(dr["profile_handle"]);
                        }

                        eUser.profile_name = Convert.ToString("");
                        if (!dr["profile_name"].Equals(DBNull.Value))
                        {
                            eUser.profile_name = Convert.ToString(dr["profile_name"]);
                        }

                        eUser.profile_followerscount = Convert.ToString("");
                        if (!dr["profile_followerscount"].Equals(DBNull.Value))
                        {
                            eUser.profile_followerscount = Convert.ToString(dr["profile_followerscount"]);
                        }

                        eUser.profile_followingcount = Convert.ToString("");
                        if (!dr["profile_followingcount"].Equals(DBNull.Value))
                        {
                            eUser.profile_followingcount = Convert.ToString(dr["profile_followingcount"]);
                        }

                        eUser.profile_tweetscount = Convert.ToString("");
                        if (!dr["profile_tweetscount"].Equals(DBNull.Value))
                        {
                            eUser.profile_tweetscount = Convert.ToString(dr["profile_tweetscount"]);
                        }

                        eUser.profile_listscount = Convert.ToString("");
                        if (!dr["profile_listscount"].Equals(DBNull.Value))
                        {
                            eUser.profile_listscount = Convert.ToString(dr["profile_listscount"]);
                        }

                        eUser.profile_isprotected = Convert.ToString("");
                        if (!dr["profile_isprotected"].Equals(DBNull.Value))
                        {
                            eUser.profile_isprotected = Convert.ToString(dr["profile_isprotected"]);
                        }

                        eUser.profile_isverified = Convert.ToString("");
                        if (!dr["profile_isverified"].Equals(DBNull.Value))
                        {
                            eUser.profile_isverified = Convert.ToString(dr["profile_isverified"]);
                        }

                        eUser.profile_verifiedtype = Convert.ToString("");
                        if (!dr["profile_verifiedtype"].Equals(DBNull.Value))
                        {
                            eUser.profile_verifiedtype = Convert.ToString(dr["profile_verifiedtype"]);
                        }

                        eUser.profile_category = Convert.ToString("");
                        if (!dr["profile_category"].Equals(DBNull.Value))
                        {
                            eUser.profile_category = Convert.ToString(dr["profile_category"]);
                        }

                        eUser.profile_profilepicurl = Convert.ToString("");
                        if (!dr["profile_profilepicurl"].Equals(DBNull.Value))
                        {
                            eUser.profile_profilepicurl = Convert.ToString(dr["profile_profilepicurl"]);
                        }

                        eUser.engagement_retweetcount = Convert.ToString("");
                        if (!dr["engagement_retweetcount"].Equals(DBNull.Value))
                        {
                            eUser.engagement_retweetcount = Convert.ToString(dr["engagement_retweetcount"]);
                        }

                        eUser.engagement_replycount = Convert.ToString("");
                        if (!dr["engagement_replycount"].Equals(DBNull.Value))
                        {
                            eUser.engagement_replycount = Convert.ToString(dr["engagement_replycount"]);
                        }

                        eUser.engagement_likecount = Convert.ToString("");
                        if (!dr["engagement_likecount"].Equals(DBNull.Value))
                        {
                            eUser.engagement_likecount = Convert.ToString(dr["engagement_likecount"]);
                        }

                        eUser.engagement_quotecount = Convert.ToString("");
                        if (!dr["engagement_quotecount"].Equals(DBNull.Value))
                        {
                            eUser.engagement_quotecount = Convert.ToString(dr["engagement_quotecount"]);
                        }

                        eUser.engagement_bookmarkcount = Convert.ToString("");
                        if (!dr["engagement_bookmarkcount"].Equals(DBNull.Value))
                        {
                            eUser.engagement_bookmarkcount = Convert.ToString(dr["engagement_bookmarkcount"]);
                        }

                        eUser.engagement_viewcount = Convert.ToString("");
                        if (!dr["engagement_viewcount"].Equals(DBNull.Value))
                        {
                            eUser.engagement_viewcount = Convert.ToString(dr["engagement_viewcount"]);
                        }

                        eUser.profile_profilepicurl = Convert.ToString("");
                        if (!dr["profile_profilepicurl"].Equals(DBNull.Value))
                        {
                            eUser.profile_profilepicurl = Convert.ToString(dr["profile_profilepicurl"]);
                        }
                        eUser.tonality = Convert.ToString("");
                        if (!dr["tonality"].Equals(DBNull.Value))
                        {
                            eUser.tonality = Convert.ToString(dr["tonality"]);
                        }
                        eUser.date_sort = Convert.ToString("");
                        if (!dr["date_sort"].Equals(DBNull.Value))
                        {
                            eUser.date_sort = String.Format("{0:d MMM yyyy | H:mm tt}", Convert.ToDateTime(dr["date_sort"]));
                        }

                        eUser.reach_sort = Convert.ToString("");
                        if (!dr["reach_sort"].Equals(DBNull.Value))
                        {
                            eUser.reach_sort = Convert.ToString(dr["reach_sort"]);
                        }

                        eUser.engagement_sort = Convert.ToString("");
                        if (!dr["engagement_sort"].Equals(DBNull.Value))
                        {
                            eUser.engagement_sort = Convert.ToString(dr["engagement_sort"]);
                        }

                        eUser.views_sort = Convert.ToString("");
                        if (!dr["views_sort"].Equals(DBNull.Value))
                        {
                            eUser.views_sort = Convert.ToString(dr["views_sort"]);
                        }

                        eUser.lstDeviceID = Convert.ToString("");
                        if (!dr["lstDeviceID"].Equals(DBNull.Value))
                        {
                            eUser.lstDeviceID = Convert.ToString(dr["lstDeviceID"]);
                        }

                        eUser.NotificationTypeID = Convert.ToString("");
                        if (!dr["NotificationTypeID"].Equals(DBNull.Value))
                        {
                            eUser.NotificationTypeID = Convert.ToString(dr["NotificationTypeID"]);
                        }

                        eUser.TopicName = Convert.ToString("");
                        if (!dr["TopicName"].Equals(DBNull.Value))
                        {
                            eUser.TopicName = Convert.ToString(dr["TopicName"]);
                        }

                        eUser.TopicDescription = Convert.ToString("");
                        if (!dr["TopicDescription"].Equals(DBNull.Value))
                        {
                            eUser.TopicDescription = Convert.ToString(dr["TopicDescription"]);
                        }

                        eUser.Condition_Name = Convert.ToString("");
                        if (!dr["condition_name"].Equals(DBNull.Value))
                        {
                            eUser.Condition_Name = Convert.ToString(dr["condition_name"]);
                        }

                        lst.Add(eUser);
                    }
                }

            }
            catch (Exception ex)
            {
                //Log("FetchAlerts_DB", ex.Message + " ->> " + ex.StackTrace);
            }
            finally
            {
                _sqlCommand.Connection.Close();
                _sqlCommand.Connection.Dispose();
            }

            return lst;
        }

        private static void Log_DB(Int32 AOSID, Int32 TopicID, string UserID, string ImageURL, string DeviceID, string Request, string Response)
        {
            SqlCommand _sqlCommand = new SqlCommand();

            try
            {
                #region Logic for Notification Log Parameters
                List<eLog> lstLogDetails = new List<eLog>();
                //Response="{\"NotificationID\":29738,\"NotSend\":\"9829486ae2d7a82e,d76d1de010ac487a\"}";
                JObject jsonobj = new JObject();
                string NotSentDeviceIds = string.Empty;
                string ErrorCode = string.Empty;
                string ErrorMessage = string.Empty;
                string message_id = "";

                if (!string.IsNullOrEmpty(Response))
                {
                    jsonobj = JObject.Parse(Response);

                    if (!string.IsNullOrEmpty(Convert.ToString(jsonobj["NotSend"])))
                    {
                        NotSentDeviceIds = Convert.ToString(jsonobj["NotSend"]);
                    }
                    else if (!string.IsNullOrEmpty(Convert.ToString(jsonobj["Message"])))
                    {
                        ErrorCode = Convert.ToString(jsonobj["Code"]);
                        ErrorMessage = Convert.ToString(jsonobj["Message"]);
                    }
                    string id = jsonobj["data"]?["id"]?.ToString();

                    if (!string.IsNullOrEmpty(id))
                    {
                        message_id = id;
                    }
                }

                string[] FailedDeviceIds = null;

                if (!string.IsNullOrEmpty(NotSentDeviceIds))
                {
                    FailedDeviceIds = NotSentDeviceIds.Split(',');
                }

                if (!string.IsNullOrEmpty(UserID) && !string.IsNullOrEmpty(DeviceID))
                {
                    string[] userids = UserID.Split(',');

                    DeviceID = DeviceID.Replace("\"", "");
                    string[] deviceids = DeviceID.Split(',');
                    //List<string> deviceids = JsonConvert.DeserializeObject<List<string>>(DeviceID);

                    for (int i = 0; i < deviceids.Length; i++)
                    {
                        eLog obj = new eLog();
                        obj.UserID = Convert.ToString(userids[i]);
                        obj.DeviceID = Convert.ToString(deviceids[i]);

                        if (!string.IsNullOrEmpty(ErrorCode) && !string.IsNullOrEmpty(ErrorMessage))
                        {
                            obj.Status = "Failed";
                            obj.ErrorCode = ErrorCode;
                            obj.ErrorMessage = ErrorMessage;
                        }
                        else if (!string.IsNullOrEmpty(NotSentDeviceIds) && FailedDeviceIds.Any(deviceId => deviceId == Convert.ToString(deviceids[i])))
                        {
                            obj.Status = "Failed";
                        }
                        else
                        {
                            obj.Status = "Success";
                        }

                        lstLogDetails.Add(obj);
                    }
                }
                #endregion



                SqlConnection _sqlConnection = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString_SahadevC2"].ToString());
                DataSet _dtSet = new DataSet();

                _sqlCommand.Connection = _sqlConnection;
                _sqlCommand.Connection.Open();
                _sqlCommand.CommandText = "USP_Service_Insert_SentryV2_Notification_Log_Conditional";
                _sqlCommand.CommandType = CommandType.StoredProcedure;
                _sqlCommand.Parameters.AddWithValue("@RecordID", AOSID);
                //_sqlCommand.Parameters.AddWithValue("@UserID", UserID);
                _sqlCommand.Parameters.AddWithValue("@TopicID", TopicID);
                _sqlCommand.Parameters.AddWithValue("@MediaTypeID", 3);
                _sqlCommand.Parameters.AddWithValue("@ImageURL", ImageURL);
                _sqlCommand.Parameters.AddWithValue("@lstDeviceID", DeviceID);
                _sqlCommand.Parameters.AddWithValue("@Request", Request);
                _sqlCommand.Parameters.AddWithValue("@Response", Response);
                _sqlCommand.Parameters.AddWithValue("@Message_ID", message_id);
                //_sqlCommand.Parameters.AddWithValue("@FromDate", Convert.ToDateTime(FromDate));
                //_sqlCommand.Parameters.AddWithValue("@ToDate", Convert.ToDateTime(ToDate));


                SqlDataAdapter _sqlDataAdapter = new SqlDataAdapter(_sqlCommand);

                _sqlDataAdapter.Fill(_dtSet);
                int NLID = 0;
                if (_dtSet != null && _dtSet.Tables.Count > 0)
                {
                    DataTable dtReport = _dtSet.Tables[0];
                    foreach (DataRow dr in dtReport.Rows)
                    {
                        if (!dr["NLID"].Equals(DBNull.Value))
                        {
                            NLID = Convert.ToInt32(dr["NLID"]);
                        }
                    }
                }
                //int NLID = Convert.ToInt32(_sqlCommand.ExecuteNonQuery());

                Log("NLID", Convert.ToString(NLID));
                _sqlCommand.Connection.Close();

                //Insert Into Notification Log Detail

                if (NLID > 0)
                {
                    for (int i = 0; i < lstLogDetails.Count; i++)
                    {
                        SqlCommand _sqlCommand1 = new SqlCommand();
                        _sqlCommand1.Connection = _sqlConnection;
                        _sqlCommand1.Connection.Open();
                        _sqlCommand1.CommandText = "USP_Service_Insert_SentryV2_Notification_Log_Conditional_Detail";
                        _sqlCommand1.CommandType = CommandType.StoredProcedure;
                        _sqlCommand1.Parameters.AddWithValue("@NLID", NLID);
                        _sqlCommand1.Parameters.AddWithValue("@RecordID", AOSID);
                        //_sqlCommand.Parameters.AddWithValue("@UserID", UserID);
                        _sqlCommand1.Parameters.AddWithValue("@TopicID", TopicID);
                        _sqlCommand1.Parameters.AddWithValue("@MediaTypeID", 3);
                        _sqlCommand1.Parameters.AddWithValue("@UserID", lstLogDetails[i].UserID);
                        _sqlCommand1.Parameters.AddWithValue("@DeviceID", lstLogDetails[i].DeviceID);
                        _sqlCommand1.Parameters.AddWithValue("@Status", lstLogDetails[i].Status);

                        _sqlCommand1.ExecuteNonQuery();
                        _sqlCommand1.Connection.Close();
                    }
                }

            }
            catch (Exception ex)
            {
                Log("Log_DB", ex.Message + " ->> " + ex.StackTrace);
            }

        }

        //private static void Log_DB(Int32 twitter_id, Int32 incident_id, string ImageURL, string lstDeviceID, string Request, string Response)
        //{
        //    SqlCommand _sqlCommand = new SqlCommand();

        //    try
        //    {
        //        SqlConnection _sqlConnection = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ToString());

        //        _sqlCommand.Connection = _sqlConnection;
        //        _sqlCommand.Connection.Open();
        //        _sqlCommand.CommandText = "USP_Service_Insert_SentryV2_Notification_Log";
        //        _sqlCommand.CommandType = CommandType.StoredProcedure;
        //        _sqlCommand.Parameters.AddWithValue("@RecordID", twitter_id);
        //        _sqlCommand.Parameters.AddWithValue("@TopicID", incident_id);
        //        _sqlCommand.Parameters.AddWithValue("@MediaTypeID", 3);
        //        _sqlCommand.Parameters.AddWithValue("@ImageURL", ImageURL);
        //        _sqlCommand.Parameters.AddWithValue("@lstDeviceID", lstDeviceID);
        //        _sqlCommand.Parameters.AddWithValue("@Request", Request);
        //        _sqlCommand.Parameters.AddWithValue("@Response", Response);

        //        int result = Convert.ToInt32(_sqlCommand.ExecuteNonQuery());

        //    }
        //    catch (Exception ex)
        //    {
        //        Log("Log_DB", ex.Message + " ->> " + ex.StackTrace);
        //    }

        //}

        static string CreateHtml(eAlerts_Twitter obj)
        {
            string strHTML = string.Empty;
            try
            {
                strHTML = System.IO.File.ReadAllText(Convert.ToString(ConfigurationManager.AppSettings["TwitterHTML"]));
                //strHTML = System.IO.File.ReadAllText(@"D:\Shivakiran\Notification Sender Sentry 2.0\TwitterHTML.txt");
                //strHTML = strHTML.Replace("#TopicName#", obj.TopicName);
                strHTML = strHTML.Replace("#date_time#", obj.date_time);
                strHTML = strHTML.Replace("#profile_name#", obj.profile_name);
                strHTML = strHTML.Replace("#profile_handle#", obj.profile_handle);
                strHTML = strHTML.Replace("#engagement_viewcount#", Convert.ToString(obj.engagement_viewcount));
                strHTML = strHTML.Replace("#profile_tweetscount#", Convert.ToString(obj.profile_tweetscount));
                strHTML = strHTML.Replace("#engagement_sort#", Convert.ToString(obj.engagement_sort));
                strHTML = strHTML.Replace("#description#", obj.description);
                strHTML = strHTML.Replace("#reach_sort#", Convert.ToString(obj.reach_sort));
            }
            catch (Exception ex)
            {

                throw ex;
            }

            return strHTML;
        }

        public static bool SendNotification_News(eAlerts_Twitter obj)
        {
            bool IsResult = false;
            try
            {


                #region Device ID Array


                if (!string.IsNullOrEmpty(obj.lstDeviceID))
                {
                    string input = obj.lstDeviceID;
                    string[] values = input.Split(',');

                    List<string> outputList = new List<string>();
                    foreach (string value in values)
                    {
                        outputList.Add(value.Trim());
                    }

                    StringBuilder jsonBuilder = new StringBuilder();
                    jsonBuilder.Append("[");
                    for (int i = 0; i < outputList.Count; i++)
                    {
                        jsonBuilder.Append("\"").Append(outputList[i]).Append("\"");
                        if (i < outputList.Count - 1)
                        {
                            jsonBuilder.Append(",");
                        }
                    }
                    jsonBuilder.Append("]");

                    obj.lstDeviceID = jsonBuilder.ToString();
                }

                #endregion

                string message = string.Empty;
                string s = Convert.ToString(obj.description);
                if (!string.IsNullOrEmpty(s))
                {
                    Char[] ca = s.ToCharArray();
                    foreach (Char c in ca)
                    {
                        //if (Char.IsSymbol(c))
                        if (!(c >= 'A' && c <= 'Z') && !(c >= 'a' && c <= 'z') && !Char.IsWhiteSpace(c) && !Char.IsPunctuation(c) && !Char.IsDigit(c))
                        {
                            message = "This content includes non-English characters. Tap here to view more details";
                            break;
                        }

                    }
                }
                if (string.IsNullOrEmpty(message))
                {
                    message = Convert.ToString(obj.description);
                }

                message = message.Replace("\"", "");
                message = message.Replace("\r\n", "");

                //string strPost = "{\"title\": \"" + obj.TopicName + "\",\"message\":\"" + "X - " + message + "\",\"image\":\"" + obj.ScreenShortImageURL
                //    + "\",\"payload\":{\"messageTypeID\":\"CON\", \"channelID\":\"TW\", \"incidentID\":\"" + obj.incident_id + "\", \"data\":{ \"primary_key\" : \"" + obj.twitter_id + "\" }},\"deviceID\": " + obj.lstDeviceID + "}";

                string strPost = "{"
                + "\"title\":\"" + obj.TopicName + "\","
                + "\"message\":\"X - " + message + "\r\n " + obj.Condition_Name + "\","
                + "\"image\":\"" + obj.ScreenShortImageURL + "\","
                + "\"payload\":{"
                    + "\"messageTypeID\":\"CON\","
                    + "\"channelID\":\"TW\","
                    + "\"incidentID\":\"" + obj.incident_id + "\","
                    + "\"data\":{"
                        + "\"primary_key\":\"" + obj.twitter_id + "\""
                        //+ "\"condition_name\":\"" + obj.Condition_Name + "\""
                    + "}"
                + "},"
                + "\"deviceID\":" + obj.lstDeviceID + "}";

                HttpWebRequest request = (HttpWebRequest)WebRequest.Create(ConfigurationManager.AppSettings["URL_SendNotification"]);

                //Create bytes array to send Input as parameter
                byte[] bytes = System.Text.Encoding.GetEncoding("ISO-8859-1").GetBytes(strPost);

                //Set request options
                request.ContentType = "application/json; charset=utf-8";
                request.ContentLength = bytes.Length;
                request.Method = "POST";
                request.Timeout = 900000;
                request.Headers["x-api-key"] = Convert.ToString(ConfigurationManager.AppSettings["x-api-key"]);
                //request.Headers["APPversion"] = "1.0.0";
                //request.Headers["APIVersion"] = "1.0.0";
                //request.Headers["DevicePlatform"] = "W";

                //Upload bytes array to request
                using (Stream os = request.GetRequestStream())
                {
                    os.Write(bytes, 0, bytes.Length);
                }

                //Get response from Request
                using (System.Net.WebResponse resp = request.GetResponse())
                {
                    using (StreamReader sr = new StreamReader(resp.GetResponseStream()))
                    {
                        string strOutput = sr.ReadToEnd().Trim();

                        Log(strOutput, "");
                        IsResult = true;

                        if (!string.IsNullOrEmpty(obj.lstDeviceID))
                        {
                            obj.lstDeviceID = obj.lstDeviceID.ToString().Replace("[", "").Replace("]", "");
                        }
                        Log("Log_DB Start", "");
                        Log_DB(obj.twitter_id, obj.incident_id, obj.UserID, obj.ScreenShortImageURL, obj.lstDeviceID, strPost, strOutput);
                        Log("Log_DB Start", "");
                    }
                }
            }
            catch (Exception ex)
            {
                Log("SendNotification_News", obj.twitter_id + "|" + obj.incident_id + "->" + ex.Message + " ->> " + ex.StackTrace);
            }

            return IsResult;
        }

        public static void HTMLCodeToImage(string strHTML, string ImageName)
        {
            //Create a new thread for each WebBrowser instance
            Thread thread = new Thread(() =>
            {
                try
                {
                    //Ensure that the thread is in STA mode
                    if (Thread.CurrentThread.GetApartmentState() != ApartmentState.STA)
                    {
                        Thread.CurrentThread.SetApartmentState(ApartmentState.STA);
                    }

                    //Create a new WebBrowser control
                    WebBrowser webBrowser = new WebBrowser();

                    //Set the size of the WebBrowser control
                    webBrowser.Width = 800; // Set the desired width
                    webBrowser.Height = 600; // Set the desired height

                    //Navigate the WebBrowser control to a blank page
                    webBrowser.Navigate("about:blank");

                    //Wait for the WebBrowser control to finish loading
                    webBrowser.DocumentCompleted += (sender, e) =>
                    {
                        try
                        {
                            //Set the HTML content of the WebBrowser control
                            webBrowser.Document.Write(strHTML);

                            //Create a Bitmap object to store the rendered image
                            Bitmap bitmap = new Bitmap(webBrowser.Width, webBrowser.Height);

                            //Render the WebBrowser control to the bitmap
                            webBrowser.DrawToBitmap(bitmap, new Rectangle(0, 0, webBrowser.Width, webBrowser.Height));

                            //Save the image to a file

                            string outputPath = ConfigurationManager.AppSettings["ImageSavePath"].ToString() + ImageName + ".jpg";
                            //string outputPath = @"D:\Shivakiran\SentryTest\" + ImageName + ".jpg";
                            bitmap.Save(outputPath, System.Drawing.Imaging.ImageFormat.Png);

                            //Console.WriteLine("Image saved as: " + System.IO.Path.GetFullPath(outputPath));
                            Log("Success", "Image saved as: " + System.IO.Path.GetFullPath(outputPath));

                            bitmap.Dispose();
                            webBrowser.Dispose();

                        }
                        catch (Exception ex)
                        {
                            Log("Failure", "Exception occurred while processing HTML " + ImageName + ": " + ex.Message);
                        }
                        finally
                        {
                            Log("Processed", "HTML Processed");
                            // Exit the application once the process is complete
                            Application.ExitThread();
                        }
                    };

                    //Run the application
                    Application.Run();
                }
                catch (Exception ex)
                {
                    Console.WriteLine("Exception occurred: " + ex.Message);
                }
            });

            //Start the thread
            thread.SetApartmentState(ApartmentState.STA); // Ensure that the thread is in STA mode
            thread.Start();
        }

        public static bool UpdateAlert_News(Int32 ArticleID, Int32 MediaTypeID)
        {
            bool IsResult = false;
            SqlCommand _sqlCommand = new SqlCommand();

            try
            {
                SqlConnection _sqlConnection = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString_SahadevD"].ToString());

                _sqlCommand.Connection = _sqlConnection;
                _sqlCommand.Connection.Open();
                _sqlCommand.CommandText = "USP_Service_UpdateAlerts_Article";
                _sqlCommand.CommandType = CommandType.StoredProcedure;
                //_sqlCommand.CommandText = "UPDATE [203.115.122.28].[ADF_SAHADEV].[dbo].[Sencheck] SET IsNotified=1 WHERE ArticleID ='" + ArticleID + "'";
                _sqlCommand.Parameters.AddWithValue("@ArticleID", ArticleID);
                _sqlCommand.Parameters.AddWithValue("@MediaTypeID", MediaTypeID);
                int result = Convert.ToInt32(_sqlCommand.ExecuteNonQuery());
                if (result > 0)
                {
                    IsResult = true;
                }
            }
            catch (Exception ex)
            {
                Log("UpdateAlert_News", ex.Message + " ->> " + ex.StackTrace);
            }
            finally
            {
                _sqlCommand.Connection.Close();
                _sqlCommand.Connection.Dispose();
            }

            return IsResult;
        }

        #region Images

        private static string CreateImage(string strUrl, string strFileName)
        {
            string strFileNameReturn = string.Empty;
            try
            {
                ServicePointManager.SecurityProtocol = (SecurityProtocolType)3072;
                string strFetchurl = System.Configuration.ConfigurationManager.AppSettings["Screenshot_APIUrl"].Replace("&amp;", "&").Replace("myurl", HttpUtility.UrlEncode(strUrl));
                strFetchurl = strFetchurl.Replace("\r\n", "");

                //TimeLog(strFetchurl);

                WebRequest request = WebRequest.Create(strFetchurl);

                //// Get the response. 
                WebResponse response = request.GetResponse();


                // Get the stream containing content returned by the server.
                Stream dataStream = response.GetResponseStream();
                System.Drawing.Image image = System.Drawing.Image.FromStream(dataStream);
                string strPath = System.Configuration.ConfigurationManager.AppSettings["ImageSavePath"] + strFileName + ".jpg";//ConfigurationManager.AppSettings["ScreenshotExtension"];
                image.Save(strPath);
                strFileNameReturn = System.Configuration.ConfigurationManager.AppSettings["ScreenshotUrl"] + strFileName + ".jpg";
            }
            catch (Exception ex)
            {
                // ErrorLog("CreateImage", strUrl + " ->" + ex.ToString());
            }

            return strFileNameReturn;
        }
        #endregion

        #region LOGGING

        //For error logging
        private static void ErrorLog(string functionName, string error)
        {
            try
            {
                string LogPath = ConfigurationManager.AppSettings["ErrorLogPath"];
                using (TextWriter myWriter = File.AppendText(LogPath))
                {

                    TextWriter.Synchronized(myWriter).WriteLine("<--> :{0}", string.Empty);
                    TextWriter.Synchronized(myWriter).WriteLine("Function Name :{0}", functionName);
                    TextWriter.Synchronized(myWriter).WriteLine("Error :{0}", error);
                    TextWriter.Synchronized(myWriter).WriteLine("Date :{0}", DateTime.Now.ToString());
                    TextWriter.Synchronized(myWriter).WriteLine("<--> :{0}", string.Empty);
                    TextWriter.Synchronized(myWriter).Flush();
                    TextWriter.Synchronized(myWriter).Close();
                }
            }
            catch (Exception ex)
            {
            }
        }

        //For debugging purpose
        private static void TimeLog(string strtext)
        {
            try
            {
                string LogPath = ConfigurationManager.AppSettings["TimeLogPath"];
                using (TextWriter myWriter = File.AppendText(LogPath))
                {

                    TextWriter.Synchronized(myWriter).WriteLine("<--> :{0}", string.Empty);
                    TextWriter.Synchronized(myWriter).WriteLine("TimeLog :{0}", strtext);
                    TextWriter.Synchronized(myWriter).WriteLine("Date :{0}", DateTime.Now.ToString());
                    TextWriter.Synchronized(myWriter).WriteLine("<--> :{0}", string.Empty);
                    TextWriter.Synchronized(myWriter).Flush();
                    TextWriter.Synchronized(myWriter).Close();
                }
            }
            catch (Exception ex)
            {
                ErrorLog("TimeLog", ex.ToString());
            }
        }

        private static void Log(string functionName, string error)
        {
            try
            {
                string LogPath = ConfigurationManager.AppSettings["LogPath"].ToString();
                using (TextWriter myWriter = File.AppendText(LogPath))
                {

                    TextWriter.Synchronized(myWriter).WriteLine("<--> :{0}", string.Empty);
                    TextWriter.Synchronized(myWriter).WriteLine("Function Name :{0}", functionName);
                    if (!String.IsNullOrEmpty(error))
                    {
                        TextWriter.Synchronized(myWriter).WriteLine("Error :{0}", error);
                    }
                    TextWriter.Synchronized(myWriter).WriteLine("Date :{0}", DateTime.Now.ToString());
                    TextWriter.Synchronized(myWriter).WriteLine("<--> :{0}", string.Empty);
                    TextWriter.Synchronized(myWriter).Flush();
                    TextWriter.Synchronized(myWriter).Close();
                }

            }
            catch (Exception ex)
            {
            }
        }

        #endregion

        ////////////////////////////

        //static void Main(string[] args)
        //{


        //    //DataTable dt = FetchAlerts_DB_Print();
        //    DataTable dt = FetchAlerts_DB_Twitter();
        //    //string htmlTable = string.Empty;

        //    try
        //    {

        //        for (int i = 0; i < dt.Rows.Count; i++)
        //        {
        //            string strHTML = ConvertDataRowToHtml(dt.Rows[i]);
        //            HTMLCodeToImage(strHTML, Convert.ToString(dt.Rows[i]["twitter_id"]));
        //        }

        //        //#region Parallel
        //        //int counter = 0;
        //        //var stopWatch = Stopwatch.StartNew();
        //        //ParallelOptions po = new ParallelOptions();
        //        //po.MaxDegreeOfParallelism = 3;
        //        //System.Net.ServicePointManager.DefaultConnectionLimit = 3;
        //        //Parallel.For(0, dt.Rows.Count, po, i =>
        //        //{
        //        //    try
        //        //    {
        //        //        string htmlTable = ConvertDataRowToHtml(dt.Rows[i]);

        //        //        string strHTML = ConvertDataRowToHtml(dt.Rows[i]);
        //        //        HTMLCodeToImage(strHTML, Convert.ToString(dt.Rows[i]["twitter_id"]));
        //        //        //Thread thread = new Thread(() =>
        //        //        //{
        //        //        //    string strHTML = ConvertDataRowToHtml(dt.Rows[i]);
        //        //        //    HTMLCodeToImage1(strHTML, Convert.ToString(dt.Rows[i]["twitter_id"]));
        //        //        //});
        //        //        //thread.SetApartmentState(ApartmentState.STA);
        //        //        //thread.Start();
        //        //        //thread.Join(); // Wait for the thread to finish before continuing

        //        //        counter++;
        //        //    }
        //        //    catch (Exception ex)
        //        //    {
        //        //        throw ex;
        //        //    }

        //        //});
        //        //#endregion

        //    }
        //    catch (Exception ex)
        //    {
        //        throw ex;
        //    }

        //}

        #region ignore the below functions
        public static DataTable FetchAlerts_DB_Online()
        {
            DataTable _dt = new DataTable();
            DataSet _dtSet = new DataSet();
            SqlCommand _sqlCommand = new SqlCommand();

            try
            {
                SqlConnection _sqlConnection = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString_SahadevE"].ToString());

                _sqlCommand.Connection = _sqlConnection;
                _sqlCommand.Connection.Open();
                _sqlCommand.CommandText = "USP_Notification_Conditional_Online";
                _sqlCommand.CommandType = CommandType.Text;
                //_sqlCommand.Parameters.AddWithValue("@MessageID", "Select");
                SqlDataAdapter _sqlDataAdapter = new SqlDataAdapter(_sqlCommand);

                _sqlDataAdapter.Fill(_dtSet);

                if (_dtSet != null && _dtSet.Tables.Count > 0)
                {
                    _dt = _dtSet.Tables[0];
                }
            }
            catch (Exception ex)
            {
                //Log("FetchAlerts_DB", ex.Message + " ->> " + ex.StackTrace);
            }
            finally
            {
                _sqlCommand.Connection.Close();
                _sqlCommand.Connection.Dispose();
            }

            return _dt;
        }

        public static DataTable FetchAlerts_DB_Print()
        {
            DataTable _dt = new DataTable();
            DataSet _dtSet = new DataSet();
            SqlCommand _sqlCommand = new SqlCommand();

            try
            {
                SqlConnection _sqlConnection = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString_SahadevE"].ToString());

                _sqlCommand.Connection = _sqlConnection;
                _sqlCommand.Connection.Open();
                _sqlCommand.CommandText = "USP_Notification_Conditional_Print";
                _sqlCommand.CommandType = CommandType.Text;
                //_sqlCommand.Parameters.AddWithValue("@MessageID", "Select");
                SqlDataAdapter _sqlDataAdapter = new SqlDataAdapter(_sqlCommand);

                _sqlDataAdapter.Fill(_dtSet);

                if (_dtSet != null && _dtSet.Tables.Count > 0)
                {
                    _dt = _dtSet.Tables[0];
                }
            }
            catch (Exception ex)
            {
                //Log("FetchAlerts_DB", ex.Message + " ->> " + ex.StackTrace);
            }
            finally
            {
                _sqlCommand.Connection.Close();
                _sqlCommand.Connection.Dispose();
            }

            return _dt;
        }

        public static DataTable FetchAlerts_DB_Twitter1()
        {
            DataTable _dt = new DataTable();
            DataSet _dtSet = new DataSet();
            SqlCommand _sqlCommand = new SqlCommand();

            try
            {
                SqlConnection _sqlConnection = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString_SahadevE"].ToString());

                _sqlCommand.Connection = _sqlConnection;
                _sqlCommand.Connection.Open();
                _sqlCommand.CommandText = "USP_Notification_Conditional_Twitter";
                _sqlCommand.CommandType = CommandType.Text;
                //_sqlCommand.Parameters.AddWithValue("@MessageID", "Select");
                SqlDataAdapter _sqlDataAdapter = new SqlDataAdapter(_sqlCommand);

                _sqlDataAdapter.Fill(_dtSet);

                if (_dtSet != null && _dtSet.Tables.Count > 0)
                {
                    _dt = _dtSet.Tables[0];
                }
            }
            catch (Exception ex)
            {
                //Log("FetchAlerts_DB", ex.Message + " ->> " + ex.StackTrace);
            }
            finally
            {
                _sqlCommand.Connection.Close();
                _sqlCommand.Connection.Dispose();
            }

            return _dt;
        }

        static string ConvertDataRowToHtml(DataRow dataRow)
        {
            StringBuilder htmlBuilder = new StringBuilder();

            // Start HTML table
            htmlBuilder.Append("<table border='1'>");

            // Start HTML table row
            htmlBuilder.Append("<tr>");

            // Loop through each column in the DataRow
            foreach (var item in dataRow.ItemArray)
            {
                // Add HTML table cell with the column value
                htmlBuilder.Append("<td>");
                htmlBuilder.Append(item.ToString());
                htmlBuilder.Append("</td>");
            }

            // End HTML table row
            htmlBuilder.Append("</tr>");

            // End HTML table
            htmlBuilder.Append("</table>");

            return htmlBuilder.ToString();
        }

        public static void HTMLCodeToImage2(string strHTML, string ImageName)
        {
            //Create a new thread for each WebBrowser instance
            Thread thread = new Thread(() =>
            {
                try
                {
                    //Ensure that the thread is in STA mode
                    if (Thread.CurrentThread.GetApartmentState() != ApartmentState.STA)
                    {
                        Thread.CurrentThread.SetApartmentState(ApartmentState.STA);
                    }

                    //Create a new WebBrowser control
                    WebBrowser webBrowser = new WebBrowser();

                    //Set the size of the WebBrowser control
                    webBrowser.Width = 800; // Set the desired width
                    webBrowser.Height = 600; // Set the desired height

                    //Navigate the WebBrowser control to a blank page
                    webBrowser.Navigate("about:blank");

                    //Wait for the WebBrowser control to finish loading
                    webBrowser.DocumentCompleted += (sender, e) =>
                    {
                        try
                        {
                            //Set the HTML content of the WebBrowser control
                            webBrowser.Document.Write(strHTML);

                            //Create a Bitmap object to store the rendered image
                            Bitmap bitmap = new Bitmap(webBrowser.Width, webBrowser.Height);

                            //Render the WebBrowser control to the bitmap
                            webBrowser.DrawToBitmap(bitmap, new Rectangle(0, 0, webBrowser.Width, webBrowser.Height));

                            //Save the image to a file

                            string outputPath = ConfigurationManager.AppSettings["ImageSavePath"].ToString() + ImageName + ".jpg";
                            //string outputPath = @"D:\Shivakiran\SentryTest\" + ImageName + ".jpg";
                            bitmap.Save(outputPath, System.Drawing.Imaging.ImageFormat.Png);

                            //Console.WriteLine("Image saved as: " + System.IO.Path.GetFullPath(outputPath));
                            Log("Success", "Image saved as: " + System.IO.Path.GetFullPath(outputPath));

                            bitmap.Dispose();
                            webBrowser.Dispose();

                        }
                        catch (Exception ex)
                        {
                            Log("Failure", "Exception occurred while processing HTML " + ImageName + ": " + ex.Message);
                        }
                        finally
                        {
                            Log("Processed", "HTML Processed");
                            // Exit the application once the process is complete
                            Application.ExitThread();
                        }
                    };

                    //Run the application
                    Application.Run();
                }
                catch (Exception ex)
                {
                    Console.WriteLine("Exception occurred: " + ex.Message);
                }
            });

            //Start the thread
            thread.SetApartmentState(ApartmentState.STA); // Ensure that the thread is in STA mode
            thread.Start();
        }

        public static void HTMLCodeToImage1(string strHTML, string ImageName)
        {
            try
            {
                // Create a new WebBrowser control
                WebBrowser webBrowser = new WebBrowser();
                webBrowser.Width = 800; // Set the desired width
                webBrowser.Height = 600; // Set the desired height

                string htmlContent = strHTML;


                webBrowser.Navigate("about:blank");
                webBrowser.DocumentCompleted += (sender, e) =>
                {

                    webBrowser.Document.Write(htmlContent);
                    Bitmap bitmap = new Bitmap(webBrowser.Width, webBrowser.Height);
                    webBrowser.DrawToBitmap(bitmap, new Rectangle(0, 0, webBrowser.Width, webBrowser.Height));

                    // Save the image to a file
                    string outputPath = @"D:\Shivakiran\SentryTest\" + ImageName + ".jpg";
                    bitmap.Save(outputPath, System.Drawing.Imaging.ImageFormat.Png);

                    Console.WriteLine("Image saved as: " + System.IO.Path.GetFullPath(outputPath));
                    bitmap.Dispose();
                    webBrowser.Dispose();
                    Application.Exit();
                };

                // Run the application
                Application.Run();
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }

        public static bool SendNotification_News(Int32 twitter_id, Int32 incident_id, string ImageURL, string lstDeviceID)
        {
            bool IsResult = false;
            try
            {
                HttpWebRequest request = (HttpWebRequest)WebRequest.Create(ConfigurationManager.AppSettings["URL_SendNotification"]);

                #region Device ID Array


                if (!string.IsNullOrEmpty(lstDeviceID))
                {
                    string input = lstDeviceID;
                    string[] values = input.Split(',');

                    List<string> outputList = new List<string>();
                    foreach (string value in values)
                    {
                        outputList.Add(value.Trim());
                    }

                    StringBuilder jsonBuilder = new StringBuilder();
                    jsonBuilder.Append("[");
                    for (int i = 0; i < outputList.Count; i++)
                    {
                        jsonBuilder.Append("\"").Append(outputList[i]).Append("\"");
                        if (i < outputList.Count - 1)
                        {
                            jsonBuilder.Append(",");
                        }
                    }
                    jsonBuilder.Append("]");

                    lstDeviceID = jsonBuilder.ToString();
                }

                #endregion

                string s = "{\"title\": \"" + twitter_id + "\",\"message\":\"Hello friends\",\"image\":\"\",\"payload\":{\"messageTypeID\":\"AIH\", \"channelID\":\"Twitter\", \"incidentID\":\"101\", \"data\":\"\"},\"deviceID\": [\"b146f4cc102c8ff1\"]}";

                string strPost = "{\"twitter_id\":\"" + twitter_id + "\",\"incident_id\":\""
                    + incident_id + "\",\"ImageURL\":\"" + ImageURL + "\",\"lstDeviceID\":" + lstDeviceID + "}";

                //Create bytes array to send Input as parameter
                byte[] bytes = System.Text.Encoding.GetEncoding("ISO-8859-1").GetBytes(strPost);

                //Set request options
                request.ContentType = "application/json; charset=utf-8";
                request.ContentLength = bytes.Length;
                request.Method = "POST";
                request.Timeout = 900000;
                //request.Headers["APPversion"] = "1.0.0";
                //request.Headers["APIVersion"] = "1.0.0";
                //request.Headers["DevicePlatform"] = "W";

                //Upload bytes array to request
                using (Stream os = request.GetRequestStream())
                {
                    os.Write(bytes, 0, bytes.Length);
                }

                //Get response from Request
                using (System.Net.WebResponse resp = request.GetResponse())
                {
                    using (StreamReader sr = new StreamReader(resp.GetResponseStream()))
                    {
                        string strOutput = sr.ReadToEnd().Trim();

                        Log(strOutput, "");
                        IsResult = true;

                        Log("Log_DB Start", "");
                        //Log_DB(twitter_id, incident_id, ImageURL, lstDeviceID, strPost, strOutput);
                        Log("Log_DB Start", "");
                    }
                }
            }
            catch (Exception ex)
            {
                Log("SendNotification_News", twitter_id + "|" + incident_id + "->" + ex.Message + " ->> " + ex.StackTrace);
            }

            return IsResult;
        }

        #endregion

        public class eLog
        {
            public string UserID { get; set; }
            public string DeviceID { get; set; }
            public string Status { get; set; }
            public string ErrorCode { get; set; }
            public string ErrorMessage { get; set; }
        }

    }
}
