﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;
using SolrNet.Attributes;

namespace DiffbotEnricher
{
    [DataContract]
    public class eArticle
    {
        [SolrField("segment")]
        public string Segment { get; set; }

        [SolrField("id")]
        public string id { get; set; }

        [SolrField("url")]
        public string Url { get; set; }

        [SolrField("digest")]
        public string Digest { get; set; }

        [SolrField("boost")]
        public string Boost { get; set; }

        [SolrField("_version_")]
        public string Version { get; set; }

        

        [SolrField("Date")]
        public DateTime Date { get; set; }

        [SolrField("Html")]
        public string Html { get; set; }

        [SolrField("Title")]
        public string Title { get; set; }

        [SolrField("Text")]
        public string Text { get; set; }

        [SolrField("ETitle")]
        public string ETitle { get; set; }

        [SolrField("EText")]
        public string EText { get; set; }


        [SolrField("Author")]
        public string Author { get; set; }

        [SolrField("SiteName")]
        public string SiteName { get; set; }

        [SolrField("AuthorUrl")]
        public string AuthorUrl { get; set; }

        [SolrField("PublisherRegion")]
        public string PublisherRegion { get; set; }

        [SolrField("PublisherCountry")]
        public string PublisherCountry { get; set; }

        [SolrField("Tags")]
        public string Tags { get; set; }

        [SolrField("TagLabel1")]
        public string TagLabel1 { get; set; }

        [SolrField("TagScore1")]
        public decimal TagScore1 { get; set; }

        [SolrField("TagCount1")]
        public Int32 TagCount1 { get; set; }

        [SolrField("TagLabel2")]
        public string TagLabel2 { get; set; }

        [SolrField("TagScore2")]
        public decimal TagScore2 { get; set; }

        [SolrField("TagCount2")]
        public Int32 TagCount2 { get; set; }

        [SolrField("TagLabel3")]
        public string TagLabel3 { get; set; }

        [SolrField("TagScore3")]
        public decimal TagScore3 { get; set; }

        [SolrField("TagCount3")]
        public Int32 TagCount3 { get; set; }

        [SolrField("TagLabel4")]
        public string TagLabel4 { get; set; }

        [SolrField("TagScore4")]
        public decimal TagScore4 { get; set; }

        [SolrField("TagCount4")]
        public Int32 TagCount4 { get; set; }

        [SolrField("TagLabel5")]
        public string TagLabel5 { get; set; }

        [SolrField("TagScore5")]
        public decimal TagScore5 { get; set; }

        [SolrField("TagCount5")]
        public Int32 TagCount5 { get; set; }

        [SolrField("Language")]
        public string Language { get; set; }

        [SolrField("images")]
        public string Images { get; set; }

        [SolrField("domain")]
        public string domain { get; set; }

        [SolrField("tstamp_ps")]
        public DateTime? tstamp_ps { get; set; }

        public string Output { get; set; }
        public string ErrorCode { get; set; }
        public string Error { get; set; }
        public Int32 Is_Premium { get; set; }

    }
}
