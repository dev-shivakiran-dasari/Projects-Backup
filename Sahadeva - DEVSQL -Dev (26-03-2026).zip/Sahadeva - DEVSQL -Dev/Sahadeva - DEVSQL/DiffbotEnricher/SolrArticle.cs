﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using SolrNet.Attributes;

namespace DiffbotEnricher
{
    public class SolrArticle
    {

        [SolrField("id")]
        public string Id { get; set; }

        [SolrField("url")]
        public string URL { get; set; }

        [SolrField("tstamp")]
        public DateTime? TStamp { get; set; }

        [SolrField("state")]
        public string State { get; set; }

        [SolrField("tryCount")]
        public Int32 TryCount { get; set; }

        [SolrField("_version_")]
        public string Version { get; set; }

        [SolrField("is_premium")]
        public Int32 Is_Premium { get; set; }
    }
}
