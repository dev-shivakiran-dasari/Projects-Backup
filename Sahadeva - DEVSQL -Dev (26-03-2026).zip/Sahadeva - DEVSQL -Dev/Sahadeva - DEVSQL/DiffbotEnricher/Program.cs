﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using SolrNet;
using System.Configuration;
using System.IO;
using Microsoft.Practices.ServiceLocation;
using SolrNet.Commands.Parameters;
using System.Reflection;
using System.Diagnostics;
using System.Threading.Tasks;
using System.Net;
using Newtonsoft.Json.Linq;
using System.Globalization;
using System.Text.RegularExpressions;
using SolrNet.Utils;

namespace DiffbotEnricher
{
    class Program
    {
        //Solr Connection
        public static ISolrOperations<SolrArticle> solrBoilerPipePS = null;
        public static ISolrOperations<eArticle> solrBoilerPipeFS = null;

        static void Main(string[] args)
        {
            TimeLog("Start Init & Set instance of Solr");
            Startup.Container.Clear();
            Startup.InitContainer();

            Startup.Init<SolrArticle>(ConfigurationManager.AppSettings["Solr_PSPath"]);
            solrBoilerPipePS = ServiceLocator.Current.GetInstance<ISolrOperations<SolrArticle>>();

            Startup.Init<eArticle>(ConfigurationManager.AppSettings["Solr_FSPath"]);
            solrBoilerPipeFS = ServiceLocator.Current.GetInstance<ISolrOperations<eArticle>>();
            TimeLog("Start Init & Set instance of Solr");

            Process();
        }

        private static void Process()
        {
            try
            {
                //Create FromDate & ToDate
                DateTime FromDate = DateTime.Now.AddMinutes(-Convert.ToInt32(ConfigurationManager.AppSettings["NoOFMinutesToSubstractFromPS"].ToString()));

                var logFile = File.ReadAllLines(ConfigurationManager.AppSettings["Publications_List"].ToString());
                List<string> lstPublications = new List<string>(logFile);

                int counter = 0;
                var stopWatch = Stopwatch.StartNew();
                ParallelOptions po = new ParallelOptions();
                po.MaxDegreeOfParallelism = lstPublications.Count; //Convert.ToInt32(ConfigurationManager.AppSettings["Publication_MaxDegreeOfParallelism"].ToString());
                System.Net.ServicePointManager.DefaultConnectionLimit = lstPublications.Count; //Convert.ToInt32(ConfigurationManager.AppSettings["Publication_MaxDegreeOfParallelism"].ToString());

                Parallel.For(0, lstPublications.Count, po, i =>
                {
                    try
                    {
                        #region Runt this code in paraelle of domain list and paas domain as extar parameter
                        //Fetch Articles To Process
                        List<SolrArticle> lstArticles = FetchArticles(FromDate, DateTime.Now.AddDays(1), lstPublications[i].ToString());

                        TimeLog("Total Count Of Articles Found " + lstArticles.Count.ToString());
                        Console.WriteLine("Total Count Of Articles Found " + lstArticles.Count.ToString());

                        TimeLog("Start Process_Diffbot");
                        Console.WriteLine("Start Process_Diffbot");
                        List<eArticle> lstArticles_Final = new List<eArticle>();
                        lstArticles_Final = Process_Diffbot(lstArticles);
                        TimeLog("End Process_Diffbot");
                        Console.WriteLine("End Process_Diffbot");

                        TimeLog("Start InsertData_FS");
                        Console.WriteLine("Start InsertData_FS");
                        InsertData_FS(lstArticles_Final);
                        TimeLog("End InsertData_FS");
                        Console.WriteLine("End InsertData_FS");

                        TimeLog("Start UpdateData_PS");
                        Console.WriteLine("Start UpdateData_PS");
                        UpdateData_PS(lstArticles, lstArticles_Final);
                        TimeLog("End UpdateData_PS");
                        Console.WriteLine("End UpdateData_PS");

                        TimeLog("Start CommitData");
                        Console.WriteLine("Start CommitData");
                        CommitData();
                        TimeLog("End CommitData");
                        Console.WriteLine("End CommitData");
                        #endregion

                        counter++;
                    }
                    catch (Exception ex)
                    {
                        ErrorLog("Parallel Error for " + lstPublications[i].ToString(), ex.ToString());
                    }

                });
                TimeLog("End Parallel.For");
                TimeLog("Parallel.For() execution time for " + " = {0} seconds:" + stopWatch.Elapsed.TotalSeconds);  
            }
            catch (Exception ex)
            {
                ErrorLog("Process", ex.Message + " ->> " + ex.StackTrace);
            }
        }


        //This function will fetch articles from primary solr on basis of start date and end date  with processed flag 0;
        private static List<SolrArticle> FetchArticles(DateTime from, DateTime to,string strPublication)
        {
            //Final articles
            SolrQueryResults<SolrArticle> lstFinalArticles = new SolrQueryResults<SolrArticle>();

            try
            {
                //Create from data and to date parameters
                string fromDate = Convert.ToDateTime(from.ToString("yyyy-MM-dd HH:mm tt")).ToString("yyyy'-'MM'-'dd'T'HH':'mm':'ss'.'fff'Z'");

                //to = DateTime.Now.AddHours(-3);

                string toDate = Convert.ToDateTime(to.ToString("yyyy-MM-dd HH:mm tt")).ToString("yyyy'-'MM'-'dd'T'HH':'mm':'ss'.'fff'Z'");


                string ExtraQueryPaameter = System.IO.File.ReadAllText(ConfigurationManager.AppSettings["ExtraQueryParameter"].ToString());

                //Create query // Pick between fromdate to todate which are not processed i.e. state=0 and Trycount<3
                string Query = " tstamp:[" + fromDate + " TO " + toDate + "]" + ExtraQueryPaameter + " AND url:\"*" + strPublication + "*\""; 

                //string Query = " tstamp:[2024-10-24T07:41:00.000Z TO " + toDate + "]" + ExtraQueryPaameter;
                TimeLog(Query);

                //Get final articles
                lstFinalArticles = solrBoilerPipePS.Query(Query,
                    new QueryOptions
                    {
                        Start = 0,
                        Rows = Convert.ToInt32(ConfigurationManager.AppSettings["NoOfRows"]),
                        OrderBy = new[] { new SolrNet.SortOrder("tstamp", Order.DESC) },
                        Fields = new[] { "tstamp,title,id,url,content,state,tryCount" },
                        ExtraParams = new KeyValuePair<string, string>[] { new KeyValuePair<string, string>("wt", "xml") }
                    });
            }
            catch (Exception ex)
            {
                ErrorLog("FetchArticles", ex.ToString());
            }

            return lstFinalArticles.ToList();
        }

        #region DIFFBOT

        public static List<eArticle> Process_Diffbot(List<SolrArticle> lstLinks)
        {
            List<eArticle> lstFinal = new List<eArticle>();

            try
            {
                //create list of tokens
                List<string> lstTokens = ConfigurationManager.AppSettings["Diffbot_Token"].ToString().Split(',').ToList();

                int counter = 0;
                var stopWatch = Stopwatch.StartNew();
                ParallelOptions po = new ParallelOptions();
                po.MaxDegreeOfParallelism = Convert.ToInt32(ConfigurationManager.AppSettings["Diffbot_MaxDegreeOfParallelism"].ToString());
                System.Net.ServicePointManager.DefaultConnectionLimit = Convert.ToInt32(ConfigurationManager.AppSettings["Diffbot_MaxDegreeOfParallelism"].ToString());

                var logFile = File.ReadAllLines(ConfigurationManager.AppSettings["Publications_List"].ToString());
                List<string> lstPublications = new List<string>(logFile);

                Parallel.For(0, lstLinks.Count, po, i =>
                {
                    try
                    {
                        string strToken = lstTokens[0];
                        if (i % 2 != 0) { strToken = lstTokens[1]; }

                        //TimeLog("Start FetchAndExtractFromDiffbot");

                        eArticle objArticle = new eArticle();

                        string strPublication = ExtractDomainame(lstLinks[i].URL);
                        string FoundPublication = lstPublications.FirstOrDefault(x => x == strPublication);
                        if (FoundPublication != null)
                        {
                            objArticle = FetchAndExtractFromDiffbot(lstLinks[i], strToken);
                            objArticle.tstamp_ps = lstLinks[i].TStamp;
                        }
                        else
                        {
                            objArticle.id = lstLinks[i].URL;
                            objArticle.Url = lstLinks[i].URL;
                            objArticle.tstamp_ps = lstLinks[i].TStamp;
                            objArticle.ErrorCode = "Publication not in Known Universe";
                            objArticle.Error = "Publication not in Known Universe";
                        }


                        lstFinal.Add(objArticle);
                        //TimeLog("End FetchAndExtractFromDiffbot");

                        counter++;
                    }
                    catch (Exception ex)
                    {
                        ErrorLog("Parallel Error for " + lstLinks[i].URL, ex.ToString());
                    }

                });
                TimeLog("End Parallel.For");
                TimeLog("Parallel.For() execution time for " + " = {0} seconds:" + stopWatch.Elapsed.TotalSeconds);

            }
            catch (Exception ex)
            {
                ErrorLog("Process_Diffbot ", ex.Message + " ->> " + ex.StackTrace);
            }

            return lstFinal;
        }

        public static eArticle FetchAndExtractFromDiffbot(SolrArticle objArticle, string strToken)
        {
            TimeLog("Start Fetching From Diffbot URL Is " + objArticle.URL);
            eArticle objeArticle = new eArticle();
            try
            {
                //TimeLog("Start GetDiffbotData URL Is " + objArticle.URL);
                objeArticle = GetDiffbotData(objArticle, strToken);
                //TimeLog("End GetDiffbotData URL Is " + "-> " + objArticle.URL);

                //TimeLog("Start ExtractFromDiffbot URL Is " + "-> " + objArticle.URL);
                objeArticle = ExtractFromDiffbot(objeArticle);
                //TimeLog("End ExtractFromDiffbot URL Is " + "-> " + objArticle.URL);
            }
            catch (Exception ex)
            {
                objeArticle.ErrorCode = "Exception";
                objeArticle.Error = "Exception";
                
                ErrorLog("FetchAndExtractFromDiffbot", ex.ToString() + " URL Is " + objArticle.URL);
            }

            TimeLog("End Fetching From Diffbot URL Is " + objArticle.URL);

            return objeArticle;
        }

        private static eArticle GetDiffbotData(SolrArticle objeJobArticle, string strToken)
        {
            eArticle oeArticle = new eArticle();
            oeArticle.id = objeJobArticle.URL;
            oeArticle.Url = objeJobArticle.URL;
            oeArticle.tstamp_ps = objeJobArticle.TStamp;

            string strOutput = string.Empty;
            string strFinalURL = string.Empty;
            try
            {
                //Get Diffbot url,tokens,timeout interval for diffbot call from config and form the url
                strFinalURL = ConfigurationManager.AppSettings["Diffbot_URL"].Replace("&amp;", "&").Replace("mytoken", strToken).Replace("mytimeout", ConfigurationManager.AppSettings["Diffbot_TimeOutIntervalForOperation"]).Replace("myurl", HttpUtility.UrlEncode(objeJobArticle.URL));

                //TimeLog(strFinalURL);

                HttpWebRequest request = (HttpWebRequest)WebRequest.Create(strFinalURL);
                request.Timeout = Convert.ToInt32(ConfigurationManager.AppSettings["Diffbot_TimeOutIntervalForOperation"]);
                request.Method = "GET";
                request.ContentType = "application/json; charset=utf-8";
                using (HttpWebResponse response = (HttpWebResponse)request.GetResponse())
                {
                    Stream stream = (Stream)response.GetResponseStream();
                    StreamReader reader = new StreamReader(stream);
                    strOutput = reader.ReadToEnd();
                    //TimeLog("Output Of URL " + objeJobArticle.URL + " is " + oeArticle.Output);
                }
                request = null;
            }
            catch (Exception ex)
            {
                ErrorLog("FetchData For Url " + strFinalURL, ex.ToString());
                strOutput = "Exception Occured " + ex.ToString();
            }

            oeArticle.Output = strOutput;
            strFinalURL = null;

            return oeArticle;
        }

        private static eArticle ExtractFromDiffbot(eArticle objArticle)
        {

            try
            {
                if (!String.IsNullOrEmpty(objArticle.Output))
                {
                    JObject obj = JObject.Parse(objArticle.Output);
                    if (obj != null)
                    {
                        if (obj["error"] != null && obj["errorCode"] != null)
                        {
                            if (Convert.ToString(obj["errorCode"]) == "404")
                            {
                                objArticle.Text = "404";
                            }
                            objArticle.ErrorCode = "From DB API - " + Convert.ToString(obj["errorCode"]);
                            objArticle.Error = "From DB API - "+Convert.ToString(obj["error"]);

                            //TimeLog("Output Of URL " + objArticle.Url + " is " + objArticle.Output);
                            obj = null;
                        }
                        else
                        {
                            #region Set output values of diffbot
                            JArray jItems = (JArray)obj["objects"];
                            if (jItems != null)
                            {
                                foreach (JToken jItem in jItems)
                                {
                                    //Set Sitename
                                    if (jItem["siteName"] != null)
                                    {
                                        objArticle.SiteName = jItem["siteName"].ToString();
                                    }

                                    ////Set Sentiment
                                    //if (jItem["sentiment"] != null)
                                    //{
                                    //    objArticle.Sentiment = Convert.ToDecimal(jItem["sentiment"].ToString());
                                    //}

                                    //Set Author
                                    if (jItem["author"] != null)
                                    {
                                        objArticle.Author = jItem["author"].ToString();
                                    }

                                    //Set AuthorURL
                                    if (jItem["authorUrl"] != null)
                                    {
                                        objArticle.AuthorUrl = jItem["authorUrl"].ToString();
                                    }

                                    //Set Title
                                    if (jItem["title"] != null)
                                    {
                                        objArticle.Title = jItem["title"].ToString();
                                    }

                                    //Set Text
                                    if (jItem["text"] != null)
                                    {
                                        objArticle.Text = jItem["text"].ToString();
                                    }

                                    if (objArticle.Url.Contains("economictimes.indiatimes.com"))
                                    {
                                        if (objArticle.Text.Contains("Subscribe to ETPrime & unlock all"))
                                        {
                                            objArticle.Is_Premium = 1;
                                        }
                                    }
                                    else if (objArticle.Url.Contains("business-standard.com"))
                                    {
                                        if (objArticle.Text.Contains("To read the full story, subscribe to BS Premium now"))
                                        {
                                            objArticle.Is_Premium = 1;
                                        }
                                    }
                                    else if (objArticle.Url.Contains("economist.com"))
                                    {
                                        if (objArticle.Text.Contains("Already have an account?Log in"))
                                        {
                                            objArticle.Is_Premium = 1;
                                        }
                                    }
                                    else if (objArticle.Url.Contains("hindustantimes.com"))
                                    {
                                        if (objArticle.Text.Contains("Continue reading with HT Premium Subscription"))
                                        {
                                            objArticle.Is_Premium = 1;
                                        }
                                    }
                                    else if (objArticle.Url.Contains("dealstreetasia.com"))
                                    {
                                        if (objArticle.Text.Contains("Already a Subscriber"))
                                        {
                                            objArticle.Is_Premium = 1;
                                        }
                                    }
                                    else if (objArticle.Url.Contains("moneycontrol.com"))
                                    {
                                        if (objArticle.Text.Contains("Unlock exclusive discounts"))
                                        {
                                            objArticle.Is_Premium = 1;
                                        }
                                    }
                                    else if (objArticle.Url.Contains("the-captable.com"))
                                    {
                                        if (objArticle.Text.Contains("join our exclusive subscriber community"))
                                        {
                                            objArticle.Is_Premium = 1;
                                        }
                                    }
                                    else if (objArticle.Url.Contains("vccircle.com"))
                                    {
                                        if (objArticle.Text.Contains("Please subscribe or log in"))
                                        {
                                            objArticle.Is_Premium = 1;
                                        }
                                    }
                                    else if (objArticle.Url.Contains("ndtvprofit.com"))
                                    {
                                        if (objArticle.Text.Contains("To continue reading this story"))
                                        {
                                            objArticle.Is_Premium = 1;
                                        }
                                    }
                                    else if (objArticle.Url.Contains("ft.com"))
                                    {
                                        if (objArticle.Text.Contains("Try unlimited access"))
                                        {
                                            objArticle.Is_Premium = 1;
                                        }
                                    }
                                    else if (objArticle.Url.Contains("ibsintelligence.com"))
                                    {
                                        if (objArticle.Text.Contains("Get access to IBSi Premium"))
                                        {
                                            objArticle.Is_Premium = 1;
                                        }
                                    }
                                    else if (objArticle.Url.Contains("mid-day.com"))
                                    {
                                        if (objArticle.Text.Contains("Choose Your Subscription Plan"))
                                        {
                                            objArticle.Is_Premium = 1;
                                        }
                                    }
                                    else if (objArticle.Url.Contains("techinasia.com"))
                                    {
                                        if (objArticle.Text.Contains("Subscribe to read the full story"))
                                        {
                                            objArticle.Is_Premium = 1;
                                        }
                                    }


                                    if (objArticle.Is_Premium == 1)
                                    {
                                        TimeLog("Premium for " + objArticle.Url);
                                        objArticle.ErrorCode = "Is_Premium";
                                        objArticle.Error = "Is_Premium";
                                    }

                                    //Set Date
                                    if (jItem["date"] != null)
                                    {
                                        if (!String.IsNullOrEmpty(jItem["date"].ToString()))
                                        {
                                            TimeLog(jItem["date"].ToString());
                                            try
                                            {
                                                if (Convert.ToString(jItem["date"].ToString()).Contains("GMT"))
                                                {
                                                    objArticle.Date = DateTime.ParseExact(Convert.ToString(jItem["date"].ToString()), "ddd, dd MMM yyyy HH:mm:ss GMT", CultureInfo.InvariantCulture);
                                                    //objArticle.Date = DateTime.Now.AddMinutes(-15);
                                                }
                                                else
                                                {
                                                    objArticle.Date = Convert.ToDateTime(jItem["date"].ToString());
                                                }

                                                if (objArticle.Date.Year <= 1900 || objArticle.Date.Year >= 2050)
                                                {
                                                    objArticle.Date = DateTime.Now;
                                                }
                                            }
                                            catch (Exception exxx)
                                            {
                                                objArticle.Date = DateTime.Now;
                                            }
                                        }
                                    }
                                    else
                                    {
                                        objArticle.Date = DateTime.Now;
                                    }

                                    TimeLog(objArticle.Date.ToString());

                                    //Set PublisherCountry
                                    if (jItem["publisherCountry"] != null)
                                    {
                                        objArticle.PublisherCountry = jItem["publisherCountry"].ToString();
                                    }

                                    //Set HumanLanguage
                                    if (jItem["humanLanguage"] != null)
                                    {
                                        objArticle.Language = jItem["humanLanguage"].ToString();
                                    }

                                    //Set PublisherRegion
                                    if (jItem["publisherRegion"] != null)
                                    {
                                        objArticle.PublisherRegion = jItem["publisherRegion"].ToString();
                                    }

                                    //Set Tags
                                    #region Tags Output
                                    if (jItem["tags"] != null)
                                    {
                                        string strTags = string.Empty;
                                        JArray jTags = (JArray)jItem["tags"];

                                        if (jTags != null)
                                        {
                                            //Set to take only 5 Tags
                                            int iTagCounter = 0;

                                            foreach (JToken jTag in jTags)
                                            {
                                                if (iTagCounter < 5)
                                                {
                                                    if (jTag["label"] != null)
                                                    {
                                                        SetProperty("TagLabel" + (iTagCounter + 1).ToString(), jTag["label"].ToString(), ref objArticle, false);
                                                        strTags += jTag["label"].ToString() + ",";
                                                    }

                                                    if (jTag["score"] != null)
                                                    {
                                                        SetProperty("TagScore" + (iTagCounter + 1).ToString(), jTag["score"].ToString(), ref objArticle, true);
                                                    }

                                                    if (jTag["count"] != null)
                                                    {
                                                        SetProperty("TagCount" + (iTagCounter + 1).ToString(), jTag["count"].ToString(), ref objArticle, false);
                                                    }

                                                    iTagCounter++;
                                                }
                                            }
                                        }

                                        objArticle.Tags = strTags.Trim(',');
                                        jTags = null;
                                    }
                                    #endregion


                                    //Set Images
                                    #region Images Output
                                    if (jItem["images"] != null)
                                    {
                                        string strImages = string.Empty;
                                        JArray jImages = (JArray)jItem["images"];

                                        if (jImages != null)
                                        {
                                            foreach (JToken jTag in jImages)
                                            {
                                                if (jTag["url"] != null)
                                                {
                                                    strImages += jTag["url"].ToString() + ",";
                                                }
                                            }
                                        }

                                        objArticle.Images = strImages.Trim(',');

                                        jImages = null;
                                    }
                                    #endregion

                                }
                            }

                            jItems = null;

                            #endregion
                        }


                    }
                    else
                    {
                        objArticle.ErrorCode = "Error";
                        objArticle.Error = "Error";
                    }

                    obj = null;
                }
                else
                {

                }
            }
            catch (Exception ex)
            {
                objArticle.ErrorCode = "Error";
                objArticle.Error = "Error";
                ErrorLog("ExtractFromDiffbot", ex.ToString());
            }

            return objArticle;
        }

        //This function will help to set property value of entity dynamically for EngCore
        private static void SetProperty(string strPropertyName, string value, ref eArticle objName, bool IsDecimal)
        {
            try
            {
                PropertyInfo propertyInfo = objName.GetType().GetProperty(strPropertyName);
                if (IsDecimal)
                {
                    propertyInfo.SetValue(objName, Convert.ToDecimal(value), null);
                }
                else
                {
                    if (strPropertyName.Contains("TagCount"))
                    {
                        propertyInfo.SetValue(objName, Convert.ToInt32(value), null);
                    }
                    else
                    {
                        propertyInfo.SetValue(objName, Convert.ToString(value), null);
                    }
                }

                propertyInfo = null;
            }
            catch (Exception ex)
            {
                ErrorLog("SetProperty", ex.ToString() + "Property Name : " + strPropertyName + "| " + "Properrty value : " + value);
            }

        }

        #endregion

        #region Create & Insert FS Data

        private static void InsertData_FS(List<eArticle> objFeeds)
        {

            for (int i = 0; i < objFeeds.Count(); i++)
            {
                try
                {
                    if (string.IsNullOrEmpty(objFeeds[i].ErrorCode))
                    {
                        CreateDocument_FS(objFeeds[i]);
                    }
                }
                catch (Exception ex)
                {
                    ErrorLog("InsertData_FS For Loop", ex.Message + " ->> " + ex.StackTrace);
                }
            }
        } 

        private static bool CreateDocument_FS(eArticle obj)
        {
            bool Result = false;
            try
            {
                solrBoilerPipeFS.Add(new eArticle()
                {
                    id = obj.id,
                    Url = obj.Url,
                    tstamp_ps = obj.tstamp_ps,
                    domain = ExtractDomainame(obj.Url),
                    Date = obj.Date,
                    Html = obj.Html,
                    Title = obj.Title,
                    Text = obj.Text,
                    ETitle = obj.Title,
                    EText = obj.Text,
                    Author = obj.Author,
                    SiteName = obj.SiteName,
                    AuthorUrl = obj.AuthorUrl,
                    PublisherRegion = obj.PublisherRegion,
                    PublisherCountry = obj.PublisherCountry,
                    Tags = obj.Tags,
                    TagLabel1 = obj.TagLabel1,
                    TagScore1 = obj.TagScore1,
                    TagCount1 = obj.TagCount1,
                    TagLabel2 = obj.TagLabel2,
                    TagScore2 = obj.TagScore2,
                    TagCount2 = obj.TagCount2,
                    TagLabel3 = obj.TagLabel3,
                    TagScore3 = obj.TagScore3,
                    TagCount3 = obj.TagCount3,
                    TagLabel4 = obj.TagLabel4,
                    TagScore4 = obj.TagScore4,
                    TagCount4 = obj.TagCount4,
                    TagLabel5 = obj.TagLabel5,
                    TagScore5 = obj.TagScore5,
                    TagCount5 = obj.TagCount5,
                    Language = obj.Language,
                    Images = obj.Images

                }, new AddParameters() { Overwrite = true });
            }
            catch (Exception ex)
            {
                ErrorLog("CreateDocument_FS", ex.Message + " ->> " + ex.StackTrace);
            }

            return Result;
        }

        
        #endregion

        #region Create & Update PS Data

        private static void UpdateData_PS(List<SolrArticle> lstArticlesPS, List<eArticle> lstArticlesFS)
        {

            for (int i = 0; i < lstArticlesFS.Count; i++)
            {
                try
                {
                    if (String.IsNullOrEmpty(lstArticlesFS[i].ErrorCode))
                    {
                        if (String.IsNullOrEmpty(lstArticlesFS[i].Title) && String.IsNullOrEmpty(lstArticlesFS[i].Text))
                        {
                            lstArticlesPS.Where(w => w.URL.ToLower() == lstArticlesFS[i].Url.ToLower()).ToList().ForEach(j => j.State = "1");
                        }
                    }
                    else if (lstArticlesFS[i].ErrorCode.ToLower().Contains("premium"))
                    {
                        lstArticlesPS.Where(w => w.URL.ToLower() == lstArticlesFS[i].Url.ToLower()).ToList().ForEach(j => j.Is_Premium = 1);
                        lstArticlesPS.Where(w => w.URL.ToLower() == lstArticlesFS[i].Url.ToLower()).ToList().ForEach(j => j.TryCount = 99);
                    }
                    else if (lstArticlesFS[i].ErrorCode.ToLower().Contains("publication not in"))
                    {
                        lstArticlesPS.Where(w => w.URL.ToLower() == lstArticlesFS[i].Url.ToLower()).ToList().ForEach(j => j.State = "1");
                        lstArticlesPS.Where(w => w.URL.ToLower() == lstArticlesFS[i].Url.ToLower()).ToList().ForEach(j => j.TryCount = 401);
                    }
                    else if (lstArticlesFS[i].ErrorCode.ToLower().Contains("from db api"))
                    {
                        lstArticlesPS.Where(w => w.URL.ToLower() == lstArticlesFS[i].Url.ToLower()).ToList().ForEach(j => j.State = "1");
                        lstArticlesPS.Where(w => w.URL.ToLower() == lstArticlesFS[i].Url.ToLower()).ToList().ForEach(j => j.TryCount = 406);
                    }
                }
                catch (Exception ex)
                {
                    ErrorLog("UpdateDocument_PS For Loop", ex.Message + " ->> " + ex.StackTrace);
                }
            }

            for (int i = 0; i < lstArticlesPS.Count; i++)
            {
                UpdateDocument_PS(lstArticlesPS[i]);
            }
        } 

        private static bool UpdateDocument_PS(SolrArticle objSolrArticle)
        {
            bool Result = false;
            try
            {
                solrBoilerPipePS.Add(new SolrArticle()
                {
                    Id = objSolrArticle.Id,
                    URL = objSolrArticle.URL,
                    TStamp = objSolrArticle.TStamp,
                    State = objSolrArticle.State,
                    TryCount = objSolrArticle.TryCount + 1,
                    Is_Premium = objSolrArticle.Is_Premium
                }, new AddParameters() { Overwrite = true });
            }
            catch (Exception ex)
            {
                ErrorLog("UpdateDocument_PS", ex.ToString());
            }

            return Result;
        }

        
        #endregion

        //Commit All Cores
        private static void CommitData()
        {
            try
            {

                HttpWebRequest request = (HttpWebRequest)WebRequest.Create(ConfigurationManager.AppSettings["Solr_PSPath"].ToString() + "/update?commit=true");
                using (HttpWebResponse response = (HttpWebResponse)request.GetResponse())
                {
                    Stream stream = (Stream)response.GetResponseStream();
                    StreamReader reader = new StreamReader(stream);
                    string strOutput = reader.ReadToEnd();
                    stream.Close();
                    reader.Close();
                }

                request = (HttpWebRequest)WebRequest.Create(ConfigurationManager.AppSettings["Solr_FSPath"].ToString() + "/update?commit=true");
                using (HttpWebResponse response = (HttpWebResponse)request.GetResponse())
                {
                    Stream stream = (Stream)response.GetResponseStream();
                    StreamReader reader = new StreamReader(stream);
                    string strOutput = reader.ReadToEnd();
                    stream.Close();
                    reader.Close();
                }
            }
            catch (Exception ex)
            {
                ErrorLog("CommitData", ex.ToString());
            }
        }

        //ExtractDomainame
        private static string ExtractDomainame(string URL)
        {
            try
            {
                string strDomain = Regex.Replace(URL, @"^([a-zA-Z]+:\/\/)?([^\/]+)\/.*?$", "$2");
                strDomain = strDomain.ToLower();
                strDomain = strDomain.Replace("www.", "");
                return strDomain;

            }
            catch (Exception ex) { return ""; }
        }

        

        #region LOGGING

        //For error logging
        private static void ErrorLog(string functionName, string error)
        {
            try
            {
                string LogPath = ConfigurationManager.AppSettings["ErrorLogPath"];
                using (TextWriter myWriter = File.AppendText(LogPath))
                {

                    TextWriter.Synchronized(myWriter).WriteLine("<--> :{0}", string.Empty);
                    TextWriter.Synchronized(myWriter).WriteLine("Function Name :{0}", functionName);
                    TextWriter.Synchronized(myWriter).WriteLine("Error :{0}", error);
                    TextWriter.Synchronized(myWriter).WriteLine("Date :{0}", DateTime.Now.ToString());
                    TextWriter.Synchronized(myWriter).WriteLine("<--> :{0}", string.Empty);
                    TextWriter.Synchronized(myWriter).Flush();
                    TextWriter.Synchronized(myWriter).Close();
                }
            }
            catch (Exception ex)
            {
            }
        }

        //For debugging purpose
        private static void TimeLog(string strtext)
        {
            try
            {
                string LogPath = ConfigurationManager.AppSettings["TimeLogPath"];
                using (TextWriter myWriter = File.AppendText(LogPath))
                {

                    TextWriter.Synchronized(myWriter).WriteLine("<--> :{0}", string.Empty);
                    TextWriter.Synchronized(myWriter).WriteLine("TimeLog :{0}", strtext);
                    TextWriter.Synchronized(myWriter).WriteLine("Date :{0}", DateTime.Now.ToString());
                    TextWriter.Synchronized(myWriter).WriteLine("<--> :{0}", string.Empty);
                    TextWriter.Synchronized(myWriter).Flush();
                    TextWriter.Synchronized(myWriter).Close();
                }
            }
            catch (Exception ex)
            {
                ErrorLog("TimeLog", ex.ToString());
            }
        }

        #endregion
    }
}
