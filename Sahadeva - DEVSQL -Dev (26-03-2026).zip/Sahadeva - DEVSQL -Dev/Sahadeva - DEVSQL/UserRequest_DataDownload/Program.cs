﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace UserRequest_DataDownload
{
    class Program
    {
        static void Main(string[] args)
        {
            DownloadData obj = new DownloadData();
            obj.DoProcess();
        }
    }
}
