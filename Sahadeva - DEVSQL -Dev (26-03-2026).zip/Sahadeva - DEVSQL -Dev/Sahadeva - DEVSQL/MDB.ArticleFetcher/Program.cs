﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Diagnostics;
using System.Threading.Tasks;
using System.Configuration;
using System.IO;
using MDB.Entities;
using System.Globalization;
using System.Xml;
using System.Drawing;
using System.Net;
using SolrNet;
using Newtonsoft.Json;

namespace MDB.ArticleFetcher
{
    public class Program
    {
        
        public static string EscapeUriDataStringRfc3986(string value)
        {
            StringBuilder escaped = new StringBuilder(Uri.EscapeDataString(value));
            string[] UriRfc3986CharsToEscape = new[] { "!", "*", "'", "(", ")" };

            // Upgrade the escaping to RFC 3986, if necessary.
            for (int i = 0; i < UriRfc3986CharsToEscape.Length; i++)
            {
                escaped.Replace(UriRfc3986CharsToEscape[i], Uri.HexEscape(UriRfc3986CharsToEscape[i][0]));
            }

            // Return the fully-RFC3986-escaped string.
            return escaped.ToString();
        }


        //This returns the web client for a randomly selected proxy from specific list of proxies
        private static HttpWebRequest GetHttpWebRequest(string strURL, string sb)
        {
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(strURL);
            try
            {
                request.Timeout = Convert.ToInt32(1800000);
                request.Method = "GET";
                request.Headers.Add(
                    "Authorization", sb.ToString());
                request.ContentType = "application/json; charset=utf-8";

            }
            catch (Exception ex)
            {
                throw ex;
            }

            return request;
        }

        private static string FetchTweets()
        {
            string json = string.Empty;

            try
            {
                string strRequestUrl = "https://api.twitter.com/2/tweets/search/recent";
                string strBearerToken = "Bearer AAAAAAAAAAAAAAAAAAAAAEnOrgEAAAAAugLZaFdz7UAnnBrNrmS4Qt0wTuc%3DXCM5qJ8XkjVI42ooM7KFOZRQdb6I3Q1bkhyOypII3A1MzjZvsZ";

                string strQuery = "India";

                Dictionary<string, string> parameters = new Dictionary<string, string>();
                parameters.Add("query", EscapeUriDataStringRfc3986(strQuery));
                parameters.Add("tweet.fields", "conversation_id,attachments,author_id,context_annotations,created_at,entities,geo,id,in_reply_to_user_id,lang,possibly_sensitive,public_metrics,referenced_tweets,source,text,withheld,note_tweet");
                parameters.Add("user.fields", "created_at,description,entities,id,location,name,pinned_tweet_id,profile_image_url,protected,public_metrics,url,username,verified,withheld,verified_type");
                parameters.Add("expansions", "attachments.poll_ids,attachments.media_keys,author_id,geo.place_id,in_reply_to_user_id,referenced_tweets.id,entities.mentions.username,referenced_tweets.id.author_id");
                parameters.Add("media.fields", "duration_ms,height,media_key,preview_image_url,type,url,width,public_metrics,organic_metrics,promoted_metrics,alt_text,variants");
                parameters.Add("max_results", "100");
                parameters.Add("start_time", DateTime.Now.AddMinutes(-200).ToString("yyyy-MM-ddTHH:mm:ss.000Z"));
                

                if (parameters.Count == 0)
                    return string.Empty;
                Dictionary<string, string>.KeyCollection.Enumerator keys = parameters.Keys.GetEnumerator();
                keys.MoveNext();
                StringBuilder sbp = new StringBuilder(
                    string.Format("{0}={1}", keys.Current, parameters[keys.Current]));
                while (keys.MoveNext())
                {
                    if (keys.Current.ToString() != "start_time")
                    {
                        sbp.AppendFormat("&{0}={1}", keys.Current, Uri.EscapeDataString(parameters[keys.Current]));
                    }
                    else
                    {
                        sbp.AppendFormat("&{0}={1}", keys.Current, parameters[keys.Current]);
                    }

                }


                ServicePointManager.SecurityProtocol = (SecurityProtocolType)3072;

                HttpWebRequest request = GetHttpWebRequest(string.Format("{0}?{1}", strRequestUrl, sbp), strBearerToken);

                using (HttpWebResponse response = (HttpWebResponse)request.GetResponse())
                {
                    string s = DateTime.Now.AddMinutes(-100).ToString("yyyy-MM-ddTHH:mm:ss.000Z");
                    Stream stream = (Stream)response.GetResponseStream();
                    StreamReader reader = new StreamReader(stream);
                    json = reader.ReadToEnd();
                }

                return json;
            }
            catch (Exception ex)
            {
                json = ex.Message;
                if (json.ToLower().Contains("too many requests") || json.ToLower().Contains("(429) client error"))
                {
                    //CHANGING ACCESS TOKEN VALUE 
                    //UpdateTwitterAccesstokens();
                }

                throw ex;
                //return json;               
            }
        }

        static void Main(string[] args)
        {
            try
            {

                string strHours = "1000";

                string strURL_SERPNews = ConfigurationManager.AppSettings["SERPNews_URL"];
                string strUserName = ConfigurationManager.AppSettings["SERPNews_DSUserName"];
                string strPassword = ConfigurationManager.AppSettings["SERPNews_DSPassword"];
                string strDepth = "500";

                string search_param = "&tbs=qdr:h" + strHours + "&source=lnt&tbas=0";

                #region Request Creation & Assigning necessary parameters
                //Create HttpWebRequest https://api.dataforseo.com/v3/serp/google/organic/live/regular
                HttpWebRequest request = (HttpWebRequest)WebRequest.Create(strURL_SERPNews);//"https://api.dataforseo.com/v3/serp/google/news/live/advanced");

                //"ouruserthree@gmail.com" + ":" + "29b9276b5bd37da7";
                string credidentials = strUserName + ":" + strPassword;

                string authorization = Convert.ToBase64String(Encoding.Default.GetBytes(credidentials));
                request.Headers["Authorization"] = "Basic " + authorization;

                var postData = new List<object>();
                postData.Add(new
                {
                    language_code = "en",
                    location_code = "2356",
                    depth = strDepth,
                    search_param = search_param,
                    keyword = "India",
                    os = "windows"
                });



                //Create bytes array to send Input as parameter
                byte[] bytes = bytes = Encoding.UTF8.GetBytes(JsonConvert.SerializeObject(postData));

                //Set request options
                request.ContentType = "application/json; charset=utf8";
                request.ContentLength = bytes.Length;
                request.Method = "POST";
                request.Timeout = Convert.ToInt32(180000);
                ServicePointManager.SecurityProtocol = (SecurityProtocolType)3072;
                //Upload bytes array to request
                using (Stream os = request.GetRequestStream())
                {
                    os.Write(bytes, 0, bytes.Length);
                }
                #endregion


                using (HttpWebResponse response = (HttpWebResponse)request.GetResponse())
                {
                    Stream stream = (Stream)response.GetResponseStream();
                    StreamReader reader = new StreamReader(stream);
                    string strOutput = reader.ReadToEnd();
                }

                return;
                string st = DateTime.Now.AddMinutes(-340).ToString("yyyy-MM-ddTHH:mm:ss.000Z");
                FetchTweets();

                return;
                Startup.Init<SolrPage>(ConfigurationManager.AppSettings["BoilerPipeFiltered"]);
                #region Commented Code
		        //2023-09-09T16:50:35Z
                //DateTime dt = Convert.ToDateTime("2024-01-10T12:53:19.000Z");
                //dt = DateTime.ParseExact("2024-01-10T12:53:19.000Z", "yyyy-MM-dd'T'HH:mm:ss'Z'", CultureInfo.InvariantCulture).ToLocalTime();
                //string dfft = DateTime.Now.ToString("yyyy-mm-dd");
                //return;
                //2024-01-15T23:59:00Z
                //string str = DateTime.Now.AddHours(1).AddHours(-15).ToString("yyyy-MM-ddTHH:mm:ssZ");
                //return; 
	            #endregion

                //Fetch Active Services
                List<eService> lstServicesFetched = new List<eService>();
                lstServicesFetched = new MDB.DAL.DAL().FetchServices();


                //List<string> lstServices = ConfigurationManager.AppSettings["Main_Services"].ToString().Split(',').ToList();

                var stopWatch = Stopwatch.StartNew();
                ParallelOptions po = new ParallelOptions();
                po.MaxDegreeOfParallelism = Convert.ToInt32(ConfigurationManager.AppSettings["Main_MaxDegreeOfParallelism"].ToString());
                System.Net.ServicePointManager.DefaultConnectionLimit = Convert.ToInt32(ConfigurationManager.AppSettings["Main_MaxDegreeOfParallelism"].ToString());

                string IsTwitter = ConfigurationManager.AppSettings["IsTwitter"].ToString();
                string IsDossier = ConfigurationManager.AppSettings["IsDossier"].ToString();
                List<eService> lstServices = new List<eService>();
                if (IsTwitter == "1")
                {
                    for (int i = 0; i < lstServicesFetched.Count; i++)
                    {
                        if (lstServicesFetched[i].ServiceID == 4)
                        {
                            lstServices.Add(lstServicesFetched[i]);
                        }
                    }
                }
                else if (IsTwitter == "0")
                {
                    for (int i = 0; i < lstServicesFetched.Count; i++)
                    {
                        if (lstServicesFetched[i].ServiceID != 4)
                        {
                            lstServices.Add(lstServicesFetched[i]);
                        }
                    }
                }

                

                if (IsDossier == "1")
                {
                    for (int i = 0; i < lstServicesFetched.Count; i++)
                    {
                        if (lstServicesFetched[i].ServiceID == 7)
                        {
                            lstServices.Add(lstServicesFetched[i]);
                        }
                    }
                }
                else if (IsDossier == "0")
                {
                    for (int i = 0; i < lstServicesFetched.Count; i++)
                    {
                        if (lstServicesFetched[i].ServiceID != 7)
                        {
                            lstServices.Add(lstServicesFetched[i]);
                        }
                    }
                }
                  

                Parallel.For(0, lstServices.Count, po, i =>
                {
                    bool Result = false;
                    try
                    {
                        TimeLog("ServiceName -> " + lstServices[i].ServiceName);
                        if (lstServices[i].ServiceName == "Contify")
                        {
                            Result = IsGoodToExecute(lstServices[i].ServiceName, lstServices[i].FrequencyInMin, lstServices[i].LastExecutionTime);
                            if (Result == true)
                            {

                                TimeLog("Start Fetching Queries For Contify");
                                List<eEntityQuery> lstQueries = new MDB.DAL.DAL().FetchQueries(lstServices[i].ServiceID);
                                TimeLog("Queries count For Contify is " + lstQueries.Count);
                                TimeLog("End Fetching Queries For Contify");

                                if (lstServices[i].ServiceName != "Dossier")
                                {
                                    new MDB.DAL.DAL().UpdateServiceHistory(lstServices[i]);
                                }

                                new MDB.Listeners.Contify().Process(lstQueries);
                            } 
                        }
                        else if (lstServices[i].ServiceName == "Google")
                        {
                            Result = IsGoodToExecute(lstServices[i].ServiceName, lstServices[i].FrequencyInMin, lstServices[i].LastExecutionTime);
                            if (Result == true)
                            {
                                TimeLog("Start Fetching Queries For Google");
                                List<eEntityQuery> lstQueries = new MDB.DAL.DAL().FetchQueries(lstServices[i].ServiceID);
                                TimeLog("Queries count For Google is " + lstQueries.Count);
                                TimeLog("End Fetching Queries For Google");

                                new MDB.DAL.DAL().UpdateServiceHistory(lstServices[i]);

                                new MDB.Listeners.Google().Process(lstQueries);
                            } 
                        }
                        else if (lstServices[i].ServiceName == "Print")
                        {
                            Result = IsGoodToExecute(lstServices[i].ServiceName, lstServices[i].FrequencyInMin, lstServices[i].LastExecutionTime);
                            if (Result == true)
                            {
                                TimeLog("Start Fetching Queries For Print");
                                List<eEntityQuery> lstQueries = new MDB.DAL.DAL().FetchQueries(lstServices[i].ServiceID);
                                TimeLog("Queries count For Print is " + lstQueries.Count);
                                TimeLog("End Fetching Queries For Print");

                                new MDB.DAL.DAL().UpdateServiceHistory(lstServices[i]);

                                new MDB.Listeners.Print().Process(lstQueries);
                            } 
                        }
                        else if (lstServices[i].ServiceName == "Twitter")
                        {
                            Result = IsGoodToExecute(lstServices[i].ServiceName, lstServices[i].FrequencyInMin, lstServices[i].LastExecutionTime);
                            if (Result == true)
                            {
                                TimeLog("Start Fetching Queries For Twitter");
                                List<eEntityQuery> lstQueries = new MDB.DAL.DAL().FetchQueries(lstServices[i].ServiceID);
                                TimeLog("Queries count For Twitter is " + lstQueries.Count);
                                TimeLog("End Fetching Queries For Twitter");

                                new MDB.DAL.DAL().UpdateServiceHistory(lstServices[i]);

                                new MDB.Listeners.Twitter().Process(lstQueries);
                            } 
                        }
                        else if (lstServices[i].ServiceName == "TwitterDetail")
                        {
                            Result = IsGoodToExecute(lstServices[i].ServiceName, lstServices[i].FrequencyInMin, lstServices[i].LastExecutionTime);
                            if (Result == true)
                            {
                                new MDB.DAL.DAL().UpdateServiceHistory(lstServices[i]);

                                new MDB.Listeners.TwitterDetail().Process();
                            }
                        }
                        else if (lstServices[i].ServiceName == "TwitterConversation")
                        {
                            Result = IsGoodToExecute(lstServices[i].ServiceName, lstServices[i].FrequencyInMin, lstServices[i].LastExecutionTime);
                            if (Result == true)
                            {
                                new MDB.DAL.DAL().UpdateServiceHistory(lstServices[i]);

                                new MDB.Listeners.TwitterConversation().Process();
                            }
                        }
                        else if (lstServices[i].ServiceName == "Solr")
                        {
                            Result = IsGoodToExecute(lstServices[i].ServiceName, lstServices[i].FrequencyInMin, lstServices[i].LastExecutionTime);
                            if (Result == true)
                            {
                                TimeLog("Start Fetching Queries For Solr");
                                List<eEntityQuery> lstQueries = new MDB.DAL.DAL().FetchQueries(lstServices[i].ServiceID);
                                TimeLog("Queries count For Google is " + lstQueries.Count);
                                TimeLog("End Fetching Queries For Solr");

                                new MDB.DAL.DAL().UpdateServiceHistory(lstServices[i]);

                                new MDB.Listeners.Solr().Process(lstQueries);
                            }
                        }
                        else if (lstServices[i].ServiceName == "Dossier")
                        {
                            Result = IsGoodToExecute(lstServices[i].ServiceName, lstServices[i].FrequencyInMin, lstServices[i].LastExecutionTime);
                            if (Result == true)
                            {
                                TimeLog("Start Fetching Queries For Google");
                                List<eEntityQuery> lstQueries = new MDB.DAL.DAL().FetchQueries(lstServices[i].ServiceID);
                                TimeLog("Queries count For Google is " + lstQueries.Count);
                                TimeLog("End Fetching Queries For Google");


                                new MDB.DAL.DAL().UpdateServiceHistory(lstServices[i]);

                                TimeLog("Start Solr().Process");
                                new MDB.Listeners.Solr().Process(lstQueries);
                                TimeLog("End Solr().Process");

                                TimeLog("Start Google().Process");
                                new MDB.Listeners.Google().Process(lstQueries);
                                TimeLog("End Google().Process");

                                
                            }

                            //Result = IsGoodToExecute(lstServices[i].ServiceName, lstServices[i].FrequencyInMin, lstServices[i].LastExecutionTime);
                            //if (Result == true)
                            //{
                            //    TimeLog("Start Fetching Queries For Solr");
                            //    List<eEntityQuery> lstQueries = new MDB.DAL.DAL().FetchQueries(lstServices[i].ServiceID);
                            //    TimeLog("Queries count For Google is " + lstQueries.Count);
                            //    TimeLog("End Fetching Queries For Solr");

                            //    new MDB.DAL.DAL().UpdateServiceHistory(lstServices[i]);

                            //    new MDB.Listeners.Solr().Process(lstQueries);
                            //}
                        }
                        else if (lstServices[i].ServiceName == "DossierManual")
                        {
                            Result = IsGoodToExecute(lstServices[i].ServiceName, lstServices[i].FrequencyInMin, lstServices[i].LastExecutionTime);
                            if (Result == true)
                            {
                                TimeLog("Start Fetching urls For DossierManual");
                                List<eUserDossierUrl> lstQueries = new MDB.DAL.DAL().FetchUserDossierUrls(lstServices[i].ServiceID);
                                TimeLog("Queries count For DossierManual is " + lstQueries.Count);
                                TimeLog("End Fetching urls For DossierManual");

                                new MDB.DAL.DAL().UpdateServiceHistory(lstServices[i]);
                                TimeLog("Start DossierManual().Process");
                                new MDB.Listeners.DossierManual().Process(lstQueries);
                                TimeLog("End DossierManual().Process");
                            }
                        }
                        else if (lstServices[i].ServiceName == "TwitterArticle")
                        {
                            Result = IsGoodToExecute(lstServices[i].ServiceName, lstServices[i].FrequencyInMin, lstServices[i].LastExecutionTime);
                            if (Result == true)
                            {
                                TimeLog("Start Fetching Queries For TwitterArticle");
                                List<eEntityQuery> lstQueries = new MDB.DAL.DAL().FetchQueries(lstServices[i].ServiceID);
                                TimeLog("Queries count For TwitterArticle is " + lstQueries.Count);
                                TimeLog("End Fetching Queries For TwitterArticle");


                                new MDB.DAL.DAL().UpdateServiceHistory(lstServices[i]);

                                TimeLog("Start TwitterArticle().Process");
                                new MDB.Listeners.TwitterArticle().Process(lstQueries);
                                TimeLog("End TwitterArticle().Process");


                            }
                        }
                        else if (lstServices[i].ServiceName == "UsedAddedUrl_Online")
                        {
                            Result = IsGoodToExecute(lstServices[i].ServiceName, lstServices[i].FrequencyInMin, lstServices[i].LastExecutionTime);
                            if (Result == true)
                            {
                                TimeLog("Start Fetching urls For UsedAddedUrl_Online");
                                List<eUserAddedUrl> lstQueries = new MDB.DAL.DAL().FetchUsedAddedUrl_Online(lstServices[i].ServiceID);
                                TimeLog("Queries count For UsedAddedUrl_Online is " + lstQueries.Count);
                                TimeLog("End Fetching urls For UsedAddedUrl_Online");

                                new MDB.DAL.DAL().UpdateServiceHistory(lstServices[i]);
                                TimeLog("Start UsedAddedUrl_Online().Process");
                                new MDB.Listeners.UserAddedUrl_Online().Process(lstQueries);
                                TimeLog("End UsedAddedUrl_Online().Process");
                            }
                        }

                        //TimeLog("IsGoodToExecute -> " + Result.ToString());

                    }
                    catch (Exception ex)
                    {
                        ErrorLog("Parallel Error for " + lstServices[i], ex.ToString());
                    }

                });
                TimeLog("End Parallel.For");
                TimeLog("Parallel.For() execution time for " + " = {0} seconds:" + stopWatch.Elapsed.TotalSeconds);

            }
            catch (Exception ex)
            {
                ErrorLog("Main ", ex.Message + " ->> " + ex.StackTrace);
            }
        }

        public static bool IsGoodToExecute(string consumerName, int frequencyInMin, DateTime LastExecutionTime)
        {
            try
            {
                TimeLog(consumerName + " " + frequencyInMin.ToString());
                
                Int64 Minutes = 0;
                bool flag = false;
                if (LastExecutionTime != null && LastExecutionTime != DateTime.MinValue)
                {
                    Int64 Days = (DateTime.Now - Convert.ToDateTime(LastExecutionTime)).Days;
                    Int64 Hours = (DateTime.Now - Convert.ToDateTime(LastExecutionTime)).Hours;
                    Minutes = (DateTime.Now - Convert.ToDateTime(LastExecutionTime)).Minutes;

                    Minutes = Minutes + (Hours * 60) + (Days * 24 * 60);
                    if (Minutes >= frequencyInMin)
                    {
                        flag = true;

                    }
                }
                else
                {

                    flag = true;
                }
                return flag;
            }
            catch (Exception ex)
            {
                ErrorLog("IsGoodToExecute", ex.Message + " ->> " + ex.StackTrace);
                return false;
            }
        }

        #region LOGGING

        //For error logging
        private static void ErrorLog(string functionName, string error)
        {
            try
            {
                string LogPath = ConfigurationManager.AppSettings["Main_ErrorLogPath"];
                using (TextWriter myWriter = File.AppendText(LogPath))
                {

                    TextWriter.Synchronized(myWriter).WriteLine("<--> :{0}", string.Empty);
                    TextWriter.Synchronized(myWriter).WriteLine("Function Name :{0}", functionName);
                    TextWriter.Synchronized(myWriter).WriteLine("Error :{0}", error);
                    TextWriter.Synchronized(myWriter).WriteLine("Date :{0}", DateTime.Now.ToString());
                    TextWriter.Synchronized(myWriter).WriteLine("<--> :{0}", string.Empty);
                    TextWriter.Synchronized(myWriter).Flush();
                    TextWriter.Synchronized(myWriter).Close();
                }
            }
            catch (Exception ex)
            {
            }
        }

        //For debugging purpose
        private static void TimeLog(string strtext)
        {
            try
            {
                string LogPath = ConfigurationManager.AppSettings["Main_TimeLogPath"];
                using (TextWriter myWriter = File.AppendText(LogPath))
                {

                    TextWriter.Synchronized(myWriter).WriteLine("<--> :{0}", string.Empty);
                    TextWriter.Synchronized(myWriter).WriteLine("TimeLog :{0}", strtext);
                    TextWriter.Synchronized(myWriter).WriteLine("Date :{0}", DateTime.Now.ToString());
                    TextWriter.Synchronized(myWriter).WriteLine("<--> :{0}", string.Empty);
                    TextWriter.Synchronized(myWriter).Flush();
                    TextWriter.Synchronized(myWriter).Close();
                }
            }
            catch (Exception ex)
            {
                ErrorLog("TimeLog", ex.ToString());
            }
        }

        #endregion

    }

}
