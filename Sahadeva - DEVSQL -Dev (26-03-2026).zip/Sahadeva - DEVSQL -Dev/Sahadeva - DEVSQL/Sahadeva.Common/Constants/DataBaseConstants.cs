﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Sahadeva.Common.Constants
{
    public class DataBaseConstants
    {
        #region Connection String

        public const string ConnectionString = "ConnectionString";

        #endregion Connection String

        #region Procedures

        public const string USP_EntityQuery_Fetch = "USP_EntityQuery_Fetch";
        public const string USP_Article_Insert = "USP_Article_Insert";
        public const string USP_Log_Insert = "USP_Log_Insert";
        
        #endregion Procedures

        #region Fields

        //Common
        public const string CreatedAt = "CreatedAt";
        public const string ModifiedAt = "ModifiedAt";
        public const string IsActive = "IsActive";



        //eEntityQuery
        public const string Query = "Query";
        public const string EntityType = "EntityType";
        public const string EntityName = "EntityName";

        //Article Fields
        public const string EQID = "EQID";
        public const string EntityID = "EntityID";
        public const string Url = "Url";
        public const string Title = "Title";
        public const string Text = "Text";
        public const string Date = "Date";
        public const string Language = "Language";
        public const string Publication = "Publication";
        public const string Publication_Url = "Publication_Url";
        public const string Summary = "Summary";
        public const string Mentioned_Companies = "Mentioned_Companies";
        public const string Mentioned_Industries = "Mentioned_Industries";
        public const string Mentioned_Locations = "Mentioned_Locations";
        public const string Mentioned_Topics = "Mentioned_Topics";
        public const string DB_Text = "DB_Text";
        public const string DB_Date = "DB_Date";
        public const string DB_Html = "DB_Html";
        public const string DB_Title = "DB_Title";
        public const string DB_Author = "DB_Author";
        public const string DB_AuthorUrl = "DB_AuthorUrl";
        public const string DB_SiteName = "DB_SiteName";
        public const string DB_PublisherRegion = "DB_PublisherRegion";
        public const string DB_PublisherCountry = "DB_PublisherCountry";
        public const string DB_Sentiment = "DB_Sentiment";
        public const string DB_Tags = "DB_Tags";
        public const string DB_TagLabel1 = "DB_TagLabel1";
        public const string DB_TagScore1 = "DB_TagScore1";
        public const string DB_TagCount1 = "DB_TagCount1";
        public const string DB_TagLabel2 = "DB_TagLabel2";
        public const string DB_TagScore2 = "DB_TagScore2";
        public const string DB_TagCount2 = "DB_TagCount2";
        public const string DB_TagLabel3 = "DB_TagLabel3";
        public const string DB_TagScore3 = "DB_TagScore3";
        public const string DB_TagCount3 = "DB_TagCount3";
        public const string DB_TagLabel4 = "DB_TagLabel4";
        public const string DB_TagScore4 = "DB_TagScore4";
        public const string DB_TagCount4 = "DB_TagCount4";
        public const string DB_TagLabel5 = "DB_TagLabel5";
        public const string DB_TagScore5 = "DB_TagScore5";
        public const string DB_TagCount5 = "DB_TagCount5";
        public const string DB_Language = "DB_Language";
        public const string DB_Images = "DB_Images";

        //Log
        public const string GUID = "GUID";
        public const string FromDate = "FromDate";
        public const string ToDate = "ToDate";
        public const string Count_Total = "Count_Total";
        public const string Count_Inserted = "Count_Inserted";
        public const string Count_Duplicate = "Count_Duplicate";
        public const string Count_Failed = "Count_Failed";
        public const string Count_DB_Successful = "Count_DB_Successful";
        public const string Count_DB_Failed = "Count_DB_Failed";

        #endregion Fields
    }
}