﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Sahadeva.Entities;
using Sahadeva.Common;
using Sahadeva.Common.Constants;
using System.Data.Common;
using System.Data;

namespace Sahadeva.DAL
{
    public class DAL
    {

        public List<eEntityQuery> FetchQueries()
        {
            List<eEntityQuery> list = new List<eEntityQuery>();
            try
            {

                using (DataAccessWrapper DataAccessWrapper = new DataAccessWrapper(DataBaseConstants.ConnectionString))
                {
                    using (DbCommand dbCommand = DataAccessWrapper.GetStoredProcCommand(DataBaseConstants.USP_EntityQuery_Fetch))
                    {
                        #region DataSet
                        using (DataSet ds = DataAccessWrapper.ExecuteDataSet(dbCommand))
                        {
                            if (ds != null)
                            {
                                DataTable dt = ds.Tables[0];
                                foreach (DataRow dr in dt.Rows)
                                {
                                    eEntityQuery objeEntityQuery = new eEntityQuery();

                                    if (!dr[DataBaseConstants.EntityID].Equals(DBNull.Value))
                                    {
                                        objeEntityQuery.EntityID = Convert.ToInt32(dr[DataBaseConstants.EntityID]);
                                    }

                                    if (!dr[DataBaseConstants.EntityName].Equals(DBNull.Value))
                                    {
                                        objeEntityQuery.EntityName = Convert.ToString(dr[DataBaseConstants.EntityName]);
                                    }

                                    if (!dr[DataBaseConstants.EntityType].Equals(DBNull.Value))
                                    {
                                        objeEntityQuery.EntityType = Convert.ToString(dr[DataBaseConstants.EntityType]);
                                    }

                                    if (!dr[DataBaseConstants.Query].Equals(DBNull.Value))
                                    {
                                        objeEntityQuery.Query = Convert.ToString(dr[DataBaseConstants.Query]);
                                    }

                                    if (!dr[DataBaseConstants.EQID].Equals(DBNull.Value))
                                    {
                                        objeEntityQuery.EQID = Convert.ToInt32(dr[DataBaseConstants.EQID]);
                                    }

                                    list.Add(objeEntityQuery);
                                }
                            }
                        }
                        #endregion
                    }
                }

            }
            catch (Exception ex)
            {

                throw ex;
            }

            return list;
        }

        public void InsertArticle(eArticle obj)
        {
            try
            {
                using (DataAccessWrapper objDataAccessWrapper = new DataAccessWrapper(DataBaseConstants.ConnectionString))
                {
                    using (DbCommand dbCommand = objDataAccessWrapper.GetStoredProcCommand(Common.Constants.DataBaseConstants.USP_Article_Insert))
                    {
                        objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.EQID, DbType.Int32, obj.EQID);
                        objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.EntityID, DbType.Int32, obj.EntityID);

                        if (!string.IsNullOrEmpty(obj.Url))
                        { objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Url, DbType.String, obj.Url); }

                        if (!string.IsNullOrEmpty(obj.Title))
                        { objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Title, DbType.String, obj.Title); }

                        if (!string.IsNullOrEmpty(obj.Text))
                        { objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Text, DbType.String, obj.Text); }

                        if (!string.IsNullOrEmpty(Convert.ToString(obj.Date)))
                        { objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Date, DbType.DateTime, obj.Date); }

                        if (!string.IsNullOrEmpty(obj.Publication))
                        { objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Publication, DbType.String, obj.Publication); }

                        if (!string.IsNullOrEmpty(obj.Publication_Url))
                        { objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Publication_Url, DbType.String, obj.Publication_Url); }

                        //if (!string.IsNullOrEmpty(obj.Language))
                        //{ objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Language, DbType.String, obj.Language); }

                        //if (!string.IsNullOrEmpty(obj.Summary))
                        //{ objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Summary, DbType.String, obj.Summary); }

                        //if (!string.IsNullOrEmpty(obj.Mentioned_Companies))
                        //{ objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Mentioned_Companies, DbType.String, obj.Mentioned_Companies); }

                        //if (!string.IsNullOrEmpty(obj.Mentioned_Industries))
                        //{ objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Mentioned_Industries, DbType.String, obj.Mentioned_Industries); }

                        //if (!string.IsNullOrEmpty(obj.Mentioned_Locations))
                        //{ objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Mentioned_Locations, DbType.String, obj.Mentioned_Locations); }

                        //if (!string.IsNullOrEmpty(obj.Mentioned_Topics))
                        //{ objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Mentioned_Topics, DbType.String, obj.Mentioned_Topics); }

                        if (!string.IsNullOrEmpty(obj.DB_Text))
                        { objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.DB_Text, DbType.String, obj.DB_Text); }

                        if (obj.DB_Date != DateTime.MinValue)
                        { objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.DB_Date, DbType.DateTime, obj.DB_Date); }

                        if (!string.IsNullOrEmpty(obj.DB_Html))
                        { objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.DB_Html, DbType.String, obj.DB_Html); }

                        if (!string.IsNullOrEmpty(obj.DB_Title))
                        { objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.DB_Title, DbType.String, obj.DB_Title); }
                        
                        if (!string.IsNullOrEmpty(obj.DB_Author))
                        { objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.DB_Author, DbType.String, obj.DB_Author); }

                        if (!string.IsNullOrEmpty(obj.DB_SiteName))
                        { objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.DB_SiteName, DbType.String, obj.DB_SiteName); }

                        if (!string.IsNullOrEmpty(obj.DB_AuthorUrl))
                        { objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.DB_AuthorUrl, DbType.String, obj.DB_AuthorUrl); }

                        if (!string.IsNullOrEmpty(obj.DB_PublisherRegion))
                        { objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.DB_PublisherRegion, DbType.String, obj.DB_PublisherRegion); }

                        if (!string.IsNullOrEmpty(obj.DB_PublisherCountry))
                        { objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.DB_PublisherCountry, DbType.String, obj.DB_PublisherCountry); }

                        objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.DB_Sentiment, DbType.Decimal, obj.DB_Sentiment);

                        if (!string.IsNullOrEmpty(obj.DB_Tags))
                        { objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.DB_Tags, DbType.String, obj.DB_Tags); }

                        if (!string.IsNullOrEmpty(obj.DB_TagLabel1))
                        { objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.DB_TagLabel1, DbType.String, obj.DB_TagLabel1); }
                        if (!string.IsNullOrEmpty(obj.DB_TagLabel2))
                        { objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.DB_TagLabel2, DbType.String, obj.DB_TagLabel2); }
                        if (!string.IsNullOrEmpty(obj.DB_TagLabel3))
                        { objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.DB_TagLabel3, DbType.String, obj.DB_TagLabel3); }
                        if (!string.IsNullOrEmpty(obj.DB_TagLabel4))
                        { objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.DB_TagLabel4, DbType.String, obj.DB_TagLabel4); }
                        if (!string.IsNullOrEmpty(obj.DB_TagLabel5))
                        { objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.DB_TagLabel5, DbType.String, obj.DB_TagLabel5); }

                        objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.DB_TagScore1, DbType.Decimal, obj.DB_TagScore1);
                        objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.DB_TagScore2, DbType.Decimal, obj.DB_TagScore2);
                        objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.DB_TagScore3, DbType.Decimal, obj.DB_TagScore3);
                        objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.DB_TagScore4, DbType.Decimal, obj.DB_TagScore4);
                        objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.DB_TagScore5, DbType.Decimal, obj.DB_TagScore5);

                        if (!string.IsNullOrEmpty(obj.DB_Language))
                        { objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.DB_Language, DbType.String, obj.DB_Language); }

                        if (!string.IsNullOrEmpty(obj.DB_Images))
                        { objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.DB_Images, DbType.String, obj.DB_Images); }

                        objDataAccessWrapper.ExecuteNonQuery(dbCommand);
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public void InsertLog(eLog obj)
        {
            try
            {
                using (DataAccessWrapper objDataAccessWrapper = new DataAccessWrapper(DataBaseConstants.ConnectionString))
                {
                    using (DbCommand dbCommand = objDataAccessWrapper.GetStoredProcCommand(Common.Constants.DataBaseConstants.USP_Log_Insert))
                    {
                        objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Count_DB_Failed, DbType.Int32, obj.Count_DB_Failed);
                        objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Count_DB_Successful, DbType.Int32, obj.Count_DB_Successful);

                        objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Count_Duplicate, DbType.Int32, obj.Count_Duplicate);
                        objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Count_Failed, DbType.Int32, obj.Count_Failed);

                        objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Count_Inserted, DbType.Int32, obj.Count_Inserted);
                        objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Count_Total, DbType.Int32, obj.Count_Total);

                        objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.EntityID, DbType.Int32, obj.EntityID);

                        if (!string.IsNullOrEmpty(Convert.ToString(obj.FromDate)))
                        { objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.FromDate, DbType.DateTime, obj.FromDate); }


                        if (!string.IsNullOrEmpty(Convert.ToString(obj.GUID)))
                        { objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.GUID, DbType.DateTime, obj.GUID); }

                        if (!string.IsNullOrEmpty(Convert.ToString(obj.ToDate)))
                        { objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.ToDate, DbType.DateTime, obj.ToDate); }

                        

                        
                        objDataAccessWrapper.ExecuteNonQuery(dbCommand);
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
