﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ProfileDetails.Updator
{
    class Program
    {
        static void Main(string[] args)
        {
            Profile_Details obj = new Profile_Details();
            obj.DoProcess();
        }
    }
}
