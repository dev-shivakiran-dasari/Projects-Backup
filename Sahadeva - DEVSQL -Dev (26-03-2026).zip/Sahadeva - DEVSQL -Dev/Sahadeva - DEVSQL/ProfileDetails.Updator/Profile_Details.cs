﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using MDB.Entities;
using System.Threading.Tasks;
using System.Diagnostics;
using System.Configuration;
using System.Net;
using System.IO;
using Newtonsoft.Json.Linq;
using System.Data;
using System.Reflection;

namespace ProfileDetails.Updator
{
    public class Profile_Details
    {
        List<eTwitter> lstTweets = new List<eTwitter>();
        List<eTwitter> lstFinal = new List<eTwitter>();

        public void DoProcess()
        {
            TimeLog("Process Started");
            try
            {
                TimeLog("Twitter_GetHandlesForProfileUpdate Started");
                lstTweets = new MDB.DAL.DAL().Twitter_FetchHandlesForDetailsUpdate();
                TimeLog("Twitter_GetHandlesForProfileUpdate Ended");

                string Query = String.Join(",", lstTweets.Select(x => x.Profile_ID.ToString()).ToArray());
                if (!String.IsNullOrEmpty(Query))
                {
                    List<string> lstIds = new List<string>();
                    lstIds = CreateTweetIDs(Query);
                    TimeLog("lstIds Count Is " + lstIds.Count.ToString());

                    if (lstIds.Count > 0)
                    {
                        var stopWatch = Stopwatch.StartNew();
                        ParallelOptions po = new ParallelOptions();
                        po.MaxDegreeOfParallelism = Convert.ToInt32(ConfigurationManager.AppSettings["Twitter_MaxDegreeOfParallelism"]);
                        System.Net.ServicePointManager.DefaultConnectionLimit = Convert.ToInt32(ConfigurationManager.AppSettings["Twitter_MaxDegreeOfParallelism"]);

                        //TimeLog("getAccesstokens Started");
                        //string strToken = getAccesstokens();
                        //TimeLog("getAccesstokens Ended");

                        string strToken = string.Empty;
                        Parallel.For(0, lstIds.Count, po, i =>
                        {
                            try
                            {
                                FetchProfileDetails_RapidAPI(lstIds[i].ToString(), strToken);
                            }
                            catch (Exception ex)
                            {
                                ErrorLog("Error for " + lstIds[i].ToString(), ex.ToString());
                            }

                        });
                        TimeLog("End Parallel.For");
                        TimeLog("Parallel.For() execution time for " + " = {0} seconds:" + stopWatch.Elapsed.TotalSeconds);

                        TimeLog("InsertData Started");
                        InsertData();
                        TimeLog("InsertData Ended");
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorLog("DoProcess", ex.Message + " ->> " + ex.StackTrace);
            }
            TimeLog("Process Ended");
        }

        public void FetchProfileDetails_RapidAPI(string Query, string token = "")
        {
            string strOutput = string.Empty;

            try
            {
                #region Creating Request

                string json = string.Empty;
                string strURL = string.Empty;
                string strFinalURL = string.Empty;

                strURL = ConfigurationManager.AppSettings["URL_RapidAPI"].ToString();
                strFinalURL = strURL + Query;

                TimeLog(strFinalURL);
                ServicePointManager.SecurityProtocol = (SecurityProtocolType)3072;

                HttpWebRequest request = (HttpWebRequest)WebRequest.Create(strFinalURL);
                request.Timeout = Convert.ToInt32(ConfigurationManager.AppSettings["Twitter_TimeOutIntervalForOperation"]);
                request.Method = "GET";
                request.ContentType = "application/json; charset=utf-8";
                request.Headers.Add("x-rapidapi-host", ConfigurationManager.AppSettings["x-rapidapi-host"].ToString());
                request.Headers.Add("x-rapidapi-key", ConfigurationManager.AppSettings["x-rapidapi-key"].ToString());
                #endregion


                #region Get Data From API
                using (HttpWebResponse response = (HttpWebResponse)request.GetResponse())
                {
                    Stream stream = (Stream)response.GetResponseStream();
                    StreamReader reader = new StreamReader(stream);
                    json = reader.ReadToEnd();

                    if (String.IsNullOrEmpty(json))
                    {
                        TimeLog("Json Is Empty In FetchProfileDetails_RapidAPI");
                    }
                    else
                    {
                        TimeLog("Json Is " + json);
                        JObject objJobject = JObject.Parse(json);
                        JArray tweets = (JArray)objJobject["users"];

                        if (tweets.Count > 0)
                        {
                            foreach (JToken tweet in tweets)
                            {

                                try
                                {
                                    #region Extract Data
                                    JObject jobject_result = JObject.Parse(tweet["result"].ToString());
                                    JObject user_public_metrics = JObject.Parse(jobject_result["legacy"].ToString());
                                    if (user_public_metrics != null)
                                    {
                                        if (!string.IsNullOrEmpty(Convert.ToString(user_public_metrics["followers_count"])))
                                        {
                                            lstFinal.Where(w => w.Profile_Handle == user_public_metrics["screen_name"].ToString()).ToList().ForEach(i => i.Profile_FollowersCount = Convert.ToInt64(user_public_metrics["followers_count"].ToString()));
                                        }
                                        if (!string.IsNullOrEmpty(Convert.ToString(user_public_metrics["friends_count"])))
                                        {
                                            lstFinal.Where(w => w.Profile_Handle == user_public_metrics["screen_name"].ToString()).ToList().ForEach(i => i.Profile_FollowingCount = Convert.ToInt64(user_public_metrics["friends_count"].ToString()));
                                        }
                                        if (!string.IsNullOrEmpty(Convert.ToString(user_public_metrics["statuses_count"])))
                                        {
                                            lstFinal.Where(w => w.Profile_Handle == user_public_metrics["screen_name"].ToString()).ToList().ForEach(i => i.Profile_TweetsCount = Convert.ToInt64(user_public_metrics["statuses_count"].ToString()));
                                        }
                                        if (!string.IsNullOrEmpty(Convert.ToString(user_public_metrics["listed_count"])))
                                        {
                                            lstFinal.Where(w => w.Profile_Handle == user_public_metrics["screen_name"].ToString()).ToList().ForEach(i => i.Profile_ListsCount = Convert.ToInt64(user_public_metrics["listed_count"].ToString()));
                                        }
                                        if (!string.IsNullOrEmpty(Convert.ToString(user_public_metrics["location"])))
                                        {
                                            lstFinal.Where(w => w.Profile_Handle == user_public_metrics["screen_name"].ToString()).ToList().ForEach(i => i.Profile_Location = Convert.ToString(user_public_metrics["location"]));
                                        }
                                        if (!string.IsNullOrEmpty(Convert.ToString(user_public_metrics["description"])))
                                        {
                                            lstFinal.Where(w => w.Profile_Handle == user_public_metrics["screen_name"].ToString()).ToList().ForEach(i => i.Profile_Description = Convert.ToString(user_public_metrics["description"]));
                                        }
                                        if (!string.IsNullOrEmpty(Convert.ToString(user_public_metrics["profile_image_url_https"])))
                                        {
                                            lstFinal.Where(w => w.Profile_Handle == user_public_metrics["screen_name"].ToString()).ToList().ForEach(i => i.Profile_ProfilePicUrl = Convert.ToString(user_public_metrics["profile_image_url_https"]));
                                        }

                                    }
                                    #endregion
                                }
                                catch (Exception exx)
                                {
                                    ErrorLog("FetchProfileDetails_RapidAPI" + Query, exx.Message + " ->> " + exx.StackTrace);
                                }

                                //if (!string.IsNullOrEmpty(Convert.ToString(tweet["url"])))
                                //{
                                //    lstFinal.Where(w => w.Profile_Handle == tweet["username"].ToString()).ToList().ForEach(i => i.Profile_ExternalUrl = Convert.ToString(tweet["url"]));
                                //}

                                //if (!string.IsNullOrEmpty(Convert.ToString(tweet["verified"])))
                                //{
                                //    lstFinal.Where(w => w.Profile_Handle == tweet["username"].ToString()).ToList().ForEach(i => i.Profile_IsVerified = Convert.ToInt16(Convert.ToString(tweet["verified"].ToString()) == "True" ? 1 : 0));
                                //}

                                //if (!string.IsNullOrEmpty(Convert.ToString(tweet["verified_type"])))
                                //{
                                //    lstFinal.Where(w => w.Profile_Handle == tweet["username"].ToString()).ToList().ForEach(i => i.Profile_VerifiedType = Convert.ToString(Convert.ToString(tweet["verified_type"].ToString())));
                                //}

                                //if (!string.IsNullOrEmpty(Convert.ToString(tweet["protected"])))
                                //{
                                //    lstFinal.Where(w => w.Profile_Handle == tweet["username"].ToString()).ToList().ForEach(i => i.Profile_IsProtected = Convert.ToInt16(Convert.ToString(tweet["protected"].ToString()) == "True" ? 1 : 0));
                                //}


                            }

                        }
                    }
                }
                #endregion
            }
            catch (Exception ex)
            {
                ErrorLog("FetchProfileDetails_RapidAPI" + Query, ex.Message + " ->> " + ex.StackTrace);
            }
        }


        private string getAccesstokens()
        {
            string strToken = string.Empty;
            try
            {
                string strTokens = ConfigurationManager.AppSettings["Twitter_BearerToken"];
                if (!String.IsNullOrEmpty(strTokens))
                {
                    //create list of tokens
                    List<string> lst = strTokens.Split(',').ToList();

                    //get random token
                    Random randNum = new Random();
                    int aRandomPos = randNum.Next(lst.Count);
                    strToken = lst[aRandomPos];
                }
            }
            catch (Exception ex)
            {
                ErrorLog("getAccesstokens", ex.Message + " ->> " + ex.StackTrace);
            }
            return strToken;
        }

        private List<string> CreateTweetIDs(string Query)
        {
            List<String> lstids = new List<string>();
            try
            {
                string[] sep = new string[] { "," };

                List<string> lstTweetUrls = Query.Split(sep, StringSplitOptions.RemoveEmptyEntries).ToList();

                if (lstTweetUrls.Count > 0)
                {
                    List<String> lstTweetIDs = lstTweetUrls.Select(i => i.Trim()).ToList();

                    lstFinal = lstTweets.Select(s => new eTwitter {
                        Profile_Handle = s.Profile_Handle
                    }).ToList();

                    int num = 0;

                    int add = 0;

                    if (lstTweetIDs.Count <= 99)
                    {
                        num = lstTweetIDs.Count;

                        string str = String.Join(",", lstTweetIDs.GetRange(add, lstTweetIDs.Count).ToArray());
                        lstids.Add(str);

                    }
                    else
                    {
                        num = lstTweetIDs.Count / 100;

                        for (int i = 1; i <= num; i++)
                        {
                            if (i < num)
                            {

                                string str = String.Join(",", lstTweetIDs.GetRange(add, 100).ToArray());
                                lstids.Add(str);
                            }
                            else
                            {

                                string str = String.Join(",", lstTweetIDs.GetRange(add, 100).ToArray());
                                lstids.Add(str);

                                if (lstTweetIDs.Count % 100 != 0)
                                {
                                    str = String.Join(",", lstTweetIDs.GetRange(add + 100, lstTweetIDs.Count - (add + 100)).ToArray());
                                    lstids.Add(str);
                                }
                                break;
                            }

                            add = add + 100;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorLog("CreateTweetIDs", ex.Message + " ->> " + ex.StackTrace);
            }

            return lstids;
        }

        private void FetchProfileDetails(string Query, string sb)
        {

            try
            {
                string json = string.Empty;

                string resource_url = ConfigurationManager.AppSettings["Twitter_ProfileDetailUrl"];

                Dictionary<string, string> parameters = new Dictionary<string, string>();
                parameters.Add("usernames", Query);
                parameters.Add("user.fields", "created_at,description,entities,id,location,name,pinned_tweet_id,profile_image_url,protected,public_metrics,url,username,verified,withheld,verified_type");
                
                Dictionary<string, string>.KeyCollection.Enumerator keys = parameters.Keys.GetEnumerator();
                keys.MoveNext();
                StringBuilder sbp = new StringBuilder(
                    string.Format("{0}={1}", keys.Current, Uri.EscapeDataString(parameters[keys.Current])));
                while (keys.MoveNext())
                    sbp.AppendFormat("&{0}={1}", keys.Current, Uri.EscapeDataString(parameters[keys.Current]));


                ServicePointManager.SecurityProtocol = (SecurityProtocolType)3072;

                #region Creating Request
                HttpWebRequest request;
                request = (HttpWebRequest)WebRequest.Create(string.Format("{0}?{1}", resource_url, sbp));
                request.Timeout = 400000;
                request.Method = "GET";
                request.Headers.Add(
                    "Authorization", sb.ToString());
                request.ContentType = "application/json; charset=utf-8";
                #endregion

                #region Get Data From API
                using (HttpWebResponse response = (HttpWebResponse)request.GetResponse())
                {
                    Stream stream = (Stream)response.GetResponseStream();
                    StreamReader reader = new StreamReader(stream);
                    json = reader.ReadToEnd();

                    if (String.IsNullOrEmpty(json))
                    {
                        TimeLog("Json Is Empty In FetchProfileDetails");
                    }
                    else
                    {
                        TimeLog("Json Is " + json);
                        JObject objJobject = JObject.Parse(json);
                        JArray tweets = (JArray)objJobject["data"];

                        if (tweets.Count > 0)
                        {
                            foreach (JToken tweet in tweets)
                            {
                                try
                                {

                                    //if (!string.IsNullOrEmpty(Convert.ToString(tweet["username"])))
                                    //{
                                    //    lstFinal.Where(w => w.Profile_Handle == tweet["username"].ToString()).ToList().ForEach(i => i.Engagement_RetweetCount = Convert.ToInt64(tweet["public_metrics"]["retweet_count"].ToString()));
                                    //}

                                    JObject user_public_metrics = JObject.Parse(tweet["public_metrics"].ToString());
                                    if (user_public_metrics != null)
                                    {
                                        if (!string.IsNullOrEmpty(Convert.ToString(user_public_metrics["followers_count"])))
                                        {
                                            lstFinal.Where(w => w.Profile_Handle == tweet["username"].ToString()).ToList().ForEach(i => i.Profile_FollowersCount = Convert.ToInt64(user_public_metrics["followers_count"].ToString()));
                                        }
                                        if (!string.IsNullOrEmpty(Convert.ToString(user_public_metrics["following_count"])))
                                        {
                                            lstFinal.Where(w => w.Profile_Handle == tweet["username"].ToString()).ToList().ForEach(i => i.Profile_FollowingCount = Convert.ToInt64(user_public_metrics["following_count"].ToString()));
                                        }
                                        if (!string.IsNullOrEmpty(Convert.ToString(user_public_metrics["tweet_count"])))
                                        {
                                            lstFinal.Where(w => w.Profile_Handle == tweet["username"].ToString()).ToList().ForEach(i => i.Profile_TweetsCount = Convert.ToInt64(user_public_metrics["tweet_count"].ToString()));
                                        }
                                        if (!string.IsNullOrEmpty(Convert.ToString(user_public_metrics["listed_count"])))
                                        {
                                            lstFinal.Where(w => w.Profile_Handle == tweet["username"].ToString()).ToList().ForEach(i => i.Profile_ListsCount = Convert.ToInt64(user_public_metrics["listed_count"].ToString()));
                                        }
                                    }

                                    
                                    if (!string.IsNullOrEmpty(Convert.ToString(tweet["location"])))
                                    {
                                        lstFinal.Where(w => w.Profile_Handle == tweet["username"].ToString()).ToList().ForEach(i => i.Profile_Location = Convert.ToString(tweet["location"]));
                                    }

                                    if (!string.IsNullOrEmpty(Convert.ToString(tweet["description"])))
                                    {
                                        lstFinal.Where(w => w.Profile_Handle == tweet["username"].ToString()).ToList().ForEach(i => i.Profile_Description = Convert.ToString(tweet["description"]));
                                    }

                                    if (!string.IsNullOrEmpty(Convert.ToString(tweet["profile_image_url"])))
                                    {
                                        lstFinal.Where(w => w.Profile_Handle == tweet["username"].ToString()).ToList().ForEach(i => i.Profile_ProfilePicUrl = Convert.ToString(tweet["profile_image_url"]));
                                    }

                                    if (!string.IsNullOrEmpty(Convert.ToString(tweet["url"])))
                                    {
                                        lstFinal.Where(w => w.Profile_Handle == tweet["username"].ToString()).ToList().ForEach(i => i.Profile_ExternalUrl = Convert.ToString(tweet["url"]));
                                    }

                                    if (!string.IsNullOrEmpty(Convert.ToString(tweet["verified"])))
                                    {
                                       lstFinal.Where(w => w.Profile_Handle == tweet["username"].ToString()).ToList().ForEach(i => i.Profile_IsVerified = Convert.ToInt16(Convert.ToString(tweet["verified"].ToString()) == "True" ? 1 : 0));
                                    }

                                    if (!string.IsNullOrEmpty(Convert.ToString(tweet["verified_type"])))
                                    {
                                        lstFinal.Where(w => w.Profile_Handle == tweet["username"].ToString()).ToList().ForEach(i => i.Profile_VerifiedType = Convert.ToString(Convert.ToString(tweet["verified_type"].ToString())));
                                    }

                                    if (!string.IsNullOrEmpty(Convert.ToString(tweet["protected"])))
                                    {
                                        lstFinal.Where(w => w.Profile_Handle == tweet["username"].ToString()).ToList().ForEach(i => i.Profile_IsProtected = Convert.ToInt16(Convert.ToString(tweet["protected"].ToString()) == "True" ? 1 : 0));
                                    }
                                }
                                catch (Exception exx)
                                {
                                    ErrorLog("ExtractTweetsFromJson For Loop For " + Convert.ToString(tweet["username"]), exx.ToString());
                                }
                            }
                        }

                    }
                #endregion
                }
            }
            catch (Exception ex)
            {
                ErrorLog("FetchProfileDetails" + Query, ex.Message + " ->> " + ex.StackTrace);
            }
        }

        private void InsertData()
        {

            try
            {
                TimeLog("lstFinal count is " + lstFinal.Count.ToString());
                DataTable dt = new DataTable();
                dt = ToDataTable(lstFinal);
                TimeLog("ToDataTable dt count is " + dt.Rows.Count.ToString());

                DataView view = new DataView(dt);
                dt = view.ToTable("Selected", false, "Profile_Handle", "Profile_FollowersCount", "Profile_FollowingCount", "Profile_TweetsCount", "Profile_ListsCount", "Profile_Location", "Profile_Description", "Profile_ProfilePicUrl", "Profile_ExternalUrl", "Profile_IsVerified", "Profile_VerifiedType", "Profile_IsProtected");

                TimeLog("InsertProfileDetail_Twitter Started");
                new MDB.DAL.DAL().InsertProfileDetail_Twitter(dt);
                TimeLog("InsertProfileDetail_Twitter Ended");

            }
            catch (Exception ex)
            {
                ErrorLog("InsertData", ex.Message + " ->> " + ex.StackTrace);
            }
        }

        private DataTable ToDataTable<T>(List<T> items)
        {
            DataTable dataTable = new DataTable(typeof(T).Name);
            try
            {
                //Get all the properties by using reflection   
                PropertyInfo[] Props = typeof(T).GetProperties(BindingFlags.Public | BindingFlags.Instance);
                foreach (PropertyInfo prop in Props)
                {
                    //Setting column names as Property names  
                    dataTable.Columns.Add(prop.Name, prop.PropertyType);
                }
                foreach (T item in items)
                {
                    var values = new object[Props.Length];
                    for (int i = 0; i < Props.Length; i++)
                    {
                        if (Props[i].PropertyType == typeof(DateTime))
                        {
                            if (Convert.ToDateTime(Props[i].GetValue(item, null)) == DateTime.MinValue)
                            {
                                values[i] = null;
                            }
                            else
                            {
                                values[i] = Props[i].GetValue(item, null);
                            }
                        }
                        else
                        {
                            values[i] = Props[i].GetValue(item, null);
                        }
                    }
                    dataTable.Rows.Add(values);
                }
            }
            catch (Exception ex)
            {
                ErrorLog("ToDataTable", ex.ToString());
            }

            return dataTable;
        }

        #region Logging
        private void TimeLog(string log)
        {
            try
            {
                //string LogPath = ConfigurationManager.AppSettings["TwitterTimeLog"].ToString();


                string LogPath = ConfigurationManager.AppSettings["Twitter_TimeLogPath"].ToString();

                using (TextWriter myWriter = File.AppendText(LogPath))
                {

                    TextWriter.Synchronized(myWriter).WriteLine("<--> :{0}", string.Empty);
                    TextWriter.Synchronized(myWriter).WriteLine("Log :{0}", log);
                    TextWriter.Synchronized(myWriter).WriteLine("Date :{0}", DateTime.Now.ToString());
                    TextWriter.Synchronized(myWriter).WriteLine("<--> :{0}", string.Empty);
                    TextWriter.Synchronized(myWriter).Flush();
                    TextWriter.Synchronized(myWriter).Close();
                }
            }
            catch (Exception ex)
            {
                ErrorLog("TimeLog ", ex.Message + " ->> " + ex.StackTrace);
            }
        }

        private void ErrorLog(string functionName, string error)
        {
            try
            {

                string LogPath = ConfigurationManager.AppSettings["Twitter_ErrorLogPath"].ToString();

                using (TextWriter myWriter = File.AppendText(LogPath))
                {

                    TextWriter.Synchronized(myWriter).WriteLine("<--> :{0}", string.Empty);
                    TextWriter.Synchronized(myWriter).WriteLine("Function Name :{0}", functionName);
                    TextWriter.Synchronized(myWriter).WriteLine("Error :{0}", error);
                    TextWriter.Synchronized(myWriter).WriteLine("Date :{0}", DateTime.Now.ToString());
                    TextWriter.Synchronized(myWriter).WriteLine("<--> :{0}", string.Empty);
                    TextWriter.Synchronized(myWriter).Flush();
                    TextWriter.Synchronized(myWriter).Close();
                }


            }
            catch (Exception ex)
            {
            }
        }
        #endregion

        
    }
}
