﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Sahadeva.API.Common.Constants
{
    public class DataBaseConstants
    {
        #region Connection String

        public const string MTrackConnectionString = "MTrack_ConnectionString";
        public const string MDBConnectionString = "MDB_ConnectionString";
        public const string PRConnectionString = "PR_ConnectionString";
        public const string SahadevConnectionString = "Sahadev_ConnectionString";

        public const string C2ConnectionString = "C2ConnectionString";

        #endregion Connection String

        #region Procedures

        public const string USP_API_User_Fetch = "USP_API_User_Fetch";
        public const string USP_API_SentryV2_User_Fetch = "USP_API_SentryV2_User_Fetch";
        public const string USP_API_UserDeviceIds_Update_AWS = "USP_API_UserDeviceIds_Update_AWS";


        public const string USP_API_SentryV2_Incident_FetchList = "USP_API_SentryV2_Incident_FetchList";
        public const string USP_API_SentryV2_Incident_FetchDetail = "USP_API_SentryV2_Incident_FetchDetail";
        public const string USP_API_SentryV2_Overview_FetchLanding = "USP_API_SentryV2_Overview_FetchLanding";
        public const string USP_API_SentryV2_Overview_FetchLanding_Mobile = "USP_API_SentryV2_Overview_FetchLanding_Mobile";

        public const string USP_API_SentryV2_ArticleOnline_FetchLanding = "USP_API_SentryV2_ArticleOnline_FetchLanding";
        public const string USP_API_SentryV2_ArticleOnline_FetchLanding_Mobile = "USP_API_SentryV2_ArticleOnline_FetchLanding_Mobile";
        public const string USP_API_SentryV2_ArticleOnline_FetchList = "USP_API_SentryV2_ArticleOnline_FetchList";
        public const string USP_API_SentryV2_ArticleOnline_FetchById = "USP_API_SentryV2_ArticleOnline_FetchById";
        public const string USP_API_SentryV2_ArticleOnline_FetchFilter = "USP_API_SentryV2_ArticleOnline_FetchFilter";


        public const string USP_API_SentryV2_ArticlePrint_FetchLanding = "USP_API_SentryV2_ArticlePrint_FetchLanding";
        public const string USP_API_SentryV2_ArticlePrint_FetchLanding_Mobile = "USP_API_SentryV2_ArticlePrint_FetchLanding_Mobile";
        public const string USP_API_SentryV2_ArticlePrint_FetchList = "USP_API_SentryV2_ArticlePrint_FetchList";
        public const string USP_API_SentryV2_ArticlePrint_FetchById = "USP_API_SentryV2_ArticlePrint_FetchById";
        public const string USP_API_SentryV2_ArticlePrint_FetchFilter = "USP_API_SentryV2_ArticlePrint_FetchFilter";

        public const string USP_API_SentryV2_Twitter_FetchLanding = "USP_API_SentryV2_Twitter_FetchLanding";
        public const string USP_API_SentryV2_Twitter_FetchLanding_Mobile = "USP_API_SentryV2_Twitter_FetchLanding_Mobile";
        public const string USP_API_SentryV2_Twitter_FetchList = "USP_API_SentryV2_Twitter_FetchList";
        public const string USP_API_SentryV2_Twitter_FetchById = "USP_API_SentryV2_Twitter_FetchById";
        public const string USP_API_SentryV2_Twitter_FetchFilter = "USP_API_SentryV2_Twitter_FetchFilter";

        public const string USP_API_SentryV2_NotificationSettings_Fetch = "USP_API_SentryV2_NotificationSettings_Fetch";
        public const string USP_API_SentryV2_NotificationSettings_Update = "USP_API_SentryV2_NotificationSettings_Update";
        public const string USP_API_SentryV2_NotificationSettings_Fetch_New = "USP_API_SentryV2_NotificationSettings_Fetch_New";
        public const string USP_API_SentryV2_NotificationSettings_Update_New = "USP_API_SentryV2_NotificationSettings_Update_New";
        public const string USP_API_SentryV2_Event_NotificationSetting_ConditionalDetail_Insert = "USP_API_SentryV2_Event_NotificationSetting_ConditionalDetail_Insert";


        public const string USP_API_SentryV2_UserRequestTopic_Insert = "USP_API_SentryV2_UserRequestTopic_Insert";

        public const string USP_API_SentryV2_Client_FetchClientsByUserID = "USP_API_SentryV2_Client_FetchClientsByUserID";

        public const string USP_API_SentryV2_Twitter_FetchParticipant_List = "USP_API_SentryV2_Twitter_FetchParticipant_List";
        public const string USP_API_SentryV2_Twitter_FetchParticipant_FetchFilter = "USP_API_SentryV2_Twitter_FetchParticipant_FetchFilter";
        public const string USP_API_SentryV2_Twitter_FetchParticipant_FetchById = "USP_API_SentryV2_Twitter_FetchParticipant_FetchById";

        public const string USP_API_SentryV2_ArticlePrint_FetchParticipant_List = "USP_API_SentryV2_ArticlePrint_FetchParticipant_List";
        public const string USP_API_SentryV2_ArticlePrint_FetchParticipant_FetchFilter = "USP_API_SentryV2_ArticlePrint_FetchParticipant_FetchFilter";
        public const string USP_API_SentryV2_ArticlePrint_FetchParticipant_FetchById = "USP_API_SentryV2_ArticlePrint_FetchParticipant_FetchById";

        public const string USP_API_SentryV2_ArticleOnline_FetchParticipant_List = "USP_API_SentryV2_ArticleOnline_FetchParticipant_List";
        public const string USP_API_SentryV2_ArticleOnline_FetchParticipant_FetchFilter = "USP_API_SentryV2_ArticleOnline_FetchParticipant_FetchFilter";
        public const string USP_API_SentryV2_ArticleOnline_FetchParticipant_FetchById = "USP_API_SentryV2_ArticleOnline_FetchParticipant_FetchById";

        //ArticleOnline
        public const string USP_ArticleOnline_Insert = "USP_ArticleOnline_Insert";
        public const string USP_ArticleOnline_CheckDuplicate = "USP_ArticleOnline_CheckDuplicate";

        //ArticleDiffbot
        public const string USP_ArticleDiffbot_CheckDuplicate = "USP_ArticleDiffbot_CheckDuplicate";

        //ArticlePrint
        public const string USP_ArticlePrint_Insert = "USP_ArticlePrint_Insert";
        public const string USP_Analaysis_Search = "USP_Analaysis_Search_Mayuresh";


        public const string USP_Log_Insert = "USP_Log_Insert";
        public const string USP_API_SentryV2_UserLog_Insert = "USP_API_SentryV2_UserLog_Insert";

        public const string USP_API_UserRequest_DataDownload_Insert = "USP_API_UserRequest_DataDownload_Insert";


        public const string USP_ZURT_Delete = "USP_ZURT_Delete";
        public const string USP_ZURT_FetchAll = "USP_ZURT_FetchAll";
        public const string USP_ZURT_FetchByID = "USP_ZURT_FetchByID";
        public const string USP_ZURT_Insert = "USP_ZURT_Insert";
        public const string USP_ZURT_Update = "USP_ZURT_Update";


        //Bookmarks
        public const string USP_UserBookmark_Update = "USP_UserBookmark_Update";
        public const string USP_UserBookmark_FetchList = "USP_UserBookmark_FetchList";

        //Notification 
        public const string USP_SentryV2_Fetch_NotificationList = "USP_SentryV2_Fetch_NotificationList";
        public const string USP_SentryV2_Update_Notifications_IsRead = "USP_SentryV2_Update_Notifications_IsRead";
        public const string USP_SentryV2_Fetch_NotificationDetail_ByNLID = "USP_SentryV2_Fetch_NotificationDetail_ByNLID";
        public const string USP_API_SentryV2_NotificationSettings_Update_Bulk = "USP_API_SentryV2_NotificationSettings_Update_Bulk";
        public const string USP_API_SentryV2_NotificationSettings_Fetch_by_IncidentID = "USP_API_SentryV2_NotificationSettings_Fetch_by_IncidentID";

        public const string USP_SentryV2_Fetch_NotificationList_New = "USP_SentryV2_Fetch_NotificationList_New";
        public const string USP_SentryV2_Fetch_NotificationDetail_ByNLID_New = "USP_SentryV2_Fetch_NotificationDetail_ByNLID_New";
        public const string USP_API_SentryV2_NotificationSettings_Update_Bulk_New = "USP_API_SentryV2_NotificationSettings_Update_Bulk_New";
        public const string USP_API_SentryV2_NotificationSettings_Fetch_by_IncidentID_New = "USP_API_SentryV2_NotificationSettings_Fetch_by_IncidentID_New";

        //Mark As Relevant
        public const string USP_API_Insert_UserRequest_Irrelavant = "USP_API_Insert_UserRequest_Irrelavant";

        //Percentage Overview and Landing
        public const string USP_API_SentryV2_Overview_FetchLanding_Percentage = "USP_API_SentryV2_Overview_FetchLanding_Percentage";
        public const string USP_API_SentryV2_ArticleOnline_FetchLanding_Percentage = "USP_API_SentryV2_ArticleOnline_FetchLanding_Percentage";
        public const string USP_API_SentryV2_ArticlePrint_FetchLanding_Percentage = "USP_API_SentryV2_ArticlePrint_FetchLanding_Percentage";
        public const string USP_API_SentryV2_Twitter_FetchLanding_percentage = "USP_API_SentryV2_Twitter_FetchLanding_percentage";
        public const string USP_API_SentryV2_YouTube_FetchLanding_percentage = "USP_API_SentryV2_YouTube_FetchLanding_percentage";

        //Hide Denominator
        public const string USP_API_SentryV2_Overview_FetchLanding_HideTotals = "USP_API_SentryV2_Overview_FetchLanding_HideTotals";
        public const string USP_API_SentryV2_ArticleOnline_FetchLanding_hide_denominator = "USP_API_SentryV2_ArticleOnline_FetchLanding_HideTotals";
        public const string USP_API_SentryV2_ArticlePrint_FetchLanding_hide_denominator = "USP_API_SentryV2_ArticlePrint_FetchLanding_HideTotals";
        public const string USP_API_SentryV2_Twitter_FetchLanding_hide_denominator = "USP_API_SentryV2_Twitter_FetchLanding_HideTotals";
        public const string USP_API_SentryV2_YouTube_FetchLanding_hide_denominator = "USP_API_SentryV2_YouTube_FetchLanding_HideTotals";

        //Youtube
        public const string USP_API_SentryV2_YouTube_FetchLanding = "USP_API_SentryV2_YouTube_FetchLanding";
        public const string USP_API_SentryV2_YouTube_FetchLanding_Mobile = "USP_API_SentryV2_YouTube_FetchLanding_Mobile";
        public const string USP_API_SentryV2_YouTube_FetchList = "USP_API_SentryV2_YouTube_FetchList";
        public const string USP_API_SentryV2_YouTube_FetchById = "USP_API_SentryV2_YouTube_FetchById";
        public const string USP_API_SentryV2_YouTube_FetchFilter = "USP_API_SentryV2_YouTube_FetchFilter";
        public const string USP_API_SentryV2_YouTube_FetchParticipant_List = "USP_API_SentryV2_YouTube_FetchParticipant_List";
        public const string USP_API_SentryV2_YouTube_FetchParticipant_FetchById = "USP_API_SentryV2_YouTube_FetchParticipant_FetchById";
        public const string USP_API_SentryV2_YouTube_FetchParticipant_FetchFilter = "USP_API_SentryV2_YouTube_FetchParticipant_FetchFilter";

        //Feed Monitor

        public const string USP_API_FeedMonitor_Funnel_Online = "USP_API_FeedMonitor_Funnel_Online";
        public const string USP_API_FeedMonitor_Funnel_Online_Detail = "USP_API_FeedMonitor_Funnel_Online_Detail";
        public const string USP_API_FeedMonitor_Incident_FetchList = "USP_API_FeedMonitor_Incident_FetchList";
        public const string USP_API_FeedMonitor_UserEvent_Stats = "USP_API_FeedMonitor_UserEvent_Stats";
        public const string USP_API_FeedMonitor_Funnel_Twitter = "USP_API_FeedMonitor_Funnel_Twitter";
        public const string USP_API_FeedMonitor_Funnel_Twitter_Detail = "USP_API_FeedMonitor_Funnel_Twitter_Detail";
        public const string USP_API_FeedMonitor_Funnel_YouTube = "USP_API_FeedMonitor_Funnel_YouTube";
        public const string USP_API_FeedMonitor_Funnel_YouTube_Detail = "USP_API_FeedMonitor_Funnel_YouTube_Detail";

        //Twitter Optimization 

        public const string USP_API_SentryV2_Twitter_FetchLanding_Optimized_StatCards = "USP_API_SentryV2_Twitter_FetchLanding_Optimized_StatCards";
        public const string USP_API_SentryV2_Twitter_FetchLanding_Optimized_Active_Participants = "USP_API_SentryV2_Twitter_FetchLanding_Optimized_Active_Participants";
        public const string USP_API_SentryV2_Twitter_FetchLanding_Optimized_Distribution_By_Engagement = "USP_API_SentryV2_Twitter_FetchLanding_Optimized_Distribution_By_Engagement";
        public const string USP_API_SentryV2_Twitter_FetchLanding_Optimized_Distribution_By_Sentiment = "USP_API_SentryV2_Twitter_FetchLanding_Optimized_Distribution_By_Sentiment";
        public const string USP_API_SentryV2_Twitter_FetchLanding_Optimized_Distribution_By_Tonaity = "USP_API_SentryV2_Twitter_FetchLanding_Optimized_Distribution_By_Tonaity";
        public const string USP_API_SentryV2_Twitter_FetchLanding_Optimized_Heading_stats = "USP_API_SentryV2_Twitter_FetchLanding_Optimized_Heading_stats";
        public const string USP_API_SentryV2_Twitter_FetchLanding_Optimized_Media_Influencers = "USP_API_SentryV2_Twitter_FetchLanding_Optimized_Media_Influencers";
        public const string USP_API_SentryV2_Twitter_FetchLanding_Optimized_Top_Mentioned_Hashtags = "USP_API_SentryV2_Twitter_FetchLanding_Optimized_Top_Mentioned_Hashtags";
        public const string USP_API_SentryV2_Twitter_FetchLanding_Optimized_TopTenContributorsByEngagement = "USP_API_SentryV2_Twitter_FetchLanding_Optimized_TopTenContributorsByEngagement";
        public const string USP_API_SentryV2_Twitter_FetchLanding_Optimized_TopTenContributorsByReach = "USP_API_SentryV2_Twitter_FetchLanding_Optimized_TopTenContributorsByReach";
        public const string USP_API_SentryV2_Twitter_FetchLanding_Optimized_TweetsTimeline = "USP_API_SentryV2_Twitter_FetchLanding_Optimized_TweetsTimeline";
        public const string USP_API_SentryV2_Twitter_FetchLanding_Optimized_conversion_themes = "USP_API_SentryV2_Twitter_FetchLanding_Optimized_conversion_themes";
        public const string USP_API_SentryV2_Twitter_FetchLanding_Optimized_Key_Highlights_Data = "USP_API_SentryV2_Twitter_FetchLanding_Optimized_Key_Highlights_Data";


        //Online Optimization

        public const string USP_API_SentryV2_ArticleOnline_FL_Optimized_StatCards = "USP_API_SentryV2_ArticleOnline_FL_Optimized_StatCards";
        public const string USP_API_SentryV2_ArticleOnline_FL_ = "USP_API_SentryV2_ArticleOnline_FL_Optimized_";

        //Print Optimization

        public const string USP_API_SentryV2_ArticlePrint_FL_Optimized_StatCards = "USP_API_SentryV2_ArticlePrint_FL_Optimized_StatCards";
        public const string USP_API_SentryV2_ArticlePrint_FL_Optimized_ = "USP_API_SentryV2_ArticlePrint_FL_Optimized_";

        //Print Optimization

        public const string USP_API_SentryV2_YouTube_FL_Optimized_StatCards = "USP_API_SentryV2_YouTube_FL_Optimized_StatCards";
        public const string USP_API_SentryV2_YouTube_FL_Optimized_ = "USP_API_SentryV2_YouTube_FL_Optimized_";

        //Download Data

        public const string USP_DownloadData_Online = "USP_DownloadData_Online";
        public const string USP_DownloadData_Print = "USP_DownloadData_Print";
        public const string USP_DownloadData_Twitter = "USP_DownloadData_Twitter";
        public const string USP_DownloadData_YouTube = "USP_DownloadData_YouTube";

        ////Heading Stats is common for all platforms 

        public const string USP_API_SentryV2_FetchLanding_Optimized_Heading_stats = "USP_API_SentryV2_FetchLanding_Optimized_Heading_stats";

        //List Pagination

        public const string USP_API_SentryV2_ArticleOnline_FetchList_Pagination = "USP_API_SentryV2_ArticleOnline_FetchList_Pagination";
        public const string USP_API_SentryV2_ArticlePrint_FetchList_Pagination = "USP_API_SentryV2_ArticlePrint_FetchList_Pagination";
        public const string USP_API_SentryV2_Twitter_FetchList_Pagination = "USP_API_SentryV2_Twitter_FetchList_Pagination";
        public const string USP_API_SentryV2_YouTube_FetchList_Pagination = "USP_API_SentryV2_YouTube_FetchList_Pagination";


        public const string USP_API_SentryV2_ArticleOnline_FetchParticipant_List_Pagination = "USP_API_SentryV2_ArticleOnline_FetchParticipant_List_Pagination";
        public const string USP_API_SentryV2_ArticlePrint_FetchParticipant_List_Pagination = "USP_API_SentryV2_ArticlePrint_FetchParticipant_List_Pagination";
        public const string USP_API_SentryV2_Twitter_FetchParticipant_List_Pagination = "USP_API_SentryV2_Twitter_FetchParticipant_List_Pagination";
        public const string USP_API_SentryV2_YouTube_FetchParticipant_List_Pagination = "USP_API_SentryV2_YouTube_FetchParticipant_List_Pagination";


        //List Page View Chart

        public const string USP_API_SentryV2_ArticleOnline_ListPage_ViewChart = "USP_API_SentryV2_ArticleOnline_ListPage_ViewChart";
        public const string USP_API_SentryV2_ArticlePrint_ListPage_ViewChart = "USP_API_SentryV2_ArticlePrint_ListPage_ViewChart";
        public const string USP_API_SentryV2_Twitter_ListPage_ViewChart = "USP_API_SentryV2_Twitter_ListPage_ViewChart";
        public const string USP_API_SentryV2_YouTube_ListPage_ViewChart = "USP_API_SentryV2_YouTube_ListPage_ViewChart";

        //user mark Irrelevant
        public const string USP_UserMarkedIrrelevantList_Fetch = "USP_UserMarkedIrrelevantList_Fetch";
        public const string USP_UserMarkedIrrelevantList_Insert = "USP_UserMarkedIrrelevantList_Insert";



        //Data Tag

        public const string USP_DataTag_Insert = "USP_DataTag_Insert";
        public const string USP_DataTagPattern_Fetch = "USP_DataTagPattern_Fetch";
        public const string USP_DataTagPattern_Insert = "USP_DataTagPattern_Insert";
        public const string USP_DataTagPattern_Update = "USP_DataTagPattern_Update";
        public const string USP_DataTagDetail_Insert = "USP_DataTagDetail_Insert";
        public const string USP_DataTag_Fetch = "USP_DataTag_Fetch";
        public const string USP_DataTag_Delete = "USP_DataTag_Delete";
        public const string USP_DataTag_Fetch_All = "USP_DataTag_Fetch_All";

        //Reddit

        public const string USP_API_SentryV2_Reddit_FetchList_Pagination = "USP_API_SentryV2_Reddit_FetchList_Pagination";
        


        #endregion Procedures

        #region Fields

        public const string TopicName = "TopicName";
        public const string TopicDescription = "TopicDescription";
        public const string Reference_ArticleUrl = "Reference_ArticleUrl";
        public const string Keywords = "Keywords";
        public const string Platforms = "Platforms";
        public const string StartDate = "StartDate";
        public const string EndDate = "EndDate";
        public const string URTID = "URTID";
        public const string RecordID = "RecordID";
        public const string Type = "Type";
        public const string TopicType = "TopicType";



        //Common
        public const string SearchText = "SearchText";
        public const string SortBy = "SortBy";
        public const string SortOrder = "SortOrder";
        public const string CreatedAt = "CreatedAt";
        public const string ModifiedAt = "ModifiedAt";
        public const string IsActive = "IsActive";
        public const string ServiceID = "ServiceID";
        public const string FromDate = "FromDate";
        public const string ToDate = "ToDate";
        public const string BaseDate = "BaseDate";
        public const string UserID = "UserID";
        public const string TwitterID = "TwitterID";
        public const string UserName = "UserName";
        public const string Password = "Password";
        public const string AppName = "AppName";
        public const string DeviceID = "DeviceID";
        public const string OS = "OS";
        public const string Screen_Name = "Screen_Name";


        public const string Sentiment = "Sentiment";
        public const string Tonality = "Tonality";
        public const string Publication_Domain = "Publication_Domain";
        public const string Publication_Type = "Publication_Type";
        public const string Publication_DA = "Publication_DA";
        public const string Publication_Traffic = "Publication_Traffic";
        public const string Publication_ImpactScore = "Publication_ImpactScore";
        public const string Publication_Name = "Publication_Name";
        public const string Publication_Edition = "Publication_Edition";
        public const string Publication_Circulation = "Publication_Circulation";

        public const string Mentioned_Hashtag = "Mentioned_Hashtag";
        public const string Mentioned_Handle = "Mentioned_Handle";
        public const string Profile_Category = "Profile_Category";
        public const string Media_Type = "Media_Type";
        public const string Mention_Type = "Mention_Type";
        public const string Client_Mention = "Client_Mention";
        public const string Headline_Sentiment = "Headline_Sentiment";
        public const string Article_Type = "Article_Type";
        public const string Eng_Type = "Eng_Type";
        public const string Hide_Denominator = "Hide_Denominator";
        public const string ShowPercentage = "Show_Percentage";



        public const string Profile_Name = "Profile_Name";
        public const string Profile_Handle = "Profile_Handle";
        public const string Participant_Type = "Participant_Type";
        public const string Profile_Followerscount = "Profile_Followerscount";
        public const string Profile_VerifiedType = "Profile_VerifiedType";

        public const string Exclude_By_Text = "Exclude_By_Text";
        public const string Last_Seen_ID = "Last_Seen_ID";
        public const string Page_Size = "Page_Size";
        public const string DataTag = "DataTag";


        //Incident
        public const string IncidentID = "IncidentID";
        public const string PlatformID = "PlatformID";
        public const string Platform_IsActive = "Platform_IsActive";
        public const string Platform_AsItHappens = "Platform_AsItHappens";
        public const string Platform_Summarised = "Platform_Summarised";
        public const string Platform_SummarisedInterval = "Platform_SummarisedInterval";
        public const string Platform_Conditional = "Platform_Conditional";


        //eEntityQuery
        public const string Query = "Query";
        public const string EntityType = "EntityType";
        public const string EntityName = "EntityName";
        public const string TopicID = "TopicID";
        public const string HistoryDate = "HistoryDate";
        public const string TagID = "TagID";


        //Article Fields
        public const string ArticleID = "ArticleID";
        public const string ADID = "ADID";
        public const string EQID = "EQID";
        public const string EntityID = "EntityID";
        public const string Url = "Url";
        public const string HashUrl = "HashUrl";
        public const string HashUrls = "HashUrls";
        public const string Title = "Title";
        public const string Text = "Text";
        public const string Date = "Date";
        public const string Language = "Language";
        public const string Publication = "Publication";
        public const string Publication_Url = "Publication_Url";
        public const string Summary = "Summary";
        public const string Mentioned_Companies = "Mentioned_Companies";
        public const string Mentioned_Industries = "Mentioned_Industries";
        public const string Mentioned_Locations = "Mentioned_Locations";
        public const string Mentioned_Topics = "Mentioned_Topics";
        public const string DB_Text = "DB_Text";
        public const string DB_Date = "DB_Date";
        public const string DB_Html = "DB_Html";
        public const string DB_Title = "DB_Title";
        public const string DB_Author = "DB_Author";
        public const string DB_AuthorUrl = "DB_AuthorUrl";
        public const string DB_SiteName = "DB_SiteName";
        public const string DB_PublisherRegion = "DB_PublisherRegion";
        public const string DB_PublisherCountry = "DB_PublisherCountry";
        public const string DB_Sentiment = "DB_Sentiment";
        public const string DB_Tags = "DB_Tags";
        public const string DB_TagLabel1 = "DB_TagLabel1";
        public const string DB_TagScore1 = "DB_TagScore1";
        public const string DB_TagCount1 = "DB_TagCount1";
        public const string DB_TagLabel2 = "DB_TagLabel2";
        public const string DB_TagScore2 = "DB_TagScore2";
        public const string DB_TagCount2 = "DB_TagCount2";
        public const string DB_TagLabel3 = "DB_TagLabel3";
        public const string DB_TagScore3 = "DB_TagScore3";
        public const string DB_TagCount3 = "DB_TagCount3";
        public const string DB_TagLabel4 = "DB_TagLabel4";
        public const string DB_TagScore4 = "DB_TagScore4";
        public const string DB_TagCount4 = "DB_TagCount4";
        public const string DB_TagLabel5 = "DB_TagLabel5";
        public const string DB_TagScore5 = "DB_TagScore5";
        public const string DB_TagCount5 = "DB_TagCount5";
        public const string DB_Language = "DB_Language";
        public const string DB_Images = "DB_Images";
        public const string TML_Publication_Domain = "TML_Publication_Domain";
        public const string TML_Publication_Name = "TML_Publication_Name";
        public const string TML_Author = "TML_Author";
        public const string TML_Channel = "TML_Channel";
        public const string TML_Handle = "TML_Handle";
        public const string Is_TML_DATA = "Is_TML_DATA";
        public const string SearchText_In = "SearchText_In";




        //Log
        public const string GUID = "GUID";
        public const string Count_Total = "Count_Total";
        public const string Count_Inserted = "Count_Inserted";
        public const string Count_Duplicate = "Count_Duplicate";
        public const string Count_Failed = "Count_Failed";
        public const string Count_DB_Successful = "Count_DB_Successful";
        public const string Count_DB_Failed = "Count_DB_Failed";


        //Print 

        public const string NewsID = "NewsID";
        public const string NewsDate = "NewsDate";
        public const string IssueDate = "IssueDate";
        public const string MEDIATYPE = "MEDIATYPE";
        public const string Publicationtype = "Publicationtype";
        public const string Agency = "Agency";
        public const string Author = "Author";
        public const string Edition = "Edition";
        public const string Source = "Source";
        public const string Journalist = "Journalist";
        public const string Supplement = "Supplement";
        public const string Headline = "Headline";
        public const string NewsText = "NewsText";
        public const string ClientID = "ClientID";
        public const string Id = "Id";
        public const string ImagePath = "ImagePath";
        public const string ImageURL = "ImageURL";
        public const string PgNO = "PgNO";
        public const string SortPNo = "SortPNo";
        public const string Height = "Height";
        public const string Col = "Col";
        public const string NewsLocation = "NewsLocation";
        public const string MTrackEntityIds = "MTrackEntityIds";
        public const string MTrackEntityName = "MTrackEntityName";
        public const string PageNo = "PageNo";
        public const string HtInCms = "HtInCms";
        public const string NoCols = "NoCols";
        public const string NewsDetailID = "NewsDetailID";
        public const string ReporterNewsId = "ReporterNewsId";
        public const string CirculationScore = "CirculationScore";
        public const string strEntityId = "strEntityId";

        //UserRequest_DataDownload
        public const string Email = "Email";
        public const string RequestJson = "RequestJson";


        //USP_UserBookmark_Update
        public const string UBID = "UBID";
        public const string Platform = "Platform";

        public const string IsRead = "IsRead";
        public const string PrimaryKey = "PrimaryKey";
        public const string NotificationType = "NotificationType";

        //Mark As Relevant
        public const string Reason = "Reason";

        //Percentage Landing and Overview
        public const string show_percentage = "show_percentage";

        //Youtube

        public const string LYID = "LYID";
        //public const string ServiceID = "ServiceID";

        public const string Video_ID = "Video_ID";
        public const string Video_URL = "Video_URL";
        public const string Video_Title = "Video_Title";
        public const string Video_Date = "Video_Date";
        public const string Video_Text = "Video_Text";
        public const string Video_Transcript = "Video_Transcript";
        public const string Video_Tags = "Video_Tags";
        public const string Duration_In_Sec = "Duration_In_Sec";

        public const string Channel_Handle = "Channel_Handle";
        public const string Channel_Name = "Channel_Name";
        public const string Channel_URL = "Channel_URL";
        public const string Channel_Joined_Date = "Channel_Joined_Date";
        public const string Channel_Description = "Channel_Description";
        public const string Channel_Profile_Image_Link = "Channel_Profile_Image_Link";
        public const string Channel_Subscriber_Count = "Channel_Subscriber_Count";
        public const string Channel_Videos_Count = "Channel_Videos_Count";
        public const string Channel_Views_Count = "Channel_Views_Count";
        public const string Channel_Country = "Channel_Country";
        public const string Channel_Category = "Channel_Category";

        public const string Engagement_View_Count = "Engagement_View_Count";
        public const string Engagement_Like_Count = "Engagement_Like_Count";
        public const string Engagement_Dislike_Count = "Engagement_Dislike_Count";
        public const string Engagement_Comment_Count = "Engagement_Comment_Count";

        public const string Duration_In_Min = "Duration_In_Min";
        public const string Video_Type = "Video_Type";
        public const string Discourse_Category = "Discourse_Category";
        public const string People_Brand_Mentions = "People_Brand_Mentions";

        //FeedMonitor

        public const string Comment = "Comment";
        public const string GoogleTab = "GoogleTab";
        public const string TopicIDs = "TopicIDs";

        //Mark Relevancy

        public const string IsRelevant = "IsRelevant";
        public const string RecordIDs = "RecordIDs";
        public const string Show_IDs = "Show_IDs";


        //DataTag
        public const string TopicTypeID = "TopicTypeID";
        public const string Colour = "Colour";
        public const string ColourCode = "ColourCode";
        public const string DataTagDesc = "DataTagDesc";
        public const string RefID = "RefID";
        public const string DTID = "DTID";
        public const string Pattern = "Pattern";
        public const string Filter = "Filter";
        public const string IsSelectAll = "IsSelectAll";
        public const string DTPID = "DTPID";
        public const string IsPattern = "IsPattern";
        public const string BatchNo = "BatchNo";
        public const string DTTID = "DTTID";

        //Notification
        public const string ConditionID = "ConditionID";
        public const string Is_Deleted = "Is_Deleted";
        public const string criteriaJson = "criteriaJson";
        public const string ConditionName = "ConditionName";


        //Reddit
        public const string Subreddit = "Subreddit";
        public const string Subreddit_Name = "Subreddit_Name";
        public const string Subreddit_Subscriber_Count = "Subreddit_Subscriber_Count";
        public const string SubredditCategory = "SubredditCategory";
        public const string IsTop1Percent = "IsTop1Percent";
        public const string TML_Subreddit = "TML_Subreddit";
        public const string HandleTextSearch = "HandleTextSearch";


        #endregion Fields
    }
}
