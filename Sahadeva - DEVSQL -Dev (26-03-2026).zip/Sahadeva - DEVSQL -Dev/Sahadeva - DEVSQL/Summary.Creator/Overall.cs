﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;
using System.Configuration;
using Newtonsoft.Json;
using System.Net;
using System.IO;
using System.Diagnostics;
using System.Threading.Tasks;
using Newtonsoft.Json.Linq;
using System.Data;
using MDB.Entities;

namespace Summary.Creator
{
    public class Overall
    {
        #region Class for Sending Parameters To Service

        [DataContract]
        public class eRequestParameter
        {
            [DataMember]
            public String ts_id { get; set; }
        }
        #endregion

        public void DoProcess(DateTime FromDate, DateTime ToDate, string TopicID)
        {
            TimeLog("Process Started");
            try
            {
                try
                {
                    DataTable dt = new MDB.DAL.DAL().Incident_OverallSummary_Insert(Convert.ToInt32(TopicID.ToString()), 0, FromDate, ToDate, "","Landing");
                    dynamic json = new JObject();
                    if (dt.Rows.Count > 0)
                    {

                        json = (JObject)JArray.FromObject(dt)[0];
                    }

                    var setting = new JsonSerializerSettings
                    {
                        MaxDepth = int.MaxValue
                    };

                    json = JsonConvert.SerializeObject(json, setting);

                    FetchData(Convert.ToString(json));
                }
                catch (Exception ex)
                {
                    ErrorLog("Error for " + TopicID.ToString(), ex.ToString());
                }

                #region COmmented Code
                //List<string> lstTopicIDs = ConfigurationManager.AppSettings["TopicIds"].ToString().Split(',').ToList();

                //var stopWatch = Stopwatch.StartNew();
                //ParallelOptions po = new ParallelOptions();
                //po.MaxDegreeOfParallelism = Convert.ToInt32(ConfigurationManager.AppSettings["Overall_MaxDegreeOfParallelism"]);
                //System.Net.ServicePointManager.DefaultConnectionLimit = Convert.ToInt32(ConfigurationManager.AppSettings["Overall_MaxDegreeOfParallelism"]);

                //Parallel.For(0, lstTopicIDs.Count, po, i =>
                //{
                //    try
                //    {
                //        DataTable dt = new MDB.DAL.DAL().Incident_OverallSummary_Insert(Convert.ToInt32(lstTopicIDs[i].ToString()), 0, FromDate, ToDate, "");
                //        dynamic json = new JObject();
                //        if (dt.Rows.Count > 0)
                //        {

                //            json = (JObject)JArray.FromObject(dt)[0];
                //        }

                //        var setting = new JsonSerializerSettings
                //        {
                //            MaxDepth = int.MaxValue
                //        };

                //        json = JsonConvert.SerializeObject(json, setting);

                //        FetchData(Convert.ToString(json));
                //    }
                //    catch (Exception ex)
                //    {
                //        ErrorLog("Error for " + lstTopicIDs[i].ToString(), ex.ToString());
                //    }

                //});
                //TimeLog("End Parallel.For");
                //TimeLog("Parallel.For() execution time for " + " = {0} seconds:" + stopWatch.Elapsed.TotalSeconds); 
                #endregion
            }
            catch (Exception ex)
            {
                ErrorLog("DoProcess", ex.Message + " ->> " + ex.StackTrace);
            }
            TimeLog("Process Ended");
        }

        public string FetchData(string Json)
        {
            string strOutput = string.Empty;

            try
            {
                string strFinalURL = string.Empty;
                string strURL_Service = ConfigurationManager.AppSettings["Url_Overall"].ToString();


                if (!String.IsNullOrEmpty(strURL_Service))
                {
                    //Create bytes array to send Input as parameter
                    byte[] bytes = bytes = Encoding.UTF8.GetBytes(Json.ToCharArray());//System.Text.Encoding.GetEncoding("ISO-8859-1").GetBytes(strParameters);

                    HttpWebRequest request = (HttpWebRequest)WebRequest.Create(strURL_Service);
                    request.Timeout = Convert.ToInt32(ConfigurationManager.AppSettings["TimeOutIntervalForOperation"]);
                    request.ContentType = "application/json; charset=utf8";
                    request.ContentLength = bytes.Length;
                    request.Method = "POST";

                    //Upload bytes array to request
                    using (Stream os = request.GetRequestStream())
                    {
                        os.Write(bytes, 0, bytes.Length);
                    }

                    //Get response from TextProcessingPipeline
                    using (System.Net.WebResponse resp = request.GetResponse())
                    {
                        using (StreamReader sr = new StreamReader(resp.GetResponseStream()))
                        {
                            strOutput = sr.ReadToEnd().Trim();
                        }
                    }

                    request = null;
                }
            }
            catch (Exception ex)
            {
                ErrorLog("FetchData " + Json, ex.Message + " ->> " + ex.StackTrace);
            }

            return strOutput;
        }

        #region Logging
        private void TimeLog(string log)
        {
            try
            {
                string LogPath = ConfigurationManager.AppSettings["Overall_TimeLogPath"].ToString();

                using (TextWriter myWriter = File.AppendText(LogPath))
                {

                    TextWriter.Synchronized(myWriter).WriteLine("<--> :{0}", string.Empty);
                    TextWriter.Synchronized(myWriter).WriteLine("Log :{0}", log);
                    TextWriter.Synchronized(myWriter).WriteLine("Date :{0}", DateTime.Now.ToString());
                    TextWriter.Synchronized(myWriter).WriteLine("<--> :{0}", string.Empty);
                    TextWriter.Synchronized(myWriter).Flush();
                    TextWriter.Synchronized(myWriter).Close();
                }
            }
            catch (Exception ex)
            {
                ErrorLog("TimeLog ", ex.Message + " ->> " + ex.StackTrace);
            }
        }

        private void ErrorLog(string functionName, string error)
        {
            try
            {

                string LogPath = ConfigurationManager.AppSettings["Overall_ErrorLogPath"].ToString();

                using (TextWriter myWriter = File.AppendText(LogPath))
                {

                    TextWriter.Synchronized(myWriter).WriteLine("<--> :{0}", string.Empty);
                    TextWriter.Synchronized(myWriter).WriteLine("Function Name :{0}", functionName);
                    TextWriter.Synchronized(myWriter).WriteLine("Error :{0}", error);
                    TextWriter.Synchronized(myWriter).WriteLine("Date :{0}", DateTime.Now.ToString());
                    TextWriter.Synchronized(myWriter).WriteLine("<--> :{0}", string.Empty);
                    TextWriter.Synchronized(myWriter).Flush();
                    TextWriter.Synchronized(myWriter).Close();
                }


            }
            catch (Exception ex)
            {
            }
        }
        #endregion
    }
}
