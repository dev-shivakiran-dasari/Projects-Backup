﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Newtonsoft.Json.Linq;
using System.Data;
using System.Configuration;
using System.IO;
using Newtonsoft.Json;
using MDB.Entities;
using System.Globalization;

namespace Summary.Creator
{
    class Program
    {
        static void Main(string[] args)
        {


            new Twitter().CreateJSON_MJ();
            return;
            try
            {
                string strSummary = ConfigurationManager.AppSettings["SummaryType"];

                #region Peak
                if (strSummary == "Peak")
                {
                    DataTable dtPeaks = new MDB.DAL.DAL().SummaryPeak_FetchPeaks(0);
                    for (int i = 0; i < dtPeaks.Rows.Count; i++)
                    {
                        try
                        {

                            DateTime FromDate = Convert.ToDateTime(Convert.ToString(dtPeaks.Rows[i]["PeakStart"]));
                            DateTime ToDate = Convert.ToDateTime(Convert.ToString(dtPeaks.Rows[i]["PeakEnd"]));
                            Int32 PeakID = Convert.ToInt32(Convert.ToString(dtPeaks.Rows[i]["PeakID"]));
                            string Platform = Convert.ToString(dtPeaks.Rows[i]["Platform"]);
                            Int32 TopicID = Convert.ToInt32(Convert.ToString(dtPeaks.Rows[i]["TopicID"]));

                            Console.WriteLine("Start for " + PeakID.ToString() + " | " + Platform);

                            if (Platform == "twitter")
                            {
                                try
                                {
                                    Twitter obj = new Twitter();
                                    obj.DoProcess(FromDate, ToDate, Convert.ToString(TopicID), strSummary, PeakID);
                                    Console.WriteLine("Twitter Completed");
                                    System.Threading.Thread.Sleep(2000);
                                }
                                catch (Exception ex)
                                {
                                    Console.WriteLine("Error for " + PeakID.ToString() + " | " + Platform + " Error Is " + ex.Message + " ->> " + ex.StackTrace);
                                }
                            }

                            if (Platform == "online")
                            {
                                try
                                {
                                    OnlineArticle objOnlineArticle = new OnlineArticle();
                                    objOnlineArticle.DoProcess(FromDate, ToDate, Convert.ToString(TopicID), strSummary, PeakID);
                                    Console.WriteLine("OnlineArticle Completed");
                                    System.Threading.Thread.Sleep(2000);
                                }
                                catch (Exception ex)
                                {
                                    Console.WriteLine("Error for " + PeakID.ToString() + " | " + Platform + " Error Is " + ex.Message + " ->> " + ex.StackTrace);
                                }
                            }

                            if (Platform == "print")
                            {
                                try
                                {
                                    PrintArticle objPrintArticle = new PrintArticle();
                                    objPrintArticle.DoProcess(FromDate, ToDate, Convert.ToString(TopicID), strSummary, PeakID);
                                    Console.WriteLine("PrintArticle Completed");
                                    System.Threading.Thread.Sleep(2000);
                                }
                                catch (Exception ex)
                                {
                                    Console.WriteLine("Error for " + PeakID.ToString() + " | " + Platform + " Error Is " + ex.Message + " ->> " + ex.StackTrace);
                                }
                            }

                            Console.WriteLine("End for " + PeakID.ToString() + " | " + Platform);

                        }
                        catch (Exception)
                        {
                            continue;
                        }

                        System.Threading.Thread.Sleep(1000);
                    }

                } 
                #endregion
                #region Scheduled
                else if (strSummary == "Scheduled")
                {
                    #region MyRegion

                    DataTable dtPeaks = new MDB.DAL.DAL().SummaryPeak_FetchPeaks(0);

                    List<string> lstTopicIDs = ConfigurationManager.AppSettings["TopicIds"].ToString().Split(',').ToList();
                    lstTopicIDs = dtPeaks.AsEnumerable().Select(r => r.Field<string>("TopicID")).ToList();

                    DateTime ToDate = DateTime.Now;
                    DateTime FromDate = ToDate.AddHours(-1);

                    for (int i = 0; i < lstTopicIDs.Count; i++)
                    {

                        Console.WriteLine(lstTopicIDs[i].ToString() + " Start at " + DateTime.Now.ToString());

                        try
                        {
                            try
                            {
                                Twitter obj = new Twitter();
                                obj.DoProcess(FromDate, ToDate, lstTopicIDs[i].ToString(), strSummary, 0);
                                Console.WriteLine("Twitter Completed");
                                System.Threading.Thread.Sleep(8000);
                            }
                            catch (Exception ex) { }

                            try
                            {
                                OnlineArticle objOnlineArticle = new OnlineArticle();
                                objOnlineArticle.DoProcess(FromDate, ToDate, lstTopicIDs[i].ToString(), strSummary, 0);
                                Console.WriteLine("OnlineArticle Completed");
                                System.Threading.Thread.Sleep(4000);
                            }
                            catch (Exception ex) { }

                            try
                            {
                                PrintArticle objPrintArticle = new PrintArticle();
                                objPrintArticle.DoProcess(FromDate, ToDate, lstTopicIDs[i].ToString(), strSummary, 0);
                                Console.WriteLine("PrintArticle Completed");
                                System.Threading.Thread.Sleep(4000);
                            }
                            catch (Exception ex) { }


                            try
                            {
                                Overall objOverall = new Overall();
                                objOverall.DoProcess(FromDate, ToDate, lstTopicIDs[i].ToString());
                                Console.WriteLine("Overall Completed");
                                System.Threading.Thread.Sleep(4000);
                            }
                            catch (Exception ex) { }


                        }
                        catch (Exception)
                        {
                            Console.WriteLine(lstTopicIDs[i].ToString() + " Error Occured at " + DateTime.Now.ToString());
                            continue;
                        }
                        Console.WriteLine(lstTopicIDs[i].ToString() + " End at " + DateTime.Now.ToString());

                        System.Threading.Thread.Sleep(2000);
                    }
                    #endregion

                }  
                #endregion 
               
            }
            catch (Exception ex)
            {
                
                throw ex;
            }
            return;
            #region MyRegion
		    Log("Incident_FetchLanding DS start", "");
            DataSet ds = new MDB.DAL.DAL().Summary_FetchJSON(10, DateTime.Parse("2024-02-25 00:00:00"), DateTime.Parse("2024-02-27 00:00:00"),0);
            Log("Incident_FetchLanding DS end", "");

            Log("Incident_FetchLanding JSON start", "");
            dynamic json = new JObject();
            if (ds.Tables.Count > 0)
            {
                json.status = "200";
                json.message = "Success";
                json.request_id = Guid.NewGuid().ToString();
                json.data = new JObject();

                dynamic o = new JObject();

                //context Start
                o.context = new JObject();
                o.context.incident_id =Convert.ToInt32(ds.Tables[0].Rows[0]["incident_id"]);
                o.context.entity_id = Convert.ToInt32(ds.Tables[0].Rows[0]["entity_id"]);
                o.context.client_issue_description = Convert.ToString(ds.Tables[0].Rows[0]["client_issue_description"]);
                o.context.tsid = Convert.ToInt32(ds.Tables[0].Rows[0]["tsid"]);

                o.context.time_interval = new JObject();
                o.context.time_interval.t1 = new JObject();
                o.context.time_interval.t2 = new JObject();

                o.context.time_interval.t1.from_date = Convert.ToString(ds.Tables[0].Rows[0]["t1_from_date"]);
                o.context.time_interval.t1.to_date = Convert.ToString(ds.Tables[0].Rows[0]["t1_to_date"]);
                o.context.time_interval.t1.p6_summary = Convert.ToString(ds.Tables[0].Rows[0]["p6_summary"]);

                o.context.time_interval.t2.from_date = Convert.ToString(ds.Tables[0].Rows[0]["t2_from_date"]);
                o.context.time_interval.t2.to_date = Convert.ToString(ds.Tables[0].Rows[0]["t2_to_date"]);
                //context End

                //prompts_variables Start
                o.prompts_variables = new JObject();

                //p_1 Start
                o.prompts_variables.p_1 = new JObject();
                o.prompts_variables.p_1.t1 = new JObject();
                o.prompts_variables.p_1.t2 = new JObject();

                o.prompts_variables.p_1.t1.total_volume = Convert.ToInt32(ds.Tables[1].Rows[0]["total_volume"]);
                o.prompts_variables.p_1.t1.total_velocity = Convert.ToInt32(ds.Tables[1].Rows[0]["total_velocity"]);
                o.prompts_variables.p_1.t1.total_reach = Convert.ToInt32(ds.Tables[1].Rows[0]["total_reach"]);
                o.prompts_variables.p_1.t1.total_engagement = Convert.ToInt32(ds.Tables[1].Rows[0]["total_engagement"]);
                o.prompts_variables.p_1.t1.total_views = Convert.ToInt32(ds.Tables[1].Rows[0]["total_views"]);
                o.prompts_variables.p_1.t1.overall_sentiment_of_tweets_in_percentage = JArray.FromObject(ds.Tables[2]);

                o.prompts_variables.p_1.t2.total_volume = Convert.ToInt32(ds.Tables[3].Rows[0]["total_volume"]);
                o.prompts_variables.p_1.t2.total_velocity = Convert.ToInt32(ds.Tables[3].Rows[0]["total_velocity"]);
                o.prompts_variables.p_1.t2.total_reach = Convert.ToInt32(ds.Tables[3].Rows[0]["total_reach"]);
                o.prompts_variables.p_1.t2.total_engagement = Convert.ToInt32(ds.Tables[3].Rows[0]["total_engagement"]);
                o.prompts_variables.p_1.t2.total_views = Convert.ToInt32(ds.Tables[3].Rows[0]["total_views"]);
                o.prompts_variables.p_1.t2.overall_sentiment_of_tweets_in_percentage = JArray.FromObject(ds.Tables[4]);
                //p_1 End

                //p_2 Start
                o.prompts_variables.p_2 = new JObject();
                o.prompts_variables.p_2.t2 = new JObject();

                o.prompts_variables.p_2.t2.total_tweets = Convert.ToInt32(ds.Tables[5].Rows[0]["total_tweets"]);
                o.prompts_variables.p_2.t2.total_retweets = Convert.ToInt32(ds.Tables[5].Rows[0]["total_retweets"]);
                o.prompts_variables.p_2.t2.total_tweets_in_ct = Convert.ToInt32(ds.Tables[5].Rows[0]["total_tweets_in_ct"]);
                o.prompts_variables.p_2.t2.total_independent_tweets = Convert.ToInt32(ds.Tables[5].Rows[0]["total_independent_tweets"]);
                //p_2 End

                //p_3 Start
                o.prompts_variables.p_3 = new JObject();
                o.prompts_variables.p_3.t2 = new JObject();

                o.prompts_variables.p_3.t2.text_of_tweet = Convert.ToString(ds.Tables[6].Rows[0]["text_of_tweet"]);
                o.prompts_variables.p_3.t2.total_retweets = Convert.ToInt32(ds.Tables[6].Rows[0]["total_retweets"]);
                o.prompts_variables.p_3.t2.profile_handle = Convert.ToString(ds.Tables[6].Rows[0]["profile_handle"]);
                //p_3 End

                //p_4 Start
                o.prompts_variables.p_4 = new JObject();
                o.prompts_variables.p_4.t2 = new JArray();
                o.prompts_variables.p_4.t2 = JArray.FromObject(ds.Tables[7]);
                //p_4 End

                //p_5.1 Start
                o.prompts_variables.p_5_1 = new JObject();
                o.prompts_variables.p_5_1.t2 = new JArray();
                o.prompts_variables.p_5_1.t2 = JArray.FromObject(ds.Tables[8]);
                //p_5.1 End

                //p_5.2 Start
                o.prompts_variables.p_5_2 = new JObject();
                o.prompts_variables.p_5_2.t2 = new JArray();
                o.prompts_variables.p_5_2.t2 = JArray.FromObject(ds.Tables[9]);
                //p_5.2 End

                //p_5.3 Start
                o.prompts_variables.p_5_3 = new JObject();
                o.prompts_variables.p_5_3.t2 = new JArray();
                o.prompts_variables.p_5_3.t2 = JArray.FromObject(ds.Tables[10]);
                //p_5.3 End

                //p_5.4 Start
                o.prompts_variables.p_5_4 = new JObject();
                o.prompts_variables.p_5_4.t2 = new JArray();

                DataTable dt = ds.Tables[11];
                DataTable dtCTDetails = ds.Tables[12];

                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    dynamic tcDetails = new JObject();
                    tcDetails.Add("tcid", Convert.ToString(dt.Rows[i]["tcid"]));
                    tcDetails.Add("ct_id", Convert.ToString(dt.Rows[i]["Tweet_ConversationID"]));
                    tcDetails.tree_details = new JArray();

                    List<eTwitter_Summary> lstTwitter_Data_V2 = new List<eTwitter_Summary>();

                    eTwitter_Summary oParent = new eTwitter_Summary();
                    oParent.Input = Convert.ToString(dt.Rows[i]["Tweet_ConversationID"]);
                    oParent.tweet_id = Convert.ToString(dt.Rows[i]["Tweet_ConversationID"]);
                    lstTwitter_Data_V2.Add(oParent);

                    DataTable dtdtCTDetailsFiltered = new DataTable();

                    dtdtCTDetailsFiltered = dtCTDetails.Select("Tweet_ConversationID = " + Convert.ToString(dt.Rows[i]["Tweet_ConversationID"])).CopyToDataTable();

                    for (int j = 0; j < dtdtCTDetailsFiltered.Rows.Count; j++)
                    {
                        eTwitter_Summary objeTwitter_Summary = new eTwitter_Summary();
                        objeTwitter_Summary.text_of_tweet = Convert.ToString(dtdtCTDetailsFiltered.Rows[j]["Tweet_Text"]);
                        objeTwitter_Summary.tweet_id = Convert.ToString(dtdtCTDetailsFiltered.Rows[j]["Tweet_ID"]);
                        objeTwitter_Summary.Tweet_RepliedToTweetID = Convert.ToString(dtdtCTDetailsFiltered.Rows[j]["Tweet_RepliedToTweetID"]);
                        objeTwitter_Summary.Twitter_ID = Convert.ToInt32(dtdtCTDetailsFiltered.Rows[j]["TwitterID"]);
                        objeTwitter_Summary.url = Convert.ToString(dtdtCTDetailsFiltered.Rows[j]["Tweet_Url"]);
                        lstTwitter_Data_V2.Add(objeTwitter_Summary);
                    }

                    if (lstTwitter_Data_V2.Count > 1)
                    {
                        List<eTwitter_Summary> lstTwitter_Data_V2_Sorted = lstTwitter_Data_V2.OrderBy(oo => Convert.ToInt64(oo.tweet_id)).ToList();

                        List<eTwitter_Summary> lstTwitter_Data_V2VM = new List<eTwitter_Summary>();
                        GetHierachicalList(lstTwitter_Data_V2_Sorted, lstTwitter_Data_V2VM, null, "");

                        
                        foreach (eTwitter_Summary t in lstTwitter_Data_V2VM)
                        {
                            try
                            {
                                lstTwitter_Data_V2_Sorted.Where(w => w.tweet_id.ToLower() == t.tweet_id.ToString().ToLower()).ToList().ForEach(k => k.hierarchy = t.hierarchy);
                            }
                            catch (Exception ex)
                            {

                            }
                        }

                        lstTwitter_Data_V2_Sorted.OrderBy(x => SortCalc(x.hierarchy)).ToList();

                        for (int l = 1; l < lstTwitter_Data_V2_Sorted.Count; l++)
                        {
                            dynamic ootree_details = new JObject();
                            ootree_details.tweet_id= lstTwitter_Data_V2_Sorted[l].Twitter_ID.ToString();
                            ootree_details.twitter_id = Convert.ToString(lstTwitter_Data_V2_Sorted[l].tweet_id.ToString());
                            ootree_details.hierarchy =Convert.ToString(lstTwitter_Data_V2_Sorted[l].hierarchy);
                            ootree_details.text_of_tweet = Convert.ToString(lstTwitter_Data_V2_Sorted[l].text_of_tweet);
                            tcDetails.tree_details.Add(ootree_details);
                        }

                        o.prompts_variables.p_5_4.t2.Add(tcDetails);
                    }
                }

                //p_5_4 End

                //p_5.5 Start
                o.prompts_variables.p_5_5 = new JObject();
                o.prompts_variables.p_5_5.t2 = new JArray();

                dt = ds.Tables[13];
                dtCTDetails = ds.Tables[14];

                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    dynamic tcDetails = new JObject();
                    tcDetails.Add("tcid", Convert.ToString(dt.Rows[i]["tcid"]));
                    tcDetails.Add("ct_id", Convert.ToString(dt.Rows[i]["Tweet_ConversationID"]));
                    tcDetails.tree_details = new JArray();

                    List<eTwitter_Summary> lstTwitter_Data_V2 = new List<eTwitter_Summary>();

                    eTwitter_Summary oParent = new eTwitter_Summary();
                    oParent.Input = Convert.ToString(dt.Rows[i]["Tweet_ConversationID"]);
                    oParent.tweet_id = Convert.ToString(dt.Rows[i]["Tweet_ConversationID"]);
                    lstTwitter_Data_V2.Add(oParent);

                    DataTable dtdtCTDetailsFiltered = new DataTable();

                    dtdtCTDetailsFiltered = dtCTDetails.Select("Tweet_ConversationID = " + Convert.ToString(dt.Rows[i]["Tweet_ConversationID"])).CopyToDataTable();

                    for (int j = 0; j < dtdtCTDetailsFiltered.Rows.Count; j++)
                    {
                        eTwitter_Summary objeTwitter_Summary = new eTwitter_Summary();
                        objeTwitter_Summary.text_of_tweet = Convert.ToString(dtdtCTDetailsFiltered.Rows[j]["Tweet_Text"]);
                        objeTwitter_Summary.tweet_id = Convert.ToString(dtdtCTDetailsFiltered.Rows[j]["Tweet_ID"]);
                        objeTwitter_Summary.Tweet_RepliedToTweetID = Convert.ToString(dtdtCTDetailsFiltered.Rows[j]["Tweet_RepliedToTweetID"]);
                        objeTwitter_Summary.Twitter_ID = Convert.ToInt32(dtdtCTDetailsFiltered.Rows[j]["TwitterID"]);
                        objeTwitter_Summary.url = Convert.ToString(dtdtCTDetailsFiltered.Rows[j]["Tweet_Url"]);
                        objeTwitter_Summary.t2 = Convert.ToString(dtdtCTDetailsFiltered.Rows[j]["t2"]);
                        lstTwitter_Data_V2.Add(objeTwitter_Summary);
                    }

                    if (lstTwitter_Data_V2.Count > 1)
                    {
                        List<eTwitter_Summary> lstTwitter_Data_V2_Sorted = lstTwitter_Data_V2.OrderBy(oo => Convert.ToInt64(oo.tweet_id)).ToList();

                        List<eTwitter_Summary> lstTwitter_Data_V2VM = new List<eTwitter_Summary>();
                        GetHierachicalList(lstTwitter_Data_V2_Sorted, lstTwitter_Data_V2VM, null, "");


                        foreach (eTwitter_Summary t in lstTwitter_Data_V2VM)
                        {
                            try
                            {
                                lstTwitter_Data_V2_Sorted.Where(w => w.tweet_id.ToLower() == t.tweet_id.ToString().ToLower()).ToList().ForEach(k => k.hierarchy = t.hierarchy);
                            }
                            catch (Exception ex)
                            {

                            }
                        }

                        lstTwitter_Data_V2_Sorted.OrderBy(x => SortCalc(x.hierarchy)).ToList();

                        for (int l = 1; l < lstTwitter_Data_V2_Sorted.Count; l++)
                        {
                            if (lstTwitter_Data_V2_Sorted[l].t2 == "1")
                            {
                                dynamic ootree_details = new JObject();
                                ootree_details.tweet_id = lstTwitter_Data_V2_Sorted[l].Twitter_ID.ToString();
                                ootree_details.twitter_id = Convert.ToString(lstTwitter_Data_V2_Sorted[l].tweet_id.ToString());
                                ootree_details.hierarchy = Convert.ToString(lstTwitter_Data_V2_Sorted[l].hierarchy);
                                ootree_details.text_of_tweet = Convert.ToString(lstTwitter_Data_V2_Sorted[l].text_of_tweet);
                                tcDetails.tree_details.Add(ootree_details);
                            }
                        }

                        o.prompts_variables.p_5_5.t2.Add(tcDetails);
                    }
                }

                //p_5_5 End

                //prompts_variables End

                json.data = o;
            }

            Log("Incident_FetchLanding JSON End", "");

            //result = File.ReadAllText(ConfigurationManager.AppSettings["FetchLanding_OnlineArticle"]);
            Log("Incident_FetchLanding SerializeObject start", "");
            var setting = new JsonSerializerSettings
            {
                MaxDepth = int.MaxValue
            };
            string result = JsonConvert.SerializeObject(json, setting);
            Log("Incident_FetchLanding SerializeObject End", ""); 
	#endregion
        }


        private static string SortCalc(string x, int count = 3)
        {
            string strreturn = string.Empty;
            if (!String.IsNullOrEmpty(x))
            {
                var array = x.Split('_').ToList();

                for (var index = 0; index < array.Count; index++)
                {
                    var length = count - array[index].Length;
                    if (length <= 0)
                        continue;
                    array[index] = new string('0', length) + array[index];
                }

                strreturn = string.Join("", array);
            }


            return strreturn;
        }

        protected static void GetHierachicalList(List<eTwitter_Summary> kart, List<eTwitter_Summary> kartVM, eTwitter_Summary currentNode, string curH)
        {

            try
            {

                List<eTwitter_Summary> tmp = new List<eTwitter_Summary>();
                if (currentNode == null)
                {
                    tmp = kart.Where(c => c.Tweet_RepliedToTweetID == null).ToList();
                }
                else
                {
                    tmp = kart.Where(c => c.Tweet_RepliedToTweetID == currentNode.tweet_id).ToList();
                }

                int count = 1;
                if (tmp.Count > 0)
                {
                    foreach (eTwitter_Summary k in tmp)
                    {

                        eTwitter_Summary tmpVM = new eTwitter_Summary { tweet_id = k.tweet_id, text_of_tweet = k.text_of_tweet, Tweet_RepliedToTweetID = k.Tweet_RepliedToTweetID };
                        tmpVM.hierarchy += curH + "_" + count.ToString();
                        if (tmpVM.hierarchy.StartsWith("_"))
                            tmpVM.hierarchy = tmpVM.hierarchy.Remove(0, 1);
                        kartVM.Add(tmpVM);
                        count++;
                        GetHierachicalList(kart, kartVM, k, tmpVM.hierarchy);
                    }
                }
            }
            catch (Exception)
            {

                throw;
            }
        }


        private static void Log(string functionName, string error)
        {
            try
            {
                if (ConfigurationManager.AppSettings["IsLogActive"].ToString() == "1")
                {
                    string LogPath = ConfigurationManager.AppSettings["LogPath"].ToString();
                    using (TextWriter myWriter = File.AppendText(LogPath))
                    {

                        TextWriter.Synchronized(myWriter).WriteLine("<--> :{0}", string.Empty);
                        TextWriter.Synchronized(myWriter).WriteLine("Function Name :{0}", functionName);
                        TextWriter.Synchronized(myWriter).WriteLine("Error :{0}", error);
                        TextWriter.Synchronized(myWriter).WriteLine("Date :{0}", DateTime.Now.ToString());
                        TextWriter.Synchronized(myWriter).WriteLine("<--> :{0}", string.Empty);
                        TextWriter.Synchronized(myWriter).Flush();
                        TextWriter.Synchronized(myWriter).Close();
                    }
                }
            }
            catch (Exception ex)
            {
            }
        }
    }
}
