﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Domain.Updator
{
    class Program
    {
        static void Main(string[] args)
        {
            Domain_Detail obj = new Domain_Detail();
            obj.DoProcess();
        }
    }
}
