﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using MDB.Entities;
using System.Threading.Tasks;
using System.Diagnostics;
using System.Configuration;
using System.Net;
using System.IO;
using Newtonsoft.Json.Linq;
using System.Data;
using System.Reflection;
using System.Threading;

namespace Domain.Updator
{
    public class Domain_Detail
    {
        List<ePublication> lstTweets = new List<ePublication>();
        List<ePublication> lstFinal = new List<ePublication>();

        public void DoProcess()
        {
            TimeLog("Process Started");

            try
            {

                string strFetchingType = ConfigurationManager.AppSettings["FetchingType"];

                TimeLog("Publication_FetchToUpdate Start");
                lstTweets = new MDB.DAL.DAL().Publication_FetchToUpdate(strFetchingType);
                TimeLog("Publication_FetchToUpdate End");

                if (lstTweets.Count > 0)
                {
                    lstFinal = lstTweets.Select(s => new ePublication { PublicationID = s.PublicationID, Domain = s.Domain }).ToList();

                    string strType = ConfigurationManager.AppSettings["InfoType"];

                    if (!String.IsNullOrEmpty(strType))
                    {

                        if (strType == "DI")
                        {
                            GetDI(lstFinal);
                        }
                        else if (strType == "DA")
                        {
                            GetDA(lstFinal);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorLog("DoProcess", ex.Message + " ->> " + ex.StackTrace);
            }
            TimeLog("Process Ended");
        }

        public void GetDI(List<ePublication> lstLinks)
        {
            Console.WriteLine("Start Parallel.For");
            try
            {
                int counter = 0;
                var stopWatch = Stopwatch.StartNew();
                ParallelOptions po = new ParallelOptions();
                po.MaxDegreeOfParallelism = Convert.ToInt32(ConfigurationManager.AppSettings["MaxDegreeOfParallelism_DI"].ToString());
                System.Net.ServicePointManager.DefaultConnectionLimit = Convert.ToInt32(ConfigurationManager.AppSettings["MaxDegreeOfParallelism_DI"].ToString());

                Parallel.For(0, lstLinks.Count, po, i =>
                {
                    try
                    {
                        FetchPublicationDetail_RapidAPI_DI(lstLinks[i].Domain.ToString());
                        counter++;
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine("Parallel Error for " + lstLinks[i], " Error Is " + ex.ToString());
                    }

                    Thread.Sleep(Convert.ToInt32(ConfigurationManager.AppSettings["ThreadDelay_DI"].ToString()));
                });
                Console.WriteLine("End Parallel.For");
                Console.WriteLine("Parallel.For() execution time for " + " = {0} seconds:" + stopWatch.Elapsed.TotalSeconds);

                TimeLog("InsertData Started");
                InsertData("DI");
                TimeLog("InsertData Ended");
            }
            catch (Exception ex)
            {
                Console.WriteLine("GetDI " + ex.Message + " ->> " + ex.StackTrace);
            }

        }

        public void GetDA(List<ePublication> lstLinks)
        {
            Console.WriteLine("Start Parallel.For");
            try
            {
                int counter = 0;
                var stopWatch = Stopwatch.StartNew();
                ParallelOptions po = new ParallelOptions();
                po.MaxDegreeOfParallelism = Convert.ToInt32(ConfigurationManager.AppSettings["MaxDegreeOfParallelism_DA"].ToString());
                System.Net.ServicePointManager.DefaultConnectionLimit = Convert.ToInt32(ConfigurationManager.AppSettings["MaxDegreeOfParallelism_DA"].ToString());

                Parallel.For(0, lstLinks.Count, po, i =>
                {
                    try
                    {
                        FetchPublicationDetail_RapidAPI_DA(lstLinks[i].Domain.ToString());
                        counter++;
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine("Parallel Error for " + lstLinks[i], " Error Is " + ex.ToString());
                    }
                });
                Console.WriteLine("End Parallel.For");
                Console.WriteLine("Parallel.For() execution time for " + " = {0} seconds:" + stopWatch.Elapsed.TotalSeconds);

                TimeLog("InsertData Started");
                InsertData("DA");
                TimeLog("InsertData Ended");
            }
            catch (Exception ex)
            {
                Console.WriteLine("GetDA " + ex.Message + " ->> " + ex.StackTrace);
            }

        }

        public void FetchPublicationDetail_RapidAPI_DA(string Query)
        {
            string strOutput = string.Empty;

            try
            {
                #region Creating Request

                string json = string.Empty;
                string strURL = string.Empty;
                string strFinalURL = string.Empty;

                strURL = ConfigurationManager.AppSettings["URL_DA_RapidAPI"].ToString();
                strFinalURL = strURL + Uri.EscapeDataString(Query);

                TimeLog(strFinalURL);
                ServicePointManager.SecurityProtocol = (SecurityProtocolType)3072;
                HttpWebRequest request = (HttpWebRequest)WebRequest.Create(strFinalURL);
                request.Timeout = Convert.ToInt32(ConfigurationManager.AppSettings["Timeout_DA"]);
                request.Method = "GET";
                request.ContentType = "application/json; charset=utf-8";
                request.Headers.Add("x-rapidapi-host", ConfigurationManager.AppSettings["DA_x-rapidapi-host"].ToString());
                request.Headers.Add("x-rapidapi-key", ConfigurationManager.AppSettings["DA_x-rapidapi-key"].ToString());
                #endregion


                #region Get Data From API
                using (HttpWebResponse response = (HttpWebResponse)request.GetResponse())
                {
                    Stream stream = (Stream)response.GetResponseStream();
                    StreamReader reader = new StreamReader(stream);
                    json = reader.ReadToEnd();
                }
                #endregion

                #region Extract Json

                if (!String.IsNullOrEmpty(json))
                {
                    JObject obj = JObject.Parse(json);
                    if (obj != null)
                    {
                        if (obj["result"] != null)
                        {
                            if (Convert.ToString(obj["result"]) == "success")
                            {
                                JObject jItems = (JObject)obj["body"];
                                if (jItems != null)
                                {
                                    if (!string.IsNullOrEmpty(Convert.ToString(jItems["da_score"])))
                                    {
                                        lstFinal.Where(w => w.Domain == Query).ToList().ForEach(i => i.DA = Convert.ToInt32(Convert.ToString(jItems["da_score"])));
                                    }
                                }
                            }
                        }
                    }
                }
                #endregion
            }
            catch (Exception ex)
            {
                lstFinal.Where(w => w.Domain == Query).ToList().ForEach(i => i.Error = "Error");
                ErrorLog("FetchPublicationDetail_RapidAPI_DA" + Query, ex.Message + " ->> " + ex.StackTrace);
            }
        }

        public void FetchPublicationDetail_RapidAPI_DI(string Query)
        {
            string strOutput = string.Empty;

            try
            {
                #region Creating Request

                string strURL = string.Empty;
                string strFinalURL = string.Empty;

                strURL = ConfigurationManager.AppSettings["URL_DI_RapidAPI"].ToString();
                strFinalURL = strURL + Uri.EscapeDataString(Query);

                TimeLog(strFinalURL);
                ServicePointManager.SecurityProtocol = (SecurityProtocolType)3072;
                HttpWebRequest request = (HttpWebRequest)WebRequest.Create(strFinalURL);
                request.Timeout = Convert.ToInt32(ConfigurationManager.AppSettings["Timeout_DI"]);
                request.Method = "GET";
                request.ContentType = "application/json; charset=utf-8";
                request.Headers.Add("x-rapidapi-host", ConfigurationManager.AppSettings["DI_x-rapidapi-host"].ToString());
                request.Headers.Add("x-rapidapi-key", ConfigurationManager.AppSettings["DI_x-rapidapi-key"].ToString());
                #endregion


                #region Get Data From API
                using (HttpWebResponse response = (HttpWebResponse)request.GetResponse())
                {
                    Stream stream = (Stream)response.GetResponseStream();
                    StreamReader reader = new StreamReader(stream);
                    strOutput = reader.ReadToEnd();
                }
                #endregion

                #region Extract Json

                if (!String.IsNullOrEmpty(strOutput))
                {
                    JObject obj = JObject.Parse(strOutput);
                    if (obj != null)
                    {
                        if (obj["status"] != null)
                        {
                            if (Convert.ToString(obj["status"]) == "200")
                            {
                                JObject jOV = (JObject)obj["data"];
                                if (jOV != null)
                                {
                                    //JObject jOV = (JObject)jData["overview"];


                                    if (jOV != null)
                                    {
                                        if (jOV["description"] != null)
                                        {
                                            lstFinal.Where(w => w.Domain == Query).ToList().ForEach(i => i.Description = Convert.ToString(jOV["description"]));
                                        }

                                        if (jOV["global_rank"] != null && !String.IsNullOrEmpty(Convert.ToString(jOV["global_rank"])))
                                        {
                                            lstFinal.Where(w => w.Domain == Query).ToList().ForEach(i => i.GlobalRank = Convert.ToInt32(Convert.ToString(jOV["global_rank"])));
                                        }

                                        if (jOV["country_rank"] != null)
                                        {
                                            if (jOV["country_rank"]["country"] != null)
                                            {
                                                if (jOV["country_rank"]["country"]["name"] != null)
                                                {
                                                    lstFinal.Where(w => w.Domain == Query).ToList().ForEach(i => i.Country = Convert.ToString(jOV["country_rank"]["country"]["name"]));
                                                }

                                            }

                                            if (jOV["country_rank"]["rank"] != null && !String.IsNullOrEmpty(Convert.ToString(jOV["country_rank"]["rank"])))
                                            {
                                                lstFinal.Where(w => w.Domain == Query).ToList().ForEach(i => i.CountryRank = Convert.ToInt32(Convert.ToString(jOV["country_rank"]["rank"])));
                                            }
                                        }

                                        string strCategory = string.Empty;

                                        if (jOV["category_rank"] != null)
                                        {
                                            strCategory = Convert.ToString(jOV["category_rank"]["category"]);
                                            lstFinal.Where(w => w.Domain == Query).ToList().ForEach(i => i.Category = Convert.ToString(jOV["category_rank"]["category"]));

                                            if (!String.IsNullOrEmpty(Convert.ToString(jOV["category_rank"]["rank"])))
                                            {
                                                lstFinal.Where(w => w.Domain == Query).ToList().ForEach(i => i.CategoryRank = Convert.ToInt32(Convert.ToString(jOV["category_rank"]["rank"])));
                                            }

                                        }

                                        if (String.IsNullOrEmpty(strCategory))
                                        {
                                            if (jOV["category"] != null && !String.IsNullOrEmpty(Convert.ToString(jOV["category"])))
                                            {
                                                lstFinal.Where(w => w.Domain == Query).ToList().ForEach(i => i.Category = Convert.ToString(jOV["category"]));
                                            }
                                        }

                                        if (jOV["engagements"] != null)
                                        {
                                            if (jOV["engagements"]["time_on_site"] != null)
                                            {

                                                string AvgTimeOnSite = Convert.ToString(jOV["engagements"]["time_on_site"]);
                                                if (!String.IsNullOrEmpty(AvgTimeOnSite) && AvgTimeOnSite != "N/A")
                                                {
                                                    Int32 AvgVisitDuartionInSec = Convert.ToInt32(Math.Round(Convert.ToDecimal(AvgTimeOnSite)));
                                                    Int32 AvgVisitDuartionInMin = 0;

                                                    if (AvgVisitDuartionInSec > 60)
                                                    {
                                                        AvgVisitDuartionInMin = Convert.ToInt32(Math.Round(Convert.ToDecimal(AvgTimeOnSite))) / 60;
                                                    }
                                                    else
                                                    {
                                                        AvgVisitDuartionInMin = 1;
                                                    }

                                                    lstFinal.Where(w => w.Domain == Query).ToList().ForEach(i => i.AvgVisitDuartionInSec = AvgVisitDuartionInSec);
                                                    lstFinal.Where(w => w.Domain == Query).ToList().ForEach(i => i.AvgVisitDuartionInMin = AvgVisitDuartionInMin);

                                                }
                                            }


                                            if (jOV["engagements"]["visits"] != null && !String.IsNullOrEmpty(Convert.ToString(jOV["engagements"]["visits"])))
                                            {
                                                lstFinal.Where(w => w.Domain == Query).ToList().ForEach(i => i.TotalVisits = Convert.ToInt64(Math.Round(Convert.ToDecimal(Convert.ToString(jOV["engagements"]["visits"])))));
                                            }

                                            if (jOV["engagements"]["page_per_visit"] != null && !String.IsNullOrEmpty(Convert.ToString(jOV["engagements"]["page_per_visit"])))
                                            {
                                                lstFinal.Where(w => w.Domain == Query).ToList().ForEach(i => i.AvgPagesPerVisit = Convert.ToInt32(Math.Round(Convert.ToDecimal(Convert.ToString(jOV["engagements"]["page_per_visit"])))));
                                            }

                                            if (jOV["engagements"]["bounce_rate"] != null && !String.IsNullOrEmpty(Convert.ToString(jOV["engagements"]["bounce_rate"])))
                                            {
                                                decimal bounce_rate = Convert.ToDecimal(Convert.ToString(jOV["engagements"]["bounce_rate"]).Replace("%", ""));
                                                lstFinal.Where(w => w.Domain == Query).ToList().ForEach(i => i.BounceRate = bounce_rate);
                                            }
                                        }

                                        JArray jtop_countries_traffics = (JArray)jOV["top_country_shares"];

                                        if (jtop_countries_traffics != null)
                                        {
                                            try
                                            {
                                                int CountryNo = 0;
                                                foreach (JToken jc in jtop_countries_traffics)
                                                {
                                                    string strTrafficCountry = Convert.ToString(jc["country"]["name"]);


                                                    if (jc["country"]["name"] != null && Convert.ToString(jc["country"]["name"]) == "India")
                                                    {
                                                        if (!String.IsNullOrEmpty(Convert.ToString(jc["value"])))
                                                        {
                                                            lstFinal.Where(w => w.Domain == Query).ToList().ForEach(i => i.AvgPagesPerVisit = Convert.ToInt32(Convert.ToString(jc["value"])));
                                                        }
                                                    }
                                                    CountryNo++;
                                                }
                                            }
                                            catch (Exception ex)
                                            {

                                            }
                                        }

                                    }

                                    else
                                    {

                                        lstFinal.Where(w => w.Domain == Query).ToList().ForEach(i => i.Error = "JOV Is Null");
                                        ErrorLog("FetchPublicationDetail_RapidAPI_DI" + Query, "JOV Is Null");
                                    }

                                }

                            }
                            else
                            {
                                lstFinal.Where(w => w.Domain == Query).ToList().ForEach(i => i.Error = "Status is not 200");
                                ErrorLog("FetchPublicationDetail_RapidAPI_DI" + Query, "Status is not 200");
                            }
                        }
                    }
                }
                #endregion
            }
            catch (Exception ex)
            {
                lstFinal.Where(w => w.Domain == Query).ToList().ForEach(i => i.Error = "Error");
                ErrorLog("FetchPublicationDetail_RapidAPI_DI" + Query, ex.Message + " ->> " + ex.StackTrace);
            }
        }

        private DataTable ToDataTable<T>(List<T> items)
        {
            DataTable dataTable = new DataTable(typeof(T).Name);
            try
            {
                //Get all the properties by using reflection   
                PropertyInfo[] Props = typeof(T).GetProperties(BindingFlags.Public | BindingFlags.Instance);
                foreach (PropertyInfo prop in Props)
                {
                    //Setting column names as Property names  
                    dataTable.Columns.Add(prop.Name, prop.PropertyType);
                }
                foreach (T item in items)
                {
                    var values = new object[Props.Length];
                    for (int i = 0; i < Props.Length; i++)
                    {
                        if (Props[i].PropertyType == typeof(DateTime))
                        {
                            if (Convert.ToDateTime(Props[i].GetValue(item, null)) == DateTime.MinValue)
                            {
                                values[i] = null;
                            }
                            else
                            {
                                values[i] = Props[i].GetValue(item, null);
                            }
                        }
                        else
                        {
                            values[i] = Props[i].GetValue(item, null);
                        }
                    }
                    dataTable.Rows.Add(values);
                }
            }
            catch (Exception ex)
            {
                ErrorLog("ToDataTable", ex.ToString());
            }

            return dataTable;
        }

        private void InsertData(string strType)
        {

            try
            {
                TimeLog("lstFinal count is " + lstFinal.Count.ToString());
                DataTable dt = new DataTable();
                dt = ToDataTable(lstFinal);
                TimeLog("ToDataTable dt count is " + dt.Rows.Count.ToString());

                DataView view = new DataView(dt);
                dt = view.ToTable("Selected", false, "PublicationID","Publication", "Domain", "Description", "DA", "GlobalRank", "Country"
                , "CountryRank", "Category", "CategoryRank", "TotalVisits", "AvgVisitDuartionInSec", "AvgVisitDuartionInMin", "AvgPagesPerVisit", 
                "BounceRate", "TrafficFromIndia", "Error");

                TimeLog("UpdateDetails_Publication Started");
                new MDB.DAL.DAL().UpdateDetails_Publication(dt, strType);
                TimeLog("UpdateDetails_Publication Ended");

            }
            catch (Exception ex)
            {
                ErrorLog("InsertData", ex.Message + " ->> " + ex.StackTrace);
            }
        }

        #region Logging
        private void TimeLog(string log)
        {
            try
            {
                //string LogPath = ConfigurationManager.AppSettings["TwitterTimeLog"].ToString();


                string LogPath = ConfigurationManager.AppSettings["TimeLogPath"].ToString();

                using (TextWriter myWriter = File.AppendText(LogPath))
                {

                    TextWriter.Synchronized(myWriter).WriteLine("<--> :{0}", string.Empty);
                    TextWriter.Synchronized(myWriter).WriteLine("Log :{0}", log);
                    TextWriter.Synchronized(myWriter).WriteLine("Date :{0}", DateTime.Now.ToString());
                    TextWriter.Synchronized(myWriter).WriteLine("<--> :{0}", string.Empty);
                    TextWriter.Synchronized(myWriter).Flush();
                    TextWriter.Synchronized(myWriter).Close();
                }
            }
            catch (Exception ex)
            {
                ErrorLog("TimeLog ", ex.Message + " ->> " + ex.StackTrace);
            }
        }

        private void ErrorLog(string functionName, string error)
        {
            try
            {

                string LogPath = ConfigurationManager.AppSettings["ErrorLogPath"].ToString();

                using (TextWriter myWriter = File.AppendText(LogPath))
                {

                    TextWriter.Synchronized(myWriter).WriteLine("<--> :{0}", string.Empty);
                    TextWriter.Synchronized(myWriter).WriteLine("Function Name :{0}", functionName);
                    TextWriter.Synchronized(myWriter).WriteLine("Error :{0}", error);
                    TextWriter.Synchronized(myWriter).WriteLine("Date :{0}", DateTime.Now.ToString());
                    TextWriter.Synchronized(myWriter).WriteLine("<--> :{0}", string.Empty);
                    TextWriter.Synchronized(myWriter).Flush();
                    TextWriter.Synchronized(myWriter).Close();
                }


            }
            catch (Exception ex)
            {
            }
        }
        #endregion

        

        
    }
}
