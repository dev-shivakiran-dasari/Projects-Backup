﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using SolrNet;
using System.Configuration;
using System.IO;
using Microsoft.Practices.ServiceLocation;
using SolrNet.Commands.Parameters;
using System.Reflection;
using System.Diagnostics;
using System.Threading.Tasks;
using System.Net;
using Newtonsoft.Json.Linq;
using System.Globalization;
using System.Text.RegularExpressions;
using SolrNet.Utils;

namespace Test_Reindexer
{
    class Program
    {
        //Solr Connection
        public static ISolrOperations<eArticle> solrBoilerPipePS = null;
        public static ISolrOperations<eArticle2> solrBoilerPipeFS = null;

        

        static void Main(string[] args)
        {

            string url = "http://sdsuniindia.com/3-killed-35-injured-in-highway-accident-in-south-afghanistan/world/news/3207002.html";
            string strPublication = ExtractDomainame(url);
            var logFile = File.ReadAllLines("D://Publications.txt");
            List<string> lstPublications = new List<string>(logFile);

            bool isPresent = lstPublications.Any(x => url.ToUpper().Contains(x.ToUpper()));
            isPresent = lstPublications.Any(s => url.Contains(s));
            string FoundPublication = lstPublications.FirstOrDefault(x => x == strPublication);


            return;
            TimeLog("Start Init & Set instance of Solr");
            Startup.Container.Clear();
            Startup.InitContainer();

            Startup.Init<eArticle>(ConfigurationManager.AppSettings["Solr_PSPath"]);
            solrBoilerPipePS = ServiceLocator.Current.GetInstance<ISolrOperations<eArticle>>();

            Startup.Init<eArticle2>(ConfigurationManager.AppSettings["Solr_FSPath"]);
            solrBoilerPipeFS = ServiceLocator.Current.GetInstance<ISolrOperations<eArticle2>>();
            TimeLog("Start Init & Set instance of Solr");

            
            Process();
        }

        private static void Process()
        {
            try
            {
                //Create FromDate & ToDate
                DateTime FromDate = DateTime.Now.AddHours(-Convert.ToInt32(ConfigurationManager.AppSettings["NoOFMinutesToSubstractFromPS"].ToString()));

                //Fetch Articles To Process
                List<eArticle> lstArticles = FetchArticles(FromDate, DateTime.Now.AddDays(1));

                TimeLog("Total Count Of Articles Found " + lstArticles.Count.ToString());

                TimeLog("Start InsertData_FS");
                InsertData_FS(lstArticles);
                TimeLog("End InsertData_FS");

                

                TimeLog("Start CommitData");
                CommitData();
                TimeLog("End CommitData");


            }
            catch (Exception ex)
            {
                ErrorLog("Process", ex.Message + " ->> " + ex.StackTrace);
            }
        }


        //This function will fetch articles from primary solr on basis of start date and end date  with processed flag 0;
        private static List<eArticle> FetchArticles(DateTime from, DateTime to)
        {
            //Final articles
            SolrQueryResults<eArticle> lstFinalArticles = new SolrQueryResults<eArticle>();

            try
            {
                //Create from data and to date parameters
                string fromDate = Convert.ToDateTime(from.ToString("yyyy-MM-dd HH:mm tt")).ToString("yyyy'-'MM'-'dd'T'HH':'mm':'ss'.'fff'Z'");
                string toDate = Convert.ToDateTime(to.ToString("yyyy-MM-dd HH:mm tt")).ToString("yyyy'-'MM'-'dd'T'HH':'mm':'ss'.'fff'Z'");

                //string ExtraQueryPaameter = System.IO.File.ReadAllText(ConfigurationManager.AppSettings["ExtraQueryParameter"].ToString());

                //Create query // Pick between fromdate to todate which are not processed i.e. state=0 and Trycount<3
                string Query = " timestamp:[" + fromDate + " TO " + toDate + "]";//+ ExtraQueryPaameter;
                TimeLog(Query);

                //Get final articles
                lstFinalArticles = solrBoilerPipePS.Query(Query,
                    new QueryOptions
                    {
                        Start = 0,
                        Rows = Convert.ToInt32(ConfigurationManager.AppSettings["NoOfRows"]),
                        OrderBy = new[] { new SolrNet.SortOrder("timestamp", Order.DESC) },
                        //Fields = new[] { "tstamp,title,id,url,content,state,tryCount" },
                        ExtraParams = new KeyValuePair<string, string>[] { new KeyValuePair<string, string>("wt", "xml") }
                    });
            }
            catch (Exception ex)
            {
                ErrorLog("FetchArticles", ex.ToString());
            }

            return lstFinalArticles.ToList();
        }

        #region Create & Insert FS Data
        private static bool CreateDocument_FS(eArticle obj)
        {
            bool Result = false;
            try
            {
                solrBoilerPipeFS.Add(new eArticle2()
                {
                    id = obj.id,
                    Url = obj.Url,
                    tstamp_ps = obj.tstamp_ps,
                    domain = obj.domain,
                    Text = obj.Text,
                    Date = obj.Date,
                    //Html = obj.Html,
                    Title = obj.Title,
                    Author = obj.Author,
                    SiteName = obj.SiteName,
                    AuthorUrl = obj.AuthorUrl,
                    PublisherRegion = obj.PublisherRegion,
                    PublisherCountry = obj.PublisherCountry,
                    //Tags = obj.Tags,
                    TagLabel1 = obj.TagLabel1,
                    TagScore1 = obj.TagScore1,
                    TagCount1 = obj.TagCount1,
                    TagLabel2 = obj.TagLabel2,
                    TagScore2 = obj.TagScore2,
                    TagCount2 = obj.TagCount2,
                    TagLabel3 = obj.TagLabel3,
                    TagScore3 = obj.TagScore3,
                    TagCount3 = obj.TagCount3,
                    TagLabel4 = obj.TagLabel4,
                    TagScore4 = obj.TagScore4,
                    TagCount4 = obj.TagCount4,
                    TagLabel5 = obj.TagLabel5,
                    TagScore5 = obj.TagScore5,
                    TagCount5 = obj.TagCount5,
                    Language = obj.Language,
                    Images = obj.Images

                }, new AddParameters() { Overwrite = true });

                

                //HttpWebRequest request = (HttpWebRequest)WebRequest.Create(ConfigurationManager.AppSettings["Solr_FSPath"].ToString() + "/update?commit=true");
                //using (HttpWebResponse response = (HttpWebResponse)request.GetResponse())
                //{
                //    Stream stream = (Stream)response.GetResponseStream();
                //    StreamReader reader = new StreamReader(stream);
                //    string strOutput = reader.ReadToEnd();
                //    stream.Close();
                //    reader.Close();
                //}
            }
            catch (Exception ex)
            {
                ErrorLog("CreateDocument_FS", ex.Message + " ->> " + ex.StackTrace);
            }

            return Result;
        }

        private static void InsertData_FS(List<eArticle> objFeeds)
        {
                #region Creating And Setting ParallelOptions
                var stopWatch = Stopwatch.StartNew();
                ParallelOptions po = new ParallelOptions();
                po.MaxDegreeOfParallelism = Convert.ToInt32(10);
                System.Net.ServicePointManager.DefaultConnectionLimit = Convert.ToInt32(10); 
                #endregion

                //Parallel.For(0, objFeeds.Count, po, i =>
                //{
                //    try
                //    {
                //        CreateDocument_FS(objFeeds[i]);
                //    }
                //    catch (Exception exx)
                //    {
                //        ErrorLog("InsertData_FS For Loop", exx.Message + " ->> " + exx.StackTrace);
                //    }
                //});
                //TimeLog("End Parallel.For");
                //TimeLog("Parallel.For() execution time for " + " = {0} seconds:" + stopWatch.Elapsed.TotalSeconds);
                for (int i = 0; i < objFeeds.Count(); i++)
                {
                    try
                    {
                        CreateDocument_FS(objFeeds[i]);
                    }
                    catch (Exception ex)
                    {
                        ErrorLog("InsertData_FS For Loop", ex.Message + " ->> " + ex.StackTrace);
                    }
                }
        }
        #endregion


        //Commit All Cores
        private static void CommitData()
        {
            try
            {

                //HttpWebRequest request = (HttpWebRequest)WebRequest.Create(ConfigurationManager.AppSettings["Solr_PSPath"].ToString() + "/update?commit=true");
                //using (HttpWebResponse response = (HttpWebResponse)request.GetResponse())
                //{
                //    Stream stream = (Stream)response.GetResponseStream();
                //    StreamReader reader = new StreamReader(stream);
                //    string strOutput = reader.ReadToEnd();
                //    stream.Close();
                //    reader.Close();
                //}

                //HttpWebRequest request = (HttpWebRequest)WebRequest.Create(ConfigurationManager.AppSettings["Solr_FSPath"].ToString() + "/update?commit=true");
                //using (HttpWebResponse response = (HttpWebResponse)request.GetResponse())
                //{
                //    Stream stream = (Stream)response.GetResponseStream();
                //    StreamReader reader = new StreamReader(stream);
                //    string strOutput = reader.ReadToEnd();
                //    stream.Close();
                //    reader.Close();
                //}

                solrBoilerPipeFS.Commit();
            }
            catch (Exception ex)
            {
                ErrorLog("CommitData", ex.ToString());
            }
        }

        //ExtractDomainame
        private static string ExtractDomainame(string URL)
        {
            try
            {
                string strDomain = Regex.Replace(URL, @"^([a-zA-Z]+:\/\/)?([^\/]+)\/.*?$", "$2");
                strDomain = strDomain.ToLower();
                strDomain = strDomain.Replace("www.", "");
                return strDomain;

            }
            catch (Exception ex) { return ""; }
        }


        #region LOGGING

        //For error logging
        private static void ErrorLog(string functionName, string error)
        {
            try
            {
                string LogPath = ConfigurationManager.AppSettings["ErrorLogPath"];
                using (TextWriter myWriter = File.AppendText(LogPath))
                {

                    TextWriter.Synchronized(myWriter).WriteLine("<--> :{0}", string.Empty);
                    TextWriter.Synchronized(myWriter).WriteLine("Function Name :{0}", functionName);
                    TextWriter.Synchronized(myWriter).WriteLine("Error :{0}", error);
                    TextWriter.Synchronized(myWriter).WriteLine("Date :{0}", DateTime.Now.ToString());
                    TextWriter.Synchronized(myWriter).WriteLine("<--> :{0}", string.Empty);
                    TextWriter.Synchronized(myWriter).Flush();
                    TextWriter.Synchronized(myWriter).Close();
                }
            }
            catch (Exception ex)
            {
            }
        }

        //For debugging purpose
        private static void TimeLog(string strtext)
        {
            try
            {
                string LogPath = ConfigurationManager.AppSettings["TimeLogPath"];
                using (TextWriter myWriter = File.AppendText(LogPath))
                {

                    TextWriter.Synchronized(myWriter).WriteLine("<--> :{0}", string.Empty);
                    TextWriter.Synchronized(myWriter).WriteLine("TimeLog :{0}", strtext);
                    TextWriter.Synchronized(myWriter).WriteLine("Date :{0}", DateTime.Now.ToString());
                    TextWriter.Synchronized(myWriter).WriteLine("<--> :{0}", string.Empty);
                    TextWriter.Synchronized(myWriter).Flush();
                    TextWriter.Synchronized(myWriter).Close();
                }
            }
            catch (Exception ex)
            {
                ErrorLog("TimeLog", ex.ToString());
            }
        }

        #endregion
    }
}
