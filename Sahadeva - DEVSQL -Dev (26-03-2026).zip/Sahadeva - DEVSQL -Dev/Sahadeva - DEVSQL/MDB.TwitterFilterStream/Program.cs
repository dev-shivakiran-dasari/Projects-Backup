﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MDB.TwitterFilterStream
{
    class Program
    {
        static void Main(string[] args)
        {
            Twitter obj = new Twitter();
            obj.Process();
        }
    }
}
