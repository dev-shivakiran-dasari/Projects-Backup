﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Configuration;
using System.IO;
using MDB.Entities;
using Newtonsoft.Json.Linq;
using System.Globalization;
using System.Diagnostics;
using System.Threading.Tasks;
using System.Net;
using System.Reflection;
using System.Text.RegularExpressions;
using Newtonsoft.Json;
using System.Threading;

namespace MDB.TwitterFilterStream
{
    public class Twitter
    {

        public void Process()
        {
            try
            {
                ServicePointManager.SecurityProtocol = (SecurityProtocolType)3072;

                string strRequestUrl = ConfigurationManager.AppSettings["Twitter_StreamUrl"];
                string strBearerToken = ConfigurationManager.AppSettings["Twitter_BearerToken"];

                Dictionary<string, string> parameters = new Dictionary<string, string>();
                parameters.Add("tweet.fields", "conversation_id,attachments,author_id,context_annotations,created_at,entities,geo,id,in_reply_to_user_id,lang,possibly_sensitive,public_metrics,referenced_tweets,source,text,withheld,note_tweet");
                parameters.Add("user.fields", "created_at,description,entities,id,location,name,pinned_tweet_id,profile_image_url,protected,public_metrics,url,username,verified,withheld,verified_type");
                parameters.Add("expansions", "attachments.poll_ids,attachments.media_keys,author_id,geo.place_id,in_reply_to_user_id,referenced_tweets.id,entities.mentions.username,referenced_tweets.id.author_id");
                parameters.Add("media.fields", "duration_ms,height,media_key,preview_image_url,type,url,width,public_metrics,organic_metrics,promoted_metrics,alt_text,variants");
                

                Dictionary<string, string>.KeyCollection.Enumerator keys = parameters.Keys.GetEnumerator();
                keys.MoveNext();
                StringBuilder sbp = new StringBuilder(
                    string.Format("{0}={1}", keys.Current, Uri.EscapeDataString(parameters[keys.Current])));
                while (keys.MoveNext())
                    sbp.AppendFormat("&{0}={1}", keys.Current, Uri.EscapeDataString(parameters[keys.Current]));

                string strUrl = string.Format("{0}?{1}", strRequestUrl, sbp);


                HttpWebRequest request = (HttpWebRequest)WebRequest.Create(strUrl);
                request.Timeout = Convert.ToInt32(1800000);
                request.Method = "GET";
                request.Headers.Add(
                    "Authorization", strBearerToken);
                request.ContentType = "application/json; charset=utf-8";



                WebResponse response = request.GetResponse();
                StreamReader streamReader = new StreamReader(response.GetResponseStream());

                while (!streamReader.EndOfStream)
                {
                    string post = streamReader.ReadLine();
                    post = post.Trim();
                    post = post.Replace(@"\r\n", "").Trim();
                    if (!String.IsNullOrEmpty(post))
                    {
                        InputDataForThread IDC = new InputDataForThread();
                        IDC.strRow = post + Environment.NewLine;

                        ParameterizedThreadStart tsDataCollector = new ParameterizedThreadStart(ProcessRow);
                        Thread cacheThread = new Thread(tsDataCollector);
                        cacheThread.CurrentCulture = new System.Globalization.CultureInfo("en-US");
                        cacheThread.Start(IDC);

                    }

                    //Console.WriteLine(post);

                    Thread.Sleep(20000);
                }
            }
            catch (Exception ex)
            {
                ErrorLog("Process ", ex.Message + " ->> " + ex.StackTrace);
            }
        }

        private void ProcessRow(object inputParameter)
        {
            try
            {
                InputDataForThread IDC = (InputDataForThread)inputParameter;
                List<eTwitter> objTwitter = new List<eTwitter>();
                objTwitter = ExtractTweetsFromJson(IDC.strRow);
                for (int i = 0; i < objTwitter.Count; i++)
                {
                    if (!String.IsNullOrEmpty(objTwitter[i].Tweet_URL))
                    {
                        TimeLog("Start InsertTweet "+objTwitter[i].EntityID + " | " + objTwitter[i].TopicID + " | " + objTwitter[i].EQID);
                        new MDB.DAL.DAL().Twitter_InsertTweet_FS(objTwitter[i], IDC.strRow);
                        TimeLog("End InsertTweet " + objTwitter[i].EntityID + " | " + objTwitter[i].TopicID + " | " + objTwitter[i].EQID);
                    }
                }
                
            }
            catch (Exception ex)
            {
                ErrorLog("ProcessRow ", ex.Message + " ->> " + ex.StackTrace);
            }


        }

        private List<eTwitter> ExtractTweetsFromJson(string strOutput)
        {
            List<eTwitter> lstTwitter = new List<eTwitter>();
            try
            {
                if (!String.IsNullOrEmpty(strOutput))
                {
                    JObject obj = JObject.Parse(strOutput);
                    if (obj != null)
                    {
                        TimeLog(strOutput);
                        #region Etract json

                        JObject jItem = (JObject)obj["data"];
                        JArray jmatching_rules = (JArray)obj["matching_rules"];

                        foreach (JToken rule in jmatching_rules)
                        {
                            if (!string.IsNullOrEmpty(Convert.ToString(rule["tag"])))
                            {
                                string strRule = Convert.ToString(rule["tag"].ToString());
                                string[] splitRule = strRule.Split('|');

                                eTwitter objTwitter = new eTwitter();
                                objTwitter.EntityID = Convert.ToInt32(splitRule[0]);
                                objTwitter.TopicID = Convert.ToInt32(splitRule[1]);
                                objTwitter.EQID = Convert.ToInt32(splitRule[2]);

                                objTwitter.ServiceID = 13;
                                objTwitter.TypeOfListening = "Query";

                                try
                                {
                                    if (!string.IsNullOrEmpty(Convert.ToString(jItem["id"])))
                                    {
                                        objTwitter.Tweet_ID = Convert.ToString(jItem["id"].ToString());
                                    }

                                    JObject jItems_includes = JObject.Parse(obj["includes"].ToString());

                                    JArray media = (JArray)jItems_includes["media"];

                                    JArray jItems_users = (JArray)jItems_includes["users"];

                                    JArray jItems_tweets = (JArray)jItems_includes["tweets"];

                                    #region Extraction from Data Array

                                    if (!string.IsNullOrEmpty(Convert.ToString(jItem["id"])))
                                    {
                                        objTwitter.Tweet_ID = Convert.ToString(jItem["id"].ToString());
                                    }

                                    if (!string.IsNullOrEmpty(Convert.ToString(jItem["text"])))
                                    {
                                        objTwitter.Tweet_Text = Convert.ToString(jItem["text"]);
                                    }

                                    if (jItem["note_tweet"] != null)
                                    {
                                        if (!string.IsNullOrEmpty(Convert.ToString(jItem["note_tweet"]["text"])))
                                        {
                                            objTwitter.Tweet_Text = Convert.ToString(jItem["note_tweet"]["text"]);
                                        }

                                    }

                                    if (!string.IsNullOrEmpty(Convert.ToString(jItem["created_at"])))
                                    {
                                        //objTwitter.Tweet_Date = DateTime.ParseExact(jItem["created_at"].ToString(), "ddd MMM dd HH:mm:ss zzzz yyyy", CultureInfo.InvariantCulture).ToLocalTime();
                                        objTwitter.Tweet_Date = Convert.ToDateTime(jItem["created_at"].ToString());
                                    }

                                    if (!string.IsNullOrEmpty(Convert.ToString(jItem["conversation_id"])))
                                    {
                                        objTwitter.Tweet_ConversationID = Convert.ToString(jItem["conversation_id"]);
                                    }

                                    if (!string.IsNullOrEmpty(Convert.ToString(jItem["lang"])))
                                    {
                                        objTwitter.Tweet_Language = Convert.ToString(jItem["lang"]);
                                    }

                                    if (jItem["referenced_tweets"] != null)
                                    {

                                        objTwitter.Tweet_IsReplied = 0;
                                        objTwitter.Tweet_IsRetweeted = 0;
                                        objTwitter.Tweet_IsQuoted = 0;

                                        #region Referenced_tweets Array
                                        JArray referenced_tweets = (JArray)jItem["referenced_tweets"];
                                        if (referenced_tweets != null)
                                        {
                                            foreach (var User in jItems_users)
                                            {
                                                if (Convert.ToString(jItem["author_id"].ToString()) == Convert.ToString(User["id"].ToString()))
                                                {

                                                    foreach (var item_referenced_tweets in referenced_tweets)
                                                    {
                                                        if (Convert.ToString(item_referenced_tweets["type"].ToString()) == "retweeted")
                                                        {

                                                            objTwitter.Tweet_IsRetweeted = 1;
                                                            objTwitter.Tweet_RetweetedToTweetID = Convert.ToString(item_referenced_tweets["id"].ToString());

                                                            foreach (var item_jItems_tweets in jItems_tweets)
                                                            {
                                                                if (Convert.ToString(item_jItems_tweets["id"].ToString()) == objTwitter.Tweet_RetweetedToTweetID)
                                                                {
                                                                    objTwitter.Tweet_RetweetedTo = "https://twitter.com/" + Convert.ToString(item_jItems_tweets["author_id"]) + "/status/" + objTwitter.Tweet_RetweetedToTweetID;

                                                                    if (objTwitter.Tweet_Text.IndexOf(":") > 0)
                                                                    {

                                                                        if (item_jItems_tweets["note_tweet"] != null)
                                                                        {
                                                                            objTwitter.Tweet_Text = objTwitter.Tweet_Text.ToString().Substring(0, objTwitter.Tweet_Text.IndexOf(":")) + " : " + Convert.ToString(item_jItems_tweets["note_tweet"]["text"]);
                                                                        }
                                                                        else
                                                                        {
                                                                            objTwitter.Tweet_Text = objTwitter.Tweet_Text.ToString().Substring(0, objTwitter.Tweet_Text.IndexOf(":")) + " : " + Convert.ToString(item_jItems_tweets["text"]);
                                                                        }
                                                                    }
                                                                }
                                                            }
                                                        }
                                                        else if (Convert.ToString(item_referenced_tweets["type"].ToString()) == "replied_to")
                                                        {
                                                            //objTwitter.Tweet_RepliedTo = "https://twitter.com/" + Convert.ToString(User["username"].ToString()) + "/status/" + Convert.ToString(item_referenced_tweets["id"].ToString());
                                                            objTwitter.Tweet_IsReplied = 1;
                                                            objTwitter.Tweet_RepliedToTweetID = Convert.ToString(item_referenced_tweets["id"].ToString());

                                                            foreach (var item_jItems_tweets in jItems_tweets)
                                                            {
                                                                if (Convert.ToString(item_jItems_tweets["id"].ToString()) == objTwitter.Tweet_RepliedToTweetID)
                                                                {
                                                                    objTwitter.Tweet_RepliedTo = "https://twitter.com/" + Convert.ToString(item_jItems_tweets["author_id"]) + "/status/" + objTwitter.Tweet_RepliedToTweetID;

                                                                    if (item_jItems_tweets["note_tweet"] != null)
                                                                    {
                                                                        objTwitter.Tweet_RepliedToText = Convert.ToString(item_jItems_tweets["note_tweet"]["text"]);
                                                                    }
                                                                    else
                                                                    {
                                                                        objTwitter.Tweet_RepliedToText = Convert.ToString(item_jItems_tweets["text"]);
                                                                    }
                                                                }
                                                            }

                                                        }
                                                        else if (Convert.ToString(item_referenced_tweets["type"].ToString()) == "quoted")
                                                        {
                                                            //objTwitter.Tweet_QuotedTo = "https://twitter.com/" + Convert.ToString(User["username"].ToString()) + "/status/" + Convert.ToString(item_referenced_tweets["id"].ToString());
                                                            objTwitter.Tweet_IsQuoted = 1;
                                                            objTwitter.Tweet_QuotedToTweetID = Convert.ToString(item_referenced_tweets["id"].ToString());

                                                            foreach (var item_jItems_tweets in jItems_tweets)
                                                            {
                                                                if (Convert.ToString(item_jItems_tweets["id"].ToString()) == objTwitter.Tweet_QuotedToTweetID)
                                                                {
                                                                    objTwitter.Tweet_QuotedTo = "https://twitter.com/" + Convert.ToString(item_jItems_tweets["author_id"]) + "/status/" + objTwitter.Tweet_QuotedToTweetID;

                                                                    if (item_jItems_tweets["note_tweet"] != null)
                                                                    {
                                                                        objTwitter.Tweet_QuotedToText = Convert.ToString(item_jItems_tweets["note_tweet"]["text"]);
                                                                    }
                                                                    else
                                                                    {
                                                                        objTwitter.Tweet_QuotedToText = Convert.ToString(item_jItems_tweets["text"]);
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }


                                                }
                                            }
                                        }
                                        #endregion
                                    }
                                    if (!string.IsNullOrEmpty(Convert.ToString(jItem["source"])))
                                    {
                                        objTwitter.Tweet_Source = Convert.ToString(jItem["source"].ToString());
                                        //objTwitter._SourceLink = strLink;
                                    }

                                    #region Engagagement
                                    if (jItem["public_metrics"] != null)
                                    {
                                        JObject public_metrics = JObject.Parse(jItem["public_metrics"].ToString());
                                        if (!string.IsNullOrEmpty(Convert.ToString(public_metrics["retweet_count"])))
                                        {
                                            objTwitter.Engagement_RetweetCount = Convert.ToInt64(public_metrics["retweet_count"].ToString());
                                        }
                                        if (!string.IsNullOrEmpty(Convert.ToString(public_metrics["like_count"])))
                                        {
                                            objTwitter.Engagement_LikeCount = Convert.ToInt64(public_metrics["like_count"].ToString());
                                        }
                                        if (!string.IsNullOrEmpty(Convert.ToString(public_metrics["reply_count"])))
                                        {
                                            objTwitter.Engagement_ReplyCount = Convert.ToInt64(public_metrics["reply_count"].ToString());
                                        }
                                        if (!string.IsNullOrEmpty(Convert.ToString(public_metrics["quote_count"])))
                                        {
                                            objTwitter.Engagement_QuoteCount = Convert.ToInt64(public_metrics["quote_count"].ToString());
                                        }
                                        if (!string.IsNullOrEmpty(Convert.ToString(public_metrics["bookmark_count"])))
                                        {
                                            objTwitter.Engagement_BookmarkCount = Convert.ToInt64(public_metrics["bookmark_count"].ToString());
                                        }
                                        if (!string.IsNullOrEmpty(Convert.ToString(public_metrics["impression_count"])))
                                        {
                                            objTwitter.Engagement_ViewCount = Convert.ToInt64(public_metrics["impression_count"].ToString());
                                        }
                                    }
                                    #endregion

                                    if (jItem["entities"] != null)
                                    {
                                        #region Entities Array
                                        JObject entities = JObject.Parse(jItem["entities"].ToString());

                                        JArray mentions = (JArray)entities["mentions"];
                                        if (mentions != null)
                                        {
                                            foreach (var item in mentions)
                                            {
                                                if (!string.IsNullOrEmpty(Convert.ToString(item["username"])))
                                                {
                                                    objTwitter.Mentioned_Handles += '@' + Convert.ToString(item["username"].ToString() + ",");
                                                }
                                            }
                                            objTwitter.Mentioned_Handles = objTwitter.Mentioned_Handles.Remove(objTwitter.Mentioned_Handles.Length - 1, 1);
                                        }
                                        JArray hashtags = (JArray)entities["hashtags"];
                                        if (hashtags != null)
                                        {
                                            foreach (var item in hashtags)
                                            {
                                                if (!string.IsNullOrEmpty(Convert.ToString(item["tag"])))
                                                {
                                                    objTwitter.Mentioned_Hashtags += "#" + Convert.ToString(item["tag"].ToString() + ",");
                                                }
                                            }
                                            objTwitter.Mentioned_Hashtags = objTwitter.Mentioned_Hashtags.Remove(objTwitter.Mentioned_Hashtags.Length - 1, 1);
                                        }
                                        JArray urls = (JArray)entities["urls"];
                                        if (urls != null)
                                        {
                                            foreach (var item in urls)
                                            {
                                                if (!string.IsNullOrEmpty(Convert.ToString(item["expanded_url"])))
                                                {
                                                    objTwitter.Mentioned_Hyperlinks += Convert.ToString(item["expanded_url"].ToString() + ",");
                                                }

                                                if (!string.IsNullOrEmpty(Convert.ToString(item["media_key"])))
                                                {
                                                    if (media != null)
                                                    {
                                                        foreach (var itemmedia in media)
                                                        {
                                                            if (Convert.ToString(itemmedia["media_key"].ToString()) == Convert.ToString(item["media_key"].ToString()))
                                                            {
                                                                if (!string.IsNullOrEmpty(Convert.ToString(itemmedia["type"])) && Convert.ToString(itemmedia["type"]) == "video")
                                                                {
                                                                    objTwitter.Mentioned_Videos += Convert.ToString(item["expanded_url"].ToString() + ",");

                                                                    if (!string.IsNullOrEmpty(Convert.ToString(itemmedia["public_metrics"])))
                                                                    {
                                                                        objTwitter.Mentioned_Videos_Views = Convert.ToInt32(Convert.ToString(itemmedia["public_metrics"]["view_count"]));
                                                                    }

                                                                    objTwitter.Mentioned_Videos_DurationInMs = Convert.ToInt32(Convert.ToString(itemmedia["duration_ms"]));
                                                                }
                                                            }

                                                            if (Convert.ToString(itemmedia["media_key"].ToString()) == Convert.ToString(item["media_key"].ToString()))
                                                            {
                                                                if (!string.IsNullOrEmpty(Convert.ToString(itemmedia["type"])) && Convert.ToString(itemmedia["type"]) == "photo")
                                                                {
                                                                    objTwitter.Mentioned_Images += Convert.ToString(item["expanded_url"].ToString() + ",");
                                                                }
                                                            }


                                                        }

                                                        if (!String.IsNullOrEmpty(objTwitter.Mentioned_Videos))
                                                        {
                                                            objTwitter.Mentioned_Videos = objTwitter.Mentioned_Videos.Remove(objTwitter.Mentioned_Videos.Length - 1, 1);
                                                        }

                                                        if (!String.IsNullOrEmpty(objTwitter.Mentioned_Images))
                                                        {
                                                            objTwitter.Mentioned_Images = objTwitter.Mentioned_Images.Remove(objTwitter.Mentioned_Images.Length - 1, 1);
                                                        }
                                                    }
                                                }


                                            }
                                            objTwitter.Mentioned_Hyperlinks = objTwitter.Mentioned_Hyperlinks.Remove(objTwitter.Mentioned_Hyperlinks.Length - 1, 1);
                                        }
                                        #endregion
                                    }

                                    #endregion

                                    #region Extraction from Users Array
                                    foreach (var user in jItems_users)
                                    {
                                        if (Convert.ToString(jItem["author_id"].ToString()) == Convert.ToString(user["id"].ToString()))
                                        {
                                            if (!string.IsNullOrEmpty(Convert.ToString(jItem["author_id"])))
                                            {
                                                objTwitter.Profile_ID = Convert.ToString(jItem["author_id"].ToString());
                                            }

                                            if (!string.IsNullOrEmpty(Convert.ToString(user["username"])))
                                            {
                                                objTwitter.Profile_Handle = Convert.ToString(user["username"].ToString());
                                            }
                                            if (!string.IsNullOrEmpty(objTwitter.Profile_Handle))
                                            {
                                                objTwitter.Tweet_URL = "https://twitter.com/" + objTwitter.Profile_Handle + "/status/" + objTwitter.Tweet_ID;
                                            }
                                            if (!string.IsNullOrEmpty(Convert.ToString(user["name"])))
                                            {
                                                string completeName = string.Empty;
                                                string[] Actorfullname = null;

                                                completeName = Convert.ToString(user["name"].ToString());
                                                Actorfullname = completeName.Split(' ');
                                                objTwitter.Profile_Name = completeName;
                                            }

                                            JObject user_public_metrics = JObject.Parse(user["public_metrics"].ToString());
                                            if (user_public_metrics != null)
                                            {
                                                if (!string.IsNullOrEmpty(Convert.ToString(user_public_metrics["followers_count"])))
                                                {
                                                    objTwitter.Profile_FollowersCount = Convert.ToInt64(user_public_metrics["followers_count"].ToString());
                                                }
                                                if (!string.IsNullOrEmpty(Convert.ToString(user_public_metrics["following_count"])))
                                                {
                                                    objTwitter.Profile_FollowingCount = Convert.ToInt64(user_public_metrics["following_count"].ToString());
                                                }
                                                if (!string.IsNullOrEmpty(Convert.ToString(user_public_metrics["tweet_count"])))
                                                {
                                                    objTwitter.Profile_TweetsCount = Convert.ToInt64(user_public_metrics["tweet_count"].ToString());
                                                }
                                                if (!string.IsNullOrEmpty(Convert.ToString(user_public_metrics["listed_count"])))
                                                {
                                                    objTwitter.Profile_ListsCount = Convert.ToInt64(user_public_metrics["listed_count"].ToString());
                                                }
                                            }

                                            if (!string.IsNullOrEmpty(Convert.ToString(user["created_at"])))
                                            {
                                                //objTwitter.Profile_JoinedDate = DateTime.ParseExact(user["created_at"].ToString(), "ddd MMM dd HH:mm:ss zzzz yyyy", CultureInfo.InvariantCulture).ToLocalTime();
                                                objTwitter.Profile_JoinedDate = Convert.ToDateTime(user["created_at"].ToString());
                                            }

                                            if (!string.IsNullOrEmpty(Convert.ToString(user["location"])))
                                            {
                                                objTwitter.Profile_Location = Convert.ToString(user["location"].ToString());
                                            }

                                            if (!string.IsNullOrEmpty(Convert.ToString(user["description"])))
                                            {
                                                objTwitter.Profile_Description = Convert.ToString(user["description"].ToString());
                                            }

                                            if (!string.IsNullOrEmpty(Convert.ToString(user["profile_image_url"])))
                                            {
                                                objTwitter.Profile_ProfilePicUrl = Convert.ToString(user["profile_image_url"].ToString());
                                            }

                                            if (!string.IsNullOrEmpty(Convert.ToString(user["url"])))
                                            {
                                                objTwitter.Profile_ExternalUrl = Convert.ToString(user["url"].ToString());
                                            }

                                            if (!string.IsNullOrEmpty(Convert.ToString(user["verified"])))
                                            {
                                                objTwitter.Profile_IsVerified = Convert.ToInt16(Convert.ToString(user["verified"].ToString()) == "True" ? 1 : 0);
                                            }

                                            if (!string.IsNullOrEmpty(Convert.ToString(user["verified_type"])))
                                            {
                                                objTwitter.Profile_VerifiedType = Convert.ToString(user["verified_type"].ToString());
                                            }

                                            if (!string.IsNullOrEmpty(Convert.ToString(user["protected"])))
                                            {
                                                objTwitter.Profile_IsProtected = Convert.ToInt16(Convert.ToString(user["protected"].ToString()) == "True" ? 1 : 0);
                                            }
                                            break;
                                        }
                                    }
                                    #endregion

                                    lstTwitter.Add(objTwitter);
                                }
                                catch (Exception exx)
                                {
                                    ErrorLog("ExtractTweetsFromJson For Loop For " + objTwitter.Tweet_ID + " -> " + strOutput, exx.ToString());
                                }
                            }
                        }

                        jItem = null;

                        #endregion


                    }
                }
            }
            catch (Exception ex)
            {
                ErrorLog("ExtractTweetsFromJson", ex.ToString());
            }

            return lstTwitter;
        }

        #region INSERT

        public bool InsertTweets(List<eTwitter> lstLinks)
        {
            bool IsSuccessful = true;
            try
            {
                for (int i = 0; i < lstLinks.Count; i++)
                {
                    try
                    {
                        TimeLog("Start InsertTweet");
                        new MDB.DAL.DAL().Twitter_InsertTweet_FS(lstLinks[i],"");
                        TimeLog("End InsertTweet");
                    }
                    catch (Exception ex)
                    {
                        IsSuccessful = false;
                        ErrorLog("For Loop Error for " + lstLinks[i].Tweet_ID, ex.ToString());
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorLog("InsertTweets ", ex.Message + " ->> " + ex.StackTrace);
            }

            return IsSuccessful;
        }

        #endregion

        #region LOGGING

        //For error logging
        private void ErrorLog(string functionName, string error)
        {
            try
            {
                string LogPath = ConfigurationManager.AppSettings["Twitter_ErrorLogPath"];
                using (TextWriter myWriter = File.AppendText(LogPath))
                {

                    TextWriter.Synchronized(myWriter).WriteLine("<--> :{0}", string.Empty);
                    TextWriter.Synchronized(myWriter).WriteLine("Function Name :{0}", functionName);
                    TextWriter.Synchronized(myWriter).WriteLine("Error :{0}", error);
                    TextWriter.Synchronized(myWriter).WriteLine("Date :{0}", DateTime.Now.ToString());
                    TextWriter.Synchronized(myWriter).WriteLine("<--> :{0}", string.Empty);
                    TextWriter.Synchronized(myWriter).Flush();
                    TextWriter.Synchronized(myWriter).Close();
                }
            }
            catch (Exception ex)
            {
            }
        }

        //For debugging purpose
        private void TimeLog(string strtext)
        {
            try
            {
                string LogPath = ConfigurationManager.AppSettings["Twitter_TimeLogPath"];
                using (TextWriter myWriter = File.AppendText(LogPath))
                {

                    TextWriter.Synchronized(myWriter).WriteLine("<--> :{0}", string.Empty);
                    TextWriter.Synchronized(myWriter).WriteLine("TimeLog :{0}", strtext);
                    TextWriter.Synchronized(myWriter).WriteLine("Date :{0}", DateTime.Now.ToString());
                    TextWriter.Synchronized(myWriter).WriteLine("<--> :{0}", string.Empty);
                    TextWriter.Synchronized(myWriter).Flush();
                    TextWriter.Synchronized(myWriter).Close();
                }
            }
            catch (Exception ex)
            {
                ErrorLog("TimeLog", ex.ToString());
            }
        }

        #endregion
    }

    public class InputDataForThread
    {
        public string strRow;
    }
}
