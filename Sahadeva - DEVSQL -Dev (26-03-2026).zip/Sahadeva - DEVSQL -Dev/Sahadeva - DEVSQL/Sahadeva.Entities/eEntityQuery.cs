﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace Sahadeva.Entities
{
    public class eEntityQuery
    {
        
        [DataMember]
        public Int32 EQID { get; set; }

        [DataMember]
        public Int32 EntityID { get; set; }

        [DataMember]
        public string Query { get; set; }

        [DataMember]
        public string EntityType { get; set; }

        [DataMember]
        public string EntityName { get; set; }
        
    }
}
