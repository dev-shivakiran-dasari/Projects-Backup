﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace Sahadeva.Entities
{
    public class eLog
    {

        [DataMember]
        public string GUID { get; set; }
      
        [DataMember]
        public Int32 EntityID { get; set; }

        [DataMember]
        public DateTime FromDate { get; set; }

        [DataMember]
        public DateTime ToDate { get; set; }

        [DataMember]
        public Int32 Count_Total { get; set; }

        [DataMember]
        public Int32 Count_Inserted { get; set; }

        [DataMember]
        public Int32 Count_Duplicate { get; set; }

        [DataMember]
        public Int32 Count_Failed { get; set; }

        [DataMember]
        public Int32 Count_DB_Successful { get; set; }

        [DataMember]
        public Int32 Count_DB_Failed { get; set; }

    }
}
