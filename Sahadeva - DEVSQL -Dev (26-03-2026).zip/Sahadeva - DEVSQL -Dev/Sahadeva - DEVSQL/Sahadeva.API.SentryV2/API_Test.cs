﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ServiceModel;
using System.ServiceModel.Activation;
using System.ServiceModel.Web;
using System.Data.SqlClient;
using System.Data;
using System.Xml;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System.Web.Script.Serialization;
using System.Runtime.Serialization.Json;
using System.IO;
using System.Text;
using System.Configuration;
using System.Net;
using System.Runtime.Serialization;

namespace Sahadeva.API.SentryV2
{
    [ServiceContract]

    [AspNetCompatibilityRequirements(RequirementsMode = AspNetCompatibilityRequirementsMode.Allowed)]

    public class API_Test
    {

        #region Class for Parameters deserialization

        [JsonObject(MemberSerialization.OptIn)]
        [DataContract]
        public class eParameters
        {

            [JsonProperty]
            [DataMember(Name = "UserID")]
            public string UserID { get; set; }

        }

        #endregion

        public eParameters GetParameters(Stream postData)
        {
            try
            {
                JObject o = JObject.Parse(new StreamReader(postData).ReadToEnd().ToString());

                eParameters obj = JsonConvert.DeserializeObject<eParameters>(o.ToString());

                return obj;
            }
            catch (Exception)
            {

                throw;
            }
        }

        [OperationContract]
        [WebInvoke(Method = "POST", UriTemplate = "FetchIncidents", ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Bare)]
        public Stream FetchIncidents(Stream postData)
        {
            string result = string.Empty;

            try
            {

                if (HttpContext.Current.Request.Headers["token"] != null && !String.IsNullOrEmpty(HttpContext.Current.Request.Headers["token"]))
                {
                    bool IsValid = ValidateRequest(Convert.ToString(HttpContext.Current.Request.Headers["token"]));
                    if (IsValid == false)
                    {
                        result = "401 Unauthorized";
                        return new MemoryStream(Encoding.UTF8.GetBytes(result));
                    }
                }

                WebOperationContext.Current.OutgoingResponse.ContentType = "application/json; charset=utf-8";

                eParameters parameters_obj = GetParameters(postData);

                var setting = new JsonSerializerSettings
                {
                    MaxDepth = int.MaxValue
                };

                result = File.ReadAllText(ConfigurationManager.AppSettings["FetchIncidents"]);

                //result = JsonConvert.SerializeObject(result, setting);
            }
            catch (Exception ex)
            {
                Log("FetchIncidents", ex.Message + " ->> " + ex.StackTrace + " Detail : " + new StreamReader(postData).ReadToEnd().ToString());
            }

            return new MemoryStream(Encoding.UTF8.GetBytes(result));

        }

        [OperationContract]
        [WebInvoke(Method = "POST", UriTemplate = "FetchIncidentDetail", ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Bare)]
        public Stream FetchIncidentDetail(Stream postData)
        {
            string result = string.Empty;

            try
            {

                if (HttpContext.Current.Request.Headers["token"] != null && !String.IsNullOrEmpty(HttpContext.Current.Request.Headers["token"]))
                {
                    bool IsValid = ValidateRequest(Convert.ToString(HttpContext.Current.Request.Headers["token"]));
                    if (IsValid == false)
                    {
                        result = "401 Unauthorized";
                        return new MemoryStream(Encoding.UTF8.GetBytes(result));
                    }
                }

                WebOperationContext.Current.OutgoingResponse.ContentType = "application/json; charset=utf-8";

                eParameters parameters_obj = GetParameters(postData);

                var setting = new JsonSerializerSettings
                {
                    MaxDepth = int.MaxValue
                };

                result = File.ReadAllText(ConfigurationManager.AppSettings["FetchIncidentDetail"]);

                //result = JsonConvert.SerializeObject(ReadFile, setting);
            }
            catch (Exception ex)
            {
                Log("FetchIncidentDetail", ex.Message + " ->> " + ex.StackTrace + " Detail : " + new StreamReader(postData).ReadToEnd().ToString());
            }

            return new MemoryStream(Encoding.UTF8.GetBytes(result));

        }


        [OperationContract]
        [WebInvoke(Method = "POST", UriTemplate = "FetchList_OnlineArticle", ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Bare)]
        public Stream FetchList_OnlineArticle(Stream postData)
        {
            string result = string.Empty;

            try
            {

                if (HttpContext.Current.Request.Headers["token"] != null && !String.IsNullOrEmpty(HttpContext.Current.Request.Headers["token"]))
                {
                    bool IsValid = ValidateRequest(Convert.ToString(HttpContext.Current.Request.Headers["token"]));
                    if (IsValid == false)
                    {
                        result = "401 Unauthorized";
                        return new MemoryStream(Encoding.UTF8.GetBytes(result));
                    }
                }

                WebOperationContext.Current.OutgoingResponse.ContentType = "application/json; charset=utf-8";

                eParameters parameters_obj = GetParameters(postData);

                var setting = new JsonSerializerSettings
                {
                    MaxDepth = int.MaxValue
                };

                result = File.ReadAllText(ConfigurationManager.AppSettings["FetchList_OnlineArticle"]);

                //result = JsonConvert.SerializeObject(ReadFile, setting);
            }
            catch (Exception ex)
            {
                Log("FetchList_OnlineArticle", ex.Message + " ->> " + ex.StackTrace + " Detail : " + new StreamReader(postData).ReadToEnd().ToString());
            }

            return new MemoryStream(Encoding.UTF8.GetBytes(result));

        }

        [OperationContract]
        [WebInvoke(Method = "POST", UriTemplate = "FetchList_PrintArticle", ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Bare)]
        public Stream FetchList_PrintArticle(Stream postData)
        {
            string result = string.Empty;

            try
            {

                if (HttpContext.Current.Request.Headers["token"] != null && !String.IsNullOrEmpty(HttpContext.Current.Request.Headers["token"]))
                {
                    bool IsValid = ValidateRequest(Convert.ToString(HttpContext.Current.Request.Headers["token"]));
                    if (IsValid == false)
                    {
                        result = "401 Unauthorized";
                        return new MemoryStream(Encoding.UTF8.GetBytes(result));
                    }
                }

                WebOperationContext.Current.OutgoingResponse.ContentType = "application/json; charset=utf-8";

                eParameters parameters_obj = GetParameters(postData);

                var setting = new JsonSerializerSettings
                {
                    MaxDepth = int.MaxValue
                };

                result = File.ReadAllText(ConfigurationManager.AppSettings["FetchList_PrintArticle"]);

                //result = JsonConvert.SerializeObject(ReadFile, setting);
            }
            catch (Exception ex)
            {
                Log("FetchList_PrintArticle", ex.Message + " ->> " + ex.StackTrace + " Detail : " + new StreamReader(postData).ReadToEnd().ToString());
            }

            return new MemoryStream(Encoding.UTF8.GetBytes(result));

        }


        [OperationContract]
        [WebInvoke(Method = "POST", UriTemplate = "FetchOnlineArticle", ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Bare)]
        public Stream FetchOnlineArticle(Stream postData)
        {
            string result = string.Empty;

            try
            {

                if (HttpContext.Current.Request.Headers["token"] != null && !String.IsNullOrEmpty(HttpContext.Current.Request.Headers["token"]))
                {
                    bool IsValid = ValidateRequest(Convert.ToString(HttpContext.Current.Request.Headers["token"]));
                    if (IsValid == false)
                    {
                        result = "401 Unauthorized";
                        return new MemoryStream(Encoding.UTF8.GetBytes(result));
                    }
                }

                WebOperationContext.Current.OutgoingResponse.ContentType = "application/json; charset=utf-8";

                eParameters parameters_obj = GetParameters(postData);

                var setting = new JsonSerializerSettings
                {
                    MaxDepth = int.MaxValue
                };

                result = File.ReadAllText(ConfigurationManager.AppSettings["FetchOnlineArticle"]);

                //result = JsonConvert.SerializeObject(ReadFile, setting);
            }
            catch (Exception ex)
            {
                Log("FetchOnlineArticle", ex.Message + " ->> " + ex.StackTrace + " Detail : " + new StreamReader(postData).ReadToEnd().ToString());
            }

            return new MemoryStream(Encoding.UTF8.GetBytes(result));

        }

        [OperationContract]
        [WebInvoke(Method = "POST", UriTemplate = "FetchPrintArticle", ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Bare)]
        public Stream FetchPrintArticle(Stream postData)
        {
            string result = string.Empty;

            try
            {

                if (HttpContext.Current.Request.Headers["token"] != null && !String.IsNullOrEmpty(HttpContext.Current.Request.Headers["token"]))
                {
                    bool IsValid = ValidateRequest(Convert.ToString(HttpContext.Current.Request.Headers["token"]));
                    if (IsValid == false)
                    {
                        result = "401 Unauthorized";
                        return new MemoryStream(Encoding.UTF8.GetBytes(result));
                    }
                }

                WebOperationContext.Current.OutgoingResponse.ContentType = "application/json; charset=utf-8";

                eParameters parameters_obj = GetParameters(postData);

                var setting = new JsonSerializerSettings
                {
                    MaxDepth = int.MaxValue
                };

                result = File.ReadAllText(ConfigurationManager.AppSettings["FetchPrintArticle"]);

                //result = JsonConvert.SerializeObject(ReadFile, setting);
            }
            catch (Exception ex)
            {
                Log("FetchPrintArticle", ex.Message + " ->> " + ex.StackTrace + " Detail : " + new StreamReader(postData).ReadToEnd().ToString());
            }

            return new MemoryStream(Encoding.UTF8.GetBytes(result));

        }

        [OperationContract]
        [WebInvoke(Method = "POST", UriTemplate = "FetchNotificationSettings", ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Bare)]
        public Stream FetchNotificationSettings(Stream postData)
        {
            string result = string.Empty;

            try
            {

                if (HttpContext.Current.Request.Headers["token"] != null && !String.IsNullOrEmpty(HttpContext.Current.Request.Headers["token"]))
                {
                    bool IsValid = ValidateRequest(Convert.ToString(HttpContext.Current.Request.Headers["token"]));
                    if (IsValid == false)
                    {
                        result = "401 Unauthorized";
                        return new MemoryStream(Encoding.UTF8.GetBytes(result));
                    }
                }

                WebOperationContext.Current.OutgoingResponse.ContentType = "application/json; charset=utf-8";

                eParameters parameters_obj = GetParameters(postData);

                var setting = new JsonSerializerSettings
                {
                    MaxDepth = int.MaxValue
                };

                result = File.ReadAllText(ConfigurationManager.AppSettings["FetchNotificationSettings"]);

                //result = JsonConvert.SerializeObject(ReadFile, setting);
            }
            catch (Exception ex)
            {
                Log("FetchNotificationSettings", ex.Message + " ->> " + ex.StackTrace + " Detail : " + new StreamReader(postData).ReadToEnd().ToString());
            }

            return new MemoryStream(Encoding.UTF8.GetBytes(result));

        }


        [OperationContract]
        [WebInvoke(Method = "POST", UriTemplate = "FetchList_Twitter", ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Bare)]
        public Stream FetchList_Twitter(Stream postData)
        {
            string result = string.Empty;

            try
            {

                if (HttpContext.Current.Request.Headers["token"] != null && !String.IsNullOrEmpty(HttpContext.Current.Request.Headers["token"]))
                {
                    bool IsValid = ValidateRequest(Convert.ToString(HttpContext.Current.Request.Headers["token"]));
                    if (IsValid == false)
                    {
                        result = "401 Unauthorized";
                        return new MemoryStream(Encoding.UTF8.GetBytes(result));
                    }
                }

                WebOperationContext.Current.OutgoingResponse.ContentType = "application/json; charset=utf-8";

                eParameters parameters_obj = GetParameters(postData);

                var setting = new JsonSerializerSettings
                {
                    MaxDepth = int.MaxValue
                };

                result = File.ReadAllText(ConfigurationManager.AppSettings["FetchList_Twitter"]);

                //result = JsonConvert.SerializeObject(ReadFile, setting);
            }
            catch (Exception ex)
            {
                Log("FetchList_Twitter", ex.Message + " ->> " + ex.StackTrace + " Detail : " + new StreamReader(postData).ReadToEnd().ToString());
            }

            return new MemoryStream(Encoding.UTF8.GetBytes(result));

        }

        [OperationContract]
        [WebInvoke(Method = "POST", UriTemplate = "FetchTweet", ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Bare)]
        public Stream FetchTweet(Stream postData)
        {
            string result = string.Empty;

            try
            {

                if (HttpContext.Current.Request.Headers["token"] != null && !String.IsNullOrEmpty(HttpContext.Current.Request.Headers["token"]))
                {
                    bool IsValid = ValidateRequest(Convert.ToString(HttpContext.Current.Request.Headers["token"]));
                    if (IsValid == false)
                    {
                        result = "401 Unauthorized";
                        return new MemoryStream(Encoding.UTF8.GetBytes(result));
                    }
                }

                WebOperationContext.Current.OutgoingResponse.ContentType = "application/json; charset=utf-8";

                eParameters parameters_obj = GetParameters(postData);

                var setting = new JsonSerializerSettings
                {
                    MaxDepth = int.MaxValue
                };

                result = File.ReadAllText(ConfigurationManager.AppSettings["FetchTweet"]);

                //result = JsonConvert.SerializeObject(ReadFile, setting);
            }
            catch (Exception ex)
            {
                Log("FetchTweet", ex.Message + " ->> " + ex.StackTrace + " Detail : " + new StreamReader(postData).ReadToEnd().ToString());
            }

            return new MemoryStream(Encoding.UTF8.GetBytes(result));

        }


        [OperationContract]
        [WebInvoke(Method = "POST", UriTemplate = "FetchFilter_OnlineArticle", ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Bare)]
        public Stream FetchFilter_OnlineArticle(Stream postData)
        {
            string result = string.Empty;

            try
            {

                if (HttpContext.Current.Request.Headers["token"] != null && !String.IsNullOrEmpty(HttpContext.Current.Request.Headers["token"]))
                {
                    bool IsValid = ValidateRequest(Convert.ToString(HttpContext.Current.Request.Headers["token"]));
                    if (IsValid == false)
                    {
                        result = "401 Unauthorized";
                        return new MemoryStream(Encoding.UTF8.GetBytes(result));
                    }
                }

                WebOperationContext.Current.OutgoingResponse.ContentType = "application/json; charset=utf-8";

                eParameters parameters_obj = GetParameters(postData);

                var setting = new JsonSerializerSettings
                {
                    MaxDepth = int.MaxValue
                };

                result = File.ReadAllText(ConfigurationManager.AppSettings["FetchFilter_OnlineArticle"]);

                //result = JsonConvert.SerializeObject(ReadFile, setting);
            }
            catch (Exception ex)
            {
                Log("FetchFilter_OnlineArticle", ex.Message + " ->> " + ex.StackTrace + " Detail : " + new StreamReader(postData).ReadToEnd().ToString());
            }

            return new MemoryStream(Encoding.UTF8.GetBytes(result));

        }

        [OperationContract]
        [WebInvoke(Method = "POST", UriTemplate = "FetchFilter_PrintArticle", ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Bare)]
        public Stream FetchFilter_Print(Stream postData)
        {
            string result = string.Empty;

            try
            {

                if (HttpContext.Current.Request.Headers["token"] != null && !String.IsNullOrEmpty(HttpContext.Current.Request.Headers["token"]))
                {
                    bool IsValid = ValidateRequest(Convert.ToString(HttpContext.Current.Request.Headers["token"]));
                    if (IsValid == false)
                    {
                        result = "401 Unauthorized";
                        return new MemoryStream(Encoding.UTF8.GetBytes(result));
                    }
                }

                WebOperationContext.Current.OutgoingResponse.ContentType = "application/json; charset=utf-8";

                eParameters parameters_obj = GetParameters(postData);

                var setting = new JsonSerializerSettings
                {
                    MaxDepth = int.MaxValue
                };

                result = File.ReadAllText(ConfigurationManager.AppSettings["FetchFilter_PrintArticle"]);

                //result = JsonConvert.SerializeObject(ReadFile, setting);
            }
            catch (Exception ex)
            {
                Log("FetchFilter_Print", ex.Message + " ->> " + ex.StackTrace + " Detail : " + new StreamReader(postData).ReadToEnd().ToString());
            }

            return new MemoryStream(Encoding.UTF8.GetBytes(result));

        }

        [OperationContract]
        [WebInvoke(Method = "POST", UriTemplate = "FetchLanding_OnlineArticle", ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Bare)]
        public Stream FetchLanding_OnlineArticle(Stream postData)
        {
            string result = string.Empty;

            try
            {

                if (HttpContext.Current.Request.Headers["token"] != null && !String.IsNullOrEmpty(HttpContext.Current.Request.Headers["token"]))
                {
                    bool IsValid = ValidateRequest(Convert.ToString(HttpContext.Current.Request.Headers["token"]));
                    if (IsValid == false)
                    {
                        result = "401 Unauthorized";
                        return new MemoryStream(Encoding.UTF8.GetBytes(result));
                    }
                }

                WebOperationContext.Current.OutgoingResponse.ContentType = "application/json; charset=utf-8";

                eParameters parameters_obj = GetParameters(postData);

                var setting = new JsonSerializerSettings
                {
                    MaxDepth = int.MaxValue
                };

                result = File.ReadAllText(ConfigurationManager.AppSettings["FetchLanding_OnlineArticle"]);

                //result = JsonConvert.SerializeObject(ReadFile, setting);
            }
            catch (Exception ex)
            {
                Log("FetchLanding_OnlineArticle", ex.Message + " ->> " + ex.StackTrace + " Detail : " + new StreamReader(postData).ReadToEnd().ToString());
            }

            return new MemoryStream(Encoding.UTF8.GetBytes(result));

        }

        [OperationContract]
        [WebInvoke(Method = "POST", UriTemplate = "FetchLanding_PrintArticle", ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Bare)]
        public Stream FetchLanding_PrintArticle(Stream postData)
        {
            string result = string.Empty;

            try
            {

                if (HttpContext.Current.Request.Headers["token"] != null && !String.IsNullOrEmpty(HttpContext.Current.Request.Headers["token"]))
                {
                    bool IsValid = ValidateRequest(Convert.ToString(HttpContext.Current.Request.Headers["token"]));
                    if (IsValid == false)
                    {
                        result = "401 Unauthorized";
                        return new MemoryStream(Encoding.UTF8.GetBytes(result));
                    }
                }

                WebOperationContext.Current.OutgoingResponse.ContentType = "application/json; charset=utf-8";

                eParameters parameters_obj = GetParameters(postData);

                var setting = new JsonSerializerSettings
                {
                    MaxDepth = int.MaxValue
                };

                result = File.ReadAllText(ConfigurationManager.AppSettings["FetchLanding_PrintArticle"]);

                //result = JsonConvert.SerializeObject(ReadFile, setting);
            }
            catch (Exception ex)
            {
                Log("FetchLanding_PrintArticle", ex.Message + " ->> " + ex.StackTrace + " Detail : " + new StreamReader(postData).ReadToEnd().ToString());
            }

            return new MemoryStream(Encoding.UTF8.GetBytes(result));

        }

        #region ValidateRequest & Log
        public bool ValidateRequest(string token)
        {
            try
            {
                if (token == ConfigurationManager.AppSettings["token"].ToString())
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            catch (Exception)
            {

                throw;
            }
        }

        private void Log(string functionName, string error)
        {
            try
            {
                string LogPath = ConfigurationManager.AppSettings["LogPath"].ToString();
                using (TextWriter myWriter = File.AppendText(LogPath))
                {

                    TextWriter.Synchronized(myWriter).WriteLine("<--> :{0}", string.Empty);
                    TextWriter.Synchronized(myWriter).WriteLine("Function Name :{0}", functionName);
                    TextWriter.Synchronized(myWriter).WriteLine("Error :{0}", error);
                    TextWriter.Synchronized(myWriter).WriteLine("Date :{0}", DateTime.Now.ToString());
                    TextWriter.Synchronized(myWriter).WriteLine("<--> :{0}", string.Empty);
                    TextWriter.Synchronized(myWriter).Flush();
                    TextWriter.Synchronized(myWriter).Close();
                }

            }
            catch (Exception ex)
            {
            }
        }
        #endregion


    }
}