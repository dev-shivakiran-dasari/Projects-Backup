﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Newtonsoft.Json.Linq;
using System.Net;
using Newtonsoft.Json;
using System.Data;
using System.IO;
using System.Configuration;

namespace Sahadeva.API.SentryV2
{
    public partial class _Default : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            //DataSet ds = new DataSet();
            //DataTable dt = new DataTable();
            //string result = string.Empty;
            //dynamic jsonnn = new JObject();
            //try
            //{
            //    dt = new Sahadeva.API.DAL.API_V2().Incident_FetchList(Convert.ToInt32(634));
            //    //Log("Twitter_FetchLanding DS start", "");
            //    //ds = new Sahadeva.API.DAL.API_V2().Twitter_FetchLanding(Convert.ToInt32(3), Convert.ToDateTime("2024-11-01 00:00:00"), Convert.ToDateTime("2024-11-04 00:00:00"), Convert.ToDateTime("2024-10-04 00:00:00"),"","");
            //    //Log("Twitter_FetchLanding DS end", "");

            //    //ds = new Sahadeva.API.DAL.API_V2().User_FetchDetails_New("sameer.kamble");
            //    //var setting = new JsonSerializerSettings
            //    //{
            //    //    MaxDepth = int.MaxValue
            //    //};
            //    //jsonnn.Status = "Yes";
            //    //jsonnn.Status_Code = "200";
            //    //jsonnn.message = "Success";
            //    //jsonnn.clients = new JArray();

            //    //Int32 UserID = 0;
            //    //if (ds != null && ds.Tables.Count > 0)
            //    //{
            //    //    dt = ds.Tables[0];
            //    //    for (int i = 0; i < dt.Rows.Count; i++)
            //    //    {
            //    //        for (int c = 0; c < dt.Columns.Count; c++)
            //    //        {
            //    //            if (dt.Columns[c].ColumnName.ToString().Contains("UserID"))
            //    //            {
            //    //                UserID = Convert.ToInt32(dt.Rows[i][c].ToString());
            //    //            }
            //    //            jsonnn.Add(dt.Columns[c].ColumnName.ToString(), dt.Rows[i][c].ToString());
            //    //        }
            //    //    }

                   
            //    //}

            //    //result = JsonConvert.SerializeObject(jsonnn, setting);
            //}
            //catch (Exception ex)
            //{
               
            //}


            //return;

            //dynamic stuff = JsonConvert.DeserializeObject(File.ReadAllText(ConfigurationManager.AppSettings["FetchNotificationSettings"]));
            //string strTopicID = stuff.data.incident_id;



            ////Int32 TopicID = Convert.ToInt32(Convert.ToString(stuff.data.incident_id));
            ////Int32 UserID = Convert.ToInt32(Convert.ToString(stuff.data.user_id));
            ////Int32 IsActive = Convert.ToInt32(Convert.ToString(stuff.data.is_active));

            ////Int32 PlatformID = Convert.ToInt32(3);
            ////Int32 Platform_IsActive = Convert.ToInt32(Convert.ToString(stuff.data.twitter.is_active));
            ////Int32 Platform_AsItHappens = Convert.ToInt32(Convert.ToString(stuff.data.twitter.as_it_happens));
            ////Int32 Platform_Summarised = Convert.ToInt32(Convert.ToString(stuff.data.twitter.summarised));
            ////Int32 Platform_SummarisedInterval = Convert.ToInt32(Convert.ToString(stuff.data.twitter.summarised_interval));
            ////Int32 Result = new Sahadeva.API.DAL.API_V2().Incident_UpdateNotificationSettings(TopicID, UserID, IsActive, PlatformID, Platform_IsActive, Platform_AsItHappens, Platform_Summarised, Platform_SummarisedInterval);

            ////PlatformID = Convert.ToInt32(1);
            ////Platform_IsActive = Convert.ToInt32(Convert.ToString(stuff.data.online_article.is_active));
            ////Platform_AsItHappens = Convert.ToInt32(Convert.ToString(stuff.data.online_article.as_it_happens));
            ////Platform_Summarised = Convert.ToInt32(Convert.ToString(stuff.data.online_article.summarised));
            ////Platform_SummarisedInterval = Convert.ToInt32(Convert.ToString(stuff.data.online_article.summarised_interval));
            ////Result = new Sahadeva.API.DAL.API_V2().Incident_UpdateNotificationSettings(TopicID, UserID, IsActive, PlatformID, Platform_IsActive, Platform_AsItHappens, Platform_Summarised, Platform_SummarisedInterval);

            ////PlatformID = Convert.ToInt32(2);
            ////Platform_IsActive = Convert.ToInt32(Convert.ToString(stuff.data.print_article.is_active));
            ////Platform_AsItHappens = Convert.ToInt32(Convert.ToString(stuff.data.print_article.as_it_happens));
            ////Platform_Summarised = Convert.ToInt32(Convert.ToString(stuff.data.print_article.summarised));
            ////Platform_SummarisedInterval = Convert.ToInt32(Convert.ToString(stuff.data.print_article.summarised_interval));
            ////Result = new Sahadeva.API.DAL.API_V2().Incident_UpdateNotificationSettings(TopicID, UserID, IsActive, PlatformID, Platform_IsActive, Platform_AsItHappens, Platform_Summarised, Platform_SummarisedInterval);



            //return;
            //string[] strArray = new string[1];
            //strArray[0] = "[joshi,mayuresh,punam]";

            //List<string> strList = new List<string>();
            //strList.Add(strArray.FirstOrDefault().ToString());



            //strList = JsonConvert.DeserializeObject<List<string>>(strArray[0]);

            //return;
            //DataSet dsss = new Sahadeva.API.DAL.API_V2().Twitter_FetchById(13668,0);
            //dynamic json = new JObject();
            //if (dsss.Tables.Count > 0)
            //{
            //    json.status = "200";
            //    json.message = "Success";
            //    json.data = new JArray();

            //    dynamic o = new JObject();
            //    o = (JObject)JArray.FromObject(dsss.Tables[0])[0];
            //    o.profile = (JObject)JArray.FromObject(dsss.Tables[1])[0];
            //    o.engagement = (JObject)JArray.FromObject(dsss.Tables[2])[0];
            //    o.mentioned_attributes = JArray.FromObject(dsss.Tables[3]);
            //    o.tags = JArray.FromObject(dsss.Tables[4]);

            //    json.data.Add(o);
            //}
            //return;

            
            //string name = stuff.status;
            //string address = stuff.data.incident_id;
            //address = stuff.data.user_id;
            //address = stuff.data.online_article.summarised_interval;

            //ds = new Sahadeva.API.DAL.API_V2().ArticleOnline_FetchById(Convert.ToInt32(797),0);

            //DateTime dttt = DateTime.Parse("2024-01-05 00:00:00");
            //json = new JObject();
            //if (ds.Tables.Count > 0)
            //{
            //    json.status = "200";
            //    json.message = "";
            //    json.data = new JArray();

            //    dynamic o = new JObject();
            //    o = (JObject)JArray.FromObject(ds.Tables[1])[0];
            //    o.publication = (JObject)JArray.FromObject(ds.Tables[1])[0];
            //    o.tags = JArray.FromObject(ds.Tables[2]);

            //    json.data.Add(o);

            //    string ss = json.ToString();
            //}
            //return;

            //dynamic jsonIncident = new JObject();
            //jsonIncident.status = "200";
            //jsonIncident.message = "";

            //jsonIncident.data = new JArray();

            //dt = new DataTable();

            //// Adding columns to the DataTable
            //dt.Columns.Add("UserId", typeof(Int32));
            //dt.Columns.Add("UserName", typeof(string));
            //dt.Columns.Add("Education", typeof(string));
            //dt.Columns.Add("Location", typeof(string));

            //// Adding rows to the DataTable
            //dt.Rows.Add(1, "Satinder Singh", "Bsc Com Sci", "Mumbai");
            //dt.Rows.Add(2, "Amit Sarna", "Mstr Com Sci", "Mumbai");
            //dt.Rows.Add(3, "Andrea Ely", "Bsc Bio-Chemistry", "Queensland");
            //dt.Rows.Add(4, "Leslie Mac", "MSC", "Town-ville");
            //dt.Rows.Add(5, "Vaibhav Adhyapak", "MBA", "New Delhi");

            ////jsonIncident.data = JsonConvert.SerializeObject(new {MyCustomName = dt});

            ////jsonIncident.data.Add(JsonConvert.SerializeObject(dt));
            //dt = new Sahadeva.API.DAL.API_V2().Incident_FetchList(0);
            //jsonIncident.data= JArray.FromObject(dt);

            ////for (int i = 0; i < 5; i++)
            ////{
            ////    JObject objIncident = new JObject();
            ////    objIncident.Add("incident_id", i+1);
            ////    objIncident.Add("title", "Byju’s Crisis");
            ////    objIncident.Add("date_time", "06 Apr 2023 to TBD");
            ////    objIncident.Add("status", "active");
            ////    objIncident.Add("description", "Failed to file its financial accounts on time.Skipped an interest payment on its term loan.Triggered a legal fight with its creditors.");
            ////    objIncident.Add("tweets_count", "110");
            ////    objIncident.Add("online_articles_count", "32");
            ////    objIncident.Add("print_articles_count", "15");
            ////    jsonIncident.data.Add(objIncident);
            ////}

            //txtJson.Text = jsonIncident.ToString(Formatting.Indented);
             
            
            ////Create Object
            //dynamic product = new JObject();

            ////Create Properties
            //product.issue_name = "Elbow Grease";
            //product.base_date = true;
            //product.Price = 4.90m;
            //product.StockCount = 9000;
            //product.StockValue = 44100;
            
            ////Create Object
            //product.print_media_article = new JObject();
            //product.print_media_article.total_count = "12.4K";
            //product.print_media_article.percent_change = "17%K";
            //product.print_media_article.state = "normal|+|-";

            ////Create Array & Add Objects in Array
            //product.stats = new JArray();
            //JObject print_media_article = new JObject();
            //print_media_article.Add("current_value","173");
            //print_media_article.Add("total_value","405");
            //print_media_article.Add("percentage_change","31");
            //print_media_article.Add("percentage_state","normal|+|-");
            //print_media_article.Add("card_type","compare");
            //product.stats.Add(print_media_article);

            //string s = product.ToString();
            //Response.Write(product.ToString());
        }

    }
}
