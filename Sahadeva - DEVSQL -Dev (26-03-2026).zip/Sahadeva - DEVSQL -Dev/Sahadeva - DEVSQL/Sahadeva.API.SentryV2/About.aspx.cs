﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Net;
using Newtonsoft.Json;
using System.Text;
using System.IO;
using System.Data;
using Newtonsoft.Json.Linq;

namespace Sahadeva.API.SentryV2
{
    public partial class About : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {

                string strToken = "045793b8fae14ebfbb5a32cc55d11fcd";// ConfigurationManager.AppSettings["URL_API_Token"];
                string strURL = "https://sentry-prod-webapi.adfactorspr.com/SentryV2_Live/V2/FetchList_Twitter";//ConfigurationManager.AppSettings["URL_API_Twitter"];

                HttpWebRequest request = (HttpWebRequest)WebRequest.Create(strURL);
                request.Headers["token"] = strToken;

                string strJson = "{\"UserID\" : \"634\",\"incident_id\":\"8\",\"base_date\":\"2024-11-08 00:00:00\",\"from_date\":\"2024-11-08 00:00:00\",\"to_date\":\"2025-01-30 00:00:00\"}";



                //Create bytes array to send Input as parameter
                byte[] bytes = bytes = Encoding.UTF8.GetBytes(strJson);

                //Set request options
                request.ContentType = "application/json; charset=utf8";
                request.ContentLength = bytes.Length;
                request.Method = "POST";
                request.Timeout = Convert.ToInt32(180000);//ConfigurationManager.AppSettings["Timeout_API"]

                //Upload bytes array to request
                using (Stream os = request.GetRequestStream())
                {
                    os.Write(bytes, 0, bytes.Length);
                }



                //Get response from TextProcessingPipeline
                using (System.Net.WebResponse resp = request.GetResponse())
                {
                    using (StreamReader sr = new StreamReader(resp.GetResponseStream()))
                    {
                        string strOutput = sr.ReadToEnd().Trim();

                        if (!String.IsNullOrEmpty(strOutput))
                        {
                            JObject obj = JObject.Parse(strOutput);
                            if (obj != null)
                            {

                                JArray jItems = (JArray)obj["data"];
                                DataTable dt = (DataTable)JsonConvert.DeserializeObject(jItems.ToString(), (typeof(DataTable)));
                            }

                            
                        }
                        

                    }
                }
            }
            catch (Exception)
            {
                
                throw;
            }

        }
    }
}
