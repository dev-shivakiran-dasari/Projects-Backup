﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ServiceModel;
using System.ServiceModel.Activation;
using System.ServiceModel.Web;
using System.Data.SqlClient;
using System.Data;
using System.Xml;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System.Web.Script.Serialization;
using System.Runtime.Serialization.Json;
using System.IO;
using System.Text;
using System.Configuration;
using System.Net;
using System.Runtime.Serialization;
using System.Net.Mail;

namespace Sahadeva.API.SentryV2
{
    public class Summary
    {
        public string FetchData_OnlineArticle(string Json, string strPeakSummary,bool IsIntent = false)
        {
            string strOutput = string.Empty;

            Log("FetchLanding_OnlineArticle_Summary", Json);
            try
            {
                string strFinalURL = string.Empty;
                string strURL_Service = ConfigurationManager.AppSettings["Url_Online_Landing"].ToString();


                if (!String.IsNullOrEmpty(strURL_Service))
                {
                    //Create bytes array to send Input as parameter
                    byte[] bytes = bytes = Encoding.UTF8.GetBytes(Json.ToCharArray());//System.Text.Encoding.GetEncoding("ISO-8859-1").GetBytes(strParameters);

                    HttpWebRequest request = (HttpWebRequest)WebRequest.Create(strURL_Service);
                    request.Timeout = Convert.ToInt32(ConfigurationManager.AppSettings["TimeOutIntervalForOperation"]);
                    request.ContentType = "application/json; charset=utf8";
                    request.ContentLength = bytes.Length;
                    request.Method = "POST";

                    //Upload bytes array to request
                    using (Stream os = request.GetRequestStream())
                    {
                        os.Write(bytes, 0, bytes.Length);
                    }

                    //Get response from TextProcessingPipeline
                    using (System.Net.WebResponse resp = request.GetResponse())
                    {
                        using (StreamReader sr = new StreamReader(resp.GetResponseStream()))
                        {
                            strOutput = sr.ReadToEnd().Trim();
                            
                            if (!String.IsNullOrEmpty(strOutput))
                            {
                                Console.WriteLine("strOutput is " + strOutput);
                                string strSummary = string.Empty;
                                dynamic stuff = JObject.Parse(strOutput);
                                if (IsIntent == true)
                                {
                                    strSummary = stuff.summary;
                                }
                                else
                                {
                                    strSummary = stuff.landing_summary;
                                }
                                dynamic json = new JObject();
                                string[] lines = strSummary.Split(new string[] { "\r\n", "\r", "\n" }, StringSplitOptions.None);
                                json = new JObject();
                                json.status = "200";
                                json.message = "Success";
                                json.data = new JObject();
                                dynamic o = new JObject();
                                o.key_highlights_data = new JArray();
                                json.data = o;

                                if (IsIntent == true)
                                {
                                    dynamic oo = new JObject();
                                    oo.type = "text";

                                    oo.excerpt = "THIS IS INTENT DRIVEN SUMMARY";
                                    oo.link = string.Empty;
                                    oo.clickable = "false";

                                    //o.key_highlights_data.Add(oo);
                                }

                                for (int i = 0; i < lines.Length; i++)
                                {
                                    //'text' as type,value as excerpt,'' as link,'false' as clickable
                                    dynamic oo = new JObject();
                                    oo.type = "text";

                                    oo.excerpt = lines[i].ToString();
                                    if (String.IsNullOrEmpty(lines[i].ToString()))
                                    {
                                        continue;
                                    }
                                    oo.link = string.Empty;
                                    oo.clickable = "false";

                                    o.key_highlights_data.Add(oo);
                                }

                                if (!String.IsNullOrEmpty(strPeakSummary))
                                {
                                    dynamic oo = new JObject();
                                    oo.type = "text";

                                    //oo.excerpt ="Peak Summary :" + strPeakSummary;
                                    oo.excerpt = strPeakSummary;
                                    oo.link = string.Empty;
                                    oo.clickable = "false";

                                    o.key_highlights_data.Add(oo);
                                }


                                strOutput = Convert.ToString(json);
                            }

                        }
                    }

                    request = null;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return strOutput;
        }

        public string FetchData_PrintArticle(string Json, string strPeakSummary, bool IsIntent = false)
        {
            string strOutput = string.Empty;

            try
            {
                string strFinalURL = string.Empty;
                string strURL_Service = ConfigurationManager.AppSettings["Url_Print_Landing"].ToString();


                if (!String.IsNullOrEmpty(strURL_Service))
                {
                    //Create bytes array to send Input as parameter
                    byte[] bytes = bytes = Encoding.UTF8.GetBytes(Json.ToCharArray());//System.Text.Encoding.GetEncoding("ISO-8859-1").GetBytes(strParameters);

                    HttpWebRequest request = (HttpWebRequest)WebRequest.Create(strURL_Service);
                    request.Timeout = Convert.ToInt32(ConfigurationManager.AppSettings["TimeOutIntervalForOperation"]);
                    request.ContentType = "application/json; charset=utf8";
                    request.ContentLength = bytes.Length;
                    request.Method = "POST";

                    //Upload bytes array to request
                    using (Stream os = request.GetRequestStream())
                    {
                        os.Write(bytes, 0, bytes.Length);
                    }

                    //Get response from TextProcessingPipeline
                    using (System.Net.WebResponse resp = request.GetResponse())
                    {
                        using (StreamReader sr = new StreamReader(resp.GetResponseStream()))
                        {
                            strOutput = sr.ReadToEnd().Trim();
                            if (!String.IsNullOrEmpty(strOutput))
                            {
                                Console.WriteLine("strOutput is " + strOutput);
                                string strSummary = string.Empty;
                                dynamic stuff = JObject.Parse(strOutput);
                                if (IsIntent == true)
                                {
                                    strSummary = stuff.summary;
                                }
                                else
                                {
                                    strSummary = stuff.landing_summary;
                                }
                                dynamic json = new JObject();
                                string[] lines = strSummary.Split(new string[] { "\r\n", "\r", "\n" }, StringSplitOptions.None);
                                json = new JObject();
                                json.status = "200";
                                json.message = "Success";
                                json.data = new JObject();
                                dynamic o = new JObject();
                                o.key_highlights_data = new JArray();
                                json.data = o;

                                if (IsIntent == true)
                                {
                                    dynamic oo = new JObject();
                                    oo.type = "text";

                                    oo.excerpt = "THIS IS INTENT DRIVEN SUMMARY";
                                    oo.link = string.Empty;
                                    oo.clickable = "false";

                                    //o.key_highlights_data.Add(oo);
                                }

                                for (int i = 0; i < lines.Length; i++)
                                {
                                    //'text' as type,value as excerpt,'' as link,'false' as clickable
                                    dynamic oo = new JObject();
                                    oo.type = "text";

                                    oo.excerpt = lines[i].ToString();
                                    if (String.IsNullOrEmpty(lines[i].ToString()))
                                    {
                                        continue;
                                    }
                                    oo.link = string.Empty;
                                    oo.clickable = "false";

                                    o.key_highlights_data.Add(oo);
                                }

                                if (!String.IsNullOrEmpty(strPeakSummary))
                                {
                                    dynamic oo = new JObject();
                                    oo.type = "text";

                                    oo.excerpt = strPeakSummary;
                                    oo.link = string.Empty;
                                    oo.clickable = "false";

                                    o.key_highlights_data.Add(oo);
                                }

                                strOutput = Convert.ToString(json);
                            }

                        }
                    }

                    request = null;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return strOutput;
        }

        public string FetchData_Twitter(string ts_id, string strPeakSummary)
        {
            string strOutput = string.Empty;

            try
            {
                string strFinalURL = string.Empty;
                string strURL_Service = ConfigurationManager.AppSettings["Url_Twitter_Landing"].ToString();

                //eRequestParameter objParameter = new eRequestParameter();
                //objParameter.ts_id = ts_id;

                if (!String.IsNullOrEmpty(strURL_Service))
                {
                    dynamic json = new JObject();
                    json.ts_id = ts_id;

                    //Create bytes array to send Input as parameter
                    byte[] bytes = bytes = Encoding.UTF8.GetBytes(Convert.ToString(json));//System.Text.Encoding.GetEncoding("ISO-8859-1").GetBytes(strParameters);

                    HttpWebRequest request = (HttpWebRequest)WebRequest.Create(strURL_Service);
                    request.Timeout = Convert.ToInt32(ConfigurationManager.AppSettings["TimeOutIntervalForOperation"]);
                    request.ContentType = "application/json; charset=utf8";
                    request.ContentLength = bytes.Length;
                    request.Method = "POST";
                    Console.WriteLine("T2");
                    //Upload bytes array to request
                    using (Stream os = request.GetRequestStream())
                    {
                        os.Write(bytes, 0, bytes.Length);
                    }

                    //Get response from TextProcessingPipeline
                    using (System.Net.WebResponse resp = request.GetResponse())
                    {
                        using (StreamReader sr = new StreamReader(resp.GetResponseStream()))
                        {
                            strOutput = sr.ReadToEnd().Trim();

                            Console.WriteLine("strOutput is " + strOutput);

                            string strSummary = string.Empty;
                            dynamic stuff = JObject.Parse(strOutput);
                            strSummary = stuff.landing_summary;
                            json = new JObject();
                            string[] lines = strSummary.Split(new string[] { "\r\n", "\r", "\n" }, StringSplitOptions.None);
                            json = new JObject();
                            json.status = "200";
                            json.message = "Success";
                            json.data = new JObject();
                            dynamic o = new JObject();
                            o.key_highlights_data = new JArray();
                            json.data = o;

                            for (int i = 0; i < lines.Length; i++)
                            {
                                //'text' as type,value as excerpt,'' as link,'false' as clickable
                                dynamic oo = new JObject();
                                oo.type = "text";

                                oo.excerpt = lines[i].ToString();
                                if (String.IsNullOrEmpty(lines[i].ToString()))
                                {
                                    continue;
                                }
                                oo.link = string.Empty;
                                oo.clickable = "false";

                                o.key_highlights_data.Add(oo);
                            }

                            if (!String.IsNullOrEmpty(strPeakSummary))
                            {
                                dynamic oo = new JObject();
                                oo.type = "text";

                                oo.excerpt = strPeakSummary;
                                oo.link = string.Empty;
                                oo.clickable = "false";

                                o.key_highlights_data.Add(oo);
                            }

                            strOutput = Convert.ToString(json);
                        }
                    }

                    request = null;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return strOutput;
        }

        public string FetchData_Twitter_Intent(string Json, string strPeakSummary)
        {
            string strOutput = string.Empty;

            try
            {
                string strFinalURL = string.Empty;
                string strURL_Service = ConfigurationManager.AppSettings["Url_Twitter_Landing"].ToString();


                if (!String.IsNullOrEmpty(strURL_Service))
                {

                    //Create bytes array to send Input as parameter
                    byte[] bytes = bytes = Encoding.UTF8.GetBytes(Json.ToCharArray());//System.Text.Encoding.GetEncoding("ISO-8859-1").GetBytes(strParameters);

                    HttpWebRequest request = (HttpWebRequest)WebRequest.Create(strURL_Service);
                    request.Timeout = Convert.ToInt32(ConfigurationManager.AppSettings["TimeOutIntervalForOperation"]);
                    request.ContentType = "application/json; charset=utf8";
                    request.ContentLength = bytes.Length;
                    request.Method = "POST";

                    //Upload bytes array to request
                    using (Stream os = request.GetRequestStream())
                    {
                        os.Write(bytes, 0, bytes.Length);
                    }

                    //Get response from TextProcessingPipeline
                    using (System.Net.WebResponse resp = request.GetResponse())
                    {
                        using (StreamReader sr = new StreamReader(resp.GetResponseStream()))
                        {
                            strOutput = sr.ReadToEnd().Trim();
                            if (!String.IsNullOrEmpty(strOutput))
                            {
                                Console.WriteLine("strOutput is " + strOutput);
                                string strSummary = string.Empty;
                                dynamic stuff = JObject.Parse(strOutput);
                                strSummary = stuff.summary;
                                dynamic json = new JObject();
                                string[] lines = strSummary.Split(new string[] { "\r\n", "\r", "\n" }, StringSplitOptions.None);
                                json = new JObject();
                                json.status = "200";
                                json.message = "Success";
                                json.data = new JObject();
                                dynamic o = new JObject();
                                o.key_highlights_data = new JArray();
                                json.data = o;

                                dynamic oo = new JObject();
                                oo.type = "text";

                                oo.excerpt = "THIS IS INTENT DRIVEN SUMMARY";
                                oo.link = string.Empty;
                                oo.clickable = "false";

                                //o.key_highlights_data.Add(oo);

                                for (int i = 0; i < lines.Length; i++)
                                {
                                    //'text' as type,value as excerpt,'' as link,'false' as clickable
                                    oo = new JObject();
                                    oo.type = "text";

                                    oo.excerpt = lines[i].ToString();
                                    if (String.IsNullOrEmpty(lines[i].ToString()))
                                    {
                                        continue;
                                    }
                                    oo.link = string.Empty;
                                    oo.clickable = "false";

                                    o.key_highlights_data.Add(oo);
                                }

                                if (!String.IsNullOrEmpty(strPeakSummary))
                                {
                                    oo = new JObject();
                                    oo.type = "text";

                                    //oo.excerpt ="Peak Summary :" + strPeakSummary;
                                    oo.excerpt = strPeakSummary;
                                    oo.link = string.Empty;
                                    oo.clickable = "false";

                                    o.key_highlights_data.Add(oo);
                                }


                                strOutput = Convert.ToString(json);
                            }
                        }
                    }

                    request = null;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return strOutput;
        }

        public string CreateJSON(Int32 TopicID, DateTime FromDate, DateTime ToDate)
        {
            string Result = string.Empty;
            try
            {

                DataSet ds = new MDB.DAL.DAL().Summary_FetchJSON(TopicID, FromDate, ToDate, 0);


                #region JSON

                dynamic json = new JObject();
                if (ds.Tables.Count > 0)
                {
                    json.status = "200";
                    json.message = "Success";
                    json.request_id = Guid.NewGuid().ToString();
                    json.data = new JObject();

                    dynamic o = new JObject();

                    #region context
                    //context Start
                    o.context = new JObject();
                    o.context.incident_id = Convert.ToInt32(ds.Tables[0].Rows[0]["incident_id"]);
                    o.context.entity_id = Convert.ToInt32(ds.Tables[0].Rows[0]["entity_id"]);
                    o.context.client_issue_description = Convert.ToString(ds.Tables[0].Rows[0]["client_issue_description"]);
                    o.context.tsid = Convert.ToInt32(ds.Tables[0].Rows[0]["tsid"]);

                    o.context.time_interval = new JObject();
                    o.context.time_interval.t1 = new JObject();
                    o.context.time_interval.t2 = new JObject();

                    o.context.time_interval.t1.from_date = Convert.ToString(ds.Tables[0].Rows[0]["t1_from_date"]);
                    o.context.time_interval.t1.to_date = Convert.ToString(ds.Tables[0].Rows[0]["t1_to_date"]);
                    o.context.time_interval.t1.p6_summary = Convert.ToString(ds.Tables[0].Rows[0]["p6_summary"]);

                    o.context.time_interval.t2.from_date = Convert.ToString(ds.Tables[0].Rows[0]["t2_from_date"]);
                    o.context.time_interval.t2.to_date = Convert.ToString(ds.Tables[0].Rows[0]["t2_to_date"]);
                    //context End 
                    #endregion

                    //prompts_variables Start
                    o.prompts_variables = new JObject();

                    #region p_1
                    //p_1 Start
                    o.prompts_variables.p_1 = new JObject();
                    o.prompts_variables.p_1.t1 = new JObject();
                    o.prompts_variables.p_1.t2 = new JObject();

                    o.prompts_variables.p_1.t1.total_volume = Convert.ToInt32(ds.Tables[1].Rows[0]["total_volume"]);
                    o.prompts_variables.p_1.t1.total_velocity = Convert.ToInt32(ds.Tables[1].Rows[0]["total_velocity"]);
                    o.prompts_variables.p_1.t1.total_reach = Convert.ToInt32(ds.Tables[1].Rows[0]["total_reach"]);
                    o.prompts_variables.p_1.t1.total_engagement = Convert.ToInt32(ds.Tables[1].Rows[0]["total_engagement"]);
                    o.prompts_variables.p_1.t1.total_views = Convert.ToInt32(ds.Tables[1].Rows[0]["total_views"]);
                    o.prompts_variables.p_1.t1.overall_sentiment_of_tweets_in_percentage = JArray.FromObject(ds.Tables[2]);

                    o.prompts_variables.p_1.t2.total_volume = Convert.ToInt32(ds.Tables[3].Rows[0]["total_volume"]);
                    o.prompts_variables.p_1.t2.total_velocity = Convert.ToInt32(ds.Tables[3].Rows[0]["total_velocity"]);
                    o.prompts_variables.p_1.t2.total_reach = Convert.ToInt32(ds.Tables[3].Rows[0]["total_reach"]);
                    o.prompts_variables.p_1.t2.total_engagement = Convert.ToInt32(ds.Tables[3].Rows[0]["total_engagement"]);
                    o.prompts_variables.p_1.t2.total_views = Convert.ToInt32(ds.Tables[3].Rows[0]["total_views"]);
                    o.prompts_variables.p_1.t2.overall_sentiment_of_tweets_in_percentage = JArray.FromObject(ds.Tables[4]);
                    //p_1 End 
                    #endregion

                    #region p_2
                    //p_2 Start
                    o.prompts_variables.p_2 = new JObject();
                    o.prompts_variables.p_2.t2 = new JObject();

                    o.prompts_variables.p_2.t2.total_tweets = Convert.ToInt32(ds.Tables[5].Rows[0]["total_tweets"]);
                    o.prompts_variables.p_2.t2.total_retweets = Convert.ToInt32(ds.Tables[5].Rows[0]["total_retweets"]);
                    o.prompts_variables.p_2.t2.total_tweets_in_ct = Convert.ToInt32(ds.Tables[5].Rows[0]["total_tweets_in_ct"]);
                    o.prompts_variables.p_2.t2.total_independent_tweets = Convert.ToInt32(ds.Tables[5].Rows[0]["total_independent_tweets"]);
                    //p_2 End 
                    #endregion

                    #region p_3
                    //p_3 Start
                    o.prompts_variables.p_3 = new JObject();
                    o.prompts_variables.p_3.t2 = new JObject();

                    if (ds.Tables[6].Rows.Count > 0)
                    {
                        o.prompts_variables.p_3.t2.text_of_tweet = Convert.ToString(ds.Tables[6].Rows[0]["text_of_tweet"]);
                        o.prompts_variables.p_3.t2.total_retweets = Convert.ToInt32(ds.Tables[6].Rows[0]["total_retweets"]);
                        o.prompts_variables.p_3.t2.profile_handle = Convert.ToString(ds.Tables[6].Rows[0]["profile_handle"]);
                    }
                    //p_3 End 
                    #endregion

                    #region p_4
                    //p_4 Start
                    o.prompts_variables.p_4 = new JObject();
                    o.prompts_variables.p_4.t2 = new JArray();
                    o.prompts_variables.p_4.t2 = JArray.FromObject(ds.Tables[7]);
                    //p_4 End 
                    #endregion

                    #region p_5.1
                    //p_5.1 Start
                    o.prompts_variables.p_5_1 = new JObject();
                    o.prompts_variables.p_5_1.t2 = new JArray();
                    o.prompts_variables.p_5_1.t2 = JArray.FromObject(ds.Tables[8]);
                    //p_5.1 End 
                    #endregion

                    #region p_5.2
                    //p_5.2 Start
                    o.prompts_variables.p_5_2 = new JObject();
                    o.prompts_variables.p_5_2.t2 = new JArray();
                    o.prompts_variables.p_5_2.t2 = JArray.FromObject(ds.Tables[9]);
                    //p_5.2 End 
                    #endregion

                    #region p_5.3
                    //p_5.3 Start
                    o.prompts_variables.p_5_3 = new JObject();
                    o.prompts_variables.p_5_3.t2 = new JArray();
                    o.prompts_variables.p_5_3.t2 = JArray.FromObject(ds.Tables[10]);
                    //p_5.3 End 
                    #endregion

                    #region p_5.4
                    //p_5.4 Start
                    o.prompts_variables.p_5_4 = new JObject();
                    o.prompts_variables.p_5_4.t2 = new JArray();

                    //DataTable dt = ds.Tables[11];
                    //DataTable dtCTDetails = ds.Tables[12];

                    //for (int i = 0; i < dt.Rows.Count; i++)
                    //{
                    //    dynamic tcDetails = new JObject();
                    //    tcDetails.Add("tcid", Convert.ToString(dt.Rows[i]["tcid"]));
                    //    tcDetails.Add("ct_id", Convert.ToString(dt.Rows[i]["Tweet_ConversationID"]));
                    //    tcDetails.tree_details = new JArray();

                    //    List<eTwitter_Summary> lstTwitter_Data_V2 = new List<eTwitter_Summary>();

                    //    eTwitter_Summary oParent = new eTwitter_Summary();
                    //    oParent.Input = Convert.ToString(dt.Rows[i]["Tweet_ConversationID"]);
                    //    oParent.tweet_id = Convert.ToString(dt.Rows[i]["Tweet_ConversationID"]);
                    //    lstTwitter_Data_V2.Add(oParent);

                    //    DataTable dtdtCTDetailsFiltered = new DataTable();

                    //    dtdtCTDetailsFiltered = dtCTDetails.Select("Tweet_ConversationID = " + Convert.ToString(dt.Rows[i]["Tweet_ConversationID"])).CopyToDataTable();

                    //    for (int j = 0; j < dtdtCTDetailsFiltered.Rows.Count; j++)
                    //    {
                    //        eTwitter_Summary objeTwitter_Summary = new eTwitter_Summary();
                    //        objeTwitter_Summary.text_of_tweet = Convert.ToString(dtdtCTDetailsFiltered.Rows[j]["Tweet_Text"]);
                    //        objeTwitter_Summary.tweet_id = Convert.ToString(dtdtCTDetailsFiltered.Rows[j]["Tweet_ID"]);
                    //        objeTwitter_Summary.Tweet_RepliedToTweetID = Convert.ToString(dtdtCTDetailsFiltered.Rows[j]["Tweet_RepliedToTweetID"]);
                    //        objeTwitter_Summary.Twitter_ID = Convert.ToInt32(dtdtCTDetailsFiltered.Rows[j]["TwitterID"]);
                    //        objeTwitter_Summary.url = Convert.ToString(dtdtCTDetailsFiltered.Rows[j]["Tweet_Url"]);
                    //        lstTwitter_Data_V2.Add(objeTwitter_Summary);
                    //    }

                    //    if (lstTwitter_Data_V2.Count > 1)
                    //    {
                    //        List<eTwitter_Summary> lstTwitter_Data_V2_Sorted = lstTwitter_Data_V2.OrderBy(oo => Convert.ToInt64(oo.tweet_id)).ToList();

                    //        List<eTwitter_Summary> lstTwitter_Data_V2VM = new List<eTwitter_Summary>();
                    //        GetHierachicalList(lstTwitter_Data_V2_Sorted, lstTwitter_Data_V2VM, null, "");


                    //        foreach (eTwitter_Summary t in lstTwitter_Data_V2VM)
                    //        {
                    //            try
                    //            {
                    //                lstTwitter_Data_V2_Sorted.Where(w => w.tweet_id.ToLower() == t.tweet_id.ToString().ToLower()).ToList().ForEach(k => k.hierarchy = t.hierarchy);
                    //            }
                    //            catch (Exception ex)
                    //            {

                    //            }
                    //        }

                    //        lstTwitter_Data_V2_Sorted.OrderBy(x => SortCalc(x.hierarchy)).ToList();

                    //        for (int l = 1; l < lstTwitter_Data_V2_Sorted.Count; l++)
                    //        {
                    //            dynamic ootree_details = new JObject();
                    //            ootree_details.tweet_id = lstTwitter_Data_V2_Sorted[l].Twitter_ID.ToString();
                    //            ootree_details.twitter_id = Convert.ToString(lstTwitter_Data_V2_Sorted[l].tweet_id.ToString());
                    //            ootree_details.hierarchy = Convert.ToString(lstTwitter_Data_V2_Sorted[l].hierarchy);
                    //            ootree_details.text_of_tweet = Convert.ToString(lstTwitter_Data_V2_Sorted[l].text_of_tweet);
                    //            tcDetails.tree_details.Add(ootree_details);
                    //        }

                    //        o.prompts_variables.p_5_4.t2.Add(tcDetails);
                    //    }
                    //}

                    //p_5_4 End 
                    #endregion

                    #region p_5.5
                    //p_5.5 Start
                    o.prompts_variables.p_5_5 = new JObject();
                    o.prompts_variables.p_5_5.t2 = new JArray();

                    //dt = ds.Tables[13];
                    //dtCTDetails = ds.Tables[14];

                    //for (int i = 0; i < dt.Rows.Count; i++)
                    //{
                    //    dynamic tcDetails = new JObject();
                    //    tcDetails.Add("tcid", Convert.ToString(dt.Rows[i]["tcid"]));
                    //    tcDetails.Add("ct_id", Convert.ToString(dt.Rows[i]["Tweet_ConversationID"]));
                    //    tcDetails.tree_details = new JArray();

                    //    List<eTwitter_Summary> lstTwitter_Data_V2 = new List<eTwitter_Summary>();

                    //    eTwitter_Summary oParent = new eTwitter_Summary();
                    //    oParent.Input = Convert.ToString(dt.Rows[i]["Tweet_ConversationID"]);
                    //    oParent.tweet_id = Convert.ToString(dt.Rows[i]["Tweet_ConversationID"]);
                    //    lstTwitter_Data_V2.Add(oParent);

                    //    DataTable dtdtCTDetailsFiltered = new DataTable();

                    //    dtdtCTDetailsFiltered = dtCTDetails.Select("Tweet_ConversationID = " + Convert.ToString(dt.Rows[i]["Tweet_ConversationID"])).CopyToDataTable();

                    //    for (int j = 0; j < dtdtCTDetailsFiltered.Rows.Count; j++)
                    //    {
                    //        eTwitter_Summary objeTwitter_Summary = new eTwitter_Summary();
                    //        objeTwitter_Summary.text_of_tweet = Convert.ToString(dtdtCTDetailsFiltered.Rows[j]["Tweet_Text"]);
                    //        objeTwitter_Summary.tweet_id = Convert.ToString(dtdtCTDetailsFiltered.Rows[j]["Tweet_ID"]);
                    //        objeTwitter_Summary.Tweet_RepliedToTweetID = Convert.ToString(dtdtCTDetailsFiltered.Rows[j]["Tweet_RepliedToTweetID"]);
                    //        objeTwitter_Summary.Twitter_ID = Convert.ToInt32(dtdtCTDetailsFiltered.Rows[j]["TwitterID"]);
                    //        objeTwitter_Summary.url = Convert.ToString(dtdtCTDetailsFiltered.Rows[j]["Tweet_Url"]);
                    //        objeTwitter_Summary.t2 = Convert.ToString(dtdtCTDetailsFiltered.Rows[j]["t2"]);
                    //        lstTwitter_Data_V2.Add(objeTwitter_Summary);
                    //    }

                    //    if (lstTwitter_Data_V2.Count > 1)
                    //    {
                    //        List<eTwitter_Summary> lstTwitter_Data_V2_Sorted = lstTwitter_Data_V2.OrderBy(oo => Convert.ToInt64(oo.tweet_id)).ToList();

                    //        List<eTwitter_Summary> lstTwitter_Data_V2VM = new List<eTwitter_Summary>();
                    //        GetHierachicalList(lstTwitter_Data_V2_Sorted, lstTwitter_Data_V2VM, null, "");


                    //        foreach (eTwitter_Summary t in lstTwitter_Data_V2VM)
                    //        {
                    //            try
                    //            {
                    //                lstTwitter_Data_V2_Sorted.Where(w => w.tweet_id.ToLower() == t.tweet_id.ToString().ToLower()).ToList().ForEach(k => k.hierarchy = t.hierarchy);
                    //            }
                    //            catch (Exception ex)
                    //            {

                    //            }
                    //        }

                    //        lstTwitter_Data_V2_Sorted.OrderBy(x => SortCalc(x.hierarchy)).ToList();

                    //        for (int l = 1; l < lstTwitter_Data_V2_Sorted.Count; l++)
                    //        {
                    //            if (lstTwitter_Data_V2_Sorted[l].t2 == "1")
                    //            {
                    //                dynamic ootree_details = new JObject();
                    //                ootree_details.tweet_id = lstTwitter_Data_V2_Sorted[l].Twitter_ID.ToString();
                    //                ootree_details.twitter_id = Convert.ToString(lstTwitter_Data_V2_Sorted[l].tweet_id.ToString());
                    //                ootree_details.hierarchy = Convert.ToString(lstTwitter_Data_V2_Sorted[l].hierarchy);
                    //                ootree_details.text_of_tweet = Convert.ToString(lstTwitter_Data_V2_Sorted[l].text_of_tweet);
                    //                tcDetails.tree_details.Add(ootree_details);
                    //            }
                    //        }

                    //        o.prompts_variables.p_5_5.t2.Add(tcDetails);
                    //    }
                    //}

                    //p_5_5 End 
                    #endregion

                    //prompts_variables End

                    json.data = o;
                }

                //TimeLog("JSON End");
                #endregion

                //result = File.ReadAllText(ConfigurationManager.AppSettings["FetchLanding_OnlineArticle"]);
                //TimeLog("SerializeObject start");
                var setting = new JsonSerializerSettings
                {
                    MaxDepth = int.MaxValue
                };
                Result = JsonConvert.SerializeObject(json, setting);
            }
            catch (Exception ex)
            {

            }

            return Result;
        }

        public string FetchData_Overall(string Json)
        {
            string strOutput = string.Empty;

            try
            {
                string strFinalURL = string.Empty;
                string strURL_Service = ConfigurationManager.AppSettings["Url_Overall_Landing"].ToString();


                if (!String.IsNullOrEmpty(strURL_Service))
                {
                    //Create bytes array to send Input as parameter
                    byte[] bytes = bytes = Encoding.UTF8.GetBytes(Json.ToCharArray());//System.Text.Encoding.GetEncoding("ISO-8859-1").GetBytes(strParameters);

                    HttpWebRequest request = (HttpWebRequest)WebRequest.Create(strURL_Service);
                    request.Timeout = Convert.ToInt32(ConfigurationManager.AppSettings["TimeOutIntervalForOperation"]);
                    request.ContentType = "application/json; charset=utf8";
                    request.ContentLength = bytes.Length;
                    request.Method = "POST";

                    //Upload bytes array to request
                    using (Stream os = request.GetRequestStream())
                    {
                        os.Write(bytes, 0, bytes.Length);
                    }

                    //Get response from TextProcessingPipeline
                    using (System.Net.WebResponse resp = request.GetResponse())
                    {
                        using (StreamReader sr = new StreamReader(resp.GetResponseStream()))
                        {
                            strOutput = sr.ReadToEnd().Trim();
                            if (!String.IsNullOrEmpty(strOutput))
                            {
                                Console.WriteLine("strOutput is " + strOutput);
                                string strSummary = string.Empty;
                                dynamic stuff = JObject.Parse(strOutput);
                                strSummary = stuff.landing_summary;
                                dynamic json = new JObject();
                                string[] lines = strSummary.Split(new string[] { "\r\n", "\r", "\n" }, StringSplitOptions.None);
                                json = new JObject();
                                json.status = "200";
                                json.message = "Success";
                                json.data = new JObject();
                                dynamic o = new JObject();
                                o.key_highlights_data = new JArray();
                                json.data = o;

                                for (int i = 0; i < lines.Length; i++)
                                {
                                    //'text' as type,value as excerpt,'' as link,'false' as clickable
                                    dynamic oo = new JObject();
                                    oo.type = "text";

                                    oo.excerpt = lines[i].ToString();
                                    if (String.IsNullOrEmpty(lines[i].ToString()))
                                    {
                                        continue;
                                    }
                                    oo.link = string.Empty;
                                    oo.clickable = "false";

                                    o.key_highlights_data.Add(oo);
                                }

                                strOutput = Convert.ToString(json);
                            }
                        }
                    }

                    request = null;
                }
            }
            catch (Exception ex)
            {

            }

            return strOutput;
        }

        public string FetchData_YouTube(string Json, string strPeakSummary, bool IsIntent = false)
        {
            string strOutput = string.Empty;

            try
            {
                string strFinalURL = string.Empty;
                string strURL_Service = ConfigurationManager.AppSettings["Url_YouTube_Landing"].ToString();


                if (!String.IsNullOrEmpty(strURL_Service))
                {
                    //Create bytes array to send Input as parameter
                    byte[] bytes = bytes = Encoding.UTF8.GetBytes(Json.ToCharArray());//System.Text.Encoding.GetEncoding("ISO-8859-1").GetBytes(strParameters);

                    HttpWebRequest request = (HttpWebRequest)WebRequest.Create(strURL_Service);
                    request.Timeout = Convert.ToInt32(ConfigurationManager.AppSettings["TimeOutIntervalForOperation"]);
                    request.ContentType = "application/json; charset=utf8";
                    request.ContentLength = bytes.Length;
                    request.Method = "POST";

                    //Upload bytes array to request
                    using (Stream os = request.GetRequestStream())
                    {
                        os.Write(bytes, 0, bytes.Length);
                    }

                    //Get response from TextProcessingPipeline
                    using (System.Net.WebResponse resp = request.GetResponse())
                    {
                        using (StreamReader sr = new StreamReader(resp.GetResponseStream()))
                        {
                            strOutput = sr.ReadToEnd().Trim();
                            
                            if (!String.IsNullOrEmpty(strOutput))
                            {
                                Console.WriteLine("strOutput is " + strOutput);
                                string strSummary = string.Empty;
                                dynamic stuff = JObject.Parse(strOutput);
                                if (IsIntent == true)
                                {
                                    strSummary = stuff.summary;
                                }
                                else
                                {
                                    strSummary = stuff.landing_summary;
                                }
                                dynamic json = new JObject();
                                string[] lines = strSummary.Split(new string[] { "\r\n", "\r", "\n" }, StringSplitOptions.None);
                                json = new JObject();
                                json.status = "200";
                                json.message = "Success";
                                json.data = new JObject();
                                dynamic o = new JObject();
                                o.key_highlights_data = new JArray();
                                json.data = o;

                                if (IsIntent == true)
                                {
                                    dynamic oo = new JObject();
                                    oo.type = "text";

                                    oo.excerpt = "THIS IS INTENT DRIVEN SUMMARY";
                                    oo.link = string.Empty;
                                    oo.clickable = "false";

                                    //o.key_highlights_data.Add(oo);
                                }

                                for (int i = 0; i < lines.Length; i++)
                                {
                                    //'text' as type,value as excerpt,'' as link,'false' as clickable
                                    dynamic oo = new JObject();
                                    oo.type = "text";

                                    oo.excerpt = lines[i].ToString();
                                    if (String.IsNullOrEmpty(lines[i].ToString()))
                                    {
                                        continue;
                                    }
                                    oo.link = string.Empty;
                                    oo.clickable = "false";

                                    o.key_highlights_data.Add(oo);
                                }

                                if (!String.IsNullOrEmpty(strPeakSummary))
                                {
                                    dynamic oo = new JObject();
                                    oo.type = "text";

                                    //oo.excerpt ="Peak Summary :" + strPeakSummary;
                                    oo.excerpt = strPeakSummary;
                                    oo.link = string.Empty;
                                    oo.clickable = "false";

                                    o.key_highlights_data.Add(oo);
                                }


                                strOutput = Convert.ToString(json);
                            }

                        }
                    }

                    request = null;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return strOutput;
        }




        public string FetchData_PeakSummarization(string Json)
        {
            string strOutput = string.Empty;

            try
            {
                string strFinalURL = string.Empty;
                string strURL_Service = ConfigurationManager.AppSettings["Url_PeakSummarization"].ToString();


                if (!String.IsNullOrEmpty(strURL_Service))
                {
                    //Create bytes array to send Input as parameter
                    byte[] bytes = bytes = Encoding.UTF8.GetBytes(Json.ToCharArray());//System.Text.Encoding.GetEncoding("ISO-8859-1").GetBytes(strParameters);

                    HttpWebRequest request = (HttpWebRequest)WebRequest.Create(strURL_Service);
                    request.Timeout = Convert.ToInt32(ConfigurationManager.AppSettings["TimeOutIntervalForOperation"]);
                    request.ContentType = "application/json; charset=utf8";
                    request.ContentLength = bytes.Length;
                    request.Method = "POST";

                    //Upload bytes array to request
                    using (Stream os = request.GetRequestStream())
                    {
                        os.Write(bytes, 0, bytes.Length);
                    }

                    //Get response from TextProcessingPipeline
                    using (System.Net.WebResponse resp = request.GetResponse())
                    {
                        using (StreamReader sr = new StreamReader(resp.GetResponseStream()))
                        {
                            strOutput = sr.ReadToEnd().Trim();
                            if (!String.IsNullOrEmpty(strOutput))
                            {
                                Console.WriteLine("strOutput is " + strOutput);
                                string strSummary = string.Empty;
                                dynamic stuff = JObject.Parse(strOutput);
                                strSummary = stuff.short_summary;
                                strOutput = strSummary;
                            }

                        }
                    }

                    request = null;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return strOutput;
        }


        private void Log(string functionName, string error)
        {
            try
            {
                if (ConfigurationManager.AppSettings["IsLogActive"].ToString() == "1")
                {
                    string LogPath = ConfigurationManager.AppSettings["LogPath"].ToString();
                    using (TextWriter myWriter = File.AppendText(LogPath))
                    {

                        TextWriter.Synchronized(myWriter).WriteLine("<--> :{0}", string.Empty);
                        TextWriter.Synchronized(myWriter).WriteLine("Function Name :{0}", functionName);
                        TextWriter.Synchronized(myWriter).WriteLine("Error :{0}", error);
                        TextWriter.Synchronized(myWriter).WriteLine("Date :{0}", DateTime.Now.ToString());
                        TextWriter.Synchronized(myWriter).WriteLine("<--> :{0}", string.Empty);
                        TextWriter.Synchronized(myWriter).Flush();
                        TextWriter.Synchronized(myWriter).Close();
                    }
                }
            }
            catch (Exception ex)
            {
            }
        }

    }

}