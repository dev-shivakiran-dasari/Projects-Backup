﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace Sahadeva.Listeners.Entities
{
    public class eArticle_Online
    {
        #region PK & Ref Ids
        [DataMember]
        public Int32 ArticleID { get; set; }

        [DataMember]
        public Int32 EQID { get; set; }

        [DataMember]
        public Int32 EntityID { get; set; }

        [DataMember]
        public Int32 NextPage { get; set; }
        #endregion

        #region Contify
        [DataMember]
        public string Url { get; set; }

        [DataMember]
        public string Title { get; set; }

        [DataMember]
        public string Text { get; set; }

        [DataMember]
        public DateTime Date { get; set; }

        [DataMember]
        public string Publication { get; set; }

        [DataMember]
        public string Publication_Url { get; set; }

        #endregion

        #region Diffbot
        [DataMember]
        public string DB_Text { get; set; }

        [DataMember]
        public DateTime DB_Date { get; set; }

        [DataMember]
        public string DB_Html { get; set; }

        [DataMember]
        public string DB_Title { get; set; }

        [DataMember]
        public string DB_Author { get; set; }

        [DataMember]
        public string DB_SiteName { get; set; }

        [DataMember]
        public string DB_AuthorUrl { get; set; }

        [DataMember]
        public string DB_PublisherRegion { get; set; }

        [DataMember]
        public string DB_PublisherCountry { get; set; }

        [DataMember]
        public decimal DB_Sentiment { get; set; }

        [DataMember]
        public string DB_Tags { get; set; }

        [DataMember]
        public string DB_TagLabel1 { get; set; }

        [DataMember]
        public decimal DB_TagScore1 { get; set; }

        [DataMember]
        public Int32 DB_TagCount1 { get; set; }

        [DataMember]
        public string DB_TagLabel2 { get; set; }

        [DataMember]
        public decimal DB_TagScore2 { get; set; }

        [DataMember]
        public Int32 DB_TagCount2 { get; set; }

        [DataMember]
        public string DB_TagLabel3 { get; set; }

        [DataMember]
        public decimal DB_TagScore3 { get; set; }

        [DataMember]
        public Int32 DB_TagCount3 { get; set; }

        [DataMember]
        public string DB_TagLabel4 { get; set; }

        [DataMember]
        public decimal DB_TagScore4 { get; set; }

        [DataMember]
        public Int32 DB_TagCount4 { get; set; }

        [DataMember]
        public string DB_TagLabel5 { get; set; }

        [DataMember]
        public decimal DB_TagScore5 { get; set; }

        [DataMember]
        public Int32 DB_TagCount5 { get; set; }

        [DataMember]
        public string DB_Language { get; set; }

        [DataMember]
        public string DB_Images { get; set; }

        [DataMember]
        public string ErrorCode { get; set; }

        [DataMember]
        public string Error { get; set; }

        [DataMember]
        public string Output { get; set; }
        #endregion
    }
}
