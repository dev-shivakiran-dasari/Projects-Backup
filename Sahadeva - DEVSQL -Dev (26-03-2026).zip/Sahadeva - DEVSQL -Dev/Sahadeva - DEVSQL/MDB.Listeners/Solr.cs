﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Configuration;
using System.IO;
using MDB.Entities;
using Newtonsoft.Json.Linq;
using System.Globalization;
using System.Diagnostics;
using System.Threading.Tasks;
using System.Net;
using System.Reflection;
using SolrNet.Utils;
using System.Text.RegularExpressions;
using Newtonsoft.Json;
using SolrNet;
using Microsoft.Practices.ServiceLocation;
using SolrNet.Commands.Parameters;
using System.Xml;

namespace MDB.Listeners
{
    public class Solr
    {
        #region Solr

        public static ISolrOperations<eSolrArticle> solrBoilerPipe = null;

        public void Process(List<eEntityQuery> lstQueries)
        {
            try
            {
                TimeLog("Start Solr Process");
                Startup.Init<eSolrArticle>(ConfigurationManager.AppSettings["nutch-enriched-articles"]);
                solrBoilerPipe = ServiceLocator.Current.GetInstance<ISolrOperations<eSolrArticle>>();

                #region Creating And Setting ParallelOptions
                var stopWatch = Stopwatch.StartNew();
                ParallelOptions po = new ParallelOptions();
                po.MaxDegreeOfParallelism = Convert.ToInt32(ConfigurationManager.AppSettings["Solr_MaxDegreeOfParallelism"].ToString());
                System.Net.ServicePointManager.DefaultConnectionLimit = Convert.ToInt32(ConfigurationManager.AppSettings["Solr_MaxDegreeOfParallelism"].ToString());
                #endregion

                Parallel.For(0, lstQueries.Count, po, i =>
                {
                    try
                    {
                        eLog oLog = new eLog();
                        oLog.GUID = Guid.NewGuid().ToString();

                        List<eArticle_Online> lstLogRecords_Final = new List<eArticle_Online>();

                        #region FetchAndExtractFromSolr
                        TimeLog("Start FetchAndExtractFromSolr");
                        List<eArticle_Online> lstArticles = FetchAndExtractFromSolr(lstQueries[i]);
                        lstLogRecords_Final = lstArticles;
                        TimeLog("Articles Count From Solr Is " + lstArticles.Count);
                        TimeLog("End FetchAndExtractFromSolr");
                        #endregion

                        #region Check Duplicates In ArticleOnline
                        TimeLog("Start Check Duplicates In ArticleOnline");
                        string strHashUrls = string.Join(",", lstArticles.Select(x => x.HashUrl));
                        List<string> lstOriginalUrls = new DAL.DAL().CheckDuplicate_ArticleOnline(lstQueries[i].EntityID, lstQueries[i].TopicID, strHashUrls);
                        lstArticles.RemoveAll(t => lstOriginalUrls.Contains(t.HashUrl));

                        //if (lstOriginalUrls.Count > 0)
                        //{
                        //    for (int t = 0; t < lstOriginalUrls.Count; t++)
                        //    {
                        //        lstLogRecords_Final.Where(w => w.HashUrl == lstOriginalUrls[t].ToString()).ToList().ForEach(z => z.LogComment = "Removed Due To Exists In DB");
                        //    }
                        //}

                        TimeLog("OriginalUrls count Is " + lstArticles.Count);
                        TimeLog("End Check Duplicates In ArticleOnline");
                        #endregion

                        List<eArticle_Online> lstlstArticles_Final = new List<eArticle_Online>();
                        lstlstArticles_Final = lstArticles;

                        if (ConfigurationManager.AppSettings["SolrRelevancy_Article"] == "1")
                        {
                            //lstlstArticles_Final = GetRelevantLinks(lstlstArticles_Final, lstQueries[i].Query, lstQueries[i].EQID, ref lstLogRecords_Final);
                            //TimeLog("After GetRelevantLinks count Is " + lstlstArticles_Final.Count);

                            if (lstlstArticles_Final.Count > 0)
                            {
                                lstlstArticles_Final = GetRelevantLinks_ParaAndRest(lstlstArticles_Final, lstQueries[i].Query, lstQueries[i].EQID, "title");
                                lstlstArticles_Final = GetRelevantLinks_ParaAndRest(lstlstArticles_Final, lstQueries[i].Query, lstQueries[i].EQID, "firstpara");
                                lstlstArticles_Final = GetRelevantLinks_ParaAndRest(lstlstArticles_Final, lstQueries[i].Query, lstQueries[i].EQID, "restofarticle");
                            }
                        }

                        //if (lstQueries[i].AppName == "Dossier")
                        //{
                        //    #region Process_Images
                        //    TimeLog("Start Process_Images");
                        //    lstlstArticles_Final = Process_Images(lstlstArticles_Final);
                        //    TimeLog("End Process_Images");
                        //    #endregion
                        //}

                        #region Insert Articles
                        TimeLog("Start InsertArticles");
                        bool IsSuccessful = InsertArticles(lstlstArticles_Final, ref lstLogRecords_Final);
                        TimeLog("End InsertArticles");
                        #endregion

                        //if (ConfigurationManager.AppSettings["IsArticleOnlineLog"] == "1")
                        //{
                        //    string strLog = string.Empty;
                        //    for (int z = 0; z < lstLogRecords_Final.Count; z++)
                        //    {
                        //        strLog = strLog + lstLogRecords_Final[z].SERPTab + "," + lstLogRecords_Final[z].Url + "," + lstLogRecords_Final[z].LogComment;
                        //        strLog = strLog + Environment.NewLine;

                        //        try
                        //        {
                        //            new MDB.DAL.DAL().InsertArticle_Log(oLog.GUID, lstLogRecords_Final[z]);
                        //        }
                        //        catch (Exception exm)
                        //        {
                        //            ErrorLog("lstLogRecords_Final Loop Error for " + lstLogRecords_Final[z].Url, exm.ToString());
                        //        }
                        //    }
                        //    TimeLog(strLog);
                        //}

                    }
                    catch (Exception ex)
                    {
                        ErrorLog("Parallel Error for " + lstQueries[i].Query, ex.ToString());
                    }

                });
                TimeLog("End Parallel.For");
                TimeLog("Parallel.For() execution time for " + " = {0} seconds:" + stopWatch.Elapsed.TotalSeconds);

            }
            catch (Exception ex)
            {
                ErrorLog("Process_Solr ", ex.Message + " ->> " + ex.StackTrace);
            }
        }

        public List<eArticle_Online> FetchAndExtractFromSolr(eEntityQuery objEQ)
        {
            List<eArticle_Online> lstFinal = new List<eArticle_Online>();

            try
            {
                TimeLog("Start FetchArticles Query Is " + objEQ.Query);
                DateTime FDate = DateTime.Now;
                Int32 NoOfHoursToSubstract = Convert.ToInt32(ConfigurationManager.AppSettings["Solr_NoOfHours"].ToString());

                if (objEQ.HistoryDate != DateTime.MinValue)
                {
                    if ((DateTime.Now - objEQ.HistoryDate).TotalHours > 0)
                    {
                        NoOfHoursToSubstract =Convert.ToInt32(Math.Round((DateTime.Now - objEQ.HistoryDate).TotalHours));
                    }
                }

                FDate = FDate.AddHours(-NoOfHoursToSubstract);

                lstFinal = FetchArticles(objEQ.Query, FDate, DateTime.Now.AddHours(5),objEQ);
                TimeLog("End FetchArticles Query Is " + objEQ.Query);

                TimeLog("FetchArticles Count Is " + lstFinal.Count.ToString());
            }
            catch (Exception ex)
            {
                ErrorLog("FetchAndExtractFromSolr", ex.ToString() + " Query Is " + objEQ.Query);
            }

            return lstFinal;
        }

        private List<eArticle_Online> FetchArticles(string keyword, DateTime from, DateTime to, eEntityQuery objEQ)
        {
            List<eSolrArticle> URLs = new List<eSolrArticle>();
            List<eArticle_Online> URLFinal = new List<eArticle_Online>();

            try
            {
                Int32 NoOfRows = Convert.ToInt32(ConfigurationManager.AppSettings["Solr_NoOfRows"]);

                if (objEQ.HistoryDate != DateTime.MinValue)
                {
                    NoOfRows = 2000;
                }

                SolrQueryResults<eSolrArticle> solrResults = null;
                string fromDate = Convert.ToDateTime(from.ToString("yyyy-MM-dd HH:mm tt")).ToString("yyyy'-'MM'-'dd'T'HH':'mm':'ss'.'fff'Z'");
                string toDate = Convert.ToDateTime(to.ToString("yyyy-MM-dd HH:mm tt")).ToString("yyyy'-'MM'-'dd'T'HH':'mm':'ss'.'fff'Z'");

                string solrKeyword = "(" + keyword + ")";

                string Query = "(EText:" + solrKeyword + " OR ETitle:" + solrKeyword + ") AND Date:[" + fromDate + " TO " + toDate + "]";

                TimeLog(Query);

                //solrResults = solrBoilerPipe.Query(Query, new QueryOptions { Start = 0, Rows = 10, OrderBy = new[] { new SolrNet.SortOrder("Date", Order.DESC) } });

                //solrResults = solrBoilerPipe.Query(Query,
                //    new QueryOptions
                //    {
                //        Start = 0,
                //        Rows = solrResults.NumFound,
                //        OrderBy = new[] { new SolrNet.SortOrder("Date", Order.DESC) },
                //        ExtraParams = new KeyValuePair<string, string>[] { new KeyValuePair<string, string>("wt", "xml") }
                //    });

                URLs = solrBoilerPipe.Query(Query,
                    new QueryOptions
                    {
                        Start = 0,
                        Rows = NoOfRows,
                        OrderBy = new[] { new SolrNet.SortOrder("timestamp", Order.DESC) },
                        ExtraParams = new KeyValuePair<string, string>[] { new KeyValuePair<string, string>("wt", "xml") }
                    });

                string a = "";
                //URLs = (List<eSolrArticle>)solrResults;

                for (int i = 0; i < URLs.Count; i++)
                {
                    eArticle_Online Article = new eArticle_Online();
                    Article.EntityID = objEQ.EntityID;
                    Article.EQID = objEQ.EQID;
                    Article.TopicID = objEQ.TopicID;
                    Article.ServiceID = 8;
                    Article.SERPTab = "Solr";
                    Article.Url = URLs[i].Url;

                    if (!String.IsNullOrEmpty(Article.Url))
                    {
                        string strUrl = Article.Url.Replace("https://", "").Replace("http://", "");
                        Article.HashUrl = CalculateHash(strUrl);
                        Article.Publication_Url = ExtractDomainame(Article.Url);
                    }

                    Article.DB_Author = URLs[i].Author;
                    Article.DB_AuthorUrl = URLs[i].AuthorUrl;
                    //Article.Boost = solrResults[i].Boost;
                    Article.DB_Date = URLs[i].Date;
                    Article.Date = URLs[i].Date;
                    try
                    {

                        if (Article.DB_Date.Year <= 1900 || Article.DB_Date.Year >= 2050)
                        {
                            Article.DB_Date = DateTime.Now;
                        }
                    }
                    catch (Exception exxx)
                    {
                        Article.DB_Date = DateTime.Now;
                    }

                    //Article.Digest = solrResults[i].Digest;
                    //Article.DocumentID = solrResults[i].DocumentID;
                    Article.DB_Language = URLs[i].Language;
                    //Article.metatag_description = solrResults[i].metatag_description;
                    //Article.metatag_keywords = solrResults[i].metatag_keywords;
                    Article.DB_PublisherCountry = URLs[i].PublisherCountry;
                    Article.DB_PublisherRegion = URLs[i].PublisherRegion;
                    //Article.Segment = solrResults[i].Segment;
                    Article.DB_SiteName = URLs[i].SiteName;
                    //Article.DB_TagCount1 = solrResults[i].TagCount1;
                    //Article.DB_TagCount2 = solrResults[i].TagCount2;
                    //Article.DB_TagCount3 = solrResults[i].TagCount3;
                    //Article.DB_TagCount4 = solrResults[i].TagCount4;
                    //Article.DB_TagCount5 = solrResults[i].TagCount5;
                    Article.DB_TagLabel1 = URLs[i].TagLabel1;
                    Article.DB_TagLabel2 = URLs[i].TagLabel2;
                    Article.DB_TagLabel3 = URLs[i].TagLabel3;
                    Article.DB_TagLabel4 = URLs[i].TagLabel4;
                    Article.DB_TagLabel5 = URLs[i].TagLabel5;
                    //o.Tags = solrResults[i].Tags;
                    Article.DB_TagScore1 = URLs[i].TagScore1;
                    Article.DB_TagScore2 = URLs[i].TagScore2;
                    Article.DB_TagScore3 = URLs[i].TagScore3;
                    Article.DB_TagScore4 = URLs[i].TagScore4;
                    Article.DB_TagScore5 = URLs[i].TagScore5;
                    Article.DB_Text = URLs[i].Text;
                    Article.DB_Title = URLs[i].Title;
                    Article.Text = URLs[i].Text;
                    Article.Title = URLs[i].Title;

                    Article.DB_Images = URLs[i].Images;
                    //o.Version = solrResults[i].Version;

                    List<string> lstReturn = GetDetailText(URLs[i].Text);
                    Article.FirstParaForRelevancy = lstReturn[0];
                    Article.RestOfArticleForRelevancy = lstReturn[1];

                    URLFinal.Add(Article);
                }

            }
            catch (Exception ex)
            {
                ErrorLog("FetchArticles", ex.Message + " ->> " + ex.StackTrace);
            }

            return URLFinal;
        }

        #endregion

        #region Relevancy

        public List<eArticle_Online> GetRelevantLinks(List<eArticle_Online> lstLinks, string strQuery, Int32 strQueryID, ref List<eArticle_Online> lstLogRecords_Final)
        {
            List<eArticle_Online> lstFinal = new List<eArticle_Online>();

            try
            {
                string strOutput = string.Empty;
                //Create Input File For Relevancy And Get Relevant Links And Then Run ForEach
                TimeLog("ConstructInputForRelevancy Started For " + strQuery);
                XmlDocument inputxmlForRelevancy = ConstructInputForRelevancy(lstLinks, "fullArticle");
                TimeLog("ConstructInputForRelevancy Ended For " + strQuery);

                if (lstLinks.Count > 0)
                {
                    TimeLog("Total links are " + lstLinks.Count);

                    RelevancyChecker objRC = new RelevancyChecker();
                    Guid BatchID = Guid.NewGuid();

                    TimeLog("Get Relevant Links Started For " + strQuery);
                    strOutput = objRC.MainFunc(inputxmlForRelevancy.InnerXml.ToString(), strQuery, BatchID.ToString() + ConfigurationManager.AppSettings["SolrRelevancy_BatchType"], "SENTRY-News");
                    if (strOutput == string.Empty)
                    {
                        ErrorLog("Problem In Relevancy Pipe", "Problem In Relevancy Pipe");
                    }

                    TimeLog("Get Relevant Links Ended For " + strQuery);

                    XmlDocument docWAR = new XmlDocument();
                    if (!String.IsNullOrEmpty(strOutput))
                    {
                        docWAR.LoadXml(strOutput);
                    }


                    foreach (eArticle_Online feed in lstLinks)
                    {
                        try
                        {
                            String HashID = feed.HashUrl;
                            bool foundLink = false;
                            XmlNode nds = docWAR.SelectSingleNode("/RelevancyRequest/Output");
                            XmlNode nd = nds.SelectSingleNode("params[ID='" + HashID + "']");
                            if (nd != null)
                            {
                                foundLink = true;
                            }

                            if (foundLink)
                            {
                                lstFinal.Add(feed);
                                lstLogRecords_Final.Where(w => w.HashUrl == feed.HashUrl).ToList().ForEach(z => z.LogComment = "Solr Found Relevant");
                            }
                            else
                            {
                                lstLogRecords_Final.Where(w => w.HashUrl == feed.HashUrl).ToList().ForEach(z => z.LogComment = "Solr Found Not Relevant");
                            }
                        }
                        catch (Exception ex)
                        {
                            ErrorLog("For Loop  " + feed.Url, ex.Message + " ->> " + ex.StackTrace);
                        }
                    }

                    TimeLog("Relevant links are " + lstFinal.Count);
                }
            }
            catch (Exception ex)
            {
                ErrorLog("GetRelevantLinks ", ex.Message + " ->> " + ex.StackTrace);
            }

            return lstFinal;
        }

        private XmlDocument ConstructInputForRelevancy(List<eArticle_Online> objFeeds, string strType)
        {
            XmlDocument inputXML = new XmlDocument();

            try
            {
                string xmlFilePath = ConfigurationManager.AppSettings["InputXMLForRelevancy"].ToString();
                inputXML.Load(xmlFilePath);

                XmlNode nodeRequest = inputXML.SelectSingleNode("/RelevancyRequest/BatchID");
                nodeRequest.InnerText = Guid.NewGuid().ToString();

                XmlNode nodeParameters = inputXML.SelectSingleNode("/RelevancyRequest/Input/Parameters");

                foreach (eArticle_Online node in objFeeds)
                {
                    try
                    {
                        if (!String.IsNullOrEmpty(node.Url))
                        {
                            string hashID = node.HashUrl;
                            string URL = node.Url;

                            XmlNode nodeParams = inputXML.CreateElement("Params");
                            nodeParameters.AppendChild(nodeParams);

                            XmlNode attrLink = inputXML.CreateElement("Link");
                            attrLink.InnerText = URL;
                            nodeParams.AppendChild(attrLink);

                            XmlNode attrHashID = inputXML.CreateElement("HashID");
                            attrHashID.InnerText = hashID;
                            nodeParams.AppendChild(attrHashID);

                            XmlNode attrNoiseCancelledContent = inputXML.CreateElement("NoiseCancelledContent");
                            string strNoiseCancelledContent = string.Empty;


                            if (strType == "fullArticle")
                            {
                                TimeLog("node.DB_Title -> " + node.DB_Title + " || node.DB_Text -> " + node.DB_Text + " || node.ADID -> " + node.ADID + " || URL -> " + URL);

                                if (!String.IsNullOrEmpty(node.DB_Title))
                                {
                                    strNoiseCancelledContent = strNoiseCancelledContent + node.DB_Title;
                                }
                                else
                                {
                                    //strNoiseCancelledContent = strNoiseCancelledContent + node.Title;
                                    ErrorLog("node.DB_Title Is Empty ", node.ADID + " -> " + URL);

                                }

                                if (!String.IsNullOrEmpty(node.DB_Text))
                                {
                                    strNoiseCancelledContent = strNoiseCancelledContent + " " + node.DB_Text;
                                }
                                else
                                {
                                    //strNoiseCancelledContent = strNoiseCancelledContent + node.Text;
                                    ErrorLog("node.DB_Text Is Empty ", node.ADID + " -> " + URL);
                                }
                            }
                            else if (strType == "firstpara")
                            {
                                if (!String.IsNullOrEmpty(node.FirstParaForRelevancy))
                                {
                                    strNoiseCancelledContent = strNoiseCancelledContent + node.FirstParaForRelevancy;
                                }
                                else
                                {
                                    //strNoiseCancelledContent = strNoiseCancelledContent + node.Title;
                                    ErrorLog("node.FirstParaForRelevancy Is Empty ", node.ADID + " -> " + URL);

                                }
                            }
                            else if (strType == "restofarticle")
                            {
                                if (!String.IsNullOrEmpty(node.RestOfArticleForRelevancy))
                                {
                                    strNoiseCancelledContent = strNoiseCancelledContent + node.RestOfArticleForRelevancy;
                                }
                                else
                                {
                                    //strNoiseCancelledContent = strNoiseCancelledContent + node.Title;
                                    ErrorLog("node.RestOfArticleForRelevancy Is Empty ", node.ADID + " -> " + URL);

                                }
                            }
                            else if (strType == "title")
                            {
                                if (!String.IsNullOrEmpty(node.DB_Title))
                                {
                                    strNoiseCancelledContent = strNoiseCancelledContent + node.DB_Title;
                                }
                                else
                                {
                                    //strNoiseCancelledContent = strNoiseCancelledContent + node.Title;
                                    ErrorLog("node.DB_Title Is Empty ", node.ADID + " -> " + URL);

                                }
                            }
                            attrNoiseCancelledContent.InnerText = strNoiseCancelledContent;
                            nodeParams.AppendChild(attrNoiseCancelledContent);
                        }
                    }
                    catch (Exception ex)
                    {
                        ErrorLog("ConstructInputForRelevancy For Loop ", ex.Message + " ->> " + ex.StackTrace);
                    }

                }

            }
            catch (Exception ex)
            {
                ErrorLog("ConstructInputForRelevancy ", ex.Message + " ->> " + ex.StackTrace);
            }

            return inputXML;
        }

        public List<eArticle_Online> GetRelevantLinks_ParaAndRest(List<eArticle_Online> lstLinks, string strQuery, Int32 strQueryID, string strType)
        {
            try
            {
                string strOutput = string.Empty;
                //Create Input File For Relevancy And Get Relevant Links And Then Run ForEach
                TimeLog("ConstructInputForRelevancy Started For " + strQuery);
                XmlDocument inputxmlForRelevancy = ConstructInputForRelevancy(lstLinks, strType);
                TimeLog("ConstructInputForRelevancy Ended For " + strQuery);

                if (lstLinks.Count > 0)
                {
                    TimeLog("Total links are " + lstLinks.Count);

                    RelevancyChecker objRC = new RelevancyChecker();
                    Guid BatchID = Guid.NewGuid();

                    TimeLog("Get Relevant Links Started For " + strQuery);
                    strOutput = objRC.MainFunc(inputxmlForRelevancy.InnerXml.ToString(), strQuery, BatchID.ToString() + ConfigurationManager.AppSettings["SolrRelevancy_BatchType"], "SENTRY-News");
                    if (strOutput == string.Empty)
                    {
                        ErrorLog("Problem In Relevancy Pipe", "Problem In Relevancy Pipe");
                    }

                    TimeLog("Get Relevant Links Ended For " + strQuery);

                    XmlDocument docWAR = new XmlDocument();
                    if (!String.IsNullOrEmpty(strOutput))
                    {
                        docWAR.LoadXml(strOutput);
                    }


                    foreach (eArticle_Online feed in lstLinks)
                    {
                        try
                        {
                            String HashID = feed.HashUrl;
                            bool foundLink = false;
                            XmlNode nds = docWAR.SelectSingleNode("/RelevancyRequest/Output");
                            XmlNode nd = nds.SelectSingleNode("params[ID='" + HashID + "']");
                            if (nd != null)
                            {
                                foundLink = true;
                            }

                            if (foundLink)
                            {
                                if (strType == "title")
                                {
                                    lstLinks.Where(w => w.HashUrl == feed.HashUrl).ToList().ForEach(z => z.Is_Relevant_Headline = "Yes");
                                }
                                else if (strType == "firstpara")
                                {
                                    lstLinks.Where(w => w.HashUrl == feed.HashUrl).ToList().ForEach(z => z.Is_Relevant_FirstPara = "Yes");
                                }
                                else if (strType == "restofarticle")
                                {
                                    lstLinks.Where(w => w.HashUrl == feed.HashUrl).ToList().ForEach(z => z.Is_Relevant_RestOfArticle = "Yes");
                                }
                            }
                            else
                            {
                                if (strType == "title")
                                {
                                    lstLinks.Where(w => w.HashUrl == feed.HashUrl).ToList().ForEach(z => z.Is_Relevant_Headline = "No");
                                }
                                else if (strType == "firstpara")
                                {
                                    lstLinks.Where(w => w.HashUrl == feed.HashUrl).ToList().ForEach(z => z.Is_Relevant_FirstPara = "No");
                                }
                                else if (strType == "restofarticle")
                                {
                                    lstLinks.Where(w => w.HashUrl == feed.HashUrl).ToList().ForEach(z => z.Is_Relevant_RestOfArticle = "No");
                                }
                            }
                        }
                        catch (Exception ex)
                        {
                            ErrorLog("For Loop  " + feed.Url, ex.Message + " ->> " + ex.StackTrace);
                        }
                    }

                }
            }
            catch (Exception ex)
            {
                ErrorLog("GetRelevantLinks_ParaAndRest", ex.Message + " ->> " + ex.StackTrace);
            }
            return lstLinks;
        }


        public List<string> GetDetailText(string strArticle)
        {
            List<string> lstreturn = new List<string>();
            try
            {
                //string strArticle = "They (Congress) claim to be running Mohabbat ki dukaan. But a journalist of our country was subjected to cruelty in the USA by Congress. A son of India was insulted in the USA. Those who claim to be champions of freedom of speech indulged in brutality,Modi, who became the first Prime Minister to visit Doda in 42 years, said.PM Modi said the manner in which the journalist was treated lowered India's prestige on American soil. He also said the word Constitution does not suit the Congress, attempting to turn the tables on the party which has repeatedly accused the BJP of subverting the Constitution.";
                string strFirstPara = string.Empty;
                string strRestOfArticle = string.Empty;
                if (!string.IsNullOrEmpty(strArticle))
                {
                    List<string> lstLines = strArticle.Split('.').ToList();

                    if (lstLines.Count > 1)
                    {
                        Int32 NoOfLinesToTake = Convert.ToInt32(Math.Ceiling((double)0.25 * lstLines.Count));

                        string[] lstFirstPara = new string[NoOfLinesToTake];
                        lstLines.CopyTo(0, lstFirstPara, 0, NoOfLinesToTake);
                        strFirstPara = string.Join(".", lstFirstPara);
                        lstreturn.Add(strFirstPara);

                        lstLines.RemoveRange(0, NoOfLinesToTake);
                        strRestOfArticle = string.Join(".", lstLines);
                        lstreturn.Add(strRestOfArticle);
                    }
                    else
                    {
                        lstreturn.Add(strArticle);
                        lstreturn.Add(strArticle);
                    }
                }
                else
                {
                    lstreturn.Add("");
                    lstreturn.Add("");
                }

            }
            catch (Exception ex)
            {
                lstreturn.Add(strArticle);
                lstreturn.Add(strArticle);

                ErrorLog("GetDetailText ", ex.Message + " ->> " + ex.StackTrace);
            }

            return lstreturn;
        }

       
        #endregion

        #region Images
        public List<eArticle_Online> Process_Images(List<eArticle_Online> lstLinks)
        {
            List<eArticle_Online> lstFinal = new List<eArticle_Online>();

            try
            {

                int counter = 0;
                var stopWatch = Stopwatch.StartNew();
                ParallelOptions po = new ParallelOptions();
                po.MaxDegreeOfParallelism = Convert.ToInt32(ConfigurationManager.AppSettings["Image_MaxDegreeOfParallelism"].ToString());
                System.Net.ServicePointManager.DefaultConnectionLimit = Convert.ToInt32(ConfigurationManager.AppSettings["Image_MaxDegreeOfParallelism"].ToString());

                Parallel.For(0, lstLinks.Count, po, i =>
                {
                    try
                    {
                        TimeLog("Start CreateImage");
                        lstLinks[i].Screenshot_FileName = CreateImage(lstLinks[i].Url, DateTime.Now.ToString("yyyyMMddHHmmssfff"));
                        lstFinal.Add(lstLinks[i]);
                        TimeLog("End CreateImage");
                        counter++;
                    }
                    catch (Exception ex)
                    {
                        ErrorLog("Parallel Error for " + lstLinks[i].Url, ex.ToString());
                    }

                });
                TimeLog("End Parallel.For");
                TimeLog("Parallel.For() execution time for " + " = {0} seconds:" + stopWatch.Elapsed.TotalSeconds);

            }
            catch (Exception ex)
            {
                ErrorLog("Process_Images ", ex.Message + " ->> " + ex.StackTrace);
            }

            return lstFinal;
        }

        private string CreateImage(string strUrl, string strFileName)
        {
            string strFileNameReturn = string.Empty;
            try
            {
                ServicePointManager.SecurityProtocol = (SecurityProtocolType)3072;
                //string strFetchurl = "https://api.urlbox.io/v1/4G9b0Mqi6yniUmhs/png?url=" + HttpUtility.UrlEncode(strUrl) + "&delay=6000";
                string strFetchurl = System.Configuration.ConfigurationManager.AppSettings["Screenshot_APIUrl"].Replace("&amp;", "&").Replace("myurl", HttpUtility.UrlEncode(strUrl));
                strFetchurl = strFetchurl.Replace("\r\n", "");

                TimeLog(strFetchurl);

                WebRequest request = WebRequest.Create(strFetchurl);

                //// Get the response. 
                WebResponse response = request.GetResponse();


                // Get the stream containing content returned by the server.
                Stream dataStream = response.GetResponseStream();
                System.Drawing.Image image = System.Drawing.Image.FromStream(dataStream);
                string strPath = System.Configuration.ConfigurationManager.AppSettings["ScreenshotSavePath_Online"] + strFileName + ".jpg";//ConfigurationManager.AppSettings["ScreenshotExtension"];
                image.Save(strPath);
                strFileNameReturn = strFileName + ".jpg";
            }
            catch (Exception ex)
            {
                ErrorLog("CreateImage", strUrl + " ->" + ex.ToString());
            }

            return strFileNameReturn;
        }
        #endregion

        #region INSERT

        public bool InsertArticles(List<eArticle_Online> lstLinks, ref List<eArticle_Online> lstLogRecords_Final)
        {
            bool IsSuccessful = true;
            try
            {
                for (int i = 0; i < lstLinks.Count; i++)
                {
                    try
                    {
                        TimeLog("Start InsertArticle");
                        new MDB.DAL.DAL().InsertArticle(lstLinks[i]);
                        TimeLog("End InsertArticle");
                        //lstLogRecords_Final.Where(w => w.HashUrl == lstLinks[i].HashUrl).ToList().ForEach(z => z.LogComment = "Inserted In DB");
                    }
                    catch (Exception ex)
                    {
                        IsSuccessful = false;
                        ErrorLog("For Loop Error for " + lstLinks[i].Url, ex.ToString());
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorLog("InsertArticles ", ex.Message + " ->> " + ex.StackTrace);
            }

            return IsSuccessful;
        }

        #endregion

        #region LOGGING

        //For error logging
        private void ErrorLog(string functionName, string error)
        {
            try
            {
                string LogPath = ConfigurationManager.AppSettings["Solr_ErrorLogPath"];
                using (TextWriter myWriter = File.AppendText(LogPath))
                {

                    TextWriter.Synchronized(myWriter).WriteLine("<--> :{0}", string.Empty);
                    TextWriter.Synchronized(myWriter).WriteLine("Function Name :{0}", functionName);
                    TextWriter.Synchronized(myWriter).WriteLine("Error :{0}", error);
                    TextWriter.Synchronized(myWriter).WriteLine("Date :{0}", DateTime.Now.ToString());
                    TextWriter.Synchronized(myWriter).WriteLine("<--> :{0}", string.Empty);
                    TextWriter.Synchronized(myWriter).Flush();
                    TextWriter.Synchronized(myWriter).Close();
                }
            }
            catch (Exception ex)
            {
            }
        }

        //For debugging purpose
        private void TimeLog(string strtext)
        {
            try
            {
                string LogPath = ConfigurationManager.AppSettings["Solr_TimeLogPath"];
                using (TextWriter myWriter = File.AppendText(LogPath))
                {

                    TextWriter.Synchronized(myWriter).WriteLine("<--> :{0}", string.Empty);
                    TextWriter.Synchronized(myWriter).WriteLine("TimeLog :{0}", strtext);
                    TextWriter.Synchronized(myWriter).WriteLine("Date :{0}", DateTime.Now.ToString());
                    TextWriter.Synchronized(myWriter).WriteLine("<--> :{0}", string.Empty);
                    TextWriter.Synchronized(myWriter).Flush();
                    TextWriter.Synchronized(myWriter).Close();
                }
            }
            catch (Exception ex)
            {
                ErrorLog("TimeLog", ex.ToString());
            }
        }

        #endregion

        #region EXTRA

        //ExtractDomainame
        private static string ExtractDomainame(string URL)
        {
            try
            {
                string strDomain = Regex.Replace(URL, @"^([a-zA-Z]+:\/\/)?([^\/]+)\/.*?$", "$2");
                strDomain = strDomain.ToLower();
                strDomain = strDomain.Replace("www.", "");
                return strDomain;

            }
            catch (Exception ex) { return ""; }
        }

        public string CalculateHash(string value)
        {
            try
            {
                var data = System.Text.Encoding.ASCII.GetBytes(value);
                data = System.Security.Cryptography.SHA256.Create().ComputeHash(data);
                return Convert.ToBase64String(data);
            }
            catch (Exception ex)
            {
                return Convert.ToBase64String(System.Text.Encoding.ASCII.GetBytes(string.Empty));
            }
        }
        #endregion
    }
}
