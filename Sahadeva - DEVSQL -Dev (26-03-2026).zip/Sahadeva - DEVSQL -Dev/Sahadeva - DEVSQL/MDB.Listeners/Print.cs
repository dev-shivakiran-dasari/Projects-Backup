﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Configuration;
using System.IO;
using MDB.Entities;
using Newtonsoft.Json.Linq;
using System.Globalization;
using System.Diagnostics;
using System.Threading.Tasks;
using System.Net;
using System.Reflection;
using SolrNet.Utils;
using System.Text.RegularExpressions;
using Newtonsoft.Json;
using SolrNet;
using Microsoft.Practices.ServiceLocation;
using SolrNet.Commands.Parameters;

namespace MDB.Listeners
{
    public class Print
    {
        public static ISolrOperations<ePrint_SolrArticle> solrBoilerPipe = null;

        #region Print

        public void Process(List<eEntityQuery> lstQueries)
        {
            try
            {
                //Startup.Init<ePrint_SolrArticle>(ConfigurationManager.AppSettings["Solr_PrintCore"]);

                var stopWatch = Stopwatch.StartNew();
                ParallelOptions po = new ParallelOptions();
                po.MaxDegreeOfParallelism = Convert.ToInt32(ConfigurationManager.AppSettings["Print_MaxDegreeOfParallelism"].ToString());
                System.Net.ServicePointManager.DefaultConnectionLimit = Convert.ToInt32(ConfigurationManager.AppSettings["Print_MaxDegreeOfParallelism"].ToString());

                DateTime ToDate = DateTime.Now;
                Int32 NoOFMinutesToSubstract = Convert.ToInt32(ConfigurationManager.AppSettings["Print_NoOfHours"].ToString());
                DateTime FromDate = ToDate.AddHours(-NoOFMinutesToSubstract);

                Parallel.For(0, lstQueries.Count, po, i =>
                {
                    try
                    {
                        eLog oLog = new eLog();
                        oLog.GUID = Guid.NewGuid().ToString();

                        TimeLog("Start FetchAndExtractFromMTrack");
                        List<eArticle_Print> lstlstArticles_Final = new List<eArticle_Print>();

                        //if (lstQueries[i].AppName == "Dossier" && lstQueries[i].HistoryDate != DateTime.MinValue)
                        if (lstQueries[i].HistoryDate != DateTime.MinValue)
                        {
                            if ((DateTime.Now - lstQueries[i].HistoryDate).TotalHours > 0)
                            {
                                NoOFMinutesToSubstract =Convert.ToInt32(Math.Round((DateTime.Now - lstQueries[i].HistoryDate).TotalHours));

                                FromDate = ToDate.AddHours(-NoOFMinutesToSubstract);
                            }
                        }

                        lstlstArticles_Final = FetchAndExtractFromMTrack(lstQueries[i], FromDate, ToDate.AddDays(1));
                        TimeLog("End FetchAndExtractFromMTrack");

                        TimeLog("Start InsertArticles");
                        bool IsSuccessful = InsertArticles(lstlstArticles_Final);
                        TimeLog("End InsertArticles");

                        if (lstQueries[i].HistoryDate != DateTime.MinValue)
                        {
                            new MDB.DAL.DAL().Topic_UpdateHistoryFlag(lstQueries[i].TopicID, lstQueries[i].EQID);
                        }

                    }
                    catch (Exception ex)
                    {
                        ErrorLog("Parallel Error for " + lstQueries[i].Query, ex.ToString());
                    }

                });
                TimeLog("End Parallel.For");
                TimeLog("Parallel.For() execution time for " + " = {0} seconds:" + stopWatch.Elapsed.TotalSeconds);

            }
            catch (Exception ex)
            {
                ErrorLog("Process_Print", ex.Message + " ->> " + ex.StackTrace);
            }
        }

        public List<eArticle_Print> FetchAndExtractFromMTrack(eEntityQuery objEQ, DateTime FromDate, DateTime ToDate)
        {
            List<eArticle_Print> lstFinal = new List<eArticle_Print>();

            try
            {
                //if (lstLinks.Count > 0)
                //{
                //    List<String> lstReporterNewsIds = lstLinks.Select(i => i.ReporterNewsId).ToList();
                //    string strReporterNewsIds = String.Join(",", lstReporterNewsIds.GetRange(0, lstReporterNewsIds.Count).ToArray());
                //    TimeLog("ReporterNewsIds Found Is " + strReporterNewsIds);
                //}

                lstFinal = new MDB.DAL.DAL().Fetch_Aticles_Print(objEQ, FromDate.ToString("yyyy-MM-dd"),ToDate.ToString("yyyy-MM-dd"));

            }
            catch (Exception ex)
            {
                ErrorLog("FetchAndExtractFromMTrack", ex.ToString());
            }

            return lstFinal;
        }

        #endregion

        #region INSERT

        public bool InsertArticles(List<eArticle_Print> lstLinks)
        {
            bool IsSuccessful = true;
            try
            {
                for (int i = 0; i < lstLinks.Count; i++)
                {
                    try
                    {
                        TimeLog("Start InsertArticle");
                        new MDB.DAL.DAL().InsertArticlePrint(lstLinks[i]);
                        TimeLog("End InsertArticle");
                    }
                    catch (Exception ex)
                    {
                        IsSuccessful = false;
                        ErrorLog("For Loop Error for " + lstLinks[i].NewsID, ex.ToString());
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorLog("InsertArticles ", ex.Message + " ->> " + ex.StackTrace);
            }

            return IsSuccessful;
        }

        #endregion

        #region LOGGING

        //For error logging
        private void ErrorLog(string functionName, string error)
        {
            try
            {
                string LogPath = ConfigurationManager.AppSettings["Print_ErrorLogPath"];
                using (TextWriter myWriter = File.AppendText(LogPath))
                {

                    TextWriter.Synchronized(myWriter).WriteLine("<--> :{0}", string.Empty);
                    TextWriter.Synchronized(myWriter).WriteLine("Function Name :{0}", functionName);
                    TextWriter.Synchronized(myWriter).WriteLine("Error :{0}", error);
                    TextWriter.Synchronized(myWriter).WriteLine("Date :{0}", DateTime.Now.ToString());
                    TextWriter.Synchronized(myWriter).WriteLine("<--> :{0}", string.Empty);
                    TextWriter.Synchronized(myWriter).Flush();
                    TextWriter.Synchronized(myWriter).Close();
                }
            }
            catch (Exception ex)
            {
            }
        }

        //For debugging purpose
        private void TimeLog(string strtext)
        {
            try
            {
                string LogPath = ConfigurationManager.AppSettings["Print_TimeLogPath"];
                using (TextWriter myWriter = File.AppendText(LogPath))
                {

                    TextWriter.Synchronized(myWriter).WriteLine("<--> :{0}", string.Empty);
                    TextWriter.Synchronized(myWriter).WriteLine("TimeLog :{0}", strtext);
                    TextWriter.Synchronized(myWriter).WriteLine("Date :{0}", DateTime.Now.ToString());
                    TextWriter.Synchronized(myWriter).WriteLine("<--> :{0}", string.Empty);
                    TextWriter.Synchronized(myWriter).Flush();
                    TextWriter.Synchronized(myWriter).Close();
                }
            }
            catch (Exception ex)
            {
                ErrorLog("TimeLog", ex.ToString());
            }
        }

        #endregion
    }
}
