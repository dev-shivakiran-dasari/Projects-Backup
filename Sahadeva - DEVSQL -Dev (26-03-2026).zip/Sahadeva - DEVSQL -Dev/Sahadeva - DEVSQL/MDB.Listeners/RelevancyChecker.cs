﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Configuration;
using System.Net;
using SolrNet;
using SolrNet.Commands.Parameters;
using Microsoft.Practices.ServiceLocation;
using System.Xml;
using System.Text.RegularExpressions;
using System.Web;
using Newtonsoft.Json.Linq;
using MDB.Entities;

namespace MDB.Listeners
{
    public class RelevancyChecker
    {
        public static ISolrOperations<SolrPage> solrBoilerPipe = null;

        public String MainFunc(String XML, String Query, String BatchID, String Type)
        {
            String OutputXML = "";
            try
            {
                #region Code

                if (Type == "SENTRY-TWT" || Type == "YT" || Type == "SENTRY-News")
                {
                    List<SolrPage> RelevantLinks = CheckTwitterRelevancy(ref XML, ref Query, BatchID, Type);
                    OutputXML = ConvertSolrObjToXML(RelevantLinks);
                }
                //else
                //{
                //    //Check relevancy (boiler pipe)
                //    List<SolrPage> RelevantLinks = CheckRelevancy(ref XML, ref Query, BatchID);
                //    OutputXML = ConvertSolrObjToXML(RelevantLinks);
                //}

                #endregion
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return OutputXML;
        }

        

        #region "Check Duplicate"

        private int CheckDupBoilerPipe(string url)
        {
            int Count = 0;
            try
            {
                url = "\"" + url + "\"";

                SolrQueryResults<SolrPage> result = null;
                solrBoilerPipe = ServiceLocator.Current.GetInstance<ISolrOperations<SolrPage>>();

                String abc = "URL:" + url + "";



                result = solrBoilerPipe.Query("URL:" + url + "",
                       new QueryOptions { Start = 0, Rows = 10 });


                result = solrBoilerPipe.Query("URL:" + url + "",
                    new QueryOptions
                    {
                        Start = 0,
                        Rows = result.NumFound,
                        Fields = new[] { "URL,NoiseCancelledContent" }
                    });

                Count = result.Count;

            }
            catch (Exception ex)
            {
                throw ex;
            }

            return Count;
        }

        #endregion

        #region "Download Data From URL And inSertion In Solr And Check Relevancy"

        public List<SolrPage> CheckTwitterRelevancy(ref String XML, ref String Query, string BatchID,string Type)
        {
            List<SolrPage> RelevantLinks = new List<SolrPage>();
            List<string> AllLinks = new List<string>();
            string strAppend = "";
            solrBoilerPipe = ServiceLocator.Current.GetInstance<ISolrOperations<SolrPage>>();

            try
            {
                XmlDocument inputXML = new XmlDocument();
                inputXML.LoadXml(XML);
                XmlNode nodeInput = inputXML.SelectSingleNode("/RelevancyRequest/Input/Parameters");
                String paramaters = nodeInput.InnerXml;


                XmlNodeList varsList = nodeInput.SelectNodes("Params");
                bool isAdded = false;
                foreach (XmlNode x in varsList)
                {
                    XmlNode nodeLink = x.SelectSingleNode("Link");
                    XmlNode nodeHashID = x.SelectSingleNode("HashID");
                    XmlNode nodeNoiseCancelledContent = x.SelectSingleNode("NoiseCancelledContent");

                    if (nodeLink != null && nodeHashID != null)
                    {
                        string URL = nodeLink.InnerText;
                        string HashID = nodeHashID.InnerText;
                        string NoiseCancelledContent = nodeNoiseCancelledContent.InnerText;
                        string jsonString = string.Empty;
                        try
                        {
                            int count = 0;// CheckDupBoilerPipe(URL);

                            if (count == 0)
                            {
                                solrBoilerPipe.Add(new SolrPage()
                                {
                                    NoiseCancelledContent = NoiseCancelledContent,
                                    URL = URL,
                                    ID = HashID,
                                    HTML = "",
                                    Title = "",
                                    Type = Type
                                    ,
                                    timestamp = DateTime.Now,
                                    BatchID = BatchID
                                }, new AddParameters() { Overwrite = true });

                                isAdded = true;
                            }



                            strAppend = strAppend + " '" + HashID + "'";
                            AllLinks.Add(HashID);
                        }
                        catch (Exception ex)
                        {
                            throw ex;
                        }

                    }
                }

                if (isAdded == true)
                {
                    solrBoilerPipe.Commit();
                }

                TimeLog("strAppend is " + strAppend);
                if (strAppend != string.Empty && strAppend != "''")
                {
                    strAppend = " AND ID:(" + strAppend.TrimStart() + ")" + " AND BatchID:(" + BatchID + ")";
                    Query = "NoiseCancelledContent:(" + Query + ")" + strAppend;

                    TimeLog(Query);

                    RelevantLinks = getDataBoilerPipe(Query);

                    List<SolrPage> lst = new List<SolrPage>();
                    //DeleteBoilerPipeDoc(lst, AllLinks, BatchID);
                }

            }
            catch (Exception ex)
            {
                
            }

            return RelevantLinks;
        }

        #endregion

        #region "Get Data From Solr"
        private List<SolrPage> getDataBoilerPipe(string strQuery)
        {
            List<SolrPage> obj = null;
            SolrQueryResults<SolrPage> solrResults = null;
            List<SolrPage> URLs = new List<SolrPage>();

            try
            {
                solrBoilerPipe = ServiceLocator.Current.GetInstance<ISolrOperations<SolrPage>>();
                solrResults = solrBoilerPipe.Query(strQuery, new QueryOptions { Start = 0, Rows = 10, OrderBy = new[] { new SolrNet.SortOrder("timestamp", Order.DESC) } });

                solrResults = solrBoilerPipe.Query(strQuery,
                    new QueryOptions
                    {
                        Start = 0,
                        Rows = solrResults.NumFound,
                        OrderBy = new[] { new SolrNet.SortOrder("timestamp", Order.DESC) },
                        Fields = new[] { "_version_,URL,NoiseCancelledContent,Title,ID,HTML" }
                    });

                //Session["lstRelevantLinksBoilerPipe"] = solrResults;
                obj = (List<SolrPage>)solrResults;// Session["lstRelevantLinksBoilerPipe"];
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return obj;
        }
        #endregion

        #region "Delete"

        private void DeleteBoilerPipeDoc(List<SolrPage> RelevantLinks, List<String> AllLinks, string BatchID)
        {
            try
            {
                solrBoilerPipe = ServiceLocator.Current.GetInstance<ISolrOperations<SolrPage>>();
                String IDsToDelete = "";
                List<String> list = RelevantLinks.Select(o => o.ID).ToList();
                AllLinks.RemoveAll(e => list.Contains(e));

                foreach (string s in AllLinks)
                {
                    IDsToDelete = IDsToDelete + " '" + s + "'";
                }

                if (IDsToDelete != string.Empty)
                {
                    SolrQuery query = new SolrQuery("ID:(" + IDsToDelete + ") AND BatchID:" + @"""" + BatchID + @"""");
                    solrBoilerPipe.Delete(query);
                    solrBoilerPipe.Commit();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


        #endregion

        #region "Get Output XML"
        private String ConvertSolrObjToXML(List<SolrPage> obj)
        {
            String toReturn = string.Empty;
            try
            {
                string strxml = System.IO.File.ReadAllText(ConfigurationManager.AppSettings["OutputXMLForSolrComponent"]);
                XmlDocument doc = new XmlDocument();
                doc.LoadXml(strxml);
                XmlNode nodeOutput = doc.SelectSingleNode("/RelevancyRequest/Output");
                foreach (SolrPage s in obj)
                {
                    XmlNode nodeParams = doc.CreateElement("params");
                    XmlNode nodeID = doc.CreateElement("ID");
                    XmlNode nodeURL = doc.CreateElement("URL");
                    XmlNode nodeTitle = doc.CreateElement("Title");
                    XmlNode nodeNoiseCancelledContent = doc.CreateElement("NoiseCancelledContent");

                    if (s.ID != null || s.ID.Trim() != string.Empty)
                    {
                        nodeID.InnerText = s.ID;
                    }
                    if (s.URL != null || s.URL.Trim() != string.Empty)
                    {
                        nodeURL.InnerText = s.URL;
                    }
                    if (s.Title != null || s.Title.Trim() != string.Empty)
                    {
                        nodeTitle.InnerText = s.Title;
                    }
                    if (s.NoiseCancelledContent != null || s.NoiseCancelledContent.Trim() != string.Empty)
                    {
                        nodeNoiseCancelledContent.InnerText = s.NoiseCancelledContent;
                    }

                    nodeParams.AppendChild(nodeID);
                    nodeParams.AppendChild(nodeURL);
                    nodeParams.AppendChild(nodeTitle);
                    nodeParams.AppendChild(nodeNoiseCancelledContent);

                    nodeOutput.AppendChild(nodeParams);
                }
                toReturn = doc.OuterXml;
                //ErrorLogwithstring("toReturn " + toReturn);

            }
            catch (Exception ex)
            {
                throw ex;
            }
            return toReturn;
        }
        #endregion

        //For debugging purpose
        private void TimeLog(string strtext)
        {
            try
            {
                string LogPath = ConfigurationManager.AppSettings["Google_TimeLogPath"];
                using (TextWriter myWriter = File.AppendText(LogPath))
                {

                    TextWriter.Synchronized(myWriter).WriteLine("<--> :{0}", string.Empty);
                    TextWriter.Synchronized(myWriter).WriteLine("TimeLog :{0}", strtext);
                    TextWriter.Synchronized(myWriter).WriteLine("Date :{0}", DateTime.Now.ToString());
                    TextWriter.Synchronized(myWriter).WriteLine("<--> :{0}", string.Empty);
                    TextWriter.Synchronized(myWriter).Flush();
                    TextWriter.Synchronized(myWriter).Close();
                }
            }
            catch (Exception ex)
            {
                //ErrorLog("TimeLog", ex.ToString());
            }
        }
    }
}
