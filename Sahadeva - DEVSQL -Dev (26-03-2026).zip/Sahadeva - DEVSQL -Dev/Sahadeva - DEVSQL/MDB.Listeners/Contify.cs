﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Configuration;
using System.IO;
using MDB.Entities;
using Newtonsoft.Json.Linq;
using System.Globalization;
using System.Diagnostics;
using System.Threading.Tasks;
using System.Net;
using System.Reflection;
using SolrNet.Utils;
using System.Text.RegularExpressions;

namespace MDB.Listeners
{
    public class Contify
    {
        #region CONTIFY

        public void Process(List<eEntityQuery> lstQueries)
        {
            try
            {
                #region Creating And Setting ParallelOptions
                var stopWatch = Stopwatch.StartNew();
                ParallelOptions po = new ParallelOptions();
                po.MaxDegreeOfParallelism = Convert.ToInt32(ConfigurationManager.AppSettings["Contify_MaxDegreeOfParallelism"].ToString());
                System.Net.ServicePointManager.DefaultConnectionLimit = Convert.ToInt32(ConfigurationManager.AppSettings["Contify_MaxDegreeOfParallelism"].ToString()); 
                #endregion

                Parallel.For(0, lstQueries.Count, po, i =>
                {
                    try
                    {
                        eLog oLog = new eLog();
                        oLog.GUID = Guid.NewGuid().ToString();

                        if (lstQueries[i].EntityType == "PPO")
                        {
                            #region PPO
                            List<string> lstPublications = new List<string> { "1179", "1848", "321458", "680407", "175", "68899", "680408" };
                            for (int j = 0; j < lstPublications.Count; j++)
                            {
                                TimeLog("Start FetchAndExtractFromContify");
                                List<eArticle_Online> lstArticles = FetchAndExtractFromContify(lstQueries[i], lstPublications[j].ToString());
                                TimeLog("Articles Count From Contify Is " + lstArticles.Count);
                                TimeLog("End FetchAndExtractFromContify");

                                TimeLog("Start Process_Diffbot");
                                List<eArticle_Online> lstlstArticles_Final = new List<eArticle_Online>();
                                lstlstArticles_Final = Process_Diffbot(lstArticles);
                                TimeLog("End Process_Diffbot");

                                TimeLog("Start InsertArticles");
                                bool IsSuccessful = InsertArticles(lstlstArticles_Final);
                                TimeLog("End InsertArticles");
                            } 
                            #endregion
                        }
                        else
                        {
                            #region FetchAndExtractFromContify
                            TimeLog("Start FetchAndExtractFromContify");
                            List<eArticle_Online> lstArticles = FetchAndExtractFromContify(lstQueries[i], "");
                            TimeLog("Articles Count From Contify Is " + lstArticles.Count);
                            TimeLog("End FetchAndExtractFromContify"); 
                            #endregion

                            #region Check Duplicates In ArticleOnline
                            TimeLog("Start Check Duplicates In ArticleOnline");
                            string strHashUrls = string.Join(",", lstArticles.Select(x => x.HashUrl));
                            List<string> lstOriginalUrls = new DAL.DAL().CheckDuplicate_ArticleOnline(lstQueries[i].EntityID, lstQueries[i].TopicID, strHashUrls);
                            lstArticles.RemoveAll(t => lstOriginalUrls.Contains(t.HashUrl));
                            TimeLog("OriginalUrls count Is " + lstArticles.Count);
                            TimeLog("End Check Duplicates In ArticleOnline"); 
                            #endregion

                            #region Check Duplicates In Diffbot
                            TimeLog("Start Check Duplicates In Diffbot");
                            strHashUrls = string.Join(",", lstArticles.Select(x => x.HashUrl));
                            lstArticles = new DAL.DAL().CheckDuplicate_Diffbot(strHashUrls, lstArticles);
                            TimeLog("End Check Duplicates In ArticleOnline"); 
                            #endregion

                            #region Process Diffbot
                            TimeLog("Start Process_Diffbot");
                            List<eArticle_Online> lstlstArticles_Final = new List<eArticle_Online>();
                            lstlstArticles_Final = Process_Diffbot(lstArticles);
                            TimeLog("End Process_Diffbot"); 
                            #endregion

                            if (lstQueries[i].AppName == "Dossier")
                            {
                                #region Process_Images
                                TimeLog("Start Process_Images");
                                lstlstArticles_Final = Process_Images(lstlstArticles_Final);
                                TimeLog("End Process_Images");
                                #endregion
                            }

                            #region Insert Articles
                            TimeLog("Start InsertArticles");
                            bool IsSuccessful = InsertArticles(lstlstArticles_Final);
                            TimeLog("End InsertArticles"); 
                            #endregion
                        }

                    }
                    catch (Exception ex)
                    {
                        ErrorLog("Parallel Error for " + lstQueries[i].Query, ex.ToString());
                    }

                });
                TimeLog("End Parallel.For");
                TimeLog("Parallel.For() execution time for " + " = {0} seconds:" + stopWatch.Elapsed.TotalSeconds);

            }
            catch (Exception ex)
            {
                ErrorLog("Process_Contify ", ex.Message + " ->> " + ex.StackTrace);
            }
        }

        public static List<eArticle_Online> FetchAndExtractFromContify(eEntityQuery objEQ, string SourceID)
        {
            List<eArticle_Online> lstFinal = new List<eArticle_Online>();

            TimeLog("Start Fetching From Contify Query Is " + objEQ.Query);

            try
            {
                Int32 NextPage = 0;

                do
                {
                    TimeLog("Start FetchArticles Query Is " + objEQ.Query);
                    string strOutput = FetchArticles(objEQ, NextPage, SourceID);
                    TimeLog("strOutput Is " + strOutput + " For " + objEQ.Query);
                    TimeLog("End FetchArticles Query Is " + objEQ.Query);

                    TimeLog("Start ExtractArticlesFromJson Query Is " + objEQ.Query);
                    List<eArticle_Online> lstArticles = ExtractArticlesFromJson(strOutput, objEQ);

                    if (lstArticles.Count > 0)
                    {
                        NextPage = lstArticles[0].NextPage;
                        lstFinal.AddRange(lstArticles);
                    }

                    TimeLog("End ExtractArticlesFromJson Query Is " + objEQ.Query);

                } while (NextPage > 0);


            }
            catch (Exception ex)
            {
                ErrorLog("FetchAndExtractFromContify", ex.ToString() + " Query Is " + objEQ.Query);
            }

            TimeLog("End Fetching From Contify Query Is " + objEQ.Query);

            return lstFinal;
        }

        private static string FetchArticles(eEntityQuery objEQ, Int32 Page, string SourceID)
        {

            string strOutput = string.Empty;
            string strFinalURL = string.Empty;
            try
            {

                #region Creating Request

                string strHours = ConfigurationManager.AppSettings["Contify_NoOfHours"].ToString();

                if (objEQ.AppName == "Dossier" && objEQ.HistoryDate != DateTime.MinValue)
                {
                    if ((DateTime.Now - objEQ.HistoryDate).TotalHours > 0)
                    {
                        strHours = Math.Round((DateTime.Now - objEQ.HistoryDate).TotalHours).ToString();
                    }
                }

                if (!String.IsNullOrEmpty(SourceID))
                {
                    strFinalURL = "https://api.contify.com/v3/insights?source_id=" + SourceID + "&start_date=mystartdate".Replace("mystartdate", DateTime.Now.AddHours(-Convert.ToInt32(strHours)).ToString("yyyy-MM-ddTHH:mm:ss.fffZ")); ;
                }
                else
                {
                    strFinalURL = ConfigurationManager.AppSettings["Contify_URL"].Replace("&amp;", "&").Replace("myquery", HttpUtility.UrlEncode(objEQ.Query)).Replace("mystartdate", DateTime.Now.AddHours(-Convert.ToInt32(strHours)).ToString("yyyy-MM-ddTHH:mm:ss.fffZ"));
                }

                if (Page > 0)
                {
                    strFinalURL = strFinalURL + "&page=" + Page.ToString();
                }

                strFinalURL = strFinalURL + "&sort_by=date";

                TimeLog(strFinalURL);

                ServicePointManager.SecurityProtocol = (SecurityProtocolType)3072;
                HttpWebRequest request = (HttpWebRequest)WebRequest.Create(strFinalURL);
                request.Timeout = Convert.ToInt32(ConfigurationManager.AppSettings["Contify_TimeOutIntervalForOperation"]);
                request.Method = "GET";
                request.ContentType = "application/json; charset=utf-8";
                request.Headers.Add("APPID", ConfigurationManager.AppSettings["Contify_APPID"].ToString());
                request.Headers.Add("APPSECRET", ConfigurationManager.AppSettings["Contify_APPSECRET"].ToString());
                #endregion

                #region Get Data From API
                using (HttpWebResponse response = (HttpWebResponse)request.GetResponse())
                {
                    Stream stream = (Stream)response.GetResponseStream();
                    StreamReader reader = new StreamReader(stream);
                    strOutput = reader.ReadToEnd();
                    TimeLog(strOutput);
                }
                #endregion
                request = null;
            }
            catch (Exception ex)
            {
                ErrorLog("FetchArticles For Query Is " + objEQ.Query, ex.ToString());
            }

            return strOutput;
        }

        private static List<eArticle_Online> ExtractArticlesFromJson(string Output, eEntityQuery objEQ)
        {
            List<eArticle_Online> lstArticles = new List<eArticle_Online>();
            string strUrl = string.Empty;
            try
            {
                if (!String.IsNullOrEmpty(Output))
                {
                    JObject obj = JObject.Parse(Output);
                    if (obj != null)
                    {
                        JArray Article_Array = (JArray)obj["results"];

                        if (Article_Array != null)
                        {
                            
                            try
                            {
                                foreach (JToken AA in Article_Array)
                                {
                                    eArticle_Online Article = new eArticle_Online();

                                    Article.EntityID = objEQ.EntityID;
                                    Article.EQID = objEQ.EQID;
                                    Article.TopicID = objEQ.TopicID;
                                    Article.ServiceID = 1;

                                    if (obj["next"] != null)
                                    {
                                        if (!String.IsNullOrEmpty(Convert.ToString(obj["next"])))
                                        {
                                            Article.NextPage = Convert.ToInt32(Convert.ToString(obj["next"]).Replace("?page=", ""));
                                        }
                                    }

                                    if (AA["url"] != null)
                                    {
                                        Article.Url = Convert.ToString(AA["url"]);

                                        Article.Publication_Url = ExtractDomainame(Article.Url);

                                        if (!String.IsNullOrEmpty(Article.Url))
                                        {
                                            string strUrll = Article.Url.Replace("https://", "").Replace("http://", "");
                                            Article.HashUrl = CalculateHash(strUrll);
                                        }

                                        strUrl = Article.Url;
                                    }
                                    if (AA["title"] != null)
                                    {
                                        Article.Title = Convert.ToString(AA["title"]);
                                    }
                                    if (AA["summary"] != null)
                                    {
                                        Article.Text = Convert.ToString(AA["summary"]);
                                    }
                                    if (AA["pub_date"] != null)
                                    {
                                        string strDate = Convert.ToString(AA["pub_date"]);
                                        Article.Date = Convert.ToDateTime(strDate).ToLocalTime();
                                        //try
                                        //{
                                        //    Article.Date = DateTime.ParseExact(strDate, "yyyy-MM-dd'T'HH:mm:ss'Z'", CultureInfo.InvariantCulture).ToLocalTime();
                                        //}
                                        //catch (Exception)
                                        //{
                                        //    Article.Date = DateTime.ParseExact(strDate, "dd-MM-yyyy HH:mm:ss", CultureInfo.InvariantCulture).ToLocalTime();
                                        //}
                                        
                                    }
                                    if (AA["source"] != null)
                                    {
                                        if (AA["source"]["name"] != null)
                                        {
                                            Article.Publication = Convert.ToString(AA["source"]["name"]);
                                        }
                                    }

                                    //if (AA["language"] != null)
                                    //{
                                    //    if (AA["language"]["name"] != null)
                                    //    {
                                    //        Article.Language = Convert.ToString(AA["language"]["name"]);
                                    //    }
                                    //}
                                    //if (AA["summary"] != null)
                                    //{
                                    //    Article.Summary = Convert.ToString(AA["summary"]);
                                    //}



                                    //JArray companies = (JArray)AA["companies"];

                                    //if (companies != null)
                                    //{

                                    //    if (companies.Count() > 0)
                                    //    {
                                    //        for (int j = 0; j < companies.Count(); j++)
                                    //        {
                                    //            if (companies[j]["name"] != null)
                                    //            {
                                    //                Article.Mentioned_Companies += "," + companies[j]["name"].ToString();
                                    //            }
                                    //        }
                                    //        Article.Mentioned_Companies = Article.Mentioned_Companies.Substring(1);
                                    //    }
                                    //}

                                    //JArray industries = (JArray)AA["industries"];

                                    //if (industries != null)
                                    //{

                                    //    if (industries.Count() > 0)
                                    //    {
                                    //        for (int j = 0; j < industries.Count(); j++)
                                    //        {
                                    //            if (industries[j]["name"] != null)
                                    //            {
                                    //                Article.Mentioned_Industries += "," + industries[j]["name"].ToString();
                                    //            }
                                    //        }
                                    //        Article.Mentioned_Industries = Article.Mentioned_Industries.Substring(1);
                                    //    }
                                    //}

                                    //JArray locations = (JArray)AA["locations"];

                                    //if (locations != null)
                                    //{

                                    //    if (locations.Count() > 0)
                                    //    {
                                    //        for (int j = 0; j < locations.Count(); j++)
                                    //        {
                                    //            if (locations[j]["name"] != null)
                                    //            {
                                    //                Article.Mentioned_Locations += "," + locations[j]["name"].ToString();
                                    //            }
                                    //        }
                                    //        Article.Mentioned_Locations = Article.Mentioned_Locations.Substring(1);
                                    //    }
                                    //}

                                    //JArray topics = (JArray)AA["topics"];

                                    //if (topics != null)
                                    //{

                                    //    if (topics.Count() > 0)
                                    //    {
                                    //        for (int j = 0; j < topics.Count(); j++)
                                    //        {
                                    //            if (topics[j]["name"] != null)
                                    //            {
                                    //                Article.Mentioned_Topics += "," + topics[j]["name"].ToString();
                                    //            }
                                    //        }
                                    //        Article.Mentioned_Topics = Article.Mentioned_Topics.Substring(1);
                                    //    }
                                    //}

                                    lstArticles.Add(Article);
                                }

                            }
                            catch (Exception ex)
                            {
                                throw ex;
                            }
                        }
                    }

                    obj = null;
                }
                else
                {

                }
            }
            catch (Exception ex)
            {
                ErrorLog("ExtractArticlesFromJson", strUrl + "->" + ex.ToString());
            }

            return lstArticles;
        }

        //ExtractDomainame
        private static string ExtractDomainame(string URL)
        {
            try
            {
                string strDomain = Regex.Replace(URL, @"^([a-zA-Z]+:\/\/)?([^\/]+)\/.*?$", "$2");
                strDomain = strDomain.ToLower();
                strDomain = strDomain.Replace("www.", "");
                return strDomain;

            }
            catch (Exception ex) { return ""; }
        }

        public static string CalculateHash(string value)
        {
            try
            {
                var data = System.Text.Encoding.ASCII.GetBytes(value);
                data = System.Security.Cryptography.SHA256.Create().ComputeHash(data);
                return Convert.ToBase64String(data);
            }
            catch (Exception ex)
            {
                return Convert.ToBase64String(System.Text.Encoding.ASCII.GetBytes(string.Empty));
            }
        } 

        #endregion

        #region Diffbot

        public static List<eArticle_Online> Process_Diffbot(List<eArticle_Online> lstLinks)
        {
            List<eArticle_Online> lstFinal = new List<eArticle_Online>();

            try
            {
                //create list of tokens
                List<string> lstTokens = ConfigurationManager.AppSettings["Diffbot_Token"].ToString().Split(',').ToList();

                int counter = 0;
                var stopWatch = Stopwatch.StartNew();
                ParallelOptions po = new ParallelOptions();
                po.MaxDegreeOfParallelism = Convert.ToInt32(ConfigurationManager.AppSettings["Diffbot_MaxDegreeOfParallelism"].ToString());
                System.Net.ServicePointManager.DefaultConnectionLimit = Convert.ToInt32(ConfigurationManager.AppSettings["Diffbot_MaxDegreeOfParallelism"].ToString());

                Parallel.For(0, lstLinks.Count, po, i =>
                {
                    try
                    {

                        if (lstLinks[i].ADID > 0)
                        {
                            lstFinal.Add(lstLinks[i]);
                        }
                        else
                        {
                            string strToken = lstTokens[0];
                            if (i % 2 != 0) { strToken = lstTokens[1]; }

                            TimeLog("Start FetchAndExtractFromDiffbot");
                            eArticle_Online objArticle = FetchAndExtractFromDiffbot(lstLinks[i], strToken);
                            lstFinal.Add(objArticle);
                            TimeLog("End FetchAndExtractFromDiffbot");
                        }

                        counter++;
                    }
                    catch (Exception ex)
                    {
                        ErrorLog("Parallel Error for " + lstLinks[i].Url, ex.ToString());
                    }

                });
                TimeLog("End Parallel.For");
                TimeLog("Parallel.For() execution time for " + " = {0} seconds:" + stopWatch.Elapsed.TotalSeconds);

            }
            catch (Exception ex)
            {
                ErrorLog("Process_Diffbot ", ex.Message + " ->> " + ex.StackTrace);
            }

            return lstFinal;
        }

        public static eArticle_Online FetchAndExtractFromDiffbot(eArticle_Online objArticle, string strToken)
        {
            TimeLog("Start Fetching From Diffbot URL Is " + objArticle.Url);

            try
            {
                TimeLog("Start GetDiffbotData URL Is " + objArticle.Url);
                objArticle = GetDiffbotData(objArticle, strToken);
                TimeLog("End GetDiffbotData URL Is " + "-> " + objArticle.Url);

                TimeLog("Start ExtractFromDiffbot URL Is " + "-> " + objArticle.Url);
                objArticle = ExtractFromDiffbot(objArticle);
                TimeLog("End ExtractFromDiffbot URL Is " + "-> " + objArticle.Url);
            }
            catch (Exception ex)
            {
                ErrorLog("FetchAndExtractFromDiffbot", ex.ToString() + " URL Is " + objArticle.Url);
            }

            TimeLog("End Fetching From Diffbot URL Is " + objArticle.Url);

            return objArticle;
        }

        private static eArticle_Online GetDiffbotData(eArticle_Online objeJobArticle, string strToken)
        {

            string strOutput = string.Empty;
            string strFinalURL = string.Empty;
            try
            {
                //Get Diffbot url,tokens,timeout interval for diffbot call from config and form the url
                strFinalURL = ConfigurationManager.AppSettings["Diffbot_URL"].Replace("&amp;", "&").Replace("mytoken", strToken).Replace("mytimeout", ConfigurationManager.AppSettings["Diffbot_TimeOutIntervalForOperation"]).Replace("myurl", HttpUtility.UrlEncode(objeJobArticle.Url));

                TimeLog(strFinalURL);

                HttpWebRequest request = (HttpWebRequest)WebRequest.Create(strFinalURL);
                request.Timeout = Convert.ToInt32(ConfigurationManager.AppSettings["Diffbot_TimeOutIntervalForOperation"]);
                request.Method = "GET";
                request.ContentType = "application/json; charset=utf-8";
                using (HttpWebResponse response = (HttpWebResponse)request.GetResponse())
                {
                    Stream stream = (Stream)response.GetResponseStream();
                    StreamReader reader = new StreamReader(stream);
                    strOutput = reader.ReadToEnd();
                    objeJobArticle.Output = strOutput;
                    //TimeLog("Output Of URL " + objeJobArticle.Link + " is " + objeJobArticle.Output);
                }
                request = null;
            }
            catch (Exception ex)
            {
                ErrorLog("FetchData For Url " + strFinalURL, ex.ToString());
                strOutput = "Exception Occured " + ex.ToString();
            }

            strFinalURL = null;

            return objeJobArticle;
        }

        private static eArticle_Online ExtractFromDiffbot(eArticle_Online objArticle)
        {

            try
            {
                if (!String.IsNullOrEmpty(objArticle.Output))
                {
                    JObject obj = JObject.Parse(objArticle.Output);
                    if (obj != null)
                    {
                        if (obj["error"] != null && obj["errorCode"] != null)
                        {
                            if (Convert.ToString(obj["errorCode"]) == "404")
                            {
                                objArticle.Text = "404";
                            }
                            objArticle.ErrorCode = Convert.ToString(obj["errorCode"]);
                            objArticle.Error = Convert.ToString(obj["error"]);

                            TimeLog("Output Of URL " + objArticle.Url + " is " + objArticle.Output);
                            obj = null;
                        }
                        else
                        {
                            #region Set output values of diffbot
                            JArray jItems = (JArray)obj["objects"];
                            if (jItems != null)
                            {
                                foreach (JToken jItem in jItems)
                                {
                                    //Set Sitename
                                    if (jItem["siteName"] != null)
                                    {
                                        objArticle.DB_SiteName = jItem["siteName"].ToString();
                                    }

                                    //Set Sentiment
                                    if (jItem["sentiment"] != null)
                                    {
                                        objArticle.DB_Sentiment = Convert.ToDecimal(jItem["sentiment"].ToString());
                                    }

                                    //Set Author
                                    if (jItem["author"] != null)
                                    {
                                        objArticle.DB_Author = jItem["author"].ToString();
                                    }

                                    //Set AuthorURL
                                    if (jItem["authorUrl"] != null)
                                    {
                                        objArticle.DB_AuthorUrl = jItem["authorUrl"].ToString();
                                    }

                                    //Set Title
                                    if (jItem["title"] != null)
                                    {
                                        objArticle.DB_Title = jItem["title"].ToString();
                                    }

                                    //Set Text
                                    if (jItem["text"] != null)
                                    {
                                        objArticle.DB_Text = jItem["text"].ToString();
                                    }

                                    //Set Date
                                    if (jItem["date"] != null)
                                    {
                                        if (!String.IsNullOrEmpty(jItem["date"].ToString()))
                                        {
                                            TimeLog(jItem["date"].ToString());
                                            try
                                            {
                                                if (Convert.ToString(jItem["date"].ToString()).Contains("GMT"))
                                                {
                                                    objArticle.DB_Date = DateTime.ParseExact(Convert.ToString(jItem["date"].ToString()), "ddd, dd MMM yyyy HH:mm:ss GMT", CultureInfo.InvariantCulture);
                                                    //objArticle.Date = DateTime.Now.AddMinutes(-15);
                                                }
                                                else
                                                {
                                                    objArticle.DB_Date = Convert.ToDateTime(jItem["date"].ToString());
                                                }

                                                if (objArticle.DB_Date.Year <= 1900 || objArticle.DB_Date.Year >= 2050)
                                                {
                                                    objArticle.DB_Date = DateTime.Now;
                                                }
                                            }
                                            catch (Exception exxx)
                                            {
                                                objArticle.DB_Date = DateTime.Now;
                                            }
                                        }
                                    }
                                    else
                                    {
                                        objArticle.DB_Date = DateTime.Now;
                                    }

                                    //Set PublisherCountry
                                    if (jItem["publisherCountry"] != null)
                                    {
                                        objArticle.DB_PublisherCountry = jItem["publisherCountry"].ToString();
                                    }

                                    //Set HumanLanguage
                                    if (jItem["humanLanguage"] != null)
                                    {
                                        objArticle.DB_Language = jItem["humanLanguage"].ToString();
                                    }

                                    //Set PublisherRegion
                                    if (jItem["publisherRegion"] != null)
                                    {
                                        objArticle.DB_PublisherRegion = jItem["publisherRegion"].ToString();
                                    }

                                    //Set Tags
                                    #region Tags Output
                                    if (jItem["tags"] != null)
                                    {
                                        string strTags = string.Empty;
                                        JArray jTags = (JArray)jItem["tags"];

                                        if (jTags != null)
                                        {
                                            //Set to take only 5 Tags
                                            int iTagCounter = 0;

                                            foreach (JToken jTag in jTags)
                                            {
                                                if (iTagCounter < 5)
                                                {
                                                    if (jTag["label"] != null)
                                                    {
                                                        SetProperty("DB_TagLabel" + (iTagCounter + 1).ToString(), jTag["label"].ToString(), ref objArticle, false);
                                                        strTags += jTag["label"].ToString() + ",";
                                                    }

                                                    if (jTag["score"] != null)
                                                    {
                                                        SetProperty("DB_TagScore" + (iTagCounter + 1).ToString(), jTag["score"].ToString(), ref objArticle, true);
                                                    }

                                                    if (jTag["count"] != null)
                                                    {
                                                        SetProperty("DB_TagCount" + (iTagCounter + 1).ToString(), jTag["count"].ToString(), ref objArticle, false);
                                                    }

                                                    iTagCounter++;
                                                }
                                            }
                                        }

                                        objArticle.DB_Tags = strTags.Trim(',');
                                        jTags = null;
                                    }
                                    #endregion


                                    //Set Images
                                    #region Images Output
                                    if (jItem["images"] != null)
                                    {
                                        string strImages = string.Empty;
                                        JArray jImages = (JArray)jItem["images"];

                                        if (jImages != null)
                                        {
                                            foreach (JToken jTag in jImages)
                                            {
                                                if (jTag["url"] != null)
                                                {
                                                    strImages += jTag["url"].ToString() + ",";
                                                }
                                            }
                                        }

                                        objArticle.DB_Images = strImages.Trim(',');

                                        jImages = null;
                                    }
                                    #endregion

                                }
                            }

                            jItems = null;

                            #endregion
                        }


                    }

                    obj = null;
                }
                else
                {

                }
            }
            catch (Exception ex)
            {
                ErrorLog("ExtractFromDiffbot", ex.ToString());
            }

            return objArticle;
        }

        //This function will help to set property value of entity dynamically for EngCore
        private static void SetProperty(string strPropertyName, string value, ref eArticle_Online objName, bool IsDecimal)
        {
            try
            {
                PropertyInfo propertyInfo = objName.GetType().GetProperty(strPropertyName);
                if (IsDecimal)
                {
                    propertyInfo.SetValue(objName, Convert.ToDecimal(value), null);
                }
                else
                {
                    if (strPropertyName.Contains("TagCount"))
                    {
                        propertyInfo.SetValue(objName, Convert.ToInt32(value), null);
                    }
                    else
                    {
                        propertyInfo.SetValue(objName, Convert.ToString(value), null);
                    }
                }

                propertyInfo = null;
            }
            catch (Exception ex)
            {
                ErrorLog("SetProperty", ex.ToString() + "Property Name : " + strPropertyName + "| " + "Properrty value : " + value);
            }

        }

        #endregion

        #region Images
        public List<eArticle_Online> Process_Images(List<eArticle_Online> lstLinks)
        {
            List<eArticle_Online> lstFinal = new List<eArticle_Online>();

            try
            {

                int counter = 0;
                var stopWatch = Stopwatch.StartNew();
                ParallelOptions po = new ParallelOptions();
                po.MaxDegreeOfParallelism = Convert.ToInt32(ConfigurationManager.AppSettings["Image_MaxDegreeOfParallelism"].ToString());
                System.Net.ServicePointManager.DefaultConnectionLimit = Convert.ToInt32(ConfigurationManager.AppSettings["Image_MaxDegreeOfParallelism"].ToString());

                Parallel.For(0, lstLinks.Count, po, i =>
                {
                    try
                    {
                        TimeLog("Start CreateImage");
                        lstLinks[i].Screenshot_FileName = CreateImage(lstLinks[i].Url, DateTime.Now.ToString("yyyyMMddHHmmssfff"));
                        lstFinal.Add(lstLinks[i]);
                        TimeLog("End CreateImage");
                        counter++;
                    }
                    catch (Exception ex)
                    {
                        ErrorLog("Parallel Error for " + lstLinks[i].Url, ex.ToString());
                    }

                });
                TimeLog("End Parallel.For");
                TimeLog("Parallel.For() execution time for " + " = {0} seconds:" + stopWatch.Elapsed.TotalSeconds);

            }
            catch (Exception ex)
            {
                ErrorLog("Process_Images ", ex.Message + " ->> " + ex.StackTrace);
            }

            return lstFinal;
        }

        private string CreateImage(string strUrl, string strFileName)
        {
            string strFileNameReturn = string.Empty;
            try
            {
                ServicePointManager.SecurityProtocol = (SecurityProtocolType)3072;
                //string strFetchurl = "https://api.urlbox.io/v1/4G9b0Mqi6yniUmhs/png?url=" + HttpUtility.UrlEncode(strUrl) + "&delay=6000";
                string strFetchurl = System.Configuration.ConfigurationManager.AppSettings["Screenshot_APIUrl"].Replace("&amp;", "&").Replace("myurl", HttpUtility.UrlEncode(strUrl));
                strFetchurl = strFetchurl.Replace("\r\n", "");

                TimeLog(strFetchurl);

                WebRequest request = WebRequest.Create(strFetchurl);

                //// Get the response. 
                WebResponse response = request.GetResponse();


                // Get the stream containing content returned by the server.
                Stream dataStream = response.GetResponseStream();
                System.Drawing.Image image = System.Drawing.Image.FromStream(dataStream);
                string strPath = System.Configuration.ConfigurationManager.AppSettings["ScreenshotSavePath_Online"] + strFileName + ".jpg";//ConfigurationManager.AppSettings["ScreenshotExtension"];
                image.Save(strPath);
                strFileNameReturn = strFileName + ".jpg";
            }
            catch (Exception ex)
            {
                ErrorLog("CreateImage", strUrl + " ->" + ex.ToString());
            }

            return strFileNameReturn;
        }
        #endregion

        #region INSERT

        public static bool InsertArticles(List<eArticle_Online> lstLinks)
        {
            bool IsSuccessful = true;
            try
            {
                for (int i = 0; i < lstLinks.Count; i++)
                {
                    try
                    {
                        TimeLog("Start InsertArticle");
                        new MDB.DAL.DAL().InsertArticle(lstLinks[i]);
                        TimeLog("End InsertArticle");
                    }
                    catch (Exception ex)
                    {
                        IsSuccessful = false;
                        ErrorLog("For Loop Error for " + lstLinks[i].Url, ex.ToString());
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorLog("InsertArticles ", ex.Message + " ->> " + ex.StackTrace);
            }

            return IsSuccessful;
        }

        #endregion

        #region LOGGING

        //For error logging
        private static void ErrorLog(string functionName, string error)
        {
            try
            {
                string LogPath = ConfigurationManager.AppSettings["Contify_ErrorLogPath"];
                using (TextWriter myWriter = File.AppendText(LogPath))
                {

                    TextWriter.Synchronized(myWriter).WriteLine("<--> :{0}", string.Empty);
                    TextWriter.Synchronized(myWriter).WriteLine("Function Name :{0}", functionName);
                    TextWriter.Synchronized(myWriter).WriteLine("Error :{0}", error);
                    TextWriter.Synchronized(myWriter).WriteLine("Date :{0}", DateTime.Now.ToString());
                    TextWriter.Synchronized(myWriter).WriteLine("<--> :{0}", string.Empty);
                    TextWriter.Synchronized(myWriter).Flush();
                    TextWriter.Synchronized(myWriter).Close();
                }
            }
            catch (Exception ex)
            {
            }
        }

        //For debugging purpose
        private static void TimeLog(string strtext)
        {
            try
            {
                string LogPath = ConfigurationManager.AppSettings["Contify_TimeLogPath"];
                using (TextWriter myWriter = File.AppendText(LogPath))
                {

                    TextWriter.Synchronized(myWriter).WriteLine("<--> :{0}", string.Empty);
                    TextWriter.Synchronized(myWriter).WriteLine("TimeLog :{0}", strtext);
                    TextWriter.Synchronized(myWriter).WriteLine("Date :{0}", DateTime.Now.ToString());
                    TextWriter.Synchronized(myWriter).WriteLine("<--> :{0}", string.Empty);
                    TextWriter.Synchronized(myWriter).Flush();
                    TextWriter.Synchronized(myWriter).Close();
                }
            }
            catch (Exception ex)
            {
                ErrorLog("TimeLog", ex.ToString());
            }
        }

        #endregion

    }
}
