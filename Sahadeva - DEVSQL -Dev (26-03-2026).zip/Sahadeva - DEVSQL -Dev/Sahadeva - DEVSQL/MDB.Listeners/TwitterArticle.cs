﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Configuration;
using System.IO;
using MDB.Entities;
using Newtonsoft.Json.Linq;
using System.Globalization;
using System.Diagnostics;
using System.Threading.Tasks;
using System.Net;
using System.Reflection;
using SolrNet.Utils;
using System.Text.RegularExpressions;
using Newtonsoft.Json;
using System.Xml;
using SolrNet;

namespace MDB.Listeners
{
    public class TwitterArticle
    {
        #region TwitterArticle

        public void Process(List<eEntityQuery> lstQueriess)
        {
            try
            {
                #region Creating And Setting ParallelOptions
                var stopWatch = Stopwatch.StartNew();
                ParallelOptions po = new ParallelOptions();
                po.MaxDegreeOfParallelism = Convert.ToInt32(ConfigurationManager.AppSettings["TwitterArticle_MaxDegreeOfParallelism"].ToString());
                System.Net.ServicePointManager.DefaultConnectionLimit = Convert.ToInt32(ConfigurationManager.AppSettings["TwitterArticle_MaxDegreeOfParallelism"].ToString());
                #endregion

                TimeLog("lstQueriess Count Is " + lstQueriess.Count.ToString());

                List<eEntityQuery> lstQueries = lstQueriess.GroupBy(x => x.TopicID).Select(g => g.OrderBy(x => x.EQID).FirstOrDefault()).ToList();

                TimeLog("lstQueries Count Is " + lstQueries.Count.ToString());

                Parallel.For(0, lstQueries.Count, po, i =>
                {
                    try
                    {
                        eLog oLog = new eLog();
                        oLog.GUID = Guid.NewGuid().ToString();

                        List<eArticle_Online> lstLogRecords_News = new List<eArticle_Online>();
                        List<eArticle_Online> lstLogRecords_All = new List<eArticle_Online>();
                        List<eArticle_Online> lstLogRecords_Final = new List<eArticle_Online>();


                        #region FetchAndExtractFromGoogle
                        TimeLog("Start FetchAndExtractFromTwitterArticle");
                        List<eArticle_Online> lstArticles = FetchAndExtractFromTwitterArticle(lstQueries[i], ref lstLogRecords_News);
                        TimeLog("Articles Count From FetchAndExtractFromTwitterArticle Is " + lstArticles.Count);
                        TimeLog("End FetchAndExtractFromTwitterArticle");
                        #endregion


                        #region Check Publications Exclusion List
                        TimeLog("Start Check Publications Exclusion List");
                        List<string> lstExclusionUrls = new DAL.DAL().FetchPublications_Exclusion(0);
                        lstArticles.RemoveAll(n => lstExclusionUrls.Exists(o => o == n.Publication_Url));

                        List<eArticle_Online> lstTemp = lstLogRecords_Final.FindAll(n => lstExclusionUrls.Exists(o => o == n.Publication_Url));
                        if (lstTemp.Count > 0)
                        {
                            for (int t = 0; t < lstTemp.Count; t++)
                            {
                                lstLogRecords_Final.Where(w => w.HashUrl == lstTemp[t].HashUrl).ToList().ForEach(z => z.LogComment = "Removed Due To Publication Exclusion List");
                            }
                        }


                        TimeLog("After excluding domains count Is " + lstArticles.Count);
                        TimeLog("End Check Publications Exclusion List");
                        #endregion

                        string strHashUrls = string.Empty;

                        #region Process_Publications
                        if (ConfigurationManager.AppSettings["Process_PublicationType"] == "1")
                        {
                            #region Check PublicationType Of Articles
                            TimeLog("Start Check PublicationType Of Articles");
                            strHashUrls = string.Join(",", lstArticles.Select(x => x.Publication_Url));
                            lstArticles = new DAL.DAL().CheckPublicationType(strHashUrls, lstArticles);
                            TimeLog("After CheckPublicationType count Is " + lstArticles.Count);
                            TimeLog("End Check PublicationType Of Articles");
                            #endregion

                            #region Process_Publications
                            TimeLog("Start Process_Publications");
                            lstArticles = Process_Publications(lstArticles);
                            TimeLog("After Process_Publications count Is " + lstArticles.Count);
                            TimeLog("End Process_Publications");
                            #endregion

                            List<eArticle_Online> lstNonNewsPublications = lstArticles.Where(article => article.PublicationType == "Non News").ToList();
                            lstArticles.RemoveAll(article => article.PublicationType == "Non News");
                            TimeLog("After lstArticles.RemoveAll PublicationType count Is " + lstArticles.Count);
                            string strNonNewsPublications = string.Join(",", lstNonNewsPublications.Select(x => x.Publication_Url));
                            bool IsSuccessful_Publication_NonNews = new DAL.DAL().InsertPublication_NonNews(strNonNewsPublications);


                            if (lstNonNewsPublications.Count > 0)
                            {
                                for (int t = 0; t < lstNonNewsPublications.Count; t++)
                                {
                                    lstLogRecords_Final.Where(w => w.HashUrl == lstNonNewsPublications[t].HashUrl).ToList().ForEach(z => z.LogComment = "Removed Due To Publication Non News");
                                }
                            }
                        }
                        #endregion

                        #region Check Duplicates In ArticleOnline
                        TimeLog("Start Check Duplicates In ArticleOnline");
                        strHashUrls = string.Join(",", lstArticles.Select(x => x.HashUrl));
                        List<string> lstOriginalUrls = new DAL.DAL().CheckDuplicate_ArticleOnline(lstQueries[i].EntityID, lstQueries[i].TopicID, strHashUrls);
                        lstArticles.RemoveAll(t => lstOriginalUrls.Contains(t.HashUrl));

                        if (lstOriginalUrls.Count > 0)
                        {
                            for (int t = 0; t < lstOriginalUrls.Count; t++)
                            {
                                lstLogRecords_Final.Where(w => w.HashUrl == lstOriginalUrls[t].ToString()).ToList().ForEach(z => z.LogComment = "Removed Due To Exists In DB");
                            }
                        }

                        TimeLog("After CheckDuplicate_ArticleOnline count Is " + lstArticles.Count);
                        TimeLog("End Check Duplicates In ArticleOnline");
                        #endregion

                        #region Check Duplicates In Diffbot
                        TimeLog("Start Check Duplicates In Diffbot");
                        strHashUrls = string.Join(",", lstArticles.Select(x => x.HashUrl));
                        lstArticles = new DAL.DAL().CheckDuplicate_Diffbot(strHashUrls, lstArticles);

                        if (lstArticles.Count > 0)
                        {
                            for (int t = 0; t < lstArticles.Count; t++)
                            {
                                if (lstArticles[t].ADID > 0)
                                {
                                    lstLogRecords_Final.Where(w => w.HashUrl == lstArticles[t].HashUrl).ToList().ForEach(z => z.LogComment = "Diffbot Data Already Present In DB");
                                }
                            }
                        }

                        TimeLog("After CheckDuplicate_Diffbot count Is " + lstArticles.Count);
                        TimeLog("End Check Duplicates In ArticleOnline");
                        #endregion

                        #region Process_Diffbot
                        TimeLog("Start Process_Diffbot");
                        List<eArticle_Online> lstlstArticles_Final = new List<eArticle_Online>();
                        lstlstArticles_Final = Process_Diffbot(lstArticles);

                        if (lstlstArticles_Final.Count > 0)
                        {
                            for (int t = 0; t < lstlstArticles_Final.Count; t++)
                            {
                                if (lstlstArticles_Final[t].ADID > 0)
                                {
                                    lstLogRecords_Final.Where(w => w.HashUrl == lstlstArticles_Final[t].HashUrl).ToList().ForEach(z => z.LogComment = "Diffbot Data Already Present In DB");
                                }
                                else
                                {
                                    if (lstlstArticles_Final[t].DB_Processed > 0)
                                    {
                                        lstLogRecords_Final.Where(w => w.HashUrl == lstlstArticles_Final[t].HashUrl).ToList().ForEach(z => z.LogComment = "Diffbot Processed");
                                    }
                                    else
                                    {
                                        lstLogRecords_Final.Where(w => w.HashUrl == lstlstArticles_Final[t].HashUrl).ToList().ForEach(z => z.LogComment = "Diffbot Failed");
                                    }
                                }
                            }
                        }

                        TimeLog("After Process_Diffbot count Is " + lstlstArticles_Final.Count);
                        TimeLog("End Process_Diffbot");
                        #endregion

                        //if (ConfigurationManager.AppSettings["SolrRelevancy_Article"] == "1")
                        //{
                        //    lstlstArticles_Final = GetRelevantLinks(lstlstArticles_Final, lstQueries[i].Query, lstQueries[i].EQID, ref lstLogRecords_Final);
                        //    TimeLog("After GetRelevantLinks count Is " + lstlstArticles_Final.Count);
                        //}

                        //if (ConfigurationManager.AppSettings["Process_Images"] == "1")
                        //{
                        //    if (lstQueries[i].AppName == "Dossier")
                        //    {
                        //        #region Process_Images
                        //        TimeLog("Start Process_Images");
                        //        lstlstArticles_Final = Process_Images(lstlstArticles_Final);
                        //        TimeLog("After Process_Images count Is " + lstlstArticles_Final.Count);
                        //        TimeLog("End Process_Images");
                        //        #endregion
                        //    }
                        //}


                        #region Insert Articles
                        TimeLog("Start InsertArticles");
                        bool IsSuccessful = InsertArticles(lstlstArticles_Final, ref lstLogRecords_Final);
                        TimeLog("End InsertArticles");
                        #endregion

                        //if (ConfigurationManager.AppSettings["IsArticleOnlineLog"] == "1")
                        //{
                        //    string strLog = string.Empty;
                        //    for (int z = 0; z < lstLogRecords_Final.Count; z++)
                        //    {
                        //        strLog = strLog + lstLogRecords_Final[z].SERPTab + "," + lstLogRecords_Final[z].Url + "," + lstLogRecords_Final[z].LogComment;
                        //        strLog = strLog + Environment.NewLine;

                        //        try
                        //        {
                        //            new MDB.DAL.DAL().InsertArticle_Log(oLog.GUID, lstLogRecords_Final[z]);
                        //        }
                        //        catch (Exception exm)
                        //        {
                        //            ErrorLog("lstLogRecords_Final Loop Error for " + lstLogRecords_Final[z].Url, exm.ToString());
                        //        }
                        //    }
                        //    TimeLog(strLog);
                        //}


                    }
                    catch (Exception ex)
                    {
                        ErrorLog("Parallel Error for " + lstQueries[i].Query, ex.ToString());
                    }

                });
                TimeLog("End Parallel.For");
                TimeLog("Parallel.For() execution time for " + " = {0} seconds:" + stopWatch.Elapsed.TotalSeconds);

            }
            catch (Exception ex)
            {
                ErrorLog("Process_Google ", ex.Message + " ->> " + ex.StackTrace);
            }
        }

        public List<eArticle_Online> FetchAndExtractFromTwitterArticle(eEntityQuery objEQ, ref List<eArticle_Online> lstLogRecords_News)
        {
            List<eArticle_Online> lstFinal = new List<eArticle_Online>();

            try
            {
                TimeLog("Start FetchLinks Query Is " + objEQ.Query);

                List<eArticle_Online> lstArticles = FetchLinks(objEQ, ref lstLogRecords_News);

                if (lstArticles.Count > 0)
                {
                    lstFinal.AddRange(lstArticles);
                }

                TimeLog("End ExtractArticlesFromJson Query Is " + objEQ.Query);
            }
            catch (Exception ex)
            {
                ErrorLog("FetchAndExtractFromGoogle", ex.ToString() + " Query Is " + objEQ.Query);
            }

            TimeLog("End Fetching From Google Query Is " + objEQ.Query);

            return lstFinal;
        }

        private List<eArticle_Online> FetchLinks(eEntityQuery objEQ, ref List<eArticle_Online> lstLogRecords_News)
        {

            List<eArticle_Online> lstArticles = new List<eArticle_Online>();
            List<eArticle_Online> lstFetched = new List<eArticle_Online>();
            lstFetched = new MDB.DAL.DAL().Twitter_FetchMentionedLinks(objEQ.TopicID);
            TimeLog("Twitter_FetchMentionedLinks Count Is " + lstFetched.Count);
            List<string> lstDomainExtExclude = new List<string>();
            lstDomainExtExclude = ConfigurationManager.AppSettings["DomainExtExclude"].ToString().Split(',').ToList();
            try
            {
                
                for (int i = 0; i < lstFetched.Count; i++)
                {
                    eArticle_Online Article = new eArticle_Online();

                    try
                    {
                        Article.EntityID = objEQ.EntityID;
                        Article.EQID = objEQ.EQID;
                        Article.TopicID = objEQ.TopicID;
                        Article.ServiceID = 10;

                        TimeLog("lstFetched[i].Url Url Is " + lstFetched[i].Url);
                        Article.Url=GetRedirectedUrl(lstFetched[i].Url);
                        TimeLog("lstFetched[i].Url GetRedirectedUrl Is " + Article.Url);

                        if (!string.IsNullOrEmpty(Article.Url))
                        {

                            Article.Publication_Url = ExtractDomainame(Article.Url);
                            Article.Publication = Article.Publication_Url;
                            Article.Date = DateTime.Now;
                            if (!String.IsNullOrEmpty(Article.Url))
                            {
                                string strUrl = Article.Url.Replace("https://", "").Replace("http://", "");
                                Article.HashUrl = CalculateHash(strUrl);
                            }
                            if (lstDomainExtExclude.Any(x => Article.Publication_Url.EndsWith(x)))
                            {
                                Article.LogComment = "Removed Due To Domain Extension";
                                lstLogRecords_News.Add(Article);
                                continue;
                            }
                            else
                            {
                                lstArticles.Add(Article);
                                lstLogRecords_News.Add(Article);
                            }
                        }
                    }
                    catch (Exception exxx)
                    {
                        ErrorLog("For Loop Error for Article Url " + lstFetched[i].Url + "  -> " + objEQ.EQID, exxx.ToString());
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorLog("ExtractArticlesFromJson", ex.ToString());
            }

            return lstArticles;
        }

        #endregion

        #region DIFFBOT

        public List<eArticle_Online> Process_Diffbot(List<eArticle_Online> lstLinks)
        {
            List<eArticle_Online> lstFinal = new List<eArticle_Online>();

            try
            {
                //create list of tokens
                List<string> lstTokens = ConfigurationManager.AppSettings["Diffbot_Token"].ToString().Split(',').ToList();

                int counter = 0;
                var stopWatch = Stopwatch.StartNew();
                ParallelOptions po = new ParallelOptions();
                po.MaxDegreeOfParallelism = Convert.ToInt32(ConfigurationManager.AppSettings["Diffbot_MaxDegreeOfParallelism"].ToString());
                System.Net.ServicePointManager.DefaultConnectionLimit = Convert.ToInt32(ConfigurationManager.AppSettings["Diffbot_MaxDegreeOfParallelism"].ToString());

                Parallel.For(0, lstLinks.Count, po, i =>
                {
                    try
                    {
                        if (lstLinks[i].ADID > 0)
                        {
                            lstFinal.Add(lstLinks[i]);
                        }
                        else
                        {
                            string strToken = lstTokens[0];
                            if (i % 2 != 0) { strToken = lstTokens[1]; }

                            TimeLog("Start FetchAndExtractFromDiffbot");
                            eArticle_Online objArticle = FetchAndExtractFromDiffbot(lstLinks[i], strToken);
                            lstFinal.Add(objArticle);

                            TimeLog("End FetchAndExtractFromDiffbot");
                        }
                        counter++;
                    }
                    catch (Exception ex)
                    {
                        ErrorLog("Parallel Error for " + lstLinks[i].Url, ex.ToString());
                    }

                });
                TimeLog("End Parallel.For");
                TimeLog("Parallel.For() execution time for " + " = {0} seconds:" + stopWatch.Elapsed.TotalSeconds);

            }
            catch (Exception ex)
            {
                ErrorLog("Process_Diffbot ", ex.Message + " ->> " + ex.StackTrace);
            }

            return lstFinal;
        }

        public eArticle_Online FetchAndExtractFromDiffbot(eArticle_Online objArticle, string strToken)
        {
            TimeLog("Start Fetching From Diffbot URL Is " + objArticle.Url);

            try
            {
                TimeLog("Start GetDiffbotData URL Is " + objArticle.Url);
                objArticle = GetDiffbotData(objArticle, strToken);
                TimeLog("End GetDiffbotData URL Is " + "-> " + objArticle.Url);

                TimeLog("Start ExtractFromDiffbot URL Is " + "-> " + objArticle.Url);
                objArticle = ExtractFromDiffbot(objArticle);
                TimeLog("End ExtractFromDiffbot URL Is " + "-> " + objArticle.Url);
            }
            catch (Exception ex)
            {
                //lstLogRecords_Final.Where(w => w.HashUrl == objArticle.HashUrl).ToList().ForEach(z => z.LogComment = "Diffbot Data Failed");
                ErrorLog("FetchAndExtractFromDiffbot", ex.ToString() + " URL Is " + objArticle.Url);
            }

            TimeLog("End Fetching From Diffbot URL Is " + objArticle.Url);

            return objArticle;
        }

        private eArticle_Online GetDiffbotData(eArticle_Online objeJobArticle, string strToken)
        {

            string strOutput = string.Empty;
            string strFinalURL = string.Empty;
            try
            {
                //Get Diffbot url,tokens,timeout interval for diffbot call from config and form the url
                strFinalURL = ConfigurationManager.AppSettings["Diffbot_URL"].Replace("&amp;", "&").Replace("mytoken", strToken).Replace("mytimeout", ConfigurationManager.AppSettings["Diffbot_TimeOutIntervalForOperation"]).Replace("myurl", HttpUtility.UrlEncode(objeJobArticle.Url));

                TimeLog(strFinalURL);

                HttpWebRequest request = (HttpWebRequest)WebRequest.Create(strFinalURL);
                request.Timeout = Convert.ToInt32(ConfigurationManager.AppSettings["Diffbot_TimeOutIntervalForOperation"]);
                request.Method = "GET";
                request.ContentType = "application/json; charset=utf-8";
                using (HttpWebResponse response = (HttpWebResponse)request.GetResponse())
                {
                    Stream stream = (Stream)response.GetResponseStream();
                    StreamReader reader = new StreamReader(stream);
                    strOutput = reader.ReadToEnd();
                    objeJobArticle.Output = strOutput;
                    TimeLog("Output Of URL " + objeJobArticle.Url + " is " + objeJobArticle.Output);
                }
                request = null;
            }
            catch (Exception ex)
            {
                //lstLogRecords_Final.Where(w => w.HashUrl == objeJobArticle.HashUrl).ToList().ForEach(z => z.LogComment = "Diffbot Data Failed");
                ErrorLog("FetchData For Url " + strFinalURL, ex.ToString());
                strOutput = "Exception Occured " + ex.ToString();
            }

            strFinalURL = null;

            return objeJobArticle;
        }

        private eArticle_Online ExtractFromDiffbot(eArticle_Online objArticle)
        {

            try
            {
                if (!String.IsNullOrEmpty(objArticle.Output))
                {
                    JObject obj = JObject.Parse(objArticle.Output);
                    if (obj != null)
                    {
                        if (obj["error"] != null && obj["errorCode"] != null)
                        {
                            if (Convert.ToString(obj["errorCode"]) == "404")
                            {
                                objArticle.Text = "404";
                            }
                            objArticle.ErrorCode = Convert.ToString(obj["errorCode"]);
                            objArticle.Error = Convert.ToString(obj["error"]);
                            //lstLogRecords_Final.Where(w => w.HashUrl == objArticle.HashUrl).ToList().ForEach(z => z.LogComment = "Diffbot Data Failed "+objArticle.Error);

                            TimeLog("Output Of URL " + objArticle.Url + " is " + objArticle.Output);
                            obj = null;
                        }
                        else
                        {
                            #region Set output values of diffbot
                            JArray jItems = (JArray)obj["objects"];
                            if (jItems != null)
                            {
                                foreach (JToken jItem in jItems)
                                {

                                    objArticle.DB_Processed = 1;

                                    //Set Sitename
                                    if (jItem["siteName"] != null)
                                    {
                                        objArticle.DB_SiteName = jItem["siteName"].ToString();
                                    }

                                    //Set Sentiment
                                    if (jItem["sentiment"] != null)
                                    {
                                        objArticle.DB_Sentiment = Convert.ToDecimal(jItem["sentiment"].ToString());
                                    }

                                    //Set Author
                                    if (jItem["author"] != null)
                                    {
                                        objArticle.DB_Author = jItem["author"].ToString();
                                    }

                                    //Set AuthorURL
                                    if (jItem["authorUrl"] != null)
                                    {
                                        objArticle.DB_AuthorUrl = jItem["authorUrl"].ToString();
                                    }

                                    //Set Title
                                    if (jItem["title"] != null)
                                    {
                                        objArticle.DB_Title = jItem["title"].ToString();
                                    }

                                    //Set Text
                                    if (jItem["text"] != null)
                                    {
                                        objArticle.DB_Text = jItem["text"].ToString();
                                    }

                                    //Set Date
                                    if (jItem["date"] != null)
                                    {
                                        if (!String.IsNullOrEmpty(jItem["date"].ToString()))
                                        {
                                            TimeLog(jItem["date"].ToString());
                                            try
                                            {
                                                if (Convert.ToString(jItem["date"].ToString()).Contains("GMT"))
                                                {
                                                    objArticle.DB_Date = DateTime.ParseExact(Convert.ToString(jItem["date"].ToString()), "ddd, dd MMM yyyy HH:mm:ss GMT", CultureInfo.InvariantCulture);
                                                    //objArticle.Date = DateTime.Now.AddMinutes(-15);
                                                }
                                                else
                                                {
                                                    objArticle.DB_Date = Convert.ToDateTime(jItem["date"].ToString());
                                                }

                                                if (objArticle.DB_Date.Year <= 1900 || objArticle.DB_Date.Year >= 2050)
                                                {
                                                    objArticle.DB_Date = DateTime.Now;
                                                }
                                            }
                                            catch (Exception exxx)
                                            {
                                                objArticle.DB_Date = DateTime.Now;
                                            }
                                        }
                                    }
                                    else
                                    {
                                        objArticle.DB_Date = DateTime.Now;
                                    }

                                    TimeLog(objArticle.DB_Date.ToString());

                                    //Set PublisherCountry
                                    if (jItem["publisherCountry"] != null)
                                    {
                                        objArticle.DB_PublisherCountry = jItem["publisherCountry"].ToString();
                                    }

                                    //Set HumanLanguage
                                    if (jItem["humanLanguage"] != null)
                                    {
                                        objArticle.DB_Language = jItem["humanLanguage"].ToString();
                                    }

                                    //Set PublisherRegion
                                    if (jItem["publisherRegion"] != null)
                                    {
                                        objArticle.DB_PublisherRegion = jItem["publisherRegion"].ToString();
                                    }

                                    //Set Tags
                                    #region Tags Output
                                    if (jItem["tags"] != null)
                                    {
                                        string strTags = string.Empty;
                                        JArray jTags = (JArray)jItem["tags"];

                                        if (jTags != null)
                                        {
                                            //Set to take only 5 Tags
                                            int iTagCounter = 0;

                                            foreach (JToken jTag in jTags)
                                            {
                                                if (iTagCounter < 5)
                                                {
                                                    if (jTag["label"] != null)
                                                    {
                                                        SetProperty("DB_TagLabel" + (iTagCounter + 1).ToString(), jTag["label"].ToString(), ref objArticle, false);
                                                        strTags += jTag["label"].ToString() + ",";
                                                    }

                                                    if (jTag["score"] != null)
                                                    {
                                                        SetProperty("DB_TagScore" + (iTagCounter + 1).ToString(), jTag["score"].ToString(), ref objArticle, true);
                                                    }

                                                    if (jTag["count"] != null)
                                                    {
                                                        SetProperty("DB_TagCount" + (iTagCounter + 1).ToString(), jTag["count"].ToString(), ref objArticle, false);
                                                    }

                                                    iTagCounter++;
                                                }
                                            }
                                        }

                                        objArticle.DB_Tags = strTags.Trim(',');
                                        jTags = null;
                                    }
                                    #endregion


                                    //Set Images
                                    #region Images Output
                                    if (jItem["images"] != null)
                                    {
                                        string strImages = string.Empty;
                                        JArray jImages = (JArray)jItem["images"];

                                        if (jImages != null)
                                        {
                                            foreach (JToken jTag in jImages)
                                            {
                                                if (jTag["url"] != null)
                                                {
                                                    strImages += jTag["url"].ToString() + ",";
                                                }
                                            }
                                        }

                                        objArticle.DB_Images = strImages.Trim(',');

                                        jImages = null;
                                    }
                                    #endregion

                                }
                            }

                            jItems = null;

                            #endregion
                        }


                    }

                    obj = null;
                }
                else
                {

                }

                //lstLogRecords_Final.Where(w => w.HashUrl == objArticle.HashUrl).ToList().ForEach(z => z.LogComment = "Diffbot Data Processed");
            }
            catch (Exception ex)
            {
                //lstLogRecords_Final.Where(w => w.HashUrl == objArticle.HashUrl).ToList().ForEach(z => z.LogComment = "Diffbot Data Failed");
                ErrorLog("ExtractFromDiffbot", ex.ToString());
            }

            return objArticle;
        }

        //This function will help to set property value of entity dynamically for EngCore
        private void SetProperty(string strPropertyName, string value, ref eArticle_Online objName, bool IsDecimal)
        {
            try
            {
                PropertyInfo propertyInfo = objName.GetType().GetProperty(strPropertyName);
                if (IsDecimal)
                {
                    propertyInfo.SetValue(objName, Convert.ToDecimal(value), null);
                }
                else
                {
                    if (strPropertyName.Contains("TagCount"))
                    {
                        propertyInfo.SetValue(objName, Convert.ToInt32(value), null);
                    }
                    else
                    {
                        propertyInfo.SetValue(objName, Convert.ToString(value), null);
                    }
                }

                propertyInfo = null;
            }
            catch (Exception ex)
            {
                ErrorLog("SetProperty", ex.ToString() + "Property Name : " + strPropertyName + "| " + "Properrty value : " + value);
            }

        }

        #endregion

        #region Images
        public List<eArticle_Online> Process_Images(List<eArticle_Online> lstLinks)
        {
            List<eArticle_Online> lstFinal = new List<eArticle_Online>();

            try
            {

                int counter = 0;
                var stopWatch = Stopwatch.StartNew();
                ParallelOptions po = new ParallelOptions();
                po.MaxDegreeOfParallelism = Convert.ToInt32(ConfigurationManager.AppSettings["Image_MaxDegreeOfParallelism"].ToString());
                System.Net.ServicePointManager.DefaultConnectionLimit = Convert.ToInt32(ConfigurationManager.AppSettings["Image_MaxDegreeOfParallelism"].ToString());

                Parallel.For(0, lstLinks.Count, po, i =>
                {
                    try
                    {
                        TimeLog("Start CreateImage");
                        lstLinks[i].Screenshot_FileName = CreateImage(lstLinks[i].Url, DateTime.Now.ToString("yyyyMMddHHmmssfff"));
                        lstFinal.Add(lstLinks[i]);
                        TimeLog("End CreateImage");
                        counter++;
                    }
                    catch (Exception ex)
                    {
                        ErrorLog("Parallel Error for " + lstLinks[i].Url, ex.ToString());
                    }

                });
                TimeLog("End Parallel.For");
                TimeLog("Parallel.For() execution time for " + " = {0} seconds:" + stopWatch.Elapsed.TotalSeconds);

            }
            catch (Exception ex)
            {
                ErrorLog("Process_Images ", ex.Message + " ->> " + ex.StackTrace);
            }

            return lstFinal;
        }

        private string CreateImage(string strUrl, string strFileName)
        {
            string strFileNameReturn = string.Empty;
            try
            {
                ServicePointManager.SecurityProtocol = (SecurityProtocolType)3072;
                //string strFetchurl = "https://api.urlbox.io/v1/4G9b0Mqi6yniUmhs/png?url=" + HttpUtility.UrlEncode(strUrl) + "&delay=6000";
                string strFetchurl = System.Configuration.ConfigurationManager.AppSettings["Screenshot_APIUrl"].Replace("&amp;", "&").Replace("myurl", HttpUtility.UrlEncode(strUrl));
                strFetchurl = strFetchurl.Replace("\r\n", "");

                TimeLog(strFetchurl);

                WebRequest request = WebRequest.Create(strFetchurl);

                //// Get the response. 
                WebResponse response = request.GetResponse();


                // Get the stream containing content returned by the server.
                Stream dataStream = response.GetResponseStream();
                System.Drawing.Image image = System.Drawing.Image.FromStream(dataStream);
                string strPath = System.Configuration.ConfigurationManager.AppSettings["ScreenshotSavePath_Online"] + strFileName + ".jpg";//ConfigurationManager.AppSettings["ScreenshotExtension"];
                image.Save(strPath);
                strFileNameReturn = strFileName + ".jpg";
            }
            catch (Exception ex)
            {
                ErrorLog("CreateImage", strUrl + " ->" + ex.ToString());
            }

            return strFileNameReturn;
        }
        #endregion

        #region INSERT

        public bool InsertArticles(List<eArticle_Online> lstLinks, ref List<eArticle_Online> lstLogRecords_Final)
        {
            bool IsSuccessful = true;
            try
            {
                for (int i = 0; i < lstLinks.Count; i++)
                {
                    try
                    {
                        TimeLog("Start InsertArticle");
                        new MDB.DAL.DAL().InsertArticle(lstLinks[i]);
                        TimeLog("End InsertArticle");
                        lstLogRecords_Final.Where(w => w.HashUrl == lstLinks[i].HashUrl).ToList().ForEach(z => z.LogComment = "Inserted In DB");
                    }
                    catch (Exception ex)
                    {
                        IsSuccessful = false;
                        ErrorLog("For Loop Error for " + lstLinks[i].Url, ex.ToString());
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorLog("InsertArticles ", ex.Message + " ->> " + ex.StackTrace);
            }

            return IsSuccessful;
        }

        #endregion

        #region LOGGING

        //For error logging
        private void ErrorLog(string functionName, string error)
        {
            try
            {
                string LogPath = ConfigurationManager.AppSettings["TwitterArticle_ErrorLogPath"];
                using (TextWriter myWriter = File.AppendText(LogPath))
                {

                    TextWriter.Synchronized(myWriter).WriteLine("<--> :{0}", string.Empty);
                    TextWriter.Synchronized(myWriter).WriteLine("Function Name :{0}", functionName);
                    TextWriter.Synchronized(myWriter).WriteLine("Error :{0}", error);
                    TextWriter.Synchronized(myWriter).WriteLine("Date :{0}", DateTime.Now.ToString());
                    TextWriter.Synchronized(myWriter).WriteLine("<--> :{0}", string.Empty);
                    TextWriter.Synchronized(myWriter).Flush();
                    TextWriter.Synchronized(myWriter).Close();
                }
            }
            catch (Exception ex)
            {
            }
        }

        //For debugging purpose
        private void TimeLog(string strtext)
        {
            try
            {
                string LogPath = ConfigurationManager.AppSettings["TwitterArticle_TimeLogPath"];
                using (TextWriter myWriter = File.AppendText(LogPath))
                {

                    TextWriter.Synchronized(myWriter).WriteLine("<--> :{0}", string.Empty);
                    TextWriter.Synchronized(myWriter).WriteLine("TimeLog :{0}", strtext);
                    TextWriter.Synchronized(myWriter).WriteLine("Date :{0}", DateTime.Now.ToString());
                    TextWriter.Synchronized(myWriter).WriteLine("<--> :{0}", string.Empty);
                    TextWriter.Synchronized(myWriter).Flush();
                    TextWriter.Synchronized(myWriter).Close();
                }
            }
            catch (Exception ex)
            {
                ErrorLog("TimeLog", ex.ToString());
            }
        }

        #endregion

        #region Relevancy
        public List<eArticle_Online> GetRelevantLinks(List<eArticle_Online> lstLinks, string strQuery, Int32 strQueryID, ref List<eArticle_Online> lstLogRecords_Final)
        {
            List<eArticle_Online> lstFinal = new List<eArticle_Online>();

            try
            {
                string strOutput = string.Empty;
                //Create Input File For Relevancy And Get Relevant Links And Then Run ForEach
                TimeLog("ConstructInputForRelevancy Started For " + strQuery);
                XmlDocument inputxmlForRelevancy = ConstructInputForRelevancy(lstLinks);
                TimeLog("ConstructInputForRelevancy Ended For " + strQuery);

                if (lstLinks.Count > 0)
                {
                    TimeLog("Total links are " + lstLinks.Count);

                    RelevancyChecker objRC = new RelevancyChecker();
                    Guid BatchID = Guid.NewGuid();

                    TimeLog("Get Relevant Links Started For " + strQuery);
                    strOutput = objRC.MainFunc(inputxmlForRelevancy.InnerXml.ToString(), strQuery, BatchID.ToString() + ConfigurationManager.AppSettings["SolrRelevancy_BatchType"], "SENTRY-News");
                    if (strOutput == string.Empty)
                    {
                        ErrorLog("Problem In Relevancy Pipe", "Problem In Relevancy Pipe");
                    }

                    TimeLog("Get Relevant Links Ended For " + strQuery);

                    XmlDocument docWAR = new XmlDocument();
                    if (!String.IsNullOrEmpty(strOutput))
                    {
                        docWAR.LoadXml(strOutput);
                    }


                    foreach (eArticle_Online feed in lstLinks)
                    {
                        try
                        {
                            String HashID = feed.HashUrl;
                            bool foundLink = false;
                            XmlNode nds = docWAR.SelectSingleNode("/RelevancyRequest/Output");
                            XmlNode nd = nds.SelectSingleNode("params[ID='" + HashID + "']");
                            if (nd != null)
                            {
                                foundLink = true;
                            }

                            if (foundLink)
                            {
                                lstFinal.Add(feed);
                                lstLogRecords_Final.Where(w => w.HashUrl == feed.HashUrl).ToList().ForEach(z => z.LogComment = "Solr Found Relevant");
                            }
                            else
                            {
                                lstLogRecords_Final.Where(w => w.HashUrl == feed.HashUrl).ToList().ForEach(z => z.LogComment = "Solr Found Not Relevant");
                            }
                        }
                        catch (Exception ex)
                        {
                            ErrorLog("For Loop  " + feed.Url, ex.Message + " ->> " + ex.StackTrace);
                        }
                    }

                    TimeLog("Relevant links are " + lstFinal.Count);
                }
            }
            catch (Exception ex)
            {
                ErrorLog("GetRelevantLinks ", ex.Message + " ->> " + ex.StackTrace);
            }

            return lstFinal;
        }

        private XmlDocument ConstructInputForRelevancy(List<eArticle_Online> objFeeds)
        {
            XmlDocument inputXML = new XmlDocument();

            try
            {
                string xmlFilePath = ConfigurationManager.AppSettings["InputXMLForRelevancy"].ToString();
                inputXML.Load(xmlFilePath);

                XmlNode nodeRequest = inputXML.SelectSingleNode("/RelevancyRequest/BatchID");
                nodeRequest.InnerText = Guid.NewGuid().ToString();

                XmlNode nodeParameters = inputXML.SelectSingleNode("/RelevancyRequest/Input/Parameters");

                foreach (eArticle_Online node in objFeeds)
                {
                    try
                    {
                        if (!String.IsNullOrEmpty(node.Url))
                        {
                            string hashID = node.HashUrl;
                            string URL = node.Url;

                            XmlNode nodeParams = inputXML.CreateElement("Params");
                            nodeParameters.AppendChild(nodeParams);

                            XmlNode attrLink = inputXML.CreateElement("Link");
                            attrLink.InnerText = URL;
                            nodeParams.AppendChild(attrLink);

                            XmlNode attrHashID = inputXML.CreateElement("HashID");
                            attrHashID.InnerText = hashID;
                            nodeParams.AppendChild(attrHashID);

                            XmlNode attrNoiseCancelledContent = inputXML.CreateElement("NoiseCancelledContent");
                            string strNoiseCancelledContent = string.Empty;

                            TimeLog("node.DB_Title -> " + node.DB_Title + " || node.DB_Text -> " + node.DB_Text + " || node.ADID -> " + node.ADID + " || URL -> " + URL);

                            if (!String.IsNullOrEmpty(node.DB_Title))
                            {
                                strNoiseCancelledContent = strNoiseCancelledContent + node.DB_Title;
                            }
                            else
                            {
                                //strNoiseCancelledContent = strNoiseCancelledContent + node.Title;
                                ErrorLog("node.DB_Title Is Empty ", node.ADID + " -> " + URL);

                            }

                            if (!String.IsNullOrEmpty(node.DB_Text))
                            {
                                strNoiseCancelledContent = strNoiseCancelledContent + " " + node.DB_Text;
                            }
                            else
                            {
                                //strNoiseCancelledContent = strNoiseCancelledContent + node.Text;
                                ErrorLog("node.DB_Text Is Empty ", node.ADID + " -> " + URL);
                            }



                            attrNoiseCancelledContent.InnerText = strNoiseCancelledContent;
                            nodeParams.AppendChild(attrNoiseCancelledContent);
                        }
                    }
                    catch (Exception ex)
                    {
                        ErrorLog("ConstructInputForRelevancy For Loop ", ex.Message + " ->> " + ex.StackTrace);
                    }

                }

            }
            catch (Exception ex)
            {
                ErrorLog("ConstructInputForRelevancy ", ex.Message + " ->> " + ex.StackTrace);
            }

            return inputXML;
        }
        #endregion

        #region PublicationType
        public List<eArticle_Online> Process_Publications(List<eArticle_Online> lstLinks)
        {
            List<eArticle_Online> lstFinal = new List<eArticle_Online>();

            try
            {

                int counter = 0;
                var stopWatch = Stopwatch.StartNew();
                ParallelOptions po = new ParallelOptions();
                po.MaxDegreeOfParallelism = Convert.ToInt32(ConfigurationManager.AppSettings["ProcessPublication_MaxDegreeOfParallelism"].ToString());
                System.Net.ServicePointManager.DefaultConnectionLimit = Convert.ToInt32(ConfigurationManager.AppSettings["ProcessPublication_MaxDegreeOfParallelism"].ToString());

                Parallel.For(0, lstLinks.Count, po, i =>
                {
                    try
                    {
                        TimeLog("Start FetchPublicationType");
                        TimeLog("lstLinks[i].PublicationType is " + lstLinks[i].PublicationType);
                        if (String.IsNullOrEmpty(lstLinks[i].PublicationType))
                        {
                            string strPublicationType = FetchPublicationType(lstLinks[i].Publication_Url);
                            TimeLog("strPublicationType is " + strPublicationType);
                            lstLinks.Where(w => w.Publication_Url == lstLinks[i].Publication_Url).ToList().ForEach(j => j.PublicationType = strPublicationType);
                        }
                        else
                        {

                        }

                        TimeLog("End FetchPublicationType");
                        counter++;
                    }
                    catch (Exception ex)
                    {
                        ErrorLog("Parallel Error for " + lstLinks[i].Url, ex.ToString());
                    }

                });
                TimeLog("End Parallel.For");
                TimeLog("Parallel.For() execution time for " + " = {0} seconds:" + stopWatch.Elapsed.TotalSeconds);

            }
            catch (Exception ex)
            {
                ErrorLog("Process_Publications ", ex.Message + " ->> " + ex.StackTrace);
            }

            return lstLinks;
        }


        public string FetchPublicationType(string domain)
        {
            string strOutput = string.Empty;

            try
            {
                string strFinalURL = string.Empty;
                string strURL_Service = ConfigurationManager.AppSettings["Url_PublicationTypeChecker"].ToString();

                if (!String.IsNullOrEmpty(strURL_Service))
                {
                    dynamic json = new JObject();
                    json.domain = domain;

                    //Create bytes array to send Input as parameter

                    byte[] bytes = bytes = Encoding.UTF8.GetBytes(Convert.ToString(json));//System.Text.Encoding.GetEncoding("ISO-8859-1").GetBytes(strParameters);

                    HttpWebRequest request = (HttpWebRequest)WebRequest.Create(strURL_Service);
                    request.Timeout = Convert.ToInt32(ConfigurationManager.AppSettings["TimeOutIntervalForOperation_PublicationType"]);
                    request.ContentType = "application/json; charset=utf8";
                    request.ContentLength = bytes.Length;
                    request.Method = "POST";
                    //Console.WriteLine("request sent");
                    //Upload bytes array to request
                    using (Stream os = request.GetRequestStream())
                    {
                        os.Write(bytes, 0, bytes.Length);
                    }

                    //Get response from TextProcessingPipeline

                    using (System.Net.WebResponse resp = request.GetResponse())
                    {
                        using (StreamReader sr = new StreamReader(resp.GetResponseStream()))
                        {
                            strOutput = sr.ReadToEnd().Trim();
                            string summary = string.Empty;
                            if (!String.IsNullOrEmpty(strOutput))
                            {
                                dynamic stuff = JObject.Parse(strOutput);
                                summary = stuff.domain_type;
                                strOutput = summary;
                            }
                            else
                            {
                                strOutput = "Non News";
                            }

                        }
                        request = null;
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorLog("FetchPublicationType :", ex.ToString());
                strOutput = "Non News";
            }
            return strOutput;
        }
        #endregion

        #region EXTRA

        //ExtractDomainame
        private static string ExtractDomainame(string URL)
        {
            try
            {
                string strDomain = Regex.Replace(URL, @"^([a-zA-Z]+:\/\/)?([^\/]+)\/.*?$", "$2");
                strDomain = strDomain.ToLower();
                strDomain = strDomain.Replace("www.", "");
                return strDomain;

            }
            catch (Exception ex) { return ""; }
        }

        //ExtractDomainame
        private static string GetRedirectedUrl(string URL)
        {
            try
            {
                try
                {
                    HttpWebRequest request = (HttpWebRequest)WebRequest.Create(URL);
                    request.UserAgent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.81 Safari/537.36";
                    using (HttpWebResponse response = (HttpWebResponse)request.GetResponse())
                    {
                        URL = response.ResponseUri.ToString();
                    }
                }
                catch (Exception ex)
                {
                    if (ex.Message.ToString().Contains("SSL/TLS"))
                    {
                        try
                        {
                            ServicePointManager.Expect100Continue = true;
                            ServicePointManager.SecurityProtocol = (SecurityProtocolType)3072;
                            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(URL);
                            request.UserAgent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.81 Safari/537.36";
                            using (HttpWebResponse response = (HttpWebResponse)request.GetResponse())
                            {
                                URL = response.ResponseUri.ToString();
                            }
                        }
                        catch (Exception exxcd)
                        {
                            
                        }
                    }
                }

                return URL;
            }
            catch (Exception ex) { return ""; }
        }

        public string CalculateHash(string value)
        {
            try
            {
                var data = System.Text.Encoding.ASCII.GetBytes(value);
                data = System.Security.Cryptography.SHA256.Create().ComputeHash(data);
                return Convert.ToBase64String(data);
            }
            catch (Exception ex)
            {
                return Convert.ToBase64String(System.Text.Encoding.ASCII.GetBytes(string.Empty));
            }
        }
        #endregion

    }
}
