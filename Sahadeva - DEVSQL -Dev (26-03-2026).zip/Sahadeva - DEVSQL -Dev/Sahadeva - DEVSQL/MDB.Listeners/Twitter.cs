﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Configuration;
using System.IO;
using MDB.Entities;
using Newtonsoft.Json.Linq;
using System.Globalization;
using System.Diagnostics;
using System.Threading.Tasks;
using System.Net;
using System.Reflection;
using SolrNet.Utils;
using System.Text.RegularExpressions;
using Newtonsoft.Json;

namespace MDB.Listeners
{
    public class Twitter
    {
        #region Twitter

        public void Process(List<eEntityQuery> lstQueries)
        {
            try
            {
                #region Creating And Setting ParallelOptions
                var stopWatch = Stopwatch.StartNew();
                ParallelOptions po = new ParallelOptions();
                po.MaxDegreeOfParallelism = Convert.ToInt32(ConfigurationManager.AppSettings["Twitter_MaxDegreeOfParallelism"].ToString());
                System.Net.ServicePointManager.DefaultConnectionLimit = Convert.ToInt32(ConfigurationManager.AppSettings["Twitter_MaxDegreeOfParallelism"].ToString());
                #endregion

                Parallel.For(0, lstQueries.Count, po, i =>
                {
                    try
                    {
                        eLog oLog = new eLog();
                        oLog.GUID = Guid.NewGuid().ToString();

                        #region FetchAndExtractFromTwitter
                        TimeLog("Start FetchAndExtractFromTwitter");
                        List<eTwitter> lstTweets = FetchAndExtractFromTwitter(lstQueries[i]);
                        TimeLog("Tweets Count From Twitter Is " + lstTweets.Count);
                        TimeLog("End FetchAndExtractFromTwitter");
                        #endregion

                        #region Insert Tweets
                        TimeLog("Start InsertTweets");
                        bool IsSuccessful = InsertTweets(lstTweets);
                        TimeLog("End InsertTweets");

                        #endregion

                    }
                    catch (Exception ex)
                    {
                        ErrorLog("Parallel Error for " + lstQueries[i].Query, ex.ToString());
                    }

                });
                TimeLog("End Parallel.For");
                TimeLog("Parallel.For() execution time for " + " = {0} seconds:" + stopWatch.Elapsed.TotalSeconds);

            }
            catch (Exception ex)
            {
                ErrorLog("Process_Twitter ", ex.Message + " ->> " + ex.StackTrace);
            }
        }

        public List<eTwitter> FetchAndExtractFromTwitter(eEntityQuery objEQ)
        {
            List<eTwitter> lstFinal = new List<eTwitter>();

            TimeLog("Start Fetching From Twitter Query Is " + objEQ.Query);

            try
            {
                string strNext_Token = string.Empty;

                Int32 Twitter_NoOfPages = Convert.ToInt32(ConfigurationManager.AppSettings["Twitter_NoOfPages"]);
                for (int i = 0; i < Twitter_NoOfPages; i++)
                {
                    TimeLog("Start FetchTweets Query Is " + objEQ.Query);
                    string strOutput = FetchTweets(objEQ, strNext_Token);
                    TimeLog("strOutput Is " + strOutput + " For " + objEQ.Query);
                    TimeLog("End FetchTweets Query Is " + objEQ.Query);

                    TimeLog("Start ExtractTweetsFromJson Query Is " + objEQ.Query);
                    List<eTwitter> lstTweets = ExtractTweetsFromJson(strOutput, objEQ);

                    if (lstTweets.Count > 0)
                    {
                        lstFinal.AddRange(lstTweets);
                    }

                    TimeLog("End ExtractTweetsFromJson Query Is " + objEQ.Query);

                    if (lstTweets.Count > 0)
                    {
                        if (String.IsNullOrEmpty(lstTweets[0].next_token))
                        {
                            TimeLog("No Next_Token");
                            break;
                        }
                        else
                        {
                            strNext_Token = lstTweets[0].next_token;
                            TimeLog("Found Next_Token " + strNext_Token);
                        }
                    }
                    else
                    {
                        break;
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorLog("FetchAndExtractFromTwitter", ex.ToString() + " Query Is " + objEQ.Query);
            }

            TimeLog("End Fetching From Twitter Query Is " + objEQ.Query);

            return lstFinal;
        }

        
        public static string EscapeUriDataStringRfc3986(string value)
        {
            StringBuilder escaped = new StringBuilder(Uri.EscapeDataString(value));
            string[] UriRfc3986CharsToEscape = new[] { "!", "*", "'", "(", ")" };

            // Upgrade the escaping to RFC 3986, if necessary.
            for (int i = 0; i < UriRfc3986CharsToEscape.Length; i++)
            {
                escaped.Replace(UriRfc3986CharsToEscape[i], Uri.HexEscape(UriRfc3986CharsToEscape[i][0]));
            }

            // Return the fully-RFC3986-escaped string.
            return escaped.ToString();
        }

        private string FetchTweets(eEntityQuery objEQ, string next_token)
        {
            string json = string.Empty;

            try
            {
                string strRequestUrl = ConfigurationManager.AppSettings["Twitter_SearchRecentUrl"];
                string strBearerToken = ConfigurationManager.AppSettings["Twitter_BearerToken"];

                // oauth application keys
                //strBearerToken  = "Bearer AAAAAAAAAAAAAAAAAAAAAEnOrgEAAAAAugLZaFdz7UAnnBrNrmS4Qt0wTuc%3DXCM5qJ8XkjVI42ooM7KFOZRQdb6I3Q1bkhyOypII3A1MzjZvsZ";

                string strQuery = objEQ.Query;
                //strQuery = "byju";

                Dictionary<string, string> parameters = new Dictionary<string, string>();
                parameters.Add("query", EscapeUriDataStringRfc3986(strQuery));
                parameters.Add("tweet.fields", "conversation_id,attachments,author_id,context_annotations,created_at,entities,geo,id,in_reply_to_user_id,lang,possibly_sensitive,public_metrics,referenced_tweets,source,text,withheld,note_tweet");
                parameters.Add("user.fields", "created_at,description,entities,id,location,name,pinned_tweet_id,profile_image_url,protected,public_metrics,url,username,verified,withheld,verified_type");
                parameters.Add("expansions", "attachments.poll_ids,attachments.media_keys,author_id,geo.place_id,in_reply_to_user_id,referenced_tweets.id,entities.mentions.username,referenced_tweets.id.author_id");
                parameters.Add("media.fields", "duration_ms,height,media_key,preview_image_url,type,url,width,public_metrics,organic_metrics,promoted_metrics,alt_text,variants");
                parameters.Add("max_results", "100");
                parameters.Add("start_time", DateTime.Now.AddMinutes(-350).ToString("yyyy-MM-ddTHH:mm:ss.000Z"));
                
                //parameters.Add("since_id", "1743672934907146474");

                if (next_token != "")
                {
                    parameters.Add("next_token", next_token);
                }

                if (parameters.Count == 0)
                    return string.Empty;
                Dictionary<string, string>.KeyCollection.Enumerator keys = parameters.Keys.GetEnumerator();
                keys.MoveNext();
                StringBuilder sbp = new StringBuilder(
                    string.Format("{0}={1}", keys.Current, parameters[keys.Current]));
                while (keys.MoveNext())
                {
                    if (keys.Current.ToString() != "start_time")
                    {
                        sbp.AppendFormat("&{0}={1}", keys.Current, Uri.EscapeDataString(parameters[keys.Current]));
                    }
                    else
                    {
                        sbp.AppendFormat("&{0}={1}", keys.Current, parameters[keys.Current]);
                    }

                }


                ServicePointManager.SecurityProtocol = (SecurityProtocolType)3072;

                HttpWebRequest request = GetHttpWebRequest(string.Format("{0}?{1}", strRequestUrl, sbp), strBearerToken);
               
                using (HttpWebResponse response = (HttpWebResponse)request.GetResponse())
                {
                    Stream stream = (Stream)response.GetResponseStream();
                    StreamReader reader = new StreamReader(stream);
                    json = reader.ReadToEnd();
                }

                return json;
            }
            catch (Exception ex)
            {
                json = ex.Message;
                if (json.ToLower().Contains("too many requests") || json.ToLower().Contains("(429) client error"))
                {
                    //CHANGING ACCESS TOKEN VALUE 
                    //UpdateTwitterAccesstokens();
                }

                throw ex;
                //return json;               
            }
        }

        //This returns the web client for a randomly selected proxy from specific list of proxies
        private HttpWebRequest GetHttpWebRequest(string strURL, string sb)
        {
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(strURL);
            try
            {
                request.Timeout = Convert.ToInt32(1800000);
                request.Method = "GET";
                request.Headers.Add(
                    "Authorization", sb.ToString());
                request.ContentType = "application/json; charset=utf-8";

            }
            catch (Exception ex)
            {
                throw ex;
            }

            return request;
        }

        private List<eTwitter> ExtractTweetsFromJson(string strOutput, eEntityQuery objEQ)
        {
            List<eTwitter> lstTwitter = new List<eTwitter>();
            try
            {
                if (!String.IsNullOrEmpty(strOutput))
                {
                    JObject obj = JObject.Parse(strOutput);
                    if (obj != null)
                    {

                        #region Etract json

                        JArray jItems = (JArray)obj["data"];

                        JObject jMeta = (JObject)obj["meta"];
                        string next_token = string.Empty;

                        if (jMeta != null)
                        {
                            if (jMeta["next_token"] != null && !string.IsNullOrEmpty(Convert.ToString(jMeta["next_token"])))
                            {
                                next_token = Convert.ToString(jMeta["next_token"].ToString());
                            }
                        }

                        if (jItems != null)
                        {
                            foreach (JToken jItem in jItems)
                            {
                                eTwitter objTwitter = new eTwitter();

                                objTwitter.EntityID = objEQ.EntityID;
                                objTwitter.EQID = objEQ.EQID;
                                objTwitter.TopicID = objEQ.TopicID;
                                objTwitter.ServiceID = 4;
                                objTwitter.TypeOfListening = "Query";

                                try
                                {
                                    if (!string.IsNullOrEmpty(Convert.ToString(jItem["id"])))
                                    {
                                        objTwitter.Tweet_ID = Convert.ToString(jItem["id"].ToString());
                                    }

                                    JObject jItems_includes = JObject.Parse(obj["includes"].ToString());

                                    JArray media = (JArray)jItems_includes["media"];

                                    JArray jItems_users = (JArray)jItems_includes["users"];

                                    JArray jItems_tweets = (JArray)jItems_includes["tweets"];

                                    #region Extraction from Data Array

                                    if (!string.IsNullOrEmpty(Convert.ToString(jItem["id"])))
                                    {
                                        objTwitter.Tweet_ID = Convert.ToString(jItem["id"].ToString());
                                    }

                                    if (!string.IsNullOrEmpty(Convert.ToString(jItem["text"])))
                                    {
                                        objTwitter.Tweet_Text = Convert.ToString(jItem["text"]);
                                    }

                                    if (jItem["note_tweet"] != null)
                                    {
                                        objTwitter.Tweet_Text = Convert.ToString(jItem["note_tweet"]["text"]);
                                    }

                                    if (!string.IsNullOrEmpty(Convert.ToString(jItem["created_at"])))
                                    {
                                        //objTwitter.Tweet_Date = DateTime.ParseExact(jItem["created_at"].ToString(), "ddd MMM dd HH:mm:ss zzzz yyyy", CultureInfo.InvariantCulture).ToLocalTime();
                                        objTwitter.Tweet_Date = Convert.ToDateTime(jItem["created_at"].ToString());
                                    }

                                    if (!string.IsNullOrEmpty(Convert.ToString(jItem["conversation_id"])))
                                    {
                                        objTwitter.Tweet_ConversationID = Convert.ToString(jItem["conversation_id"]);
                                    }

                                    if (!string.IsNullOrEmpty(Convert.ToString(jItem["lang"])))
                                    {
                                        objTwitter.Tweet_Language = Convert.ToString(jItem["lang"]);
                                    }

                                    if (jItem["referenced_tweets"] != null)
                                    {

                                        objTwitter.Tweet_IsReplied = 0;
                                        objTwitter.Tweet_IsRetweeted = 0;
                                        objTwitter.Tweet_IsQuoted = 0;

                                        #region Referenced_tweets Array
                                        JArray referenced_tweets = (JArray)jItem["referenced_tweets"];
                                        if (referenced_tweets != null)
                                        {
                                            foreach (var User in jItems_users)
                                            {
                                                if (Convert.ToString(jItem["author_id"].ToString()) == Convert.ToString(User["id"].ToString()))
                                                {

                                                    foreach (var item_referenced_tweets in referenced_tweets)
                                                    {
                                                        if (Convert.ToString(item_referenced_tweets["type"].ToString()) == "retweeted")
                                                        {
                                                            
                                                            objTwitter.Tweet_IsRetweeted = 1;
                                                            objTwitter.Tweet_RetweetedToTweetID = Convert.ToString(item_referenced_tweets["id"].ToString());

                                                            foreach (var item_jItems_tweets in jItems_tweets)
                                                            {
                                                                if (Convert.ToString(item_jItems_tweets["id"].ToString()) == objTwitter.Tweet_RetweetedToTweetID)
                                                                {
                                                                    objTwitter.Tweet_RetweetedTo = "https://twitter.com/" + Convert.ToString(item_jItems_tweets["author_id"]) + "/status/" + objTwitter.Tweet_RetweetedToTweetID;

                                                                    if (objTwitter.Tweet_Text.IndexOf(":") > 0)
                                                                    {

                                                                        if (item_jItems_tweets["note_tweet"] != null)
                                                                        {
                                                                            objTwitter.Tweet_Text = objTwitter.Tweet_Text.ToString().Substring(0, objTwitter.Tweet_Text.IndexOf(":")) + " : " + Convert.ToString(item_jItems_tweets["note_tweet"]["text"]);
                                                                        }
                                                                        else
                                                                        {
                                                                            objTwitter.Tweet_Text = objTwitter.Tweet_Text.ToString().Substring(0, objTwitter.Tweet_Text.IndexOf(":")) + " : " + Convert.ToString(item_jItems_tweets["text"]);
                                                                        }
                                                                    }
                                                                }
                                                            }
                                                        }
                                                        else if (Convert.ToString(item_referenced_tweets["type"].ToString()) == "replied_to")
                                                        {
                                                            //objTwitter.Tweet_RepliedTo = "https://twitter.com/" + Convert.ToString(User["username"].ToString()) + "/status/" + Convert.ToString(item_referenced_tweets["id"].ToString());
                                                            objTwitter.Tweet_IsReplied = 1;
                                                            objTwitter.Tweet_RepliedToTweetID = Convert.ToString(item_referenced_tweets["id"].ToString());

                                                            foreach (var item_jItems_tweets in jItems_tweets)
                                                            {
                                                                if (Convert.ToString(item_jItems_tweets["id"].ToString()) == objTwitter.Tweet_RepliedToTweetID)
                                                                {
                                                                    objTwitter.Tweet_RepliedTo = "https://twitter.com/" + Convert.ToString(item_jItems_tweets["author_id"]) + "/status/" + objTwitter.Tweet_RepliedToTweetID;

                                                                    if (item_jItems_tweets["note_tweet"] != null)
                                                                    {
                                                                        objTwitter.Tweet_RepliedToText =  Convert.ToString(item_jItems_tweets["note_tweet"]["text"]);
                                                                    }
                                                                    else
                                                                    {
                                                                        objTwitter.Tweet_RepliedToText = Convert.ToString(item_jItems_tweets["text"]);
                                                                    } 
                                                                }
                                                            }

                                                        }
                                                        else if (Convert.ToString(item_referenced_tweets["type"].ToString()) == "quoted")
                                                        {
                                                            //objTwitter.Tweet_QuotedTo = "https://twitter.com/" + Convert.ToString(User["username"].ToString()) + "/status/" + Convert.ToString(item_referenced_tweets["id"].ToString());
                                                            objTwitter.Tweet_IsQuoted = 1;
                                                            objTwitter.Tweet_QuotedToTweetID = Convert.ToString(item_referenced_tweets["id"].ToString());

                                                            foreach (var item_jItems_tweets in jItems_tweets)
                                                            {
                                                                if (Convert.ToString(item_jItems_tweets["id"].ToString()) == objTwitter.Tweet_QuotedToTweetID)
                                                                {
                                                                    objTwitter.Tweet_QuotedTo = "https://twitter.com/" + Convert.ToString(item_jItems_tweets["author_id"]) + "/status/" + objTwitter.Tweet_QuotedToTweetID;
                                                                    
                                                                    if (item_jItems_tweets["note_tweet"] != null)
                                                                    {
                                                                        objTwitter.Tweet_QuotedToText = Convert.ToString(item_jItems_tweets["note_tweet"]["text"]);
                                                                    }
                                                                    else
                                                                    {
                                                                        objTwitter.Tweet_QuotedToText = Convert.ToString(item_jItems_tweets["text"]);
                                                                    } 
                                                                }
                                                            }
                                                        }
                                                    }


                                                }
                                            }
                                        }
                                        #endregion
                                    }
                                    if (!string.IsNullOrEmpty(Convert.ToString(jItem["source"])))
                                    {
                                        objTwitter.Tweet_Source = Convert.ToString(jItem["source"].ToString());
                                        //objTwitter._SourceLink = strLink;
                                    }

                                    #region Engagagement
                                    if (jItem["public_metrics"] != null)
                                    {
                                        JObject public_metrics = JObject.Parse(jItem["public_metrics"].ToString());
                                        if (!string.IsNullOrEmpty(Convert.ToString(public_metrics["retweet_count"])))
                                        {
                                            objTwitter.Engagement_RetweetCount = Convert.ToInt64(public_metrics["retweet_count"].ToString());
                                        }
                                        if (!string.IsNullOrEmpty(Convert.ToString(public_metrics["like_count"])))
                                        {
                                            objTwitter.Engagement_LikeCount = Convert.ToInt64(public_metrics["like_count"].ToString());
                                        }
                                        if (!string.IsNullOrEmpty(Convert.ToString(public_metrics["reply_count"])))
                                        {
                                            objTwitter.Engagement_ReplyCount = Convert.ToInt64(public_metrics["reply_count"].ToString());
                                        }
                                        if (!string.IsNullOrEmpty(Convert.ToString(public_metrics["quote_count"])))
                                        {
                                            objTwitter.Engagement_QuoteCount = Convert.ToInt64(public_metrics["quote_count"].ToString());
                                        }
                                        if (!string.IsNullOrEmpty(Convert.ToString(public_metrics["bookmark_count"])))
                                        {
                                            objTwitter.Engagement_BookmarkCount = Convert.ToInt64(public_metrics["bookmark_count"].ToString());
                                        }
                                        if (!string.IsNullOrEmpty(Convert.ToString(public_metrics["impression_count"])))
                                        {
                                            objTwitter.Engagement_ViewCount = Convert.ToInt64(public_metrics["impression_count"].ToString());
                                        }
                                    }
                                    #endregion

                                    if (jItem["entities"] != null)
                                    {
                                        #region Entities Array
                                        JObject entities = JObject.Parse(jItem["entities"].ToString());

                                        JArray mentions = (JArray)entities["mentions"];
                                        if (mentions != null)
                                        {
                                            foreach (var item in mentions)
                                            {
                                                if (!string.IsNullOrEmpty(Convert.ToString(item["username"])))
                                                {
                                                    objTwitter.Mentioned_Handles += '@' + Convert.ToString(item["username"].ToString() + ",");
                                                }
                                            }
                                            objTwitter.Mentioned_Handles = objTwitter.Mentioned_Handles.Remove(objTwitter.Mentioned_Handles.Length - 1, 1);
                                        }
                                        JArray hashtags = (JArray)entities["hashtags"];
                                        if (hashtags != null)
                                        {
                                            foreach (var item in hashtags)
                                            {
                                                if (!string.IsNullOrEmpty(Convert.ToString(item["tag"])))
                                                {
                                                    objTwitter.Mentioned_Hashtags += "#" + Convert.ToString(item["tag"].ToString() + ",");
                                                }
                                            }
                                            objTwitter.Mentioned_Hashtags = objTwitter.Mentioned_Hashtags.Remove(objTwitter.Mentioned_Hashtags.Length - 1, 1);
                                        }
                                        JArray urls = (JArray)entities["urls"];
                                        if (urls != null)
                                        {
                                            foreach (var item in urls)
                                            {
                                                if (!string.IsNullOrEmpty(Convert.ToString(item["expanded_url"])))
                                                {
                                                    objTwitter.Mentioned_Hyperlinks += Convert.ToString(item["expanded_url"].ToString() + ",");
                                                }

                                                if (!string.IsNullOrEmpty(Convert.ToString(item["media_key"])))
                                                {
                                                    if (media != null)
                                                    {
                                                        foreach (var itemmedia in media)
                                                        {
                                                            if (Convert.ToString(itemmedia["media_key"].ToString()) == Convert.ToString(item["media_key"].ToString()))
                                                            {
                                                                if (!string.IsNullOrEmpty(Convert.ToString(itemmedia["type"])) && Convert.ToString(itemmedia["type"]) == "video")
                                                                {
                                                                    objTwitter.Mentioned_Videos += Convert.ToString(item["expanded_url"].ToString() + ",");

                                                                    if (!string.IsNullOrEmpty(Convert.ToString(itemmedia["public_metrics"])))
                                                                    {
                                                                        objTwitter.Mentioned_Videos_Views = Convert.ToInt32(Convert.ToString(itemmedia["public_metrics"]["view_count"]));
                                                                    }

                                                                    objTwitter.Mentioned_Videos_DurationInMs = Convert.ToInt32(Convert.ToString(itemmedia["duration_ms"]));
                                                                }
                                                            }

                                                            if (Convert.ToString(itemmedia["media_key"].ToString()) == Convert.ToString(item["media_key"].ToString()))
                                                            {
                                                                if (!string.IsNullOrEmpty(Convert.ToString(itemmedia["type"])) && Convert.ToString(itemmedia["type"]) == "photo")
                                                                {
                                                                    objTwitter.Mentioned_Images += Convert.ToString(item["expanded_url"].ToString() + ",");
                                                                }
                                                            }


                                                        }

                                                        if (!String.IsNullOrEmpty(objTwitter.Mentioned_Videos))
                                                        {
                                                            objTwitter.Mentioned_Videos = objTwitter.Mentioned_Videos.Remove(objTwitter.Mentioned_Videos.Length - 1, 1);
                                                        }

                                                        if (!String.IsNullOrEmpty(objTwitter.Mentioned_Images))
                                                        {
                                                            objTwitter.Mentioned_Images = objTwitter.Mentioned_Images.Remove(objTwitter.Mentioned_Images.Length - 1, 1);
                                                        }
                                                    }
                                                }


                                            }
                                            objTwitter.Mentioned_Hyperlinks = objTwitter.Mentioned_Hyperlinks.Remove(objTwitter.Mentioned_Hyperlinks.Length - 1, 1);
                                        }
                                        #endregion
                                    }

                                    #endregion

                                    #region Extraction from Users Array
                                    foreach (var user in jItems_users)
                                    {
                                        if (Convert.ToString(jItem["author_id"].ToString()) == Convert.ToString(user["id"].ToString()))
                                        {
                                            if (!string.IsNullOrEmpty(Convert.ToString(jItem["author_id"])))
                                            {
                                                objTwitter.Profile_ID = Convert.ToString(jItem["author_id"].ToString());
                                            }

                                            if (!string.IsNullOrEmpty(Convert.ToString(user["username"])))
                                            {
                                                objTwitter.Profile_Handle = Convert.ToString(user["username"].ToString());
                                            }
                                            if (!string.IsNullOrEmpty(objTwitter.Profile_Handle))
                                            {
                                                objTwitter.Tweet_URL = "https://twitter.com/" + objTwitter.Profile_Handle + "/status/" + objTwitter.Tweet_ID;
                                            }
                                            if (!string.IsNullOrEmpty(Convert.ToString(user["name"])))
                                            {
                                                string completeName = string.Empty;
                                                string[] Actorfullname = null;

                                                completeName = Convert.ToString(user["name"].ToString());
                                                Actorfullname = completeName.Split(' ');
                                                objTwitter.Profile_Name = completeName;
                                            }

                                            JObject user_public_metrics = JObject.Parse(user["public_metrics"].ToString());
                                            if (user_public_metrics != null)
                                            {
                                                if (!string.IsNullOrEmpty(Convert.ToString(user_public_metrics["followers_count"])))
                                                {
                                                    objTwitter.Profile_FollowersCount = Convert.ToInt64(user_public_metrics["followers_count"].ToString());
                                                }
                                                if (!string.IsNullOrEmpty(Convert.ToString(user_public_metrics["following_count"])))
                                                {
                                                    objTwitter.Profile_FollowingCount = Convert.ToInt64(user_public_metrics["following_count"].ToString());
                                                }
                                                if (!string.IsNullOrEmpty(Convert.ToString(user_public_metrics["tweet_count"])))
                                                {
                                                    objTwitter.Profile_TweetsCount = Convert.ToInt64(user_public_metrics["tweet_count"].ToString());
                                                }
                                                if (!string.IsNullOrEmpty(Convert.ToString(user_public_metrics["listed_count"])))
                                                {
                                                    objTwitter.Profile_ListsCount = Convert.ToInt64(user_public_metrics["listed_count"].ToString());
                                                }
                                            }

                                            if (!string.IsNullOrEmpty(Convert.ToString(user["created_at"])))
                                            {
                                                //objTwitter.Profile_JoinedDate = DateTime.ParseExact(user["created_at"].ToString(), "ddd MMM dd HH:mm:ss zzzz yyyy", CultureInfo.InvariantCulture).ToLocalTime();
                                                objTwitter.Profile_JoinedDate = Convert.ToDateTime(user["created_at"].ToString());
                                            }

                                            if (!string.IsNullOrEmpty(Convert.ToString(user["location"])))
                                            {
                                                objTwitter.Profile_Location = Convert.ToString(user["location"].ToString());
                                            }

                                            if (!string.IsNullOrEmpty(Convert.ToString(user["description"])))
                                            {
                                                objTwitter.Profile_Description = Convert.ToString(user["description"].ToString());
                                            }

                                            if (!string.IsNullOrEmpty(Convert.ToString(user["profile_image_url"])))
                                            {
                                                objTwitter.Profile_ProfilePicUrl = Convert.ToString(user["profile_image_url"].ToString());
                                            }

                                            if (!string.IsNullOrEmpty(Convert.ToString(user["url"])))
                                            {
                                                objTwitter.Profile_ExternalUrl = Convert.ToString(user["url"].ToString());
                                            }

                                            if (!string.IsNullOrEmpty(Convert.ToString(user["verified"])))
                                            {
                                                objTwitter.Profile_IsVerified = Convert.ToInt16(Convert.ToString(user["verified"].ToString()) == "True" ? 1 : 0);
                                            }

                                            if (!string.IsNullOrEmpty(Convert.ToString(user["verified_type"])))
                                            {
                                                objTwitter.Profile_VerifiedType = Convert.ToString(user["verified_type"].ToString());
                                            }

                                            if (!string.IsNullOrEmpty(Convert.ToString(user["protected"])))
                                            {
                                                objTwitter.Profile_IsProtected = Convert.ToInt16(Convert.ToString(user["protected"].ToString()) == "True" ? 1 : 0);
                                            }
                                            break;
                                        }
                                    }
                                    #endregion

                                    objTwitter.next_token = next_token;

                                    lstTwitter.Add(objTwitter);
                                }
                                catch (Exception exx)
                                {
                                    ErrorLog("ExtractTweetsFromJson For Loop For " + objTwitter.Tweet_ID, exx.ToString());
                                }
                            }
                        }

                        jItems = null;

                        #endregion


                    }
                }
            }
            catch (Exception ex)
            {
                ErrorLog("ExtractTweetsFromJson", ex.ToString());
            }

            return lstTwitter;
        }

        #endregion

        #region INSERT

        public bool InsertTweets(List<eTwitter> lstLinks)
        {
            bool IsSuccessful = true;
            try
            {
                for (int i = 0; i < lstLinks.Count; i++)
                {
                    try
                    {
                        TimeLog("Start InsertTweet");
                        new MDB.DAL.DAL().Twitter_InsertTweet(lstLinks[i]);
                        TimeLog("End InsertTweet");
                    }
                    catch (Exception ex)
                    {
                        IsSuccessful = false;
                        ErrorLog("For Loop Error for " + lstLinks[i].Tweet_ID, ex.ToString());
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorLog("InsertTweets ", ex.Message + " ->> " + ex.StackTrace);
            }

            return IsSuccessful;
        }

        #endregion

        #region LOGGING

        //For error logging
        private void ErrorLog(string functionName, string error)
        {
            try
            {
                string LogPath = ConfigurationManager.AppSettings["Twitter_ErrorLogPath"];
                using (TextWriter myWriter = File.AppendText(LogPath))
                {

                    TextWriter.Synchronized(myWriter).WriteLine("<--> :{0}", string.Empty);
                    TextWriter.Synchronized(myWriter).WriteLine("Function Name :{0}", functionName);
                    TextWriter.Synchronized(myWriter).WriteLine("Error :{0}", error);
                    TextWriter.Synchronized(myWriter).WriteLine("Date :{0}", DateTime.Now.ToString());
                    TextWriter.Synchronized(myWriter).WriteLine("<--> :{0}", string.Empty);
                    TextWriter.Synchronized(myWriter).Flush();
                    TextWriter.Synchronized(myWriter).Close();
                }
            }
            catch (Exception ex)
            {
            }
        }

        //For debugging purpose
        private void TimeLog(string strtext)
        {
            try
            {
                string LogPath = ConfigurationManager.AppSettings["Twitter_TimeLogPath"];
                using (TextWriter myWriter = File.AppendText(LogPath))
                {

                    TextWriter.Synchronized(myWriter).WriteLine("<--> :{0}", string.Empty);
                    TextWriter.Synchronized(myWriter).WriteLine("TimeLog :{0}", strtext);
                    TextWriter.Synchronized(myWriter).WriteLine("Date :{0}", DateTime.Now.ToString());
                    TextWriter.Synchronized(myWriter).WriteLine("<--> :{0}", string.Empty);
                    TextWriter.Synchronized(myWriter).Flush();
                    TextWriter.Synchronized(myWriter).Close();
                }
            }
            catch (Exception ex)
            {
                ErrorLog("TimeLog", ex.ToString());
            }
        }

        #endregion
    }
}
