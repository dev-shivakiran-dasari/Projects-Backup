﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Configuration;
using System.IO;
using MDB.Entities;
using Newtonsoft.Json.Linq;
using System.Globalization;
using System.Diagnostics;
using System.Threading.Tasks;
using System.Net;
using System.Reflection;
using SolrNet.Utils;
using System.Text.RegularExpressions;
using Newtonsoft.Json;
using System.Xml;
using SolrNet;

namespace MDB.Listeners
{
    public class DossierManual
    {
        #region Google

        public void Process(List<eUserDossierUrl> lstUrls)
        {
            try
            {
                #region Creating And Setting ParallelOptions
                var stopWatch = Stopwatch.StartNew();
                ParallelOptions po = new ParallelOptions();
                po.MaxDegreeOfParallelism = Convert.ToInt32(ConfigurationManager.AppSettings["DossierManual_MaxDegreeOfParallelism"].ToString());
                System.Net.ServicePointManager.DefaultConnectionLimit = Convert.ToInt32(ConfigurationManager.AppSettings["DossierManual_MaxDegreeOfParallelism"].ToString());
                #endregion

                Parallel.For(0, lstUrls.Count, po, i =>
                {
                    try
                    {
                        #region ExtractFromUrl
                        TimeLog("Start ExtractFromUrl");
                        List<eArticle_Online> lstArticles = ExtractFromUrl(lstUrls[i]);
                        TimeLog("Articles Count From ExtractFromUrl Is " + lstArticles.Count);
                        TimeLog("End ExtractFromUrl");
                        #endregion

                        string strHashUrls = string.Empty;
                        
                        #region Check Duplicates In Diffbot
                        TimeLog("Start Check Duplicates In Diffbot");
                        strHashUrls = string.Join(",", lstArticles.Select(x => x.HashUrl));
                        lstArticles = new DAL.DAL().CheckDuplicate_Diffbot(strHashUrls, lstArticles);

                        TimeLog("After CheckDuplicate_Diffbot count Is " + lstArticles.Count);
                        TimeLog("End Check Duplicates In ArticleOnline");
                        #endregion

                        #region Process_Diffbot
                        TimeLog("Start Process_Diffbot");
                        List<eArticle_Online> lstlstArticles_Final = new List<eArticle_Online>();
                        lstlstArticles_Final = Process_Diffbot(lstArticles);
                        TimeLog("After Process_Diffbot count Is " + lstlstArticles_Final.Count);
                        TimeLog("End Process_Diffbot");
                        #endregion

                        #region Insert Articles
                        TimeLog("Start InsertArticles");
                        bool IsSuccessful = InsertArticles(lstlstArticles_Final);
                        TimeLog("End InsertArticles");
                        #endregion
                    }
                    catch (Exception ex)
                    {
                        ErrorLog("Parallel Error for " + lstUrls[i].URL, ex.ToString());
                    }

                });
                TimeLog("End Parallel.For");
                TimeLog("Parallel.For() execution time for " + " = {0} seconds:" + stopWatch.Elapsed.TotalSeconds);

            }
            catch (Exception ex)
            {
                ErrorLog("Process_Google ", ex.Message + " ->> " + ex.StackTrace);
            }
        }

        private List<eArticle_Online> ExtractFromUrl(eUserDossierUrl objEQ)
        {
            List<eArticle_Online> lstArticles = new List<eArticle_Online>();

            try
            {

                eArticle_Online Article = new eArticle_Online();
                Article.UDID = objEQ.UDID;
                Article.EntityID = objEQ.EntityID;
                Article.EQID = objEQ.EQID;
                Article.TopicID = objEQ.TopicID;
                Article.ServiceID = 9;
                Article.SERPTab = "DossierManual";
                Article.Url = objEQ.URL;

                if (!String.IsNullOrEmpty(Article.Url))
                {
                    Article.Publication_Url = ExtractDomainame(Article.Url);
                    string strUrl = Article.Url.Replace("https://", "").Replace("http://", "");
                    Article.HashUrl = CalculateHash(strUrl);
                }

                lstArticles.Add(Article);
            }
            catch (Exception ex)
            {
                ErrorLog("ExtractArticlesFromJson", ex.ToString());
            }

            return lstArticles;
        }

        #endregion

        #region DIFFBOT

        public List<eArticle_Online> Process_Diffbot(List<eArticle_Online> lstLinks)
        {
            List<eArticle_Online> lstFinal = new List<eArticle_Online>();

            try
            {
                //create list of tokens
                List<string> lstTokens = ConfigurationManager.AppSettings["Diffbot_Token"].ToString().Split(',').ToList();

                int counter = 0;
                var stopWatch = Stopwatch.StartNew();
                ParallelOptions po = new ParallelOptions();
                po.MaxDegreeOfParallelism = Convert.ToInt32(ConfigurationManager.AppSettings["Diffbot_MaxDegreeOfParallelism"].ToString());
                System.Net.ServicePointManager.DefaultConnectionLimit = Convert.ToInt32(ConfigurationManager.AppSettings["Diffbot_MaxDegreeOfParallelism"].ToString());

                Parallel.For(0, lstLinks.Count, po, i =>
                {
                    try
                    {
                        if (lstLinks[i].ADID > 0)
                        {
                            lstFinal.Add(lstLinks[i]);
                        }
                        else
                        {
                            string strToken = lstTokens[0];
                            if (i % 2 != 0) { strToken = lstTokens[1]; }

                            TimeLog("Start FetchAndExtractFromDiffbot");
                            eArticle_Online objArticle = FetchAndExtractFromDiffbot(lstLinks[i], strToken);
                            lstFinal.Add(objArticle);

                            TimeLog("End FetchAndExtractFromDiffbot");
                        }
                        counter++;
                    }
                    catch (Exception ex)
                    {
                        ErrorLog("Parallel Error for " + lstLinks[i].Url, ex.ToString());
                    }

                });
                TimeLog("End Parallel.For");
                TimeLog("Parallel.For() execution time for " + " = {0} seconds:" + stopWatch.Elapsed.TotalSeconds);

            }
            catch (Exception ex)
            {
                ErrorLog("Process_Diffbot ", ex.Message + " ->> " + ex.StackTrace);
            }

            return lstFinal;
        }

        public eArticle_Online FetchAndExtractFromDiffbot(eArticle_Online objArticle, string strToken)
        {
            TimeLog("Start Fetching From Diffbot URL Is " + objArticle.Url);

            try
            {
                TimeLog("Start GetDiffbotData URL Is " + objArticle.Url);
                objArticle = GetDiffbotData(objArticle, strToken);
                TimeLog("End GetDiffbotData URL Is " + "-> " + objArticle.Url);

                TimeLog("Start ExtractFromDiffbot URL Is " + "-> " + objArticle.Url);
                objArticle = ExtractFromDiffbot(objArticle);
                TimeLog("End ExtractFromDiffbot URL Is " + "-> " + objArticle.Url);
            }
            catch (Exception ex)
            {
                //lstLogRecords_Final.Where(w => w.HashUrl == objArticle.HashUrl).ToList().ForEach(z => z.LogComment = "Diffbot Data Failed");
                ErrorLog("FetchAndExtractFromDiffbot", ex.ToString() + " URL Is " + objArticle.Url);
            }

            TimeLog("End Fetching From Diffbot URL Is " + objArticle.Url);

            return objArticle;
        }

        private eArticle_Online GetDiffbotData(eArticle_Online objeJobArticle, string strToken)
        {

            string strOutput = string.Empty;
            string strFinalURL = string.Empty;
            try
            {
                //Get Diffbot url,tokens,timeout interval for diffbot call from config and form the url
                strFinalURL = ConfigurationManager.AppSettings["Diffbot_URL"].Replace("&amp;", "&").Replace("mytoken", strToken).Replace("mytimeout", ConfigurationManager.AppSettings["Diffbot_TimeOutIntervalForOperation"]).Replace("myurl", HttpUtility.UrlEncode(objeJobArticle.Url));

                TimeLog(strFinalURL);

                HttpWebRequest request = (HttpWebRequest)WebRequest.Create(strFinalURL);
                request.Timeout = Convert.ToInt32(ConfigurationManager.AppSettings["Diffbot_TimeOutIntervalForOperation"]);
                request.Method = "GET";
                request.ContentType = "application/json; charset=utf-8";
                using (HttpWebResponse response = (HttpWebResponse)request.GetResponse())
                {
                    Stream stream = (Stream)response.GetResponseStream();
                    StreamReader reader = new StreamReader(stream);
                    strOutput = reader.ReadToEnd();
                    objeJobArticle.Output = strOutput;
                    TimeLog("Output Of URL " + objeJobArticle.Url + " is " + objeJobArticle.Output);
                }
                request = null;
            }
            catch (Exception ex)
            {
                //lstLogRecords_Final.Where(w => w.HashUrl == objeJobArticle.HashUrl).ToList().ForEach(z => z.LogComment = "Diffbot Data Failed");
                ErrorLog("FetchData For Url " + strFinalURL, ex.ToString());
                strOutput = "Exception Occured " + ex.ToString();
                objeJobArticle.Error = "Error In Diffbot Processing";
            }

            strFinalURL = null;

            return objeJobArticle;
        }

        private eArticle_Online ExtractFromDiffbot(eArticle_Online objArticle)
        {

            try
            {
                if (!String.IsNullOrEmpty(objArticle.Output))
                {
                    JObject obj = JObject.Parse(objArticle.Output);
                    if (obj != null)
                    {
                        if (obj["error"] != null && obj["errorCode"] != null)
                        {
                            if (Convert.ToString(obj["errorCode"]) == "404")
                            {
                                objArticle.Text = "404";
                            }
                            objArticle.ErrorCode = Convert.ToString(obj["errorCode"]);
                            objArticle.Error = objArticle.ErrorCode + "->"+ Convert.ToString(obj["error"]);
                            //lstLogRecords_Final.Where(w => w.HashUrl == objArticle.HashUrl).ToList().ForEach(z => z.LogComment = "Diffbot Data Failed "+objArticle.Error);

                            TimeLog("Output Of URL " + objArticle.Url + " is " + objArticle.Output);
                            obj = null;
                        }
                        else
                        {
                            #region Set output values of diffbot
                            JArray jItems = (JArray)obj["objects"];
                            if (jItems != null)
                            {
                                foreach (JToken jItem in jItems)
                                {

                                    objArticle.DB_Processed = 1;

                                    //Set Sitename
                                    if (jItem["siteName"] != null)
                                    {
                                        objArticle.DB_SiteName = jItem["siteName"].ToString();
                                    }

                                    //Set Sentiment
                                    if (jItem["sentiment"] != null)
                                    {
                                        objArticle.DB_Sentiment = Convert.ToDecimal(jItem["sentiment"].ToString());
                                    }

                                    //Set Author
                                    if (jItem["author"] != null)
                                    {
                                        objArticle.DB_Author = jItem["author"].ToString();
                                    }

                                    //Set AuthorURL
                                    if (jItem["authorUrl"] != null)
                                    {
                                        objArticle.DB_AuthorUrl = jItem["authorUrl"].ToString();
                                    }

                                    //Set Title
                                    if (jItem["title"] != null)
                                    {
                                        objArticle.DB_Title = jItem["title"].ToString();
                                    }

                                    //Set Text
                                    if (jItem["text"] != null)
                                    {
                                        objArticle.DB_Text = jItem["text"].ToString();
                                    }

                                    //Set Date
                                    if (jItem["date"] != null)
                                    {
                                        if (!String.IsNullOrEmpty(jItem["date"].ToString()))
                                        {
                                            TimeLog(jItem["date"].ToString());
                                            try
                                            {
                                                if (Convert.ToString(jItem["date"].ToString()).Contains("GMT"))
                                                {
                                                    objArticle.DB_Date = DateTime.ParseExact(Convert.ToString(jItem["date"].ToString()), "ddd, dd MMM yyyy HH:mm:ss GMT", CultureInfo.InvariantCulture);
                                                    //objArticle.Date = DateTime.Now.AddMinutes(-15);
                                                }
                                                else
                                                {
                                                    objArticle.DB_Date = Convert.ToDateTime(jItem["date"].ToString());
                                                }

                                                if (objArticle.DB_Date.Year <= 1900 || objArticle.DB_Date.Year >= 2050)
                                                {
                                                    objArticle.DB_Date = DateTime.Now;
                                                }
                                            }
                                            catch (Exception exxx)
                                            {
                                                objArticle.DB_Date = DateTime.Now;
                                            }
                                        }
                                    }
                                    else
                                    {
                                        objArticle.DB_Date = DateTime.Now;
                                    }

                                    TimeLog(objArticle.DB_Date.ToString());

                                    //Set PublisherCountry
                                    if (jItem["publisherCountry"] != null)
                                    {
                                        objArticle.DB_PublisherCountry = jItem["publisherCountry"].ToString();
                                    }

                                    //Set HumanLanguage
                                    if (jItem["humanLanguage"] != null)
                                    {
                                        objArticle.DB_Language = jItem["humanLanguage"].ToString();
                                    }

                                    //Set PublisherRegion
                                    if (jItem["publisherRegion"] != null)
                                    {
                                        objArticle.DB_PublisherRegion = jItem["publisherRegion"].ToString();
                                    }

                                    //Set Tags
                                    #region Tags Output
                                    if (jItem["tags"] != null)
                                    {
                                        string strTags = string.Empty;
                                        JArray jTags = (JArray)jItem["tags"];

                                        if (jTags != null)
                                        {
                                            //Set to take only 5 Tags
                                            int iTagCounter = 0;

                                            foreach (JToken jTag in jTags)
                                            {
                                                if (iTagCounter < 5)
                                                {
                                                    if (jTag["label"] != null)
                                                    {
                                                        SetProperty("DB_TagLabel" + (iTagCounter + 1).ToString(), jTag["label"].ToString(), ref objArticle, false);
                                                        strTags += jTag["label"].ToString() + ",";
                                                    }

                                                    if (jTag["score"] != null)
                                                    {
                                                        SetProperty("DB_TagScore" + (iTagCounter + 1).ToString(), jTag["score"].ToString(), ref objArticle, true);
                                                    }

                                                    if (jTag["count"] != null)
                                                    {
                                                        SetProperty("DB_TagCount" + (iTagCounter + 1).ToString(), jTag["count"].ToString(), ref objArticle, false);
                                                    }

                                                    iTagCounter++;
                                                }
                                            }
                                        }

                                        objArticle.DB_Tags = strTags.Trim(',');
                                        jTags = null;
                                    }
                                    #endregion


                                    //Set Images
                                    #region Images Output
                                    if (jItem["images"] != null)
                                    {
                                        string strImages = string.Empty;
                                        JArray jImages = (JArray)jItem["images"];

                                        if (jImages != null)
                                        {
                                            foreach (JToken jTag in jImages)
                                            {
                                                if (jTag["url"] != null)
                                                {
                                                    strImages += jTag["url"].ToString() + ",";
                                                }
                                            }
                                        }

                                        objArticle.DB_Images = strImages.Trim(',');

                                        jImages = null;
                                    }
                                    #endregion

                                }
                            }

                            jItems = null;

                            #endregion
                        }


                    }

                    obj = null;
                }
                else
                {

                }

                //lstLogRecords_Final.Where(w => w.HashUrl == objArticle.HashUrl).ToList().ForEach(z => z.LogComment = "Diffbot Data Processed");
            }
            catch (Exception ex)
            {
                //lstLogRecords_Final.Where(w => w.HashUrl == objArticle.HashUrl).ToList().ForEach(z => z.LogComment = "Diffbot Data Failed");
                ErrorLog("ExtractFromDiffbot", ex.ToString());
                objArticle.Error = "Error In Diffbot Processing";
            }

            return objArticle;
        }

        //This function will help to set property value of entity dynamically for EngCore
        private void SetProperty(string strPropertyName, string value, ref eArticle_Online objName, bool IsDecimal)
        {
            try
            {
                PropertyInfo propertyInfo = objName.GetType().GetProperty(strPropertyName);
                if (IsDecimal)
                {
                    propertyInfo.SetValue(objName, Convert.ToDecimal(value), null);
                }
                else
                {
                    if (strPropertyName.Contains("TagCount"))
                    {
                        propertyInfo.SetValue(objName, Convert.ToInt32(value), null);
                    }
                    else
                    {
                        propertyInfo.SetValue(objName, Convert.ToString(value), null);
                    }
                }

                propertyInfo = null;
            }
            catch (Exception ex)
            {
                ErrorLog("SetProperty", ex.ToString() + "Property Name : " + strPropertyName + "| " + "Properrty value : " + value);
            }

        }

        #endregion

        #region Images
        public List<eArticle_Online> Process_Images(List<eArticle_Online> lstLinks)
        {
            List<eArticle_Online> lstFinal = new List<eArticle_Online>();

            try
            {

                int counter = 0;
                var stopWatch = Stopwatch.StartNew();
                ParallelOptions po = new ParallelOptions();
                po.MaxDegreeOfParallelism = Convert.ToInt32(ConfigurationManager.AppSettings["Image_MaxDegreeOfParallelism"].ToString());
                System.Net.ServicePointManager.DefaultConnectionLimit = Convert.ToInt32(ConfigurationManager.AppSettings["Image_MaxDegreeOfParallelism"].ToString());

                Parallel.For(0, lstLinks.Count, po, i =>
                {
                    try
                    {
                        TimeLog("Start CreateImage");
                        lstLinks[i].Screenshot_FileName = CreateImage(lstLinks[i].Url, DateTime.Now.ToString("yyyyMMddHHmmssfff"));
                        lstFinal.Add(lstLinks[i]);
                        TimeLog("End CreateImage");
                        counter++;
                    }
                    catch (Exception ex)
                    {
                        ErrorLog("Parallel Error for " + lstLinks[i].Url, ex.ToString());
                    }

                });
                TimeLog("End Parallel.For");
                TimeLog("Parallel.For() execution time for " + " = {0} seconds:" + stopWatch.Elapsed.TotalSeconds);

            }
            catch (Exception ex)
            {
                ErrorLog("Process_Images ", ex.Message + " ->> " + ex.StackTrace);
            }

            return lstFinal;
        }

        private string CreateImage(string strUrl, string strFileName)
        {
            string strFileNameReturn = string.Empty;
            try
            {
                ServicePointManager.SecurityProtocol = (SecurityProtocolType)3072;
                //string strFetchurl = "https://api.urlbox.io/v1/4G9b0Mqi6yniUmhs/png?url=" + HttpUtility.UrlEncode(strUrl) + "&delay=6000";
                string strFetchurl = System.Configuration.ConfigurationManager.AppSettings["Screenshot_APIUrl"].Replace("&amp;", "&").Replace("myurl", HttpUtility.UrlEncode(strUrl));
                strFetchurl = strFetchurl.Replace("\r\n", "");

                TimeLog(strFetchurl);

                WebRequest request = WebRequest.Create(strFetchurl);

                //// Get the response. 
                WebResponse response = request.GetResponse();


                // Get the stream containing content returned by the server.
                Stream dataStream = response.GetResponseStream();
                System.Drawing.Image image = System.Drawing.Image.FromStream(dataStream);
                string strPath = System.Configuration.ConfigurationManager.AppSettings["ScreenshotSavePath_Online"] + strFileName + ".jpg";//ConfigurationManager.AppSettings["ScreenshotExtension"];
                image.Save(strPath);
                strFileNameReturn = strFileName + ".jpg";
            }
            catch (Exception ex)
            {
                ErrorLog("CreateImage", strUrl + " ->" + ex.ToString());
            }

            return strFileNameReturn;
        }
        #endregion

        #region INSERT

        public bool InsertArticles(List<eArticle_Online> lstLinks)
        {
            bool IsSuccessful = true;
            try
            {
                for (int i = 0; i < lstLinks.Count; i++)
                {
                    try
                    {
                        string strError = string.Empty;
                        Int32 ArticleID = 0;
                        strError = lstLinks[i].Error;

                        if (String.IsNullOrEmpty(strError))
                        {
                            if (String.IsNullOrEmpty(lstLinks[i].DB_Title) && String.IsNullOrEmpty(lstLinks[i].DB_Text))
                            {
                                strError = "Diffbot Error";
                            }
                        }

                        if (String.IsNullOrEmpty(strError))
                        {
                            TimeLog("Start InsertArticle");
                            ArticleID = new MDB.DAL.DAL().InsertArticle_DossierManual(lstLinks[i]);
                            TimeLog("End InsertArticle");
                        }

                        TimeLog("Start UpdateUrl_DossierManual");
                        eUserDossierUrl oeUserDossierUrl = new eUserDossierUrl();
                        oeUserDossierUrl.UDID = lstLinks[i].UDID;
                        oeUserDossierUrl.Error = strError;
                        new MDB.DAL.DAL().UpdateUrl_DossierManual(oeUserDossierUrl, ArticleID);
                        TimeLog("End UpdateUrl_DossierManual");

                        
                    }
                    catch (Exception ex)
                    {
                        IsSuccessful = false;
                        ErrorLog("For Loop Error for " + lstLinks[i].Url, ex.ToString());
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorLog("InsertArticles ", ex.Message + " ->> " + ex.StackTrace);
            }

            return IsSuccessful;
        }

        #endregion

        #region LOGGING

        //For error logging
        private void ErrorLog(string functionName, string error)
        {
            try
            {
                string LogPath = ConfigurationManager.AppSettings["DossierManual_ErrorLogPath"];
                using (TextWriter myWriter = File.AppendText(LogPath))
                {

                    TextWriter.Synchronized(myWriter).WriteLine("<--> :{0}", string.Empty);
                    TextWriter.Synchronized(myWriter).WriteLine("Function Name :{0}", functionName);
                    TextWriter.Synchronized(myWriter).WriteLine("Error :{0}", error);
                    TextWriter.Synchronized(myWriter).WriteLine("Date :{0}", DateTime.Now.ToString());
                    TextWriter.Synchronized(myWriter).WriteLine("<--> :{0}", string.Empty);
                    TextWriter.Synchronized(myWriter).Flush();
                    TextWriter.Synchronized(myWriter).Close();
                }
            }
            catch (Exception ex)
            {
            }
        }

        //For debugging purpose
        private void TimeLog(string strtext)
        {
            try
            {
                string LogPath = ConfigurationManager.AppSettings["DossierManual_TimeLogPath"];
                using (TextWriter myWriter = File.AppendText(LogPath))
                {

                    TextWriter.Synchronized(myWriter).WriteLine("<--> :{0}", string.Empty);
                    TextWriter.Synchronized(myWriter).WriteLine("TimeLog :{0}", strtext);
                    TextWriter.Synchronized(myWriter).WriteLine("Date :{0}", DateTime.Now.ToString());
                    TextWriter.Synchronized(myWriter).WriteLine("<--> :{0}", string.Empty);
                    TextWriter.Synchronized(myWriter).Flush();
                    TextWriter.Synchronized(myWriter).Close();
                }
            }
            catch (Exception ex)
            {
                ErrorLog("TimeLog", ex.ToString());
            }
        }

        #endregion

        #region EXTRA

        //ExtractDomainame
        private static string ExtractDomainame(string URL)
        {
            try
            {
                string strDomain = Regex.Replace(URL, @"^([a-zA-Z]+:\/\/)?([^\/]+)\/.*?$", "$2");
                strDomain = strDomain.ToLower();
                strDomain = strDomain.Replace("www.", "");
                return strDomain;

            }
            catch (Exception ex) { return ""; }
        }

        public string CalculateHash(string value)
        {
            try
            {
                var data = System.Text.Encoding.ASCII.GetBytes(value);
                data = System.Security.Cryptography.SHA256.Create().ComputeHash(data);
                return Convert.ToBase64String(data);
            }
            catch (Exception ex)
            {
                return Convert.ToBase64String(System.Text.Encoding.ASCII.GetBytes(string.Empty));
            }
        }
        #endregion
    }
}
