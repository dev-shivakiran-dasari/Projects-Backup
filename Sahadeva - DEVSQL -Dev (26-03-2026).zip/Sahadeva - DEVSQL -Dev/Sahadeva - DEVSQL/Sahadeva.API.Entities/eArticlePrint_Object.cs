﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Runtime.Serialization;

namespace Sahadeva.API.Entities
{
    [Serializable]
    [DataContract]
    public class eArticlePrint_Object
    {
        public string status { get; set; }
        public string message { get; set; }
        public List<eArticlePrint> data { get; set; }

        public eArticlePrint_Object()
        {
            data = new List<eArticlePrint>();
        }

    }
}