﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Runtime.Serialization;

namespace Sahadeva.API.Entities
{
    [Serializable]
    [DataContract]
    public class eArticlePrint
    {
        [DataMember(Order = 1)]
        public Int32 article_id { get; set; }

        [DataMember(Order = 2)]
        public string url { get; set; }

        [DataMember(Order = 3)]
        public string title { get; set; }

        [DataMember(Order = 4)]
        public string description { get; set; }

        [DataMember(Order = 5)]
        public string author { get; set; }

        [DataMember(Order = 6)]
        public string author_type { get; set; }

        [DataMember(Order = 7)]
        public string date_time { get; set; }

        [DataMember(Order = 8)]
        public string publication { get; set; }

        [DataMember(Order = 8)]
        public string publication_type { get; set; }

        [DataMember(Order = 9)]
        public string publication_category { get; set; }

        [DataMember(Order = 10)]
        public string edition { get; set; }

        [DataMember(Order = 11)]
        public int page_no { get; set; }

        [DataMember(Order = 12)]
        public string language { get; set; }

        [DataMember(Order = 13)]
        public decimal publication_pi { get; set; }

        [DataMember(Order = 14)]
        public string sentiment { get; set; }

        [DataMember(Order = 15)]
        public Int16 sentiment_score { get; set; }

        [DataMember(Order = 16)]
        public string sentiment_explanation { get; set; }

        [DataMember(Order = 17)]
        public string article_type { get; set; }
    }
}
