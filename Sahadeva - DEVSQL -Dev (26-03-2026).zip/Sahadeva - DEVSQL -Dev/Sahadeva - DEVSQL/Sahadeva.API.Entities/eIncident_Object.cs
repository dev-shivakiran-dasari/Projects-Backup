﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Runtime.Serialization;

namespace Sahadeva.API.Entities
{
    [Serializable]
    [DataContract]
    public class eIncident_Object
    {

        public string status { get; set; }
        public string message { get; set; }
        public List<eIncident> data { get; set; }

        public eIncident_Object()
        {
            data = new List<eIncident>();
        }

    }
}