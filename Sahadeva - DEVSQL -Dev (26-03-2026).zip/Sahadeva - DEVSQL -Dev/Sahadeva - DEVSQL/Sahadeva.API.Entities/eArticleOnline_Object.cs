﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Runtime.Serialization;

namespace Sahadeva.API.Entities
{
    [Serializable]
    [DataContract]
    public class eArticleOnline_Object
    {
        public string status { get; set; }
        public string message { get; set; }
        public List<eArticleOnline> data { get; set; }

        public eArticleOnline_Object()
        {
            data = new List<eArticleOnline>();
        }

    }
}