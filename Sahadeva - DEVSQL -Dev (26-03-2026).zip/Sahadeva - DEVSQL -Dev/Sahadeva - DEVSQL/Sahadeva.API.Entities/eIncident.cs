﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Runtime.Serialization;

namespace Sahadeva.API.Entities
{
    [Serializable]
    [DataContract]
    public class eIncident
    {
        [DataMember(Order = 1)]
        public int incident_id { get; set; }

        [DataMember(Order = 2)]
        public string icon { get; set; }

        [DataMember(Order = 3)]
        public string title { get; set; }

        [DataMember(Order = 4)]
        public string description { get; set; }

        [DataMember(Order = 5)]
        public string date_time { get; set; }

        [DataMember(Order = 6)]
        public string status { get; set; }

        [DataMember(Order = 9)]
        public string tweets_count { get; set; }

        [DataMember(Order = 10)]
        public string articles_count { get; set; }


        public eIncident()
        {

        }
    }
}