﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using MDB.Common;
using MDB.Entities;
using System.Data.Common;
using MDB.Common.Constants;
using MDB.Common;
using System.Data;
using System.IO;
using System.Configuration;
using System.Diagnostics;
using System.Threading.Tasks;
using System.Net;
using Newtonsoft.Json.Linq;
using System.Globalization;
using System.Reflection;
using SolrNet.Utils;

namespace TestCEP_DBProcessor
{
    class Program
    {
        #region Class for Article

        public class eArticle
        {
            public Int32 ArticleID { get; set; }
            public string Url { get; set; }
            public Int32 IsDiffbotProcessed { get; set; }

        }
        #endregion

        static void Main(string[] args)
        {
            try
            {
                TimeLog("Start FetchArticlesToProcess");
                List<eArticle> lstArticles = FetchArticlesToProcess();
                TimeLog("Articles Count Is " + lstArticles.Count);
                TimeLog("End FetchArticlesToProcess");

                TimeLog("Start Process_Diffbot");
                List<eArticle_Online> lstlstArticles_Final = new List<eArticle_Online>();
                lstlstArticles_Final = Process_Diffbot(lstArticles);
                TimeLog("End Process_Diffbot");



                TimeLog("Start InsertArticles");
                bool IsSuccessful = InsertArticles(lstlstArticles_Final);
                TimeLog("End InsertArticles");
            }
            catch (Exception ex)
            {
                
                throw;
            }

        }

        public static bool InsertArticles(List<eArticle_Online> lstLinks)
        {
            bool IsSuccessful = true;
            try
            {
                for (int i = 0; i < lstLinks.Count; i++)
                {
                    try
                    {
                        TimeLog("Start InsertArticle");
                        UpdateDBFields(lstLinks[i]);
                        TimeLog("End InsertArticle");
                    }
                    catch (Exception ex)
                    {
                        IsSuccessful = false;
                        ErrorLog("For Loop Error for " + lstLinks[i].Url, ex.ToString());
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorLog("InsertArticles ", ex.Message + " ->> " + ex.StackTrace);
            }

            return IsSuccessful;
        }

        #region DIFFBOT

        public static List<eArticle_Online> Process_Diffbot(List<eArticle> lstLinks)
        {
            List<eArticle_Online> lstFinal = new List<eArticle_Online>();

            try
            {
                //create list of tokens
                List<string> lstTokens = ConfigurationManager.AppSettings["Diffbot_Token"].ToString().Split(',').ToList();

                int counter = 0;
                var stopWatch = Stopwatch.StartNew();
                ParallelOptions po = new ParallelOptions();
                po.MaxDegreeOfParallelism = Convert.ToInt32(ConfigurationManager.AppSettings["Diffbot_MaxDegreeOfParallelism"].ToString());
                System.Net.ServicePointManager.DefaultConnectionLimit = Convert.ToInt32(ConfigurationManager.AppSettings["Diffbot_MaxDegreeOfParallelism"].ToString());

                Parallel.For(0, lstLinks.Count, po, i =>
                {
                    try
                    {
                        string strToken = lstTokens[0];
                        if (i % 2 != 0) { strToken = lstTokens[1]; }

                        eArticle_Online o = new eArticle_Online();
                        o.ArticleID = lstLinks[i].ArticleID;
                        o.Url = lstLinks[i].Url;

                        TimeLog("Start FetchAndExtractFromDiffbot");
                        eArticle_Online objArticle = FetchAndExtractFromDiffbot(o, strToken);
                        lstFinal.Add(objArticle);
                        TimeLog("End FetchAndExtractFromDiffbot");
                        counter++;
                    }
                    catch (Exception ex)
                    {
                        ErrorLog("Parallel Error for " + lstLinks[i].Url, ex.ToString());
                    }

                });
                TimeLog("End Parallel.For");
                TimeLog("Parallel.For() execution time for " + " = {0} seconds:" + stopWatch.Elapsed.TotalSeconds);

            }
            catch (Exception ex)
            {
                ErrorLog("Process_Diffbot ", ex.Message + " ->> " + ex.StackTrace);
            }

            return lstFinal;
        }

        public static eArticle_Online FetchAndExtractFromDiffbot(eArticle_Online objArticle, string strToken)
        {
            TimeLog("Start Fetching From Diffbot URL Is " + objArticle.Url);

            try
            {
                TimeLog("Start GetDiffbotData URL Is " + objArticle.Url);
                objArticle = GetDiffbotData(objArticle, strToken);
                TimeLog("End GetDiffbotData URL Is " + "-> " + objArticle.Url);

                TimeLog("Start ExtractFromDiffbot URL Is " + "-> " + objArticle.Url);
                objArticle = ExtractFromDiffbot(objArticle);
                TimeLog("End ExtractFromDiffbot URL Is " + "-> " + objArticle.Url);
            }
            catch (Exception ex)
            {
                ErrorLog("FetchAndExtractFromDiffbot", ex.ToString() + " URL Is " + objArticle.Url);
            }

            TimeLog("End Fetching From Diffbot URL Is " + objArticle.Url);

            return objArticle;
        }

        private static eArticle_Online GetDiffbotData(eArticle_Online objeJobArticle, string strToken)
        {

            string strOutput = string.Empty;
            string strFinalURL = string.Empty;
            try
            {
                //Get Diffbot url,tokens,timeout interval for diffbot call from config and form the url
                strFinalURL = ConfigurationManager.AppSettings["Diffbot_URL"].Replace("&amp;", "&").Replace("mytoken", strToken).Replace("mytimeout", ConfigurationManager.AppSettings["Diffbot_TimeOutIntervalForOperation"]).Replace("myurl", HttpUtility.UrlEncode(objeJobArticle.Url));

                TimeLog(strFinalURL);

                HttpWebRequest request = (HttpWebRequest)WebRequest.Create(strFinalURL);
                request.Timeout = Convert.ToInt32(ConfigurationManager.AppSettings["Diffbot_TimeOutIntervalForOperation"]);
                request.Method = "GET";
                request.ContentType = "application/json; charset=utf-8";
                using (HttpWebResponse response = (HttpWebResponse)request.GetResponse())
                {
                    Stream stream = (Stream)response.GetResponseStream();
                    StreamReader reader = new StreamReader(stream);
                    strOutput = reader.ReadToEnd();
                    objeJobArticle.Output = strOutput;
                    TimeLog("Output Of URL " + objeJobArticle.Url + " is " + objeJobArticle.Output);
                }
                request = null;
            }
            catch (Exception ex)
            {
                ErrorLog("FetchData For Url " + strFinalURL, ex.ToString());
                strOutput = "Exception Occured " + ex.ToString();
            }

            strFinalURL = null;

            return objeJobArticle;
        }

        private static eArticle_Online ExtractFromDiffbot(eArticle_Online objArticle)
        {

            try
            {
                if (!String.IsNullOrEmpty(objArticle.Output))
                {
                    JObject obj = JObject.Parse(objArticle.Output);
                    if (obj != null)
                    {
                        if (obj["error"] != null && obj["errorCode"] != null)
                        {
                            if (Convert.ToString(obj["errorCode"]) == "404")
                            {
                                objArticle.Text = "404";
                            }
                            objArticle.ErrorCode = Convert.ToString(obj["errorCode"]);
                            objArticle.Error = Convert.ToString(obj["error"]);

                            TimeLog("Output Of URL " + objArticle.Url + " is " + objArticle.Output);
                            obj = null;
                        }
                        else
                        {
                            #region Set output values of diffbot
                            JArray jItems = (JArray)obj["objects"];
                            if (jItems != null)
                            {
                                foreach (JToken jItem in jItems)
                                {
                                    //Set Sitename
                                    if (jItem["siteName"] != null)
                                    {
                                        objArticle.DB_SiteName = jItem["siteName"].ToString();
                                    }

                                    //Set Sentiment
                                    if (jItem["sentiment"] != null)
                                    {
                                        objArticle.DB_Sentiment = Convert.ToDecimal(jItem["sentiment"].ToString());
                                    }

                                    //Set Author
                                    if (jItem["author"] != null)
                                    {
                                        objArticle.DB_Author = jItem["author"].ToString();
                                    }

                                    //Set AuthorURL
                                    if (jItem["authorUrl"] != null)
                                    {
                                        objArticle.DB_AuthorUrl = jItem["authorUrl"].ToString();
                                    }

                                    //Set Title
                                    if (jItem["title"] != null)
                                    {
                                        objArticle.DB_Title = jItem["title"].ToString();
                                    }

                                    //Set Text
                                    if (jItem["text"] != null)
                                    {
                                        objArticle.DB_Text = jItem["text"].ToString();
                                    }

                                    //Set Date
                                    if (jItem["date"] != null)
                                    {
                                        if (!String.IsNullOrEmpty(jItem["date"].ToString()))
                                        {
                                            TimeLog(jItem["date"].ToString());
                                            try
                                            {
                                                if (Convert.ToString(jItem["date"].ToString()).Contains("GMT"))
                                                {
                                                    objArticle.DB_Date = DateTime.ParseExact(Convert.ToString(jItem["date"].ToString()), "ddd, dd MMM yyyy HH:mm:ss GMT", CultureInfo.InvariantCulture);
                                                    //objArticle.Date = DateTime.Now.AddMinutes(-15);
                                                }
                                                else
                                                {
                                                    objArticle.DB_Date = Convert.ToDateTime(jItem["date"].ToString());
                                                }

                                                if (objArticle.DB_Date.Year <= 1900 || objArticle.DB_Date.Year >= 2050)
                                                {
                                                    objArticle.DB_Date = DateTime.Now;
                                                }
                                            }
                                            catch (Exception exxx)
                                            {
                                                objArticle.DB_Date = DateTime.Now;
                                            }
                                        }
                                    }
                                    else
                                    {
                                        objArticle.DB_Date = DateTime.Now;
                                    }

                                    TimeLog(objArticle.DB_Date.ToString());

                                    //Set PublisherCountry
                                    if (jItem["publisherCountry"] != null)
                                    {
                                        objArticle.DB_PublisherCountry = jItem["publisherCountry"].ToString();
                                    }

                                    //Set HumanLanguage
                                    if (jItem["humanLanguage"] != null)
                                    {
                                        objArticle.DB_Language = jItem["humanLanguage"].ToString();
                                    }

                                    //Set PublisherRegion
                                    if (jItem["publisherRegion"] != null)
                                    {
                                        objArticle.DB_PublisherRegion = jItem["publisherRegion"].ToString();
                                    }

                                    //Set Tags
                                    #region Tags Output
                                    if (jItem["tags"] != null)
                                    {
                                        string strTags = string.Empty;
                                        JArray jTags = (JArray)jItem["tags"];

                                        if (jTags != null)
                                        {
                                            //Set to take only 5 Tags
                                            int iTagCounter = 0;

                                            foreach (JToken jTag in jTags)
                                            {
                                                if (iTagCounter < 5)
                                                {
                                                    if (jTag["label"] != null)
                                                    {
                                                        SetProperty("DB_TagLabel" + (iTagCounter + 1).ToString(), jTag["label"].ToString(), ref objArticle, false);
                                                        strTags += jTag["label"].ToString() + ",";
                                                    }

                                                    if (jTag["score"] != null)
                                                    {
                                                        SetProperty("DB_TagScore" + (iTagCounter + 1).ToString(), jTag["score"].ToString(), ref objArticle, true);
                                                    }

                                                    if (jTag["count"] != null)
                                                    {
                                                        SetProperty("DB_TagCount" + (iTagCounter + 1).ToString(), jTag["count"].ToString(), ref objArticle, false);
                                                    }

                                                    iTagCounter++;
                                                }
                                            }
                                        }

                                        objArticle.DB_Tags = strTags.Trim(',');
                                        jTags = null;
                                    }
                                    #endregion


                                    //Set Images
                                    #region Images Output
                                    if (jItem["images"] != null)
                                    {
                                        string strImages = string.Empty;
                                        JArray jImages = (JArray)jItem["images"];

                                        if (jImages != null)
                                        {
                                            foreach (JToken jTag in jImages)
                                            {
                                                if (jTag["url"] != null)
                                                {
                                                    strImages += jTag["url"].ToString() + ",";
                                                }
                                            }
                                        }

                                        objArticle.DB_Images = strImages.Trim(',');

                                        jImages = null;
                                    }
                                    #endregion

                                }
                            }

                            jItems = null;

                            #endregion
                        }


                    }

                    obj = null;
                }
                else
                {

                }
            }
            catch (Exception ex)
            {
                ErrorLog("ExtractFromDiffbot", ex.ToString());
            }

            return objArticle;
        }

        //This function will help to set property value of entity dynamically for EngCore
        private static void SetProperty(string strPropertyName, string value, ref eArticle_Online objName, bool IsDecimal)
        {
            try
            {
                PropertyInfo propertyInfo = objName.GetType().GetProperty(strPropertyName);
                if (IsDecimal)
                {
                    propertyInfo.SetValue(objName, Convert.ToDecimal(value), null);
                }
                else
                {
                    if (strPropertyName.Contains("TagCount"))
                    {
                        propertyInfo.SetValue(objName, Convert.ToInt32(value), null);
                    }
                    else
                    {
                        propertyInfo.SetValue(objName, Convert.ToString(value), null);
                    }
                }

                propertyInfo = null;
            }
            catch (Exception ex)
            {
                ErrorLog("SetProperty", ex.ToString() + "Property Name : " + strPropertyName + "| " + "Properrty value : " + value);
            }

        }

        #endregion

        public static List<eArticle> FetchArticlesToProcess()
        {
            List<eArticle> list = new List<eArticle>();
            try
            {

                using (DataAccessWrapper DataAccessWrapper = new DataAccessWrapper(DataBaseConstants.MDBConnectionString))
                {
                    //using (DbCommand dbCommand = DataAccessWrapper.GetStoredProcCommand(DataBaseConstants.USP_EntityQuery_Fetch))
                    using (DbCommand dbCommand = DataAccessWrapper.GetStoredProcCommand("USP_ArticleOnline_Excel_FetchArticlesToProcess"))
                    {

                        #region DataSet
                        using (DataSet ds = DataAccessWrapper.ExecuteDataSet(dbCommand))
                        {
                            if (ds != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
                            {
                                DataTable dt = ds.Tables[0];
                                foreach (DataRow dr in dt.Rows)
                                {
                                    eArticle objeEntityQuery = new eArticle();

                                    if (!dr["ArticleID"].Equals(DBNull.Value))
                                    {
                                        objeEntityQuery.ArticleID = Convert.ToInt32(dr["ArticleID"]);
                                    }

                                    if (!dr["Url"].Equals(DBNull.Value))
                                    {
                                        objeEntityQuery.Url = Convert.ToString(dr[DataBaseConstants.Url]);
                                    }

                                    list.Add(objeEntityQuery);
                                }
                            }
                        }
                        #endregion
                    }
                }

            }
            catch (Exception ex)
            {

                throw ex;
            }

            return list;
        }

        public static Int32 UpdateDBFields(eArticle_Online obj)
        {
            Int32 Result = 0;

            try
            {
                using (DataAccessWrapper objDataAccessWrapper = new DataAccessWrapper(DataBaseConstants.MDBConnectionString))
                {
                    //using (DbCommand dbCommand = objDataAccessWrapper.GetStoredProcCommand(MDB.Common.Constants.DataBaseConstants.USP_ArticleOnline_Insert))
                    using (DbCommand dbCommand = objDataAccessWrapper.GetStoredProcCommand("USP_ArticleOnline_Excel_UpdateDBFields"))
                    {
                        objDataAccessWrapper.AddInParameter(dbCommand, "ArticleID", DbType.Int32, obj.ArticleID);

                        if (!string.IsNullOrEmpty(obj.DB_Text))
                        { objDataAccessWrapper.AddInParameter(dbCommand, MDB.Common.Constants.DataBaseConstants.DB_Text, DbType.String, obj.DB_Text); }

                        if (obj.DB_Date != DateTime.MinValue)
                        { objDataAccessWrapper.AddInParameter(dbCommand, MDB.Common.Constants.DataBaseConstants.DB_Date, DbType.DateTime, obj.DB_Date); }

                        if (!string.IsNullOrEmpty(obj.DB_Html))
                        { objDataAccessWrapper.AddInParameter(dbCommand, MDB.Common.Constants.DataBaseConstants.DB_Html, DbType.String, obj.DB_Html); }

                        if (!string.IsNullOrEmpty(obj.DB_Title))
                        { objDataAccessWrapper.AddInParameter(dbCommand, MDB.Common.Constants.DataBaseConstants.DB_Title, DbType.String, obj.DB_Title); }

                        if (!string.IsNullOrEmpty(obj.DB_Author))
                        { objDataAccessWrapper.AddInParameter(dbCommand, MDB.Common.Constants.DataBaseConstants.DB_Author, DbType.String, obj.DB_Author); }

                        if (!string.IsNullOrEmpty(obj.DB_SiteName))
                        { objDataAccessWrapper.AddInParameter(dbCommand, MDB.Common.Constants.DataBaseConstants.DB_SiteName, DbType.String, obj.DB_SiteName); }

                        if (!string.IsNullOrEmpty(obj.DB_AuthorUrl))
                        { objDataAccessWrapper.AddInParameter(dbCommand, MDB.Common.Constants.DataBaseConstants.DB_AuthorUrl, DbType.String, obj.DB_AuthorUrl); }

                        if (!string.IsNullOrEmpty(obj.DB_PublisherRegion))
                        { objDataAccessWrapper.AddInParameter(dbCommand, MDB.Common.Constants.DataBaseConstants.DB_PublisherRegion, DbType.String, obj.DB_PublisherRegion); }

                        if (!string.IsNullOrEmpty(obj.DB_PublisherCountry))
                        { objDataAccessWrapper.AddInParameter(dbCommand, MDB.Common.Constants.DataBaseConstants.DB_PublisherCountry, DbType.String, obj.DB_PublisherCountry); }

                        objDataAccessWrapper.AddInParameter(dbCommand, MDB.Common.Constants.DataBaseConstants.DB_Sentiment, DbType.Decimal, obj.DB_Sentiment);

                        if (!string.IsNullOrEmpty(obj.DB_Tags))
                        { objDataAccessWrapper.AddInParameter(dbCommand, MDB.Common.Constants.DataBaseConstants.DB_Tags, DbType.String, obj.DB_Tags); }

                        if (!string.IsNullOrEmpty(obj.DB_TagLabel1))
                        { objDataAccessWrapper.AddInParameter(dbCommand, MDB.Common.Constants.DataBaseConstants.DB_TagLabel1, DbType.String, obj.DB_TagLabel1); }
                        if (!string.IsNullOrEmpty(obj.DB_TagLabel2))
                        { objDataAccessWrapper.AddInParameter(dbCommand, MDB.Common.Constants.DataBaseConstants.DB_TagLabel2, DbType.String, obj.DB_TagLabel2); }
                        if (!string.IsNullOrEmpty(obj.DB_TagLabel3))
                        { objDataAccessWrapper.AddInParameter(dbCommand, MDB.Common.Constants.DataBaseConstants.DB_TagLabel3, DbType.String, obj.DB_TagLabel3); }
                        if (!string.IsNullOrEmpty(obj.DB_TagLabel4))
                        { objDataAccessWrapper.AddInParameter(dbCommand, MDB.Common.Constants.DataBaseConstants.DB_TagLabel4, DbType.String, obj.DB_TagLabel4); }
                        if (!string.IsNullOrEmpty(obj.DB_TagLabel5))
                        { objDataAccessWrapper.AddInParameter(dbCommand, MDB.Common.Constants.DataBaseConstants.DB_TagLabel5, DbType.String, obj.DB_TagLabel5); }

                        objDataAccessWrapper.AddInParameter(dbCommand, MDB.Common.Constants.DataBaseConstants.DB_TagScore1, DbType.Decimal, obj.DB_TagScore1);
                        objDataAccessWrapper.AddInParameter(dbCommand, MDB.Common.Constants.DataBaseConstants.DB_TagScore2, DbType.Decimal, obj.DB_TagScore2);
                        objDataAccessWrapper.AddInParameter(dbCommand, MDB.Common.Constants.DataBaseConstants.DB_TagScore3, DbType.Decimal, obj.DB_TagScore3);
                        objDataAccessWrapper.AddInParameter(dbCommand, MDB.Common.Constants.DataBaseConstants.DB_TagScore4, DbType.Decimal, obj.DB_TagScore4);
                        objDataAccessWrapper.AddInParameter(dbCommand, MDB.Common.Constants.DataBaseConstants.DB_TagScore5, DbType.Decimal, obj.DB_TagScore5);

                        if (!string.IsNullOrEmpty(obj.DB_Language))
                        { objDataAccessWrapper.AddInParameter(dbCommand, MDB.Common.Constants.DataBaseConstants.DB_Language, DbType.String, obj.DB_Language); }

                        if (!string.IsNullOrEmpty(obj.DB_Images))
                        { objDataAccessWrapper.AddInParameter(dbCommand, MDB.Common.Constants.DataBaseConstants.DB_Images, DbType.String, obj.DB_Images); }

                        objDataAccessWrapper.ExecuteNonQuery(dbCommand);

                        Result = obj.ArticleID;
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return Result;
        }

        #region LOGGING

        //For error logging
        private static void ErrorLog(string functionName, string error)
        {
            try
            {
                string LogPath = ConfigurationManager.AppSettings["Google_ErrorLogPath"];
                using (TextWriter myWriter = File.AppendText(LogPath))
                {

                    TextWriter.Synchronized(myWriter).WriteLine("<--> :{0}", string.Empty);
                    TextWriter.Synchronized(myWriter).WriteLine("Function Name :{0}", functionName);
                    TextWriter.Synchronized(myWriter).WriteLine("Error :{0}", error);
                    TextWriter.Synchronized(myWriter).WriteLine("Date :{0}", DateTime.Now.ToString());
                    TextWriter.Synchronized(myWriter).WriteLine("<--> :{0}", string.Empty);
                    TextWriter.Synchronized(myWriter).Flush();
                    TextWriter.Synchronized(myWriter).Close();
                }
            }
            catch (Exception ex)
            {
            }
        }

        //For debugging purpose
        private static void TimeLog(string strtext)
        {
            try
            {
                string LogPath = ConfigurationManager.AppSettings["Google_TimeLogPath"];
                using (TextWriter myWriter = File.AppendText(LogPath))
                {

                    TextWriter.Synchronized(myWriter).WriteLine("<--> :{0}", string.Empty);
                    TextWriter.Synchronized(myWriter).WriteLine("TimeLog :{0}", strtext);
                    TextWriter.Synchronized(myWriter).WriteLine("Date :{0}", DateTime.Now.ToString());
                    TextWriter.Synchronized(myWriter).WriteLine("<--> :{0}", string.Empty);
                    TextWriter.Synchronized(myWriter).Flush();
                    TextWriter.Synchronized(myWriter).Close();
                }
            }
            catch (Exception ex)
            {
                ErrorLog("TimeLog", ex.ToString());
            }
        }

        #endregion

    }
}
