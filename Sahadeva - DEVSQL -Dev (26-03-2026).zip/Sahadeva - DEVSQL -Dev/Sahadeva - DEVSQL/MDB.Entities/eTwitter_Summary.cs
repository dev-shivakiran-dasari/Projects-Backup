﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace MDB.Entities
{
    public class eTwitter_Summary
    {
        [DataMember]
        public string Input { get; set; }

        [DataMember]
        public string Tweet_RepliedToTweetID { get; set; }

        [DataMember]
        public string tweet_id { get; set; }

        [DataMember]
        public Int32 Twitter_ID { get; set; }

        [DataMember]
        public string url { get; set; }

        [DataMember]
        public Int32 hierarchy_order { get; set; }

        [DataMember]
        public string hierarchy { get; set; }

        [DataMember]
        public string text_of_tweet { get; set; }

        [DataMember]
        public string t2 { get; set; }
        
    }
}
