﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace MDB.Entities
{
    public class eService
    {
        [DataMember]
        public Int32 ServiceID { get; set; }

        [DataMember]
        public string ServiceName { get; set; }

        [DataMember]
        public Int32 IsActive { get; set; }

        [DataMember]
        public Int32 FrequencyInMin { get; set; }

        [DataMember]
        public DateTime LastExecutionTime { get; set; }

    }
}
