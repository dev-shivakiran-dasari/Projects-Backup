﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace MDB.Entities
{
    public class eTwitter
    {
        #region PK & Ref Ids
        [DataMember]
        public Int32 TwitterID { get; set; }

        [DataMember]
        public Int32 EQID { get; set; }

        [DataMember]
        public Int32 EntityID { get; set; }

        [DataMember]
        public Int32 TopicID { get; set; }

        [DataMember]
        public Int16 ServiceID { get; set; }
        #endregion

        #region Tweet
        [DataMember]
        public string Tweet_ID { get; set; }

        [DataMember]
        public string Tweet_URL { get; set; }

        [DataMember]
        public string Tweet_Text { get; set; }

        [DataMember]
        public DateTime Tweet_Date { get; set; }

        [DataMember]
        public string Tweet_ConversationID { get; set; }

        [DataMember]
        public Int16 Tweet_IsReplied { get; set; }

        [DataMember]
        public string Tweet_RepliedTo { get; set; }

        [DataMember]
        public string Tweet_RepliedToText { get; set; }

        [DataMember]
        public string Tweet_RepliedToTweetID { get; set; }

        [DataMember]
        public Int16 Tweet_IsRetweeted { get; set; }

        [DataMember]
        public string Tweet_RetweetedTo { get; set; }

        [DataMember]
        public string Tweet_RetweetedToTweetID { get; set; }

        [DataMember]
        public Int16 Tweet_IsQuoted { get; set; }

        [DataMember]
        public string Tweet_QuotedTo { get; set; }

        [DataMember]
        public string Tweet_QuotedToText { get; set; }

        [DataMember]
        public string Tweet_QuotedToTweetID { get; set; }

        [DataMember]
        public string Tweet_Language { get; set; }

        [DataMember]
        public string Tweet_Source { get; set; }
        #endregion

        #region Engagement
        [DataMember]
        public Int64 Engagement_RetweetCount { get; set; }

        [DataMember]
        public Int64 Engagement_ReplyCount { get; set; }

        [DataMember]
        public Int64 Engagement_LikeCount { get; set; }

        [DataMember]
        public Int64 Engagement_QuoteCount { get; set; }

        [DataMember]
        public Int64 Engagement_BookmarkCount { get; set; }

        [DataMember]
        public Int64 Engagement_ViewCount { get; set; }
        #endregion

        #region Mentioned
        [DataMember]
        public string Mentioned_Handles { get; set; }

        [DataMember]
        public string Mentioned_Hashtags { get; set; }

        [DataMember]
        public string Mentioned_Hyperlinks { get; set; }

        [DataMember]
        public string Mentioned_Images { get; set; }

        [DataMember]
        public string Mentioned_Videos { get; set; }

        [DataMember]
        public Int32 Mentioned_Videos_Views { get; set; }

        [DataMember]
        public Int32 Mentioned_Videos_DurationInMs { get; set; }
        #endregion

        #region Profile

        [DataMember]
        public string Profile_ID { get; set; }

        [DataMember]
        public string Profile_Handle { get; set; }

        [DataMember]
        public string Profile_Name { get; set; }

        [DataMember]
        public string Profile_Description { get; set; }

        [DataMember]
        public DateTime Profile_JoinedDate { get; set; }

        [DataMember]
        public Int64 Profile_FollowersCount { get; set; }

        [DataMember]
        public Int64 Profile_FollowingCount { get; set; }

        [DataMember]
        public Int64 Profile_TweetsCount { get; set; }

        [DataMember]
        public Int64 Profile_ListsCount { get; set; }

        [DataMember]
        public Int16 Profile_IsProtected { get; set; }

        [DataMember]
        public Int16 Profile_IsVerified { get; set; }

        [DataMember]
        public string Profile_VerifiedType { get; set; }

        [DataMember]
        public string Profile_Location { get; set; }

        [DataMember]
        public string Profile_ProfilePicUrl { get; set; }

        [DataMember]
        public string Profile_ExternalUrl { get; set; }
        #endregion

        [DataMember]
        public string TypeOfListening { get; set; }

        [DataMember]
        public string next_token { get; set; }

        [DataMember]
        public Int32 CT_Is_Detail_Fetched { get; set; }

        [DataMember]
        public DateTime CT_TreeParse_LastUpdatedAt { get; set; }

        [DataMember]
        public string CT_GroupKey { get; set; }

        [DataMember]
        public string CT_Query { get; set; }

        [DataMember]
        public Int32 CT_IsRelevant { get; set; }

        [DataMember]
        public string CT_Relevant_Reason { get; set; }

        [DataMember]
        public DateTime Incident_StartDate { get; set; }
        
    }
}
