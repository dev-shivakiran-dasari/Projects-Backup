﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using SolrNet.Attributes;

namespace MDB.Entities
{
    public class ePrint_SolrArticle
    {
        [SolrField("ReporterNewsId")]
        public string ReporterNewsId { get; set; }
    }
}
