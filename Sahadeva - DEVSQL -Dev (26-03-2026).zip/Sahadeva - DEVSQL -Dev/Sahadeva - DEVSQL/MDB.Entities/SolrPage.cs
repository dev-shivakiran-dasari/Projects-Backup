﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using SolrNet.Attributes;

namespace MDB.Entities
{
    public class SolrPage
    {
        [SolrField("BatchID")]
        public string BatchID { get; set; }
        [SolrField("HTML")]
        public string HTML { get; set; }
        [SolrField("ID")]
        public string ID { get; set; }
        [SolrField("NoiseCancelledContent")]
        public string NoiseCancelledContent { get; set; }
        [SolrField("PublishedDate")]
        public DateTime PublishedDate { get; set; }
        [SolrField("timestamp")]
        public DateTime timestamp { get; set; }
        [SolrField("Title")]
        public string Title { get; set; }
        [SolrField("Type")]
        public string Type { get; set; }
        [SolrField("URL")]
        public string URL { get; set; }
        [SolrField("_version_")]
        public string Version { get; set; }
    }
}
