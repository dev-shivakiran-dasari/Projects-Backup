﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace MDB.Entities
{
    public class eArticle_Print
    {
        #region PK & Ref Ids
        [DataMember]
        public Int32 ArticleID { get; set; }

        [DataMember]
        public Int32 EQID { get; set; }

        [DataMember]
        public Int32 EntityID { get; set; }

        [DataMember]
        public Int32 TopicID { get; set; }

        [DataMember]
        public string Source { get; set; }

        #endregion

        [DataMember]
        public Int32 NewsID { get; set; }

        [DataMember]
        public DateTime NewsDate { get; set; }

        [DataMember]
        public DateTime IssueDate { get; set; }

        [DataMember]
        public string Url { get; set; }

        [DataMember]
        public string MEDIATYPE { get; set; }

        [DataMember]
        public string MTrackEntityName { get; set; }

        [DataMember]
        public string Publicationtype { get; set; }

        [DataMember]
        public string Publication { get; set; }

        [DataMember]
        public string Language { get; set; }

        [DataMember]
        public string Agency { get; set; }

        [DataMember]
        public string Author { get; set; }

        [DataMember]
        public string Edition { get; set; }
        
        [DataMember]
        public string Journalist { get; set; }

        [DataMember]
        public string Supplement { get; set; }

        [DataMember]
        public string Headline { get; set; }

        [DataMember]
        public string Summary { get; set; }

        [DataMember]
        public string NewsText { get; set; }

        [DataMember]
        public string ClientID { get; set; }

        [DataMember]
        public Int32 Id { get; set; }

        [DataMember]
        public string ImagePath { get; set; }

        [DataMember]
        public string ImageURL { get; set; }

        [DataMember]
        public string PgNO { get; set; }

        [DataMember]
        public string SortPNo { get; set; }

        [DataMember]
        public string Height { get; set; }

        [DataMember]
        public string Col { get; set; }

        [DataMember]
        public string NewsLocation { get; set; }

        [DataMember]
        public string MTrackEntityIds { get; set; }

        [DataMember]
        public string PageNo { get; set; }

        [DataMember]
        public string HtInCms { get; set; }

        [DataMember]
        public string NoCols { get; set; }

        [DataMember]
        public Int32 NewsDetailID { get; set; }

        [DataMember]
        public Int64 CirculationScore { get; set; }

        [DataMember]
        public Int32 ReporterNewsId { get; set; }

        [DataMember]
        public decimal AVE { get; set; }

        [DataMember]
        public string Is_Relevant_Headline { get; set; }

        [DataMember]
        public string Is_Relevant_FirstPara { get; set; }

        [DataMember]
        public string Is_Relevant_RestOfArticle { get; set; }

        [DataMember]
        public string HeadlineForRelevancy { get; set; }

        [DataMember]
        public string FirstParaForRelevancy { get; set; }

        [DataMember]
        public string RestOfArticleForRelevancy { get; set; }
    }
}
