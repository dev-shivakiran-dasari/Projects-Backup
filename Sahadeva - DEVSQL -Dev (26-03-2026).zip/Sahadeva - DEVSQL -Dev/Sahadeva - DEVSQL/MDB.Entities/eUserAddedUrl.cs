﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace MDB.Entities
{
    public class eUserAddedUrl
    {
        [DataMember]
        public Int32 UAUID { get; set; }

        [DataMember]
        public Int32 TopicID { get; set; }

        [DataMember]
        public Int32 EntityID { get; set; }

        [DataMember]
        public Int32 EQID { get; set; }

        [DataMember]
        public Int32 MediaTypeID { get; set; }
        
        [DataMember]
        public string URL { get; set; }

        [DataMember]
        public string Error { get; set; }

        [DataMember]
        public string RecordID { get; set; }
    }
}
