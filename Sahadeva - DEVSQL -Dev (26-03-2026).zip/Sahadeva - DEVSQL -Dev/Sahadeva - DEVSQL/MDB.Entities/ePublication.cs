﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace MDB.Entities
{
    public class ePublication
    {
        [DataMember]
        public Int32 PublicationID { get; set; }

        [DataMember]
        public String Publication { get; set; }

        [DataMember]
        public String Domain { get; set; }

        [DataMember]
        public string Description { get; set; }

        [DataMember]
        public Int32 DA { get; set; }

        [DataMember]
        public Int32 GlobalRank { get; set; }

        [DataMember]
        public string Country { get; set; }

        [DataMember]
        public Int32 CountryRank { get; set; }

        [DataMember]
        public string Category { get; set; }

        [DataMember]
        public Int32 CategoryRank { get; set; }

        [DataMember]
        public Int64 TotalVisits { get; set; }

        [DataMember]
        public Int32 AvgVisitDuartionInSec { get; set; }

        [DataMember]
        public Int32 AvgVisitDuartionInMin { get; set; }

        [DataMember]
        public Int32 AvgPagesPerVisit { get; set; }

        [DataMember]
        public decimal BounceRate { get; set; }

        [DataMember]
        public decimal TrafficFromIndia { get; set; }

        [DataMember]
        public string Error { get; set; }

        
    }
}
