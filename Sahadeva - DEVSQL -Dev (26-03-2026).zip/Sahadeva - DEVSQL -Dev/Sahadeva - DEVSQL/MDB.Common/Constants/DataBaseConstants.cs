﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MDB.Common.Constants
{
    public class DataBaseConstants
    {
        #region Connection String

        public const string MTrackConnectionString = "MTrackConnectionString";
        public const string MDBConnectionString = "MDBConnectionString";


        #endregion Connection String

        #region Procedures

        //ServiceHistory
        public const string USP_mstService_Fetch = "USP_mstService_Fetch";
        public const string USP_mstService_Update = "USP_mstService_Update";

        //EntityQuery
        public const string USP_EntityQuery_Fetch = "USP_EntityQuery_Fetch";

        //UserDossierUrl
        public const string USP_UserDossierUrl_Fetch = "USP_UserDossierUrl_Fetch";

        //Topic
        public const string USP_Topic_UpdateHistoryDate = "USP_Topic_UpdateHistoryDate";
        public const string USP_Topic_UpdateHistoryFlag = "USP_Topic_UpdateHistoryFlag";
        

        //mstPublication_Exclude
        public const string USP_PublicationExclude_Fetch = "USP_PublicationExclude_Fetch";

        //mstPublication
        public const string USP_PublicationKnown_Fetch = "USP_PublicationKnown_Fetch";
        public const string USP_mstPublication_CheckPublicationType = "USP_mstPublication_CheckPublicationType";
        public const string USP_mstPublication_InsertNonNews = "USP_mstPublication_InsertNonNews";
        

        //ArticleOnline
        public const string USP_ArticleOnline_Insert = "USP_ArticleOnline_Insert";
        public const string USP_ArticleOnline_Insert_DossierManual = "USP_ArticleOnline_Insert_DossierManual";
        public const string USP_ArticleOnline_Insert_UserAddedUrl = "USP_ArticleOnline_Insert_UserAddedUrl";
        public const string USP_UserDossierUrl_Update = "USP_UserDossierUrl_Update";
        public const string USP_UserAddedUrl_Update = "USP_UserAddedUrl_Update";
        public const string USP_ArticleOnline_CheckDuplicate = "USP_ArticleOnline_CheckDuplicate";
        public const string USP_Publication_FetchToUpdate = "USP_Publication_FetchToUpdate";
        public const string USP_Publication_UpdateDetails = "USP_Publication_UpdateDetails";
        
        

        //ArticleDiffbot
        public const string USP_ArticleDiffbot_CheckDuplicate = "USP_ArticleDiffbot_CheckDuplicate";

        //ArticlePrint
        public const string USP_ArticlePrint_Insert = "USP_ArticlePrint_Insert";
        public const string USP_Analaysis_Search = "USP_Analaysis_Search_Mayuresh";

        //Twitter
        public const string USP_Twitter_Insert = "USP_Twitter_Insert";
        public const string USP_TwitterFS_Insert = "USP_TwitterFS_Insert";
        
        public const string USP_Twitter_FetchConversationIds = "USP_Twitter_FetchConversationIds";
        public const string USP_Twitter_UpdateConversationId = "USP_Twitter_UpdateConversationId";
        public const string USP_Twitter_FetchTweetIdsForEngagementUpdate = "USP_Twitter_FetchTweetIdsForEngagementUpdate";

        
        public const string USP_Twitter_InsertEngagement = "USP_Twitter_InsertEngagement";
        public const string USP_Twitter_FetchHandlesForDetailsUpdate = "USP_Twitter_FetchHandlesForDetailsUpdate";
        public const string USP_Twitter_InsertProfileDetail = "USP_Twitter_InsertProfileDetail";
        public const string USP_Twitter_FetchMentionedLinks = "USP_Twitter_FetchMentionedLinks";

        public const string USP_Twitter_FetchToCreateSummaryJson = "USP_Twitter_FetchToCreateSummaryJson";
        public const string USP_Twitter_FetchToCreateSummaryJson_MJ = "USP_Twitter_FetchToCreateSummaryJson_MJ";
        public const string USP_ArticleOnlineSummary_Insert = "USP_ArticleOnlineSummary_Insert";
        public const string USP_ArticlePrintSummary_Insert = "USP_ArticlePrintSummary_Insert";
        public const string USP_TwitterSummary_Insert = "USP_TwitterSummary_Insert";
        public const string USP_OverallSummary_Insert = "USP_OverallSummary_Insert";

        public const string USP_Summary_FetchPeakSummaries = "USP_Summary_FetchPeakSummaries";
        public const string USP_Peak_FetchPeaks = "USP_Peak_FetchPeaks";
        
        
        
        public const string USP_Log_Insert = "USP_Log_Insert";

        public const string USP_ArticleOnlineLog_Insert = "USP_ArticleOnlineLog_Insert";
        public const string USP_YouTubeSummary_Insert = "USP_YouTubeSummary_Insert";
        


        //Shiv
        public const string USP_Twitter_FetchQueriesToCreateInFS = "USP_Twitter_FetchQueriesToCreateInFS";
        public const string USP_Twitter_UpdateTCQuery = "USP_Twitter_UpdateTCQuery";

        #endregion Procedures

        #region Fields
        public const string ServiceName = "ServiceName";
        public const string IsActive = "IsActive";
        public const string FrequencyInMin = "FrequencyInMin";
        public const string LastExecutionTime = "LastExecutionTime";
        public const string Platform = "Platform";
        

        //Common
        public const string Type = "Type";
        public const string GroupKey = "GroupKey";
        public const string CreatedAt = "CreatedAt";
        public const string ModifiedAt = "ModifiedAt";
        public const string ServiceID = "ServiceID";
        public const string TMID = "TMID";
        

        //Incident
        public const string IncidentID = "IncidentID";

        //eEntityQuery
        public const string Query = "Query";
        public const string EntityType = "EntityType";
        public const string EntityName = "EntityName";
        public const string TopicID = "TopicID";
        public const string AppName = "AppName";
        public const string HistoryDate = "History_Date";

        //Article Fields
        public const string UDID = "UDID";
        public const string UAUID = "UAUID";
        public const string Error = "Error";
        public const string ArticleID = "ArticleID";
        public const string ADID = "ADID";
        public const string EQID = "EQID";
        public const string EntityID = "EntityID";
        public const string SERPTab = "SERPTab";
        public const string Url = "Url";
        public const string HashUrl = "HashUrl";
        public const string HashUrls = "HashUrls";
        public const string Title = "Title";
        public const string Text = "Text";
        public const string Date = "Date";
        public const string Language = "Language";
        public const string Publication = "Publication";
        public const string Publication_Url = "Publication_Url";
        public const string PublicationType = "PublicationType";
        public const string Summary = "Summary";
        public const string SummaryType = "SummaryType";
        public const string PeakID = "PeakID";
        
        public const string Mentioned_Companies = "Mentioned_Companies";
        public const string Mentioned_Industries = "Mentioned_Industries";
        public const string Mentioned_Locations = "Mentioned_Locations";
        public const string Mentioned_Topics = "Mentioned_Topics";
        public const string DB_Text = "DB_Text";
        public const string DB_Date = "DB_Date";
        public const string DB_Html = "DB_Html";
        public const string DB_Title = "DB_Title";
        public const string DB_Author = "DB_Author";
        public const string DB_AuthorUrl = "DB_AuthorUrl";
        public const string DB_SiteName = "DB_SiteName";
        public const string DB_PublisherRegion = "DB_PublisherRegion";
        public const string DB_PublisherCountry = "DB_PublisherCountry";
        public const string DB_Sentiment = "DB_Sentiment";
        public const string DB_Tags = "DB_Tags";
        public const string DB_TagLabel1 = "DB_TagLabel1";
        public const string DB_TagScore1 = "DB_TagScore1";
        public const string DB_TagCount1 = "DB_TagCount1";
        public const string DB_TagLabel2 = "DB_TagLabel2";
        public const string DB_TagScore2 = "DB_TagScore2";
        public const string DB_TagCount2 = "DB_TagCount2";
        public const string DB_TagLabel3 = "DB_TagLabel3";
        public const string DB_TagScore3 = "DB_TagScore3";
        public const string DB_TagCount3 = "DB_TagCount3";
        public const string DB_TagLabel4 = "DB_TagLabel4";
        public const string DB_TagScore4 = "DB_TagScore4";
        public const string DB_TagCount4 = "DB_TagCount4";
        public const string DB_TagLabel5 = "DB_TagLabel5";
        public const string DB_TagScore5 = "DB_TagScore5";
        public const string DB_TagCount5 = "DB_TagCount5";
        public const string DB_Language = "DB_Language";
        public const string DB_Images = "DB_Images";
        public const string Screenshot_FileName = "Screenshot_FileName";
        public const string LogComment = "LogComment";
        public const string PublicationID = "PublicationID";
        public const string Is_Relevant_Headline = "Is_Relevant_Headline";
        public const string Is_Relevant_FirstPara = "Is_Relevant_FirstPara";
        public const string Is_Relevant_RestOfArticle = "Is_Relevant_RestOfArticle";
        public const string HeadlineForRelevancy = "HeadlineForRelevancy";
        public const string FirstParaForRelevancy = "FirstParaForRelevancy";
        public const string RestOfArticleForRelevancy = "RestOfArticleForRelevancy";



        //Log
        public const string GUID = "GUID";
        public const string FromDate = "FromDate";
        public const string ToDate = "ToDate";
        public const string Count_Total = "Count_Total";
        public const string Count_Inserted = "Count_Inserted";
        public const string Count_Duplicate = "Count_Duplicate";
        public const string Count_Failed = "Count_Failed";
        public const string Count_DB_Successful = "Count_DB_Successful";
        public const string Count_DB_Failed = "Count_DB_Failed";


        //Print 

        public const string NewsID = "NewsID";
        public const string AVE = "AVE";
        public const string NewsDate = "NewsDate";
        public const string IssueDate = "IssueDate";
        public const string MEDIATYPE = "MEDIATYPE";
        public const string Publicationtype = "Publicationtype";        
        public const string Agency = "Agency";
        public const string Author = "Author";
        public const string Edition = "Edition";
        public const string Source = "Source";
        public const string Journalist = "Journalist";
        public const string Supplement = "Supplement";
        public const string Headline = "Headline";
        public const string NewsText = "NewsText";
        public const string ClientID = "ClientID";
        public const string Id = "Id";
        public const string ImagePath = "ImagePath";
        public const string ImageURL = "ImageURL";
        public const string PgNO = "PgNO";
        public const string SortPNo = "SortPNo";
        public const string Height = "Height";
        public const string Col = "Col";
        public const string NewsLocation = "NewsLocation";
        public const string MTrackEntityIds = "MTrackEntityIds";
        public const string MTrackEntityName = "MTrackEntityName";
        public const string PageNo = "PageNo";
        public const string HtInCms = "HtInCms";
        public const string NoCols = "NoCols";
        public const string NewsDetailID = "NewsDetailID";
        public const string ReporterNewsId = "ReporterNewsId";
        public const string CirculationScore = "CirculationScore";
        public const string strEntityId = "strEntityId";


        //Twitter
        public const string Tweet_ID = "Tweet_ID";
        public const string Tweet_URL = "Tweet_URL";
        public const string Tweet_Text = "Tweet_Text";
        public const string Tweet_Date = "Tweet_Date";
        public const string Tweet_ConversationID = "Tweet_ConversationID";
        public const string Tweet_IsReplied = "Tweet_IsReplied";
        public const string Tweet_RepliedTo = "Tweet_RepliedTo";
        public const string Tweet_RepliedToTweetID = "Tweet_RepliedToTweetID";
        public const string Tweet_RepliedToText = "Tweet_RepliedToText";
        public const string Tweet_IsRetweeted = "Tweet_IsRetweeted";
        public const string Tweet_RetweetedTo = "Tweet_RetweetedTo";
        public const string Tweet_RetweetedToTweetID = "Tweet_RetweetedToTweetID";
        public const string Tweet_IsQuoted = "Tweet_IsQuoted";
        public const string Tweet_QuotedTo = "Tweet_QuotedTo";
        public const string Tweet_QuotedToTweetID = "Tweet_QuotedToTweetID";
        public const string Tweet_QuotedToText = "Tweet_QuotedToText";
        public const string Tweet_QuotedText = "Tweet_QuotedText";
        public const string Tweet_Language = "Tweet_Language";
        public const string Tweet_Source = "Tweet_Source";
        public const string Engagement_RetweetCount = "Engagement_RetweetCount";
        public const string Engagement_ReplyCount = "Engagement_ReplyCount";
        public const string Engagement_LikeCount = "Engagement_LikeCount";
        public const string Engagement_QuoteCount = "Engagement_QuoteCount";
        public const string Engagement_BookmarkCount = "Engagement_BookmarkCount";
        public const string Engagement_ViewCount = "Engagement_ViewCount";
        public const string Mentioned_Handles = "Mentioned_Handles";
        public const string Mentioned_Hashtags = "Mentioned_Hashtags";
        public const string Mentioned_Hyperlinks = "Mentioned_Hyperlinks";
        public const string Mentioned_Images = "Mentioned_Images";
        public const string Mentioned_Videos = "Mentioned_Videos";
        public const string Mentioned_Video_ViewsCount = "Mentioned_Video_ViewsCount";
        public const string Mentioned_Video_DurationInMs = "Mentioned_Video_DurationInMs";
        public const string Profile_ID = "Profile_ID";
        public const string Profile_Handle = "Profile_Handle";
        public const string Profile_Name = "Profile_Name";
        public const string Profile_Description = "Profile_Description";
        public const string Profile_JoinedDate = "Profile_JoinedDate";
        public const string Profile_FollowersCount = "Profile_FollowersCount";
        public const string Profile_FollowingCount = "Profile_FollowingCount";
        public const string Profile_TweetsCount = "Profile_TweetsCount";
        public const string Profile_ListsCount = "Profile_ListsCount";
        public const string Profile_IsProtected = "Profile_IsProtected";
        public const string Profile_IsVerified = "Profile_IsVerified";
        public const string Profile_VerifiedType = "Profile_VerifiedType";
        public const string Profile_Location = "Profile_Location";
        public const string Profile_ProfilePicUrl = "Profile_ProfilePicUrl";
        public const string Profile_ExternalUrl = "Profile_ExternalUrl";
        public const string TypeOfListening = "TypeOfListening";
        public const string CT_Is_Detail_Fetched = "CT_Is_Detail_Fetched";
        public const string CT_TreeParse_LastUpdatedAt = "CT_TreeParse_LastUpdatedAt";
        public const string CT_IsRelevant = "CT_IsRelevant";
        public const string CT_Relevant_Reason = "CT_Relevant_Reason";
        
        public const string Incident_StartDate = "Incident_StartDate";
        public const string CT_Query = "CT_Query";

        public const string UDTT_Twitter_Engagement = "UDTT_Twitter_Engagement";
        public const string UDTT_Twitter_ProfileDetail = "UDTT_Twitter_ProfileDetail";
        public const string UDTT_Publication_Detail = "UDTT_Publication_Detail";

        //Shiv
        public const string TagQueryID = "TagQueryID";
        public const string Result = "Result";
        

        #endregion Fields
    }
}
