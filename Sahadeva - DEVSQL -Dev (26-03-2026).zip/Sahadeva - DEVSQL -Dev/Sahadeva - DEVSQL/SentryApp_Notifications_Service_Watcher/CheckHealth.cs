﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Configuration;
using System.IO;
using System.Data;
using System.Diagnostics;
using System.Data.SqlClient;
using System.Net.Mail;
using System.Web;
using System.Net;

namespace SentryApp_Notifications_Service_Watcher
{
    public class CheckHealth
    {
        public void DoProcess()
        {
            try
            {
                var stopWatch = Stopwatch.StartNew();

                ErrorLog("Program", "Start");
                ErrorLog("SentryApp_Notifications_Service_Watcher", "Start");

                DataTable _dt = new DataTable();
                _dt = FetchPending_UserRequest_DataDownload();

                string strEmail = Convert.ToString(ConfigurationManager.AppSettings["ToEmailIds"]);

                if (_dt != null)
                {
                    string Summerized_Interval = _dt.Rows[0]["Summerized_Interval"].ToString();
                    string RealTime = _dt.Rows[0]["RealTime"].ToString();
                    string Conditional = _dt.Rows[0]["Conditional"].ToString();

                    string body= GetHtmlTable(_dt);

                    if (Summerized_Interval != "Working Fine" || RealTime != "Working Fine" || Conditional != "Working Fine")
                    {
                        SendMail(strEmail, body, ConfigurationManager.AppSettings["MailSubject"].ToString(), ConfigurationManager.AppSettings["CCEmailID"].ToString(), ConfigurationManager.AppSettings["BCCEmailID"].ToString());
                    }
                }

                ErrorLog("SentryApp_Notifications_Service_Watcher", "End");
                ErrorLog("SentryApp_Notifications_Service_Watcher Table Rows", Convert.ToString(_dt.Rows.Count));



            }
            catch (Exception ex)
            {
                ErrorLog("DoProcess", ex.ToString());
            }

        }


        public DataTable FetchPending_UserRequest_DataDownload()
        {

            DataTable _dt = new DataTable();
            DataSet _dtSet = new DataSet();
            SqlCommand _sqlCommand = new SqlCommand();

            try
            {
                SqlConnection _sqlConnection = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ToString());

                _sqlCommand.Connection = _sqlConnection;
                _sqlCommand.Connection.Open();
                _sqlCommand.CommandText = "USP_SentryV2_Notification_Service_Watcher";
                _sqlCommand.CommandType = CommandType.Text;
                _sqlCommand.CommandTimeout = Convert.ToInt32(ConfigurationManager.AppSettings["SP_Timeout"]);
                //_sqlCommand.Parameters.AddWithValue("@MessageID", "Select");
                SqlDataAdapter _sqlDataAdapter = new SqlDataAdapter(_sqlCommand);

                _sqlDataAdapter.Fill(_dtSet);

                if (_dtSet != null && _dtSet.Tables.Count > 0)
                {
                    _dt = _dtSet.Tables[0];
                }

            }
            catch (Exception ex)
            {
                ErrorLog("USP_SentryV2_Notification_Service_Watcher", ex.Message + " ->> " + ex.StackTrace);
            }

            return _dt;
        }


        private bool SendMail(string ToMailID, string Body, string Subject, string CCMailID, string BCCMailID)
        {

            bool IsSent = false;
            try
            {
                //Get From App Config From MailID
                string FromMailID = ConfigurationManager.AppSettings["FromMailAddress"].ToString();
                //Set From Mail ID To MailAddress Properties
                MailAddress ObjFrom = new MailAddress(FromMailID, ConfigurationManager.AppSettings["FromDisplayName"].ToString());
                //Call the refrence of ddll system.net.mail.MailMessage which help to send you mail
                System.Net.Mail.MailMessage mails = new System.Net.Mail.MailMessage();
                //Define all proprties related mail configration
                //Set from mail ID here
                mails.From = ObjFrom;
                //Multiple TO Mailid which available comma sepreated the split bu (,)
                string[] SplitTOMailID = ToMailID.Split(',');
                //if array is available the using foreach loop get one by one id 
                foreach (string ToMailIDValues in SplitTOMailID)
                {
                    //Check here if id is not null or blank
                    if (!string.IsNullOrEmpty(ToMailIDValues))
                    {
                        //Here add in To MailID Properites
                        mails.To.Add(ToMailIDValues);
                    }
                }
                //Multiple CC Mailid which available comma sepreated the split bu (,)
                string[] SplitCCMailID = CCMailID.Split(',');
                foreach (string CCMailIDValues in SplitCCMailID)
                {
                    //Check here if id is not null or blank
                    if (!string.IsNullOrEmpty(CCMailIDValues))
                    {
                        //Here add in CC MailID Properites
                        mails.CC.Add(CCMailIDValues);
                    }
                }
                //Multiple BCC Mailid which available comma sepreated the split bu (,)
                string[] SplitBCCMailID = BCCMailID.Split(',');
                foreach (string CCMailIDValues in SplitBCCMailID)
                {
                    //Check here if id is not null or blank
                    if (!string.IsNullOrEmpty(CCMailIDValues))
                    {
                        //Here add in BCC MailID Properites
                        mails.Bcc.Add(CCMailIDValues);
                    }
                }
                // Set Subject
                mails.Subject = Subject.Replace('\r', ' ').Replace('\n', ' ');
                mails.Subject = HttpUtility.HtmlDecode(mails.Subject);
                //if Set html body then always set true
                mails.IsBodyHtml = true;
                //set Message Body
                mails.Body = Body;

                //Call SMTP as alias objSMTP
                SmtpClient objSMTP = new SmtpClient();


                if (ConfigurationManager.AppSettings["MailServer"].ToString() == "smtp1.projectstoday.com")
                {
                    objSMTP = new SmtpClient();
                    objSMTP.Host = ConfigurationManager.AppSettings["Host"].ToString();
                    objSMTP.Port = Convert.ToInt32(ConfigurationManager.AppSettings["Port"]);
                    objSMTP.EnableSsl = true;
                    objSMTP.DeliveryMethod = SmtpDeliveryMethod.Network;
                    var fromAddress = new MailAddress(ConfigurationManager.AppSettings["FromMailAddress"].ToString(), ConfigurationManager.AppSettings["FromDisplayName"].ToString());
                    objSMTP.Credentials = new NetworkCredential(fromAddress.Address, ConfigurationManager.AppSettings["Password"].ToString());
                }

                objSMTP.Send(mails);
                IsSent = true;
            }
            catch (Exception ex)
            {
                ErrorLog("SendMail ", ex.ToString() + " ->> " + ex.Message + " ->> " + ex.StackTrace);
                //throw err;
            }

            return IsSent;
        }

        //For error logging
        private static void ErrorLog(string functionName, string error)
        {
            try
            {
                string LogPath = ConfigurationManager.AppSettings["ErrorLogPath"];
                using (TextWriter myWriter = File.AppendText(LogPath))
                {

                    TextWriter.Synchronized(myWriter).WriteLine("<--> :{0}", string.Empty);
                    TextWriter.Synchronized(myWriter).WriteLine("Function Name :{0}", functionName);
                    TextWriter.Synchronized(myWriter).WriteLine("Error :{0}", error);
                    TextWriter.Synchronized(myWriter).WriteLine("Date :{0}", DateTime.Now.ToString());
                    TextWriter.Synchronized(myWriter).WriteLine("<--> :{0}", string.Empty);
                    TextWriter.Synchronized(myWriter).Flush();
                    TextWriter.Synchronized(myWriter).Close();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        //For debugging purpose
        private static void TimeLog(string strtext)
        {
            try
            {
                string LogPath = ConfigurationManager.AppSettings["TimeLogPath"];
                using (TextWriter myWriter = File.AppendText(LogPath))
                {

                    TextWriter.Synchronized(myWriter).WriteLine("<--> :{0}", string.Empty);
                    TextWriter.Synchronized(myWriter).WriteLine("TimeLog :{0}", strtext);
                    TextWriter.Synchronized(myWriter).WriteLine("Date :{0}", DateTime.Now.ToString());
                    TextWriter.Synchronized(myWriter).WriteLine("<--> :{0}", string.Empty);
                    TextWriter.Synchronized(myWriter).Flush();
                    TextWriter.Synchronized(myWriter).Close();
                }
            }
            catch (Exception ex)
            {
                ErrorLog("TimeLog", ex.ToString());
            }
        }

        static string GetHtmlTable(DataTable dt)
        {
            StringBuilder sb = new StringBuilder();

            sb.Append(@"
<html>
  <body style='font-family:Segoe UI, Arial, sans-serif; background-color:#f4f6f9; padding:20px;'>
    <div style='max-width:700px; margin:auto; background:#ffffff; border-radius:10px; 
                box-shadow:0 2px 8px rgba(0,0,0,0.1); padding:20px;'>
      
      <h2 style='color:#2F5496; text-align:center; margin-bottom:20px;'>
        📊 Notifictaion service Health Status
      </h2>
      <p style='font-size:14px; color:#333;'>Hello Team,</p>
      <p style='font-size:14px; color:#333;'>Please find below the current status of the services:</p>

      <table style='width:100%; border-collapse:collapse; font-size:14px; text-align:center;'>
        <thead>
          <tr style='background:#2F5496; color:#ffffff;'>
");

            // Table Header
            foreach (DataColumn col in dt.Columns)
            {
                sb.AppendFormat("<th style='padding:10px; border:1px solid #ddd;'>{0}</th>", col.ColumnName);
            }

            sb.Append("</tr></thead><tbody>");

            // Table Rows
            foreach (DataRow row in dt.Rows)
            {
                sb.Append("<tr>");
                foreach (var cell in row.ItemArray)
                {
                    string value = cell.ToString();
                    string color = "#28a745"; // green
                    if (value.Contains("No records in last one hour")) color = "#dc3545"; // red
                    //else if (value.Contains("Warning")) color = "#ffc107"; // yellow
                    //else if (value.Contains("Pending")) color = "#17a2b8"; // blue

                    sb.AppendFormat("<td style='padding:10px; border:1px solid #ddd; font-weight:600; color:{0};'>{1}</td>", color, value);
                }
                sb.Append("</tr>");
            }

            sb.Append(@"
        </tbody>
      </table>

      <p style='font-size:13px; color:#555; margin-top:20px;'>
        Regards,<br/>Monitoring Service
      </p>
    </div>
  </body>
</html>");

            return sb.ToString();
        }

    }
}
