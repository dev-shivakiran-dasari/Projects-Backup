﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SentryApp_Notifications_Service_Watcher
{
    class Program
    {
        static void Main(string[] args)
        {
            CheckHealth obj = new CheckHealth();
            obj.DoProcess();
        }
    }
}
