﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using MDB.Entities;
using MDB.Common;
using MDB.Common.Constants;
using System.Data;
using System.Data.Common;
using System.Security.Cryptography;
using System.IO;

namespace MDB.DAL
{
    public class DAL
    {

        #region ServiceHistory

        public List<eService> FetchServices()
        {
            List<eService> list = new List<eService>();
            try
            {
                using (DataAccessWrapper DataAccessWrapper = new DataAccessWrapper(DataBaseConstants.MDBConnectionString))
                {
                    using (DbCommand dbCommand = DataAccessWrapper.GetStoredProcCommand(DataBaseConstants.USP_mstService_Fetch))
                    {
                        #region DataSet
                        using (DataSet ds = DataAccessWrapper.ExecuteDataSet(dbCommand))
                        {
                            if (ds != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
                            {
                                DataTable dt = ds.Tables[0];
                                foreach (DataRow dr in dt.Rows)
                                {
                                    eService objeEntityQuery = new eService();

                                    if (!dr[DataBaseConstants.ServiceID].Equals(DBNull.Value))
                                    {
                                        objeEntityQuery.ServiceID = Convert.ToInt32(dr[DataBaseConstants.ServiceID]);
                                    }

                                    if (!dr[DataBaseConstants.ServiceName].Equals(DBNull.Value))
                                    {
                                        objeEntityQuery.ServiceName = Convert.ToString(dr[DataBaseConstants.ServiceName]);
                                    }

                                    if (!dr[DataBaseConstants.FrequencyInMin].Equals(DBNull.Value))
                                    {
                                        objeEntityQuery.FrequencyInMin = Convert.ToInt32(dr[DataBaseConstants.FrequencyInMin]);
                                    }

                                    if (!dr[DataBaseConstants.IsActive].Equals(DBNull.Value))
                                    {
                                        objeEntityQuery.IsActive = Convert.ToInt32(dr[DataBaseConstants.IsActive]);
                                    }

                                    if (!dr[DataBaseConstants.LastExecutionTime].Equals(DBNull.Value))
                                    {
                                        objeEntityQuery.LastExecutionTime = Convert.ToDateTime(dr[DataBaseConstants.LastExecutionTime]);
                                    }

                                    list.Add(objeEntityQuery);
                                }
                            }
                        }
                        #endregion
                    }
                }

            }
            catch (Exception ex)
            {

                throw ex;
            }

            return list;
        }

        public void UpdateServiceHistory(eService obj)
        {
            try
            {
                using (DataAccessWrapper objDataAccessWrapper = new DataAccessWrapper(DataBaseConstants.MDBConnectionString))
                {
                    using (DbCommand dbCommand = objDataAccessWrapper.GetStoredProcCommand(Common.Constants.DataBaseConstants.USP_mstService_Update))
                    {
                        objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.ServiceID, DbType.Int32, obj.ServiceID);

                        //if (obj.LastExecutionTime != DateTime.MinValue)
                        //{ objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.LastExecutionTime, DbType.DateTime, DateTime.Now); }

                        objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.LastExecutionTime, DbType.DateTime, DateTime.Now);

                        objDataAccessWrapper.ExecuteNonQuery(dbCommand);
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        #endregion


        public List<eUserDossierUrl> FetchUserDossierUrls(Int32 ServiceID)
        {
            List<eUserDossierUrl> list = new List<eUserDossierUrl>();
            try
            {

                using (DataAccessWrapper DataAccessWrapper = new DataAccessWrapper(DataBaseConstants.MDBConnectionString))
                {
                    using (DbCommand dbCommand = DataAccessWrapper.GetStoredProcCommand(DataBaseConstants.USP_EntityQuery_Fetch))
                    {
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.ServiceID, DbType.Int32, ServiceID);
                        #region DataSet
                        using (DataSet ds = DataAccessWrapper.ExecuteDataSet(dbCommand))
                        {
                            if (ds != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
                            {
                                DataTable dt = ds.Tables[0];
                                foreach (DataRow dr in dt.Rows)
                                {
                                    eUserDossierUrl objeEntityQuery = new eUserDossierUrl();

                                    if (!dr[DataBaseConstants.UDID].Equals(DBNull.Value))
                                    {
                                        objeEntityQuery.UDID = Convert.ToInt32(dr[DataBaseConstants.UDID]);
                                    }

                                    if (!dr[DataBaseConstants.EntityID].Equals(DBNull.Value))
                                    {
                                        objeEntityQuery.EntityID = Convert.ToInt32(dr[DataBaseConstants.EntityID]);
                                    }

                                    if (!dr[DataBaseConstants.EQID].Equals(DBNull.Value))
                                    {
                                        objeEntityQuery.EQID = Convert.ToInt32(dr[DataBaseConstants.EQID]);
                                    }

                                    if (!dr[DataBaseConstants.TopicID].Equals(DBNull.Value))
                                    {
                                        objeEntityQuery.TopicID = Convert.ToInt32(dr[DataBaseConstants.TopicID]);
                                    }

                                    if (!dr[DataBaseConstants.Url].Equals(DBNull.Value))
                                    {
                                        objeEntityQuery.URL = Convert.ToString(dr[DataBaseConstants.Url]);
                                    }

                                    list.Add(objeEntityQuery);
                                }
                            }
                        }
                        #endregion
                    }
                }

            }
            catch (Exception ex)
            {

                throw ex;
            }

            return list;
        }

        public List<eUserAddedUrl> FetchUsedAddedUrl_Online(Int32 ServiceID)
        {
            List<eUserAddedUrl> list = new List<eUserAddedUrl>();
            try
            {

                using (DataAccessWrapper DataAccessWrapper = new DataAccessWrapper(DataBaseConstants.MDBConnectionString))
                {
                    using (DbCommand dbCommand = DataAccessWrapper.GetStoredProcCommand(DataBaseConstants.USP_EntityQuery_Fetch))
                    {
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.ServiceID, DbType.Int32, ServiceID);
                        #region DataSet
                        using (DataSet ds = DataAccessWrapper.ExecuteDataSet(dbCommand))
                        {
                            if (ds != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
                            {
                                DataTable dt = ds.Tables[0];
                                foreach (DataRow dr in dt.Rows)
                                {
                                    eUserAddedUrl objeEntityQuery = new eUserAddedUrl();

                                    if (!dr[DataBaseConstants.UAUID].Equals(DBNull.Value))
                                    {
                                        objeEntityQuery.UAUID = Convert.ToInt32(dr[DataBaseConstants.UAUID]);
                                    }

                                    if (!dr[DataBaseConstants.EntityID].Equals(DBNull.Value))
                                    {
                                        objeEntityQuery.EntityID = Convert.ToInt32(dr[DataBaseConstants.EntityID]);
                                    }

                                    if (!dr[DataBaseConstants.EQID].Equals(DBNull.Value))
                                    {
                                        objeEntityQuery.EQID = Convert.ToInt32(dr[DataBaseConstants.EQID]);
                                    }

                                    if (!dr[DataBaseConstants.TopicID].Equals(DBNull.Value))
                                    {
                                        objeEntityQuery.TopicID = Convert.ToInt32(dr[DataBaseConstants.TopicID]);
                                    }

                                    if (!dr[DataBaseConstants.Url].Equals(DBNull.Value))
                                    {
                                        objeEntityQuery.URL = Convert.ToString(dr[DataBaseConstants.Url]);
                                    }

                                    list.Add(objeEntityQuery);
                                }
                            }
                        }
                        #endregion
                    }
                }

            }
            catch (Exception ex)
            {

                throw ex;
            }

            return list;
        }



        #region Queries
        public List<eEntityQuery> FetchQueries(Int32 ServiceID)
        {
            List<eEntityQuery> list = new List<eEntityQuery>();
            try
            {

                using (DataAccessWrapper DataAccessWrapper = new DataAccessWrapper(DataBaseConstants.MDBConnectionString))
                {
                    using (DbCommand dbCommand = DataAccessWrapper.GetStoredProcCommand(DataBaseConstants.USP_EntityQuery_Fetch))
                    {
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.ServiceID, DbType.Int32, ServiceID);

                        #region DataSet
                        using (DataSet ds = DataAccessWrapper.ExecuteDataSet(dbCommand))
                        {
                            if (ds != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
                            {
                                DataTable dt = ds.Tables[0];
                                foreach (DataRow dr in dt.Rows)
                                {
                                    eEntityQuery objeEntityQuery = new eEntityQuery();

                                    if (!dr[DataBaseConstants.EntityID].Equals(DBNull.Value))
                                    {
                                        objeEntityQuery.EntityID = Convert.ToInt32(dr[DataBaseConstants.EntityID]);
                                    }

                                    if (!dr[DataBaseConstants.EntityName].Equals(DBNull.Value))
                                    {
                                        objeEntityQuery.EntityName = Convert.ToString(dr[DataBaseConstants.EntityName]);
                                    }

                                    if (!dr[DataBaseConstants.EntityType].Equals(DBNull.Value))
                                    {
                                        objeEntityQuery.EntityType = Convert.ToString(dr[DataBaseConstants.EntityType]);
                                    }

                                    if (!dr[DataBaseConstants.Query].Equals(DBNull.Value))
                                    {
                                        objeEntityQuery.Query = Convert.ToString(dr[DataBaseConstants.Query]);
                                    }

                                    if (!dr[DataBaseConstants.EQID].Equals(DBNull.Value))
                                    {
                                        objeEntityQuery.EQID = Convert.ToInt32(dr[DataBaseConstants.EQID]);
                                    }

                                    if (!dr[DataBaseConstants.TopicID].Equals(DBNull.Value))
                                    {
                                        objeEntityQuery.TopicID = Convert.ToInt32(dr[DataBaseConstants.TopicID]);
                                    }

                                    if (!dr[DataBaseConstants.AppName].Equals(DBNull.Value))
                                    {
                                        objeEntityQuery.AppName = Convert.ToString(dr[DataBaseConstants.AppName]);
                                    }

                                    if (!dr[DataBaseConstants.HistoryDate].Equals(DBNull.Value))
                                    {
                                        objeEntityQuery.HistoryDate = Convert.ToDateTime(dr[DataBaseConstants.HistoryDate]);
                                    }

                                    list.Add(objeEntityQuery);
                                }
                            }
                        }
                        #endregion
                    }
                }

            }
            catch (Exception ex)
            {

                throw ex;
            }

            return list;
        }

        public void Topic_UpdateHistoryFlag(Int32 TopicID, Int32 EQID)
        {
            try
            {
                using (DataAccessWrapper objDataAccessWrapper = new DataAccessWrapper(DataBaseConstants.MDBConnectionString))
                {
                    using (DbCommand dbCommand = objDataAccessWrapper.GetStoredProcCommand(Common.Constants.DataBaseConstants.USP_Topic_UpdateHistoryFlag))
                    {
                        objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.TopicID, DbType.Int32, TopicID);
                        objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.EQID, DbType.Int32, EQID);

                        objDataAccessWrapper.ExecuteNonQuery(dbCommand);
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        #endregion

        #region OnlineArticle

        public void InsertArticle(eArticle_Online obj)
        {
            try
            {
                using (DataAccessWrapper objDataAccessWrapper = new DataAccessWrapper(DataBaseConstants.MDBConnectionString))
                {
                    using (DbCommand dbCommand = objDataAccessWrapper.GetStoredProcCommand(Common.Constants.DataBaseConstants.USP_ArticleOnline_Insert))
                    {
                        objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.EQID, DbType.Int32, obj.EQID);
                        objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.EntityID, DbType.Int32, obj.EntityID);
                        objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.TopicID, DbType.Int32, obj.TopicID);
                        objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.ServiceID, DbType.Int32, obj.ServiceID);
                        objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.ADID, DbType.Int32, obj.ADID);
                        objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.SERPTab, DbType.String, obj.SERPTab);

                        if (!string.IsNullOrEmpty(obj.HashUrl))
                        { objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.HashUrl, DbType.String, obj.HashUrl); }


                        if (!string.IsNullOrEmpty(obj.Url))
                        { objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Url, DbType.String, obj.Url); }

                        if (!string.IsNullOrEmpty(obj.Title))
                        { objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Title, DbType.String, obj.Title); }

                        if (!string.IsNullOrEmpty(obj.Text))
                        { objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Text, DbType.String, obj.Text); }

                        if (obj.Date != DateTime.MinValue)
                        { objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Date, DbType.DateTime, obj.Date); }

                        if (!string.IsNullOrEmpty(obj.Publication))
                        { objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Publication, DbType.String, obj.Publication); }

                        if (!string.IsNullOrEmpty(obj.Publication_Url))
                        { objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Publication_Url, DbType.String, obj.Publication_Url); }

                        if (!string.IsNullOrEmpty(obj.DB_Text))
                        { objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.DB_Text, DbType.String, obj.DB_Text); }

                        if (obj.DB_Date != DateTime.MinValue)
                        { objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.DB_Date, DbType.DateTime, obj.DB_Date); }

                        if (!string.IsNullOrEmpty(obj.DB_Html))
                        { objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.DB_Html, DbType.String, obj.DB_Html); }

                        if (!string.IsNullOrEmpty(obj.DB_Title))
                        { objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.DB_Title, DbType.String, obj.DB_Title); }

                        if (!string.IsNullOrEmpty(obj.DB_Author))
                        { objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.DB_Author, DbType.String, obj.DB_Author); }

                        if (!string.IsNullOrEmpty(obj.DB_SiteName))
                        { objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.DB_SiteName, DbType.String, obj.DB_SiteName); }

                        if (!string.IsNullOrEmpty(obj.DB_AuthorUrl))
                        { objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.DB_AuthorUrl, DbType.String, obj.DB_AuthorUrl); }

                        if (!string.IsNullOrEmpty(obj.DB_PublisherRegion))
                        { objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.DB_PublisherRegion, DbType.String, obj.DB_PublisherRegion); }

                        if (!string.IsNullOrEmpty(obj.DB_PublisherCountry))
                        { objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.DB_PublisherCountry, DbType.String, obj.DB_PublisherCountry); }

                        objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.DB_Sentiment, DbType.Decimal, obj.DB_Sentiment);

                        if (!string.IsNullOrEmpty(obj.DB_Tags))
                        { objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.DB_Tags, DbType.String, obj.DB_Tags); }

                        if (!string.IsNullOrEmpty(obj.DB_TagLabel1))
                        { objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.DB_TagLabel1, DbType.String, obj.DB_TagLabel1); }
                        if (!string.IsNullOrEmpty(obj.DB_TagLabel2))
                        { objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.DB_TagLabel2, DbType.String, obj.DB_TagLabel2); }
                        if (!string.IsNullOrEmpty(obj.DB_TagLabel3))
                        { objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.DB_TagLabel3, DbType.String, obj.DB_TagLabel3); }
                        if (!string.IsNullOrEmpty(obj.DB_TagLabel4))
                        { objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.DB_TagLabel4, DbType.String, obj.DB_TagLabel4); }
                        if (!string.IsNullOrEmpty(obj.DB_TagLabel5))
                        { objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.DB_TagLabel5, DbType.String, obj.DB_TagLabel5); }

                        objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.DB_TagScore1, DbType.Decimal, obj.DB_TagScore1);
                        objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.DB_TagScore2, DbType.Decimal, obj.DB_TagScore2);
                        objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.DB_TagScore3, DbType.Decimal, obj.DB_TagScore3);
                        objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.DB_TagScore4, DbType.Decimal, obj.DB_TagScore4);
                        objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.DB_TagScore5, DbType.Decimal, obj.DB_TagScore5);

                        if (!string.IsNullOrEmpty(obj.DB_Language))
                        { objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.DB_Language, DbType.String, obj.DB_Language); }

                        if (!string.IsNullOrEmpty(obj.DB_Images))
                        { objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.DB_Images, DbType.String, obj.DB_Images); }

                        if (!string.IsNullOrEmpty(obj.Screenshot_FileName))
                        { objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Screenshot_FileName, DbType.String, obj.Screenshot_FileName); }

                        if (!string.IsNullOrEmpty(obj.PublicationType))
                        { objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.PublicationType, DbType.String, obj.PublicationType); }

                        #region Added By Mayuresh
                        if (!string.IsNullOrEmpty(obj.Is_Relevant_Headline))
                        { objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Is_Relevant_Headline, DbType.String, obj.Is_Relevant_Headline); }

                        if (!string.IsNullOrEmpty(obj.Is_Relevant_FirstPara))
                        { objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Is_Relevant_FirstPara, DbType.String, obj.Is_Relevant_FirstPara); }

                        if (!string.IsNullOrEmpty(obj.Is_Relevant_RestOfArticle))
                        { objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Is_Relevant_RestOfArticle, DbType.String, obj.Is_Relevant_RestOfArticle); }

                        if (!string.IsNullOrEmpty(obj.HeadlineForRelevancy))
                        { objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.HeadlineForRelevancy, DbType.String, obj.HeadlineForRelevancy); }

                        if (!string.IsNullOrEmpty(obj.FirstParaForRelevancy))
                        { objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.FirstParaForRelevancy, DbType.String, obj.FirstParaForRelevancy); }

                        if (!string.IsNullOrEmpty(obj.RestOfArticleForRelevancy))
                        { objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.RestOfArticleForRelevancy, DbType.String, obj.RestOfArticleForRelevancy); }

                        #endregion
                        objDataAccessWrapper.ExecuteNonQuery(dbCommand);
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public Int32 InsertArticle_DossierManual(eArticle_Online obj)
        {
            Int32 ArticleID = 0;
            try
            {
                using (DataAccessWrapper objDataAccessWrapper = new DataAccessWrapper(DataBaseConstants.MDBConnectionString))
                {
                    using (DbCommand dbCommand = objDataAccessWrapper.GetStoredProcCommand(Common.Constants.DataBaseConstants.USP_ArticleOnline_Insert_DossierManual))
                    {
                        objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.EQID, DbType.Int32, obj.EQID);
                        objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.EntityID, DbType.Int32, obj.EntityID);
                        objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.TopicID, DbType.Int32, obj.TopicID);
                        objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.ServiceID, DbType.Int32, obj.ServiceID);
                        objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.ADID, DbType.Int32, obj.ADID);
                        objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.SERPTab, DbType.String, obj.SERPTab);

                        if (!string.IsNullOrEmpty(obj.HashUrl))
                        { objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.HashUrl, DbType.String, obj.HashUrl); }


                        if (!string.IsNullOrEmpty(obj.Url))
                        { objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Url, DbType.String, obj.Url); }

                        if (!string.IsNullOrEmpty(obj.Title))
                        { objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Title, DbType.String, obj.Title); }

                        if (!string.IsNullOrEmpty(obj.Text))
                        { objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Text, DbType.String, obj.Text); }

                        if (obj.Date != DateTime.MinValue)
                        { objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Date, DbType.DateTime, obj.Date); }

                        if (!string.IsNullOrEmpty(obj.Publication))
                        { objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Publication, DbType.String, obj.Publication); }

                        if (!string.IsNullOrEmpty(obj.Publication_Url))
                        { objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Publication_Url, DbType.String, obj.Publication_Url); }

                        if (!string.IsNullOrEmpty(obj.DB_Text))
                        { objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.DB_Text, DbType.String, obj.DB_Text); }

                        if (obj.DB_Date != DateTime.MinValue)
                        { objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.DB_Date, DbType.DateTime, obj.DB_Date); }

                        if (!string.IsNullOrEmpty(obj.DB_Html))
                        { objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.DB_Html, DbType.String, obj.DB_Html); }

                        if (!string.IsNullOrEmpty(obj.DB_Title))
                        { objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.DB_Title, DbType.String, obj.DB_Title); }

                        if (!string.IsNullOrEmpty(obj.DB_Author))
                        { objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.DB_Author, DbType.String, obj.DB_Author); }

                        if (!string.IsNullOrEmpty(obj.DB_SiteName))
                        { objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.DB_SiteName, DbType.String, obj.DB_SiteName); }

                        if (!string.IsNullOrEmpty(obj.DB_AuthorUrl))
                        { objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.DB_AuthorUrl, DbType.String, obj.DB_AuthorUrl); }

                        if (!string.IsNullOrEmpty(obj.DB_PublisherRegion))
                        { objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.DB_PublisherRegion, DbType.String, obj.DB_PublisherRegion); }

                        if (!string.IsNullOrEmpty(obj.DB_PublisherCountry))
                        { objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.DB_PublisherCountry, DbType.String, obj.DB_PublisherCountry); }

                        objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.DB_Sentiment, DbType.Decimal, obj.DB_Sentiment);

                        if (!string.IsNullOrEmpty(obj.DB_Tags))
                        { objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.DB_Tags, DbType.String, obj.DB_Tags); }

                        if (!string.IsNullOrEmpty(obj.DB_TagLabel1))
                        { objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.DB_TagLabel1, DbType.String, obj.DB_TagLabel1); }
                        if (!string.IsNullOrEmpty(obj.DB_TagLabel2))
                        { objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.DB_TagLabel2, DbType.String, obj.DB_TagLabel2); }
                        if (!string.IsNullOrEmpty(obj.DB_TagLabel3))
                        { objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.DB_TagLabel3, DbType.String, obj.DB_TagLabel3); }
                        if (!string.IsNullOrEmpty(obj.DB_TagLabel4))
                        { objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.DB_TagLabel4, DbType.String, obj.DB_TagLabel4); }
                        if (!string.IsNullOrEmpty(obj.DB_TagLabel5))
                        { objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.DB_TagLabel5, DbType.String, obj.DB_TagLabel5); }

                        objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.DB_TagScore1, DbType.Decimal, obj.DB_TagScore1);
                        objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.DB_TagScore2, DbType.Decimal, obj.DB_TagScore2);
                        objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.DB_TagScore3, DbType.Decimal, obj.DB_TagScore3);
                        objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.DB_TagScore4, DbType.Decimal, obj.DB_TagScore4);
                        objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.DB_TagScore5, DbType.Decimal, obj.DB_TagScore5);

                        if (!string.IsNullOrEmpty(obj.DB_Language))
                        { objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.DB_Language, DbType.String, obj.DB_Language); }

                        if (!string.IsNullOrEmpty(obj.DB_Images))
                        { objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.DB_Images, DbType.String, obj.DB_Images); }

                        if (!string.IsNullOrEmpty(obj.Screenshot_FileName))
                        { objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Screenshot_FileName, DbType.String, obj.Screenshot_FileName); }

                        if (!string.IsNullOrEmpty(obj.PublicationType))
                        { objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.PublicationType, DbType.String, obj.PublicationType); }

                        ArticleID = Convert.ToInt32(objDataAccessWrapper.ExecuteScalar(dbCommand));
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return ArticleID;
        }

        public Int32 InsertArticle_UserAddedUrl(eArticle_Online obj)
        {
            Int32 ArticleID = 0;
            try
            {
                using (DataAccessWrapper objDataAccessWrapper = new DataAccessWrapper(DataBaseConstants.MDBConnectionString))
                {
                    using (DbCommand dbCommand = objDataAccessWrapper.GetStoredProcCommand(Common.Constants.DataBaseConstants.USP_ArticleOnline_Insert_UserAddedUrl))
                    {
                        objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.EQID, DbType.Int32, obj.EQID);
                        objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.EntityID, DbType.Int32, obj.EntityID);
                        objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.TopicID, DbType.Int32, obj.TopicID);
                        objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.ServiceID, DbType.Int32, obj.ServiceID);
                        objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.ADID, DbType.Int32, obj.ADID);
                        objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.SERPTab, DbType.String, obj.SERPTab);

                        if (!string.IsNullOrEmpty(obj.HashUrl))
                        { objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.HashUrl, DbType.String, obj.HashUrl); }


                        if (!string.IsNullOrEmpty(obj.Url))
                        { objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Url, DbType.String, obj.Url); }

                        if (!string.IsNullOrEmpty(obj.Title))
                        { objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Title, DbType.String, obj.Title); }

                        if (!string.IsNullOrEmpty(obj.Text))
                        { objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Text, DbType.String, obj.Text); }

                        if (obj.Date != DateTime.MinValue)
                        { objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Date, DbType.DateTime, obj.Date); }

                        if (!string.IsNullOrEmpty(obj.Publication))
                        { objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Publication, DbType.String, obj.Publication); }

                        if (!string.IsNullOrEmpty(obj.Publication_Url))
                        { objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Publication_Url, DbType.String, obj.Publication_Url); }

                        if (!string.IsNullOrEmpty(obj.DB_Text))
                        { objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.DB_Text, DbType.String, obj.DB_Text); }

                        if (obj.DB_Date != DateTime.MinValue)
                        { objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.DB_Date, DbType.DateTime, obj.DB_Date); }

                        if (!string.IsNullOrEmpty(obj.DB_Html))
                        { objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.DB_Html, DbType.String, obj.DB_Html); }

                        if (!string.IsNullOrEmpty(obj.DB_Title))
                        { objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.DB_Title, DbType.String, obj.DB_Title); }

                        if (!string.IsNullOrEmpty(obj.DB_Author))
                        { objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.DB_Author, DbType.String, obj.DB_Author); }

                        if (!string.IsNullOrEmpty(obj.DB_SiteName))
                        { objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.DB_SiteName, DbType.String, obj.DB_SiteName); }

                        if (!string.IsNullOrEmpty(obj.DB_AuthorUrl))
                        { objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.DB_AuthorUrl, DbType.String, obj.DB_AuthorUrl); }

                        if (!string.IsNullOrEmpty(obj.DB_PublisherRegion))
                        { objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.DB_PublisherRegion, DbType.String, obj.DB_PublisherRegion); }

                        if (!string.IsNullOrEmpty(obj.DB_PublisherCountry))
                        { objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.DB_PublisherCountry, DbType.String, obj.DB_PublisherCountry); }

                        objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.DB_Sentiment, DbType.Decimal, obj.DB_Sentiment);

                        if (!string.IsNullOrEmpty(obj.DB_Tags))
                        { objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.DB_Tags, DbType.String, obj.DB_Tags); }

                        if (!string.IsNullOrEmpty(obj.DB_TagLabel1))
                        { objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.DB_TagLabel1, DbType.String, obj.DB_TagLabel1); }
                        if (!string.IsNullOrEmpty(obj.DB_TagLabel2))
                        { objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.DB_TagLabel2, DbType.String, obj.DB_TagLabel2); }
                        if (!string.IsNullOrEmpty(obj.DB_TagLabel3))
                        { objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.DB_TagLabel3, DbType.String, obj.DB_TagLabel3); }
                        if (!string.IsNullOrEmpty(obj.DB_TagLabel4))
                        { objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.DB_TagLabel4, DbType.String, obj.DB_TagLabel4); }
                        if (!string.IsNullOrEmpty(obj.DB_TagLabel5))
                        { objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.DB_TagLabel5, DbType.String, obj.DB_TagLabel5); }

                        objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.DB_TagScore1, DbType.Decimal, obj.DB_TagScore1);
                        objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.DB_TagScore2, DbType.Decimal, obj.DB_TagScore2);
                        objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.DB_TagScore3, DbType.Decimal, obj.DB_TagScore3);
                        objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.DB_TagScore4, DbType.Decimal, obj.DB_TagScore4);
                        objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.DB_TagScore5, DbType.Decimal, obj.DB_TagScore5);

                        if (!string.IsNullOrEmpty(obj.DB_Language))
                        { objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.DB_Language, DbType.String, obj.DB_Language); }

                        if (!string.IsNullOrEmpty(obj.DB_Images))
                        { objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.DB_Images, DbType.String, obj.DB_Images); }

                        if (!string.IsNullOrEmpty(obj.Screenshot_FileName))
                        { objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Screenshot_FileName, DbType.String, obj.Screenshot_FileName); }

                        if (!string.IsNullOrEmpty(obj.PublicationType))
                        { objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.PublicationType, DbType.String, obj.PublicationType); }

                        ArticleID = Convert.ToInt32(objDataAccessWrapper.ExecuteScalar(dbCommand));
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return ArticleID;
        }

        public void UpdateUrl_DossierManual(eUserDossierUrl obj, Int32 ArticleID)
        {
            try
            {
                using (DataAccessWrapper objDataAccessWrapper = new DataAccessWrapper(DataBaseConstants.MDBConnectionString))
                {
                    using (DbCommand dbCommand = objDataAccessWrapper.GetStoredProcCommand(Common.Constants.DataBaseConstants.USP_UserDossierUrl_Update))
                    {
                        objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.UDID, DbType.Int32, obj.UDID);

                        objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Error, DbType.String, obj.Error);

                        objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.ArticleID, DbType.Int32, ArticleID);

                        objDataAccessWrapper.ExecuteNonQuery(dbCommand);
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public void UpdateUrl_UserAddedUrl_Online(eUserAddedUrl obj, Int32 ArticleID)
        {
            try
            {
                using (DataAccessWrapper objDataAccessWrapper = new DataAccessWrapper(DataBaseConstants.MDBConnectionString))
                {
                    using (DbCommand dbCommand = objDataAccessWrapper.GetStoredProcCommand(Common.Constants.DataBaseConstants.USP_UserAddedUrl_Update))
                    {
                        objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.UDID, DbType.Int32, obj.UAUID);

                        objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Error, DbType.String, obj.Error);

                        objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.ArticleID, DbType.Int32, ArticleID);

                        objDataAccessWrapper.ExecuteNonQuery(dbCommand);
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


        public void InsertArticle_Log(string BatchID, eArticle_Online obj)
        {
            try
            {
                using (DataAccessWrapper objDataAccessWrapper = new DataAccessWrapper(DataBaseConstants.MDBConnectionString))
                {
                    using (DbCommand dbCommand = objDataAccessWrapper.GetStoredProcCommand(Common.Constants.DataBaseConstants.USP_ArticleOnlineLog_Insert))
                    {

                        objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.GUID, DbType.String, BatchID);

                        objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.EQID, DbType.Int32, obj.EQID);
                        objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.EntityID, DbType.Int32, obj.EntityID);
                        objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.TopicID, DbType.Int32, obj.TopicID);

                        if (!string.IsNullOrEmpty(obj.Url))
                        { objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Url, DbType.String, obj.Url); }

                        if (obj.Date != DateTime.MinValue)
                        { objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Date, DbType.DateTime, obj.Date); }

                        if (!string.IsNullOrEmpty(obj.SERPTab))
                        { objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.SERPTab, DbType.String, obj.SERPTab); }

                        if (!string.IsNullOrEmpty(obj.LogComment))
                        { objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.LogComment, DbType.String, obj.LogComment); }

                        objDataAccessWrapper.ExecuteNonQuery(dbCommand);
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public List<string> CheckDuplicate_ArticleOnline(Int32 EntityID, Int32 TopicID, String HashUrls)
        {
            List<string> lstHashUrl = new List<string>();

            try
            {
                using (DataAccessWrapper objDataAccessWrapper = new DataAccessWrapper(DataBaseConstants.MDBConnectionString))
                {
                    using (DbCommand dbCommand = objDataAccessWrapper.GetStoredProcCommand(DataBaseConstants.USP_ArticleOnline_CheckDuplicate))
                    {
                        objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.EntityID, DbType.Int32, EntityID);
                        objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.TopicID, DbType.Int32, TopicID);

                        if (!string.IsNullOrEmpty(HashUrls))
                        { objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.HashUrls, DbType.String, HashUrls); }

                        #region DataSet
                        using (DataSet ds = objDataAccessWrapper.ExecuteDataSet(dbCommand))
                        {
                            if (ds != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
                            {
                                DataTable dt = ds.Tables[0];
                                foreach (DataRow dr in dt.Rows)
                                {
                                    if (!dr[DataBaseConstants.HashUrl].Equals(DBNull.Value))
                                    {
                                        lstHashUrl.Add(Convert.ToString(dr[DataBaseConstants.HashUrl]));
                                    }

                                }
                            }
                        }
                        #endregion
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return lstHashUrl;
        }

        public List<eArticle_Online> CheckDuplicate_Diffbot(String HashUrls, List<eArticle_Online> lstArticles)
        {
            try
            {
                using (DataAccessWrapper objDataAccessWrapper = new DataAccessWrapper(DataBaseConstants.MDBConnectionString))
                {
                    using (DbCommand dbCommand = objDataAccessWrapper.GetStoredProcCommand(DataBaseConstants.USP_ArticleDiffbot_CheckDuplicate))
                    {

                        if (!string.IsNullOrEmpty(HashUrls))
                        { objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.HashUrls, DbType.String, HashUrls); }

                        #region DataSet
                        using (DataSet ds = objDataAccessWrapper.ExecuteDataSet(dbCommand))
                        {
                            if (ds != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
                            {
                                DataTable dt = ds.Tables[0];
                                foreach (DataRow dr in dt.Rows)
                                {
                                    if (!dr[DataBaseConstants.HashUrl].Equals(DBNull.Value))
                                    {
                                        string strHash = Convert.ToString(dr[DataBaseConstants.HashUrl]);

                                        if (!dr[DataBaseConstants.ADID].Equals(DBNull.Value))
                                        {
                                            lstArticles.Where(w => w.HashUrl == strHash).ToList().ForEach(i => i.ADID = Convert.ToInt32(dr[DataBaseConstants.ADID]));
                                        }

                                        if (!dr[DataBaseConstants.DB_Title].Equals(DBNull.Value))
                                        {
                                            lstArticles.Where(w => w.HashUrl == strHash).ToList().ForEach(i => i.DB_Title = Convert.ToString(dr[DataBaseConstants.DB_Title]));
                                        }

                                        if (!dr[DataBaseConstants.DB_Text].Equals(DBNull.Value))
                                        {
                                            lstArticles.Where(w => w.HashUrl == strHash).ToList().ForEach(i => i.DB_Text = Convert.ToString(dr[DataBaseConstants.DB_Text]));
                                        }
                                    }
                                }
                            }
                        }
                        #endregion
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return lstArticles;
        }

        public List<string> FetchPublications_Exclusion(Int32 TopicID)
        {
            List<string> list = new List<string>();
            try
            {

                using (DataAccessWrapper DataAccessWrapper = new DataAccessWrapper(DataBaseConstants.MDBConnectionString))
                {
                    using (DbCommand dbCommand = DataAccessWrapper.GetStoredProcCommand(DataBaseConstants.USP_PublicationExclude_Fetch))
                    {
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.TopicID, DbType.Int32, TopicID);

                        #region DataSet
                        using (DataSet ds = DataAccessWrapper.ExecuteDataSet(dbCommand))
                        {
                            if (ds != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
                            {
                                DataTable dt = ds.Tables[0];
                                foreach (DataRow dr in dt.Rows)
                                {
                                    eArticle_Online objeEntityQuery = new eArticle_Online();

                                    if (!dr[DataBaseConstants.Publication_Url].Equals(DBNull.Value))
                                    {
                                        objeEntityQuery.Publication_Url = Convert.ToString(dr[DataBaseConstants.Publication_Url]);
                                    }

                                    list.Add(objeEntityQuery.Publication_Url);
                                }
                            }
                        }
                        #endregion
                    }
                }

            }
            catch (Exception ex)
            {

                throw ex;
            }

            return list;
        }

        public List<eArticle_Online> CheckPublicationType(String HashUrls, List<eArticle_Online> lstArticles)
        {
            try
            {
                using (DataAccessWrapper objDataAccessWrapper = new DataAccessWrapper(DataBaseConstants.MDBConnectionString))
                {
                    using (DbCommand dbCommand = objDataAccessWrapper.GetStoredProcCommand(DataBaseConstants.USP_mstPublication_CheckPublicationType))
                    {

                        if (!string.IsNullOrEmpty(HashUrls))
                        { objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.HashUrls, DbType.String, HashUrls); }

                        #region DataSet
                        using (DataSet ds = objDataAccessWrapper.ExecuteDataSet(dbCommand))
                        {
                            if (ds != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
                            {
                                DataTable dt = ds.Tables[0];
                                foreach (DataRow dr in dt.Rows)
                                {
                                    if (!dr[DataBaseConstants.HashUrl].Equals(DBNull.Value))
                                    {
                                        string strPublication_Url = Convert.ToString(dr[DataBaseConstants.HashUrl]);

                                        if (!dr[DataBaseConstants.PublicationType].Equals(DBNull.Value))
                                        {
                                            lstArticles.Where(w => w.Publication_Url == strPublication_Url).ToList().ForEach(i => i.PublicationType = Convert.ToString(dr[DataBaseConstants.PublicationType]));
                                        }
                                    }
                                }
                            }
                        }
                        #endregion
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return lstArticles;
        }

        public List<eArticle_Online> FetchPublications_Known(Int32 TopicID)
        {
            List<eArticle_Online> list = new List<eArticle_Online>();
            try
            {

                using (DataAccessWrapper DataAccessWrapper = new DataAccessWrapper(DataBaseConstants.MDBConnectionString))
                {
                    using (DbCommand dbCommand = DataAccessWrapper.GetStoredProcCommand(DataBaseConstants.USP_PublicationKnown_Fetch))
                    {
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.TopicID, DbType.Int32, TopicID);

                        #region DataSet
                        using (DataSet ds = DataAccessWrapper.ExecuteDataSet(dbCommand))
                        {
                            if (ds != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
                            {
                                DataTable dt = ds.Tables[0];
                                foreach (DataRow dr in dt.Rows)
                                {
                                    eArticle_Online objeEntityQuery = new eArticle_Online();

                                    if (!dr[DataBaseConstants.Publication_Url].Equals(DBNull.Value))
                                    {
                                        objeEntityQuery.Publication_Url = Convert.ToString(dr[DataBaseConstants.Publication_Url]);
                                    }

                                    if (!dr[DataBaseConstants.PublicationType].Equals(DBNull.Value))
                                    {
                                        objeEntityQuery.PublicationType = Convert.ToString(dr[DataBaseConstants.PublicationType]);
                                    }

                                    list.Add(objeEntityQuery);
                                }
                            }
                        }
                        #endregion
                    }
                }

            }
            catch (Exception ex)
            {

                throw ex;
            }

            return list;
        }

        public bool InsertPublication_NonNews(String HashUrls)
        {
            try
            {
                using (DataAccessWrapper objDataAccessWrapper = new DataAccessWrapper(DataBaseConstants.MDBConnectionString))
                {
                    using (DbCommand dbCommand = objDataAccessWrapper.GetStoredProcCommand(Common.Constants.DataBaseConstants.USP_mstPublication_InsertNonNews))
                    {
                        if (!string.IsNullOrEmpty(HashUrls))
                        { objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.HashUrls, DbType.String, HashUrls); }


                        objDataAccessWrapper.ExecuteNonQuery(dbCommand);
                        return true;
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


        public List<ePublication> Publication_FetchToUpdate(string strType)
        {
            List<ePublication> list = new List<ePublication>();
            try
            {

                using (DataAccessWrapper DataAccessWrapper = new DataAccessWrapper(DataBaseConstants.MDBConnectionString))
                {
                    using (DbCommand dbCommand = DataAccessWrapper.GetStoredProcCommand(DataBaseConstants.USP_Publication_FetchToUpdate))
                    {

                        if (!string.IsNullOrEmpty(strType))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Type, DbType.String, strType); }

                        #region DataSet
                        using (DataSet ds = DataAccessWrapper.ExecuteDataSet(dbCommand))
                        {
                            if (ds != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
                            {
                                DataTable dt = ds.Tables[0];
                                foreach (DataRow dr in dt.Rows)
                                {
                                    ePublication objeEntityQuery = new ePublication();

                                    if (!dr[DataBaseConstants.PublicationID].Equals(DBNull.Value))
                                    {
                                        objeEntityQuery.PublicationID = Convert.ToInt32(dr[DataBaseConstants.PublicationID]);
                                    }

                                    if (!dr[DataBaseConstants.Publication].Equals(DBNull.Value))
                                    {
                                        objeEntityQuery.Domain = Convert.ToString(dr[DataBaseConstants.Publication]);
                                        objeEntityQuery.Publication = Convert.ToString(dr[DataBaseConstants.Publication]);
                                    }

                                    list.Add(objeEntityQuery);
                                }
                            }
                        }
                        #endregion
                    }
                }

            }
            catch (Exception ex)
            {

                throw ex;
            }

            return list;
        }

        public Int32 UpdateDetails_Publication(DataTable dt, string strType)
        {
            Int32 Result = 0;
            try
            {
                using (DataAccessWrapper wrapper = new DataAccessWrapper(DataBaseConstants.MDBConnectionString))
                {
                    using (DbCommand cmd = wrapper.GetStoredProcCommand(DataBaseConstants.USP_Publication_UpdateDetails))
                    {
                        cmd.CommandTimeout = 0;

                        if (!string.IsNullOrEmpty(strType))
                        { wrapper.AddInParameter(cmd, Common.Constants.DataBaseConstants.Type, DbType.String, strType); }

                        System.Data.SqlClient.SqlParameter temp = new System.Data.SqlClient.SqlParameter("@" + DataBaseConstants.UDTT_Publication_Detail, SqlDbType.Structured);
                        temp.TypeName = "dbo." + DataBaseConstants.UDTT_Publication_Detail;
                        temp.Value = dt;
                        cmd.Parameters.Add(temp);

                        Result = Convert.ToInt32(wrapper.ExecuteScalar(cmd));
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return Result;
        }

        #endregion

        #region PRINT

        public string Encrypt(string clearText)
        {

            string EncryptionKey = "MAKV2SPBNI99212";

            byte[] clearBytes = Encoding.Unicode.GetBytes(clearText);

            using (Aes encryptor = Aes.Create())
            {

                Rfc2898DeriveBytes pdb = new Rfc2898DeriveBytes(EncryptionKey, new byte[] { 0x49, 0x76, 0x61, 0x6e, 0x20, 0x4d, 0x65, 0x64, 0x76, 0x65, 0x64, 0x65, 0x76 });

                encryptor.Key = pdb.GetBytes(32);

                encryptor.IV = pdb.GetBytes(16);

                using (MemoryStream ms = new MemoryStream())
                {

                    using (CryptoStream cs = new CryptoStream(ms, encryptor.CreateEncryptor(), CryptoStreamMode.Write))
                    {

                        cs.Write(clearBytes, 0, clearBytes.Length);

                        cs.Close();

                    }

                    clearText = Convert.ToBase64String(ms.ToArray());

                }

            }

            return clearText;

        }

        public List<eArticle_Print> Fetch_Aticles_Print(eEntityQuery objEQ, string FromDate, string ToDate)
        {
            List<eArticle_Print> list = new List<eArticle_Print>();
            try
            {

                using (DataAccessWrapper DataAccessWrapper = new DataAccessWrapper(DataBaseConstants.MTrackConnectionString))
                {
                    using (DbCommand dbCommand = DataAccessWrapper.GetStoredProcCommand(DataBaseConstants.USP_Analaysis_Search))
                    {

                        if (!string.IsNullOrEmpty(objEQ.Query))
                        {
                            DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.strEntityId, DbType.String, objEQ.Query);
                            DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.FromDate, DbType.String, FromDate);
                            DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.ToDate, DbType.String, ToDate);

                            #region DataSet
                            using (DataSet ds = DataAccessWrapper.ExecuteDataSet(dbCommand))
                            {
                                if (ds != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
                                {
                                    DataTable dt = ds.Tables[0];
                                    foreach (DataRow dr in dt.Rows)
                                    {
                                        eArticle_Print obj = new eArticle_Print();
                                        obj.EQID = objEQ.EQID;
                                        obj.EntityID = objEQ.EntityID;
                                        obj.TopicID = objEQ.TopicID;
                                        if (!dr[DataBaseConstants.NewsID].Equals(DBNull.Value))
                                        {
                                            obj.NewsID = Convert.ToInt32(dr[DataBaseConstants.NewsID]);

                                            obj.Url = Encrypt(Convert.ToString(obj.NewsID));
                                        }

                                        if (!dr[DataBaseConstants.AVE].Equals(DBNull.Value))
                                        {
                                            obj.AVE = Convert.ToDecimal(dr[DataBaseConstants.AVE]);
                                        }

                                        if (!dr[DataBaseConstants.NewsDate].Equals(DBNull.Value))
                                        {
                                            obj.NewsDate = Convert.ToDateTime(dr[DataBaseConstants.NewsDate]);
                                        }

                                        if (!dr[DataBaseConstants.IssueDate].Equals(DBNull.Value))
                                        {
                                            obj.IssueDate = Convert.ToDateTime(dr[DataBaseConstants.IssueDate]);
                                        }



                                        if (!dr[DataBaseConstants.MEDIATYPE].Equals(DBNull.Value))
                                        {
                                            obj.MEDIATYPE = dr[DataBaseConstants.MEDIATYPE].ToString();
                                        }

                                        if (!dr[DataBaseConstants.EntityName].Equals(DBNull.Value))
                                        {
                                            obj.MTrackEntityName = dr[DataBaseConstants.EntityName].ToString();
                                        }

                                        if (!dr[DataBaseConstants.Publicationtype].Equals(DBNull.Value))
                                        {
                                            obj.Publicationtype = dr[DataBaseConstants.Publicationtype].ToString();
                                        }

                                        if (!dr[DataBaseConstants.Publication].Equals(DBNull.Value))
                                        {
                                            obj.Publication = dr[DataBaseConstants.Publication].ToString();
                                        }

                                        if (!dr[DataBaseConstants.Language].Equals(DBNull.Value))
                                        {
                                            obj.Language = dr[DataBaseConstants.Language].ToString();
                                        }

                                        if (!dr[DataBaseConstants.Agency].Equals(DBNull.Value))
                                        {
                                            obj.Agency = dr[DataBaseConstants.Agency].ToString();
                                        }

                                        if (!dr[DataBaseConstants.Author].Equals(DBNull.Value))
                                        {
                                            obj.Author = dr[DataBaseConstants.Author].ToString();
                                        }

                                        if (!dr[DataBaseConstants.Edition].Equals(DBNull.Value))
                                        {
                                            obj.Edition = dr[DataBaseConstants.Edition].ToString();
                                        }

                                        if (!dr[DataBaseConstants.Source].Equals(DBNull.Value))
                                        {
                                            obj.Source = dr[DataBaseConstants.Source].ToString();
                                        }

                                        if (!dr[DataBaseConstants.Journalist].Equals(DBNull.Value))
                                        {
                                            obj.Journalist = dr[DataBaseConstants.Journalist].ToString();
                                        }

                                        if (!dr[DataBaseConstants.Supplement].Equals(DBNull.Value))
                                        {
                                            obj.Supplement = dr[DataBaseConstants.Supplement].ToString();
                                        }

                                        if (!dr[DataBaseConstants.Headline].Equals(DBNull.Value))
                                        {
                                            obj.Headline = dr[DataBaseConstants.Headline].ToString();
                                        }

                                        if (!dr[DataBaseConstants.Summary].Equals(DBNull.Value))
                                        {
                                            obj.Summary = dr[DataBaseConstants.Summary].ToString();
                                        }

                                        if (!dr[DataBaseConstants.NewsText].Equals(DBNull.Value))
                                        {
                                            obj.NewsText = dr[DataBaseConstants.NewsText].ToString();
                                        }

                                        if (!dr[DataBaseConstants.ClientID].Equals(DBNull.Value))
                                        {
                                            obj.ClientID = dr[DataBaseConstants.ClientID].ToString();
                                        }

                                        if (!dr[DataBaseConstants.Id].Equals(DBNull.Value))
                                        {
                                            obj.Id = Convert.ToInt32(dr[DataBaseConstants.Id]);
                                        }

                                        if (!dr[DataBaseConstants.ImagePath].Equals(DBNull.Value))
                                        {
                                            obj.ImagePath = dr[DataBaseConstants.ImagePath].ToString();
                                        }

                                        if (!dr[DataBaseConstants.ImageURL].Equals(DBNull.Value))
                                        {
                                            obj.ImageURL = dr[DataBaseConstants.ImageURL].ToString();
                                        }

                                        if (!dr[DataBaseConstants.PgNO].Equals(DBNull.Value))
                                        {
                                            obj.PgNO = dr[DataBaseConstants.PgNO].ToString();
                                        }

                                        if (!dr[DataBaseConstants.SortPNo].Equals(DBNull.Value))
                                        {
                                            obj.SortPNo = dr[DataBaseConstants.SortPNo].ToString();
                                        }

                                        if (!dr[DataBaseConstants.Height].Equals(DBNull.Value))
                                        {
                                            obj.Height = dr[DataBaseConstants.Height].ToString();
                                        }

                                        if (!dr[DataBaseConstants.Col].Equals(DBNull.Value))
                                        {
                                            obj.Col = dr[DataBaseConstants.Col].ToString();
                                        }

                                        if (!dr[DataBaseConstants.NewsLocation].Equals(DBNull.Value))
                                        {
                                            obj.NewsLocation = dr[DataBaseConstants.NewsLocation].ToString();
                                        }

                                        if (!dr[DataBaseConstants.EntityID].Equals(DBNull.Value))
                                        {
                                            obj.MTrackEntityIds = dr[DataBaseConstants.EntityID].ToString();
                                        }

                                        if (!dr[DataBaseConstants.PageNo].Equals(DBNull.Value))
                                        {
                                            obj.PageNo = dr[DataBaseConstants.PageNo].ToString();
                                        }

                                        if (!dr[DataBaseConstants.HtInCms].Equals(DBNull.Value))
                                        {
                                            obj.HtInCms = dr[DataBaseConstants.HtInCms].ToString();
                                        }

                                        if (!dr[DataBaseConstants.NoCols].Equals(DBNull.Value))
                                        {
                                            obj.NoCols = dr[DataBaseConstants.NoCols].ToString();
                                        }

                                        if (!dr[DataBaseConstants.NewsDetailID].Equals(DBNull.Value))
                                        {
                                            obj.NewsDetailID = Convert.ToInt32(dr[DataBaseConstants.NewsDetailID]);
                                        }

                                        if (!dr[DataBaseConstants.ReporterNewsId].Equals(DBNull.Value))
                                        {
                                            obj.ReporterNewsId = Convert.ToInt32(dr[DataBaseConstants.ReporterNewsId]);
                                        }

                                        if (!dr[DataBaseConstants.CirculationScore].Equals(DBNull.Value))
                                        {
                                            obj.CirculationScore = Convert.ToInt64(dr[DataBaseConstants.CirculationScore]);
                                        }

                                        list.Add(obj);
                                    }
                                }
                            }
                            #endregion

                        }
                    }
                }

            }
            catch (Exception ex)
            {

                throw ex;
            }

            return list;
        }

        public void InsertArticlePrint(eArticle_Print obj)
        {
            try
            {
                using (DataAccessWrapper objDataAccessWrapper = new DataAccessWrapper(DataBaseConstants.MDBConnectionString))
                {
                    using (DbCommand dbCommand = objDataAccessWrapper.GetStoredProcCommand(Common.Constants.DataBaseConstants.USP_ArticlePrint_Insert))
                    {
                        objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.EQID, DbType.Int32, obj.EQID);
                        objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.EntityID, DbType.Int32, obj.EntityID);
                        objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.NewsID, DbType.Int32, obj.NewsID);
                        objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.TopicID, DbType.Int32, obj.TopicID);

                        objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.AVE, DbType.Decimal, obj.AVE);

                        if (obj.NewsDate != DateTime.MinValue)
                        {
                            objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.NewsDate, DbType.DateTime, obj.NewsDate);
                        }

                        if (obj.IssueDate != DateTime.MinValue)
                        {
                            objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.IssueDate, DbType.DateTime, obj.IssueDate);
                        }

                        if (!string.IsNullOrEmpty(obj.Url))
                        {
                            objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Url, DbType.String, obj.Url);
                        }

                        if (!string.IsNullOrEmpty(obj.MEDIATYPE))
                        {
                            objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.MEDIATYPE, DbType.String, obj.MEDIATYPE);
                        }

                        if (!string.IsNullOrEmpty(obj.MTrackEntityName))
                        {
                            objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.MTrackEntityName, DbType.String, obj.MTrackEntityName);
                        }

                        if (!string.IsNullOrEmpty(obj.Publicationtype))
                        {
                            objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Publicationtype, DbType.String, obj.Publicationtype);
                        }

                        if (!string.IsNullOrEmpty(obj.Publication))
                        {
                            objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Publication, DbType.String, obj.Publication);
                        }

                        if (!string.IsNullOrEmpty(obj.Language))
                        {
                            objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Language, DbType.String, obj.Language);
                        }

                        if (!string.IsNullOrEmpty(obj.Agency))
                        {
                            objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Agency, DbType.String, obj.Agency);
                        }

                        if (!string.IsNullOrEmpty(obj.Author))
                        {
                            objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Author, DbType.String, obj.Author);
                        }

                        if (!string.IsNullOrEmpty(obj.Edition))
                        {
                            objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Edition, DbType.String, obj.Edition);
                        }

                        if (!string.IsNullOrEmpty(obj.Source))
                        {
                            objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Source, DbType.String, obj.Source);
                        }

                        if (!string.IsNullOrEmpty(obj.Journalist))
                        {
                            objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Journalist, DbType.String, obj.Journalist);
                        }

                        if (!string.IsNullOrEmpty(obj.Supplement))
                        {
                            objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Supplement, DbType.String, obj.Supplement);
                        }

                        if (!string.IsNullOrEmpty(obj.Headline))
                        {
                            objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Headline, DbType.String, obj.Headline);
                        }

                        if (!string.IsNullOrEmpty(obj.Summary))
                        {
                            objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Summary, DbType.String, obj.Summary);
                        }

                        if (!string.IsNullOrEmpty(obj.NewsText))
                        {
                            objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.NewsText, DbType.String, obj.NewsText);
                        }

                        if (!string.IsNullOrEmpty(obj.ClientID))
                        {
                            objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.ClientID, DbType.String, obj.ClientID);
                        }

                        objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Id, DbType.Int32, obj.Id);

                        if (!string.IsNullOrEmpty(obj.ImagePath))
                        {
                            objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.ImagePath, DbType.String, obj.ImagePath);
                        }

                        if (!string.IsNullOrEmpty(obj.ImageURL))
                        {
                            objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.ImageURL, DbType.String, obj.ImageURL);
                        }

                        if (!string.IsNullOrEmpty(obj.PgNO))
                        {
                            objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.PgNO, DbType.String, obj.PgNO);
                        }

                        if (!string.IsNullOrEmpty(obj.SortPNo))
                        {
                            objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.SortPNo, DbType.String, obj.SortPNo);
                        }

                        if (!string.IsNullOrEmpty(obj.Height))
                        {
                            objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Height, DbType.String, obj.Height);
                        }

                        if (!string.IsNullOrEmpty(obj.Col))
                        {
                            objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Col, DbType.String, obj.Col);
                        }

                        if (!string.IsNullOrEmpty(obj.NewsLocation))
                        {
                            objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.NewsLocation, DbType.String, obj.NewsLocation);
                        }

                        if (!string.IsNullOrEmpty(obj.MTrackEntityIds))
                        {
                            objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.MTrackEntityIds, DbType.String, obj.MTrackEntityIds);
                        }

                        if (!string.IsNullOrEmpty(obj.PageNo))
                        {
                            objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.PageNo, DbType.String, obj.PageNo);
                        }

                        if (!string.IsNullOrEmpty(obj.HtInCms))
                        {
                            objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.HtInCms, DbType.String, obj.HtInCms);
                        }

                        if (!string.IsNullOrEmpty(obj.NoCols))
                        {
                            objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.NoCols, DbType.String, obj.NoCols);
                        }

                        objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.NewsDetailID, DbType.Int32, obj.NewsDetailID);

                        objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.ReporterNewsId, DbType.Int32, obj.ReporterNewsId);

                        objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.CirculationScore, DbType.Int64, obj.CirculationScore);

                        if (!string.IsNullOrEmpty(obj.Is_Relevant_Headline))
                        { objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Is_Relevant_Headline, DbType.String, obj.Is_Relevant_Headline); }

                        if (!string.IsNullOrEmpty(obj.Is_Relevant_FirstPara))
                        { objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Is_Relevant_FirstPara, DbType.String, obj.Is_Relevant_FirstPara); }

                        if (!string.IsNullOrEmpty(obj.Is_Relevant_RestOfArticle))
                        { objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Is_Relevant_RestOfArticle, DbType.String, obj.Is_Relevant_RestOfArticle); }

                        if (!string.IsNullOrEmpty(obj.HeadlineForRelevancy))
                        { objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.HeadlineForRelevancy, DbType.String, obj.HeadlineForRelevancy); }

                        if (!string.IsNullOrEmpty(obj.FirstParaForRelevancy))
                        { objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.FirstParaForRelevancy, DbType.String, obj.FirstParaForRelevancy); }

                        if (!string.IsNullOrEmpty(obj.RestOfArticleForRelevancy))
                        { objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.RestOfArticleForRelevancy, DbType.String, obj.RestOfArticleForRelevancy); }

                        objDataAccessWrapper.ExecuteScalar(dbCommand);
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


        #endregion

        #region Twitter

        public void Twitter_InsertTweet(eTwitter obj)
        {
            try
            {
                using (DataAccessWrapper objDataAccessWrapper = new DataAccessWrapper(DataBaseConstants.MDBConnectionString))
                {
                    using (DbCommand dbCommand = objDataAccessWrapper.GetStoredProcCommand(Common.Constants.DataBaseConstants.USP_Twitter_Insert))
                    {
                        objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.EQID, DbType.Int32, obj.EQID);
                        objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.EntityID, DbType.Int32, obj.EntityID);
                        objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.TopicID, DbType.Int32, obj.TopicID);

                        objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Engagement_BookmarkCount, DbType.Int64, obj.Engagement_BookmarkCount);
                        objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Engagement_LikeCount, DbType.Int64, obj.Engagement_LikeCount);
                        objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Engagement_QuoteCount, DbType.Int64, obj.Engagement_QuoteCount);
                        objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Engagement_ReplyCount, DbType.Int64, obj.Engagement_ReplyCount);
                        objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Engagement_RetweetCount, DbType.Int64, obj.Engagement_RetweetCount);
                        objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Engagement_ViewCount, DbType.Int64, obj.Engagement_ViewCount);


                        if (!string.IsNullOrEmpty(obj.Mentioned_Handles))
                        { objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Mentioned_Handles, DbType.String, obj.Mentioned_Handles); }

                        if (!string.IsNullOrEmpty(obj.Mentioned_Hashtags))
                        { objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Mentioned_Hashtags, DbType.String, obj.Mentioned_Hashtags); }

                        if (!string.IsNullOrEmpty(obj.Mentioned_Hyperlinks))
                        { objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Mentioned_Hyperlinks, DbType.String, obj.Mentioned_Hyperlinks); }

                        if (!string.IsNullOrEmpty(obj.Mentioned_Images))
                        { objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Mentioned_Images, DbType.String, obj.Mentioned_Images); }

                        if (!string.IsNullOrEmpty(obj.Mentioned_Videos))
                        { objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Mentioned_Videos, DbType.String, obj.Mentioned_Videos); }

                        objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Mentioned_Video_DurationInMs, DbType.Int64, obj.Mentioned_Videos_DurationInMs);
                        objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Mentioned_Video_ViewsCount, DbType.Int64, obj.Mentioned_Videos_Views);


                        if (!string.IsNullOrEmpty(obj.Profile_Description))
                        { objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Profile_Description, DbType.String, obj.Profile_Description); }

                        if (!string.IsNullOrEmpty(obj.Profile_ExternalUrl))
                        { objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Profile_ExternalUrl, DbType.String, obj.Profile_ExternalUrl); }

                        if (!string.IsNullOrEmpty(obj.Profile_ID))
                        { objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Profile_ID, DbType.String, obj.Profile_ID); }

                        objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Profile_FollowersCount, DbType.Int64, obj.Profile_FollowersCount);
                        objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Profile_FollowingCount, DbType.Int64, obj.Profile_FollowingCount);


                        if (!string.IsNullOrEmpty(obj.Profile_Handle))
                        { objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Profile_Handle, DbType.String, obj.Profile_Handle); }

                        objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Profile_IsProtected, DbType.Int16, obj.Profile_IsProtected);
                        objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Profile_IsVerified, DbType.Int16, obj.Profile_IsVerified);

                        if (obj.Profile_JoinedDate != DateTime.MinValue)
                        { objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Profile_JoinedDate, DbType.DateTime, obj.Profile_JoinedDate); }

                        objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Profile_ListsCount, DbType.Int64, obj.Profile_ListsCount);

                        if (!string.IsNullOrEmpty(obj.Profile_Location))
                        { objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Profile_Location, DbType.String, obj.Profile_Location); }

                        if (!string.IsNullOrEmpty(obj.Profile_Name))
                        { objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Profile_Name, DbType.String, obj.Profile_Name); }

                        if (!string.IsNullOrEmpty(obj.Profile_ProfilePicUrl))
                        { objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Profile_ProfilePicUrl, DbType.String, obj.Profile_ProfilePicUrl); }

                        objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Profile_TweetsCount, DbType.Int64, obj.Profile_TweetsCount);

                        if (!string.IsNullOrEmpty(obj.Profile_VerifiedType))
                        { objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Profile_VerifiedType, DbType.String, obj.Profile_VerifiedType); }

                        if (!string.IsNullOrEmpty(obj.Tweet_ConversationID))
                        { objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Tweet_ConversationID, DbType.String, obj.Tweet_ConversationID); }

                        if (obj.Tweet_Date != DateTime.MinValue)
                        { objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Tweet_Date, DbType.DateTime, obj.Tweet_Date); }

                        if (!string.IsNullOrEmpty(obj.Tweet_ID))
                        { objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Tweet_ID, DbType.String, obj.Tweet_ID); }

                        objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Tweet_IsQuoted, DbType.Int16, obj.Tweet_IsQuoted);
                        objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Tweet_IsReplied, DbType.Int16, obj.Tweet_IsReplied);
                        objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Tweet_IsRetweeted, DbType.Int16, obj.Tweet_IsRetweeted);

                        if (!string.IsNullOrEmpty(obj.Tweet_Language))
                        { objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Tweet_Language, DbType.String, obj.Tweet_Language); }

                        if (!string.IsNullOrEmpty(obj.Tweet_QuotedTo))
                        { objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Tweet_QuotedTo, DbType.String, obj.Tweet_QuotedTo); }

                        if (!string.IsNullOrEmpty(obj.Tweet_QuotedToText))
                        { objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Tweet_QuotedToText, DbType.String, obj.Tweet_QuotedToText); }

                        if (!string.IsNullOrEmpty(obj.Tweet_QuotedToTweetID))
                        { objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Tweet_QuotedToTweetID, DbType.String, obj.Tweet_QuotedToTweetID); }

                        if (!string.IsNullOrEmpty(obj.Tweet_RepliedTo))
                        { objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Tweet_RepliedTo, DbType.String, obj.Tweet_RepliedTo); }

                        if (!string.IsNullOrEmpty(obj.Tweet_RepliedToText))
                        { objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Tweet_RepliedToText, DbType.String, obj.Tweet_RepliedToText); }

                        if (!string.IsNullOrEmpty(obj.Tweet_RepliedToTweetID))
                        { objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Tweet_RepliedToTweetID, DbType.String, obj.Tweet_RepliedToTweetID); }

                        if (!string.IsNullOrEmpty(obj.Tweet_RetweetedTo))
                        { objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Tweet_RetweetedTo, DbType.String, obj.Tweet_RetweetedTo); }

                        if (!string.IsNullOrEmpty(obj.Tweet_RetweetedToTweetID))
                        { objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Tweet_RetweetedToTweetID, DbType.String, obj.Tweet_RetweetedToTweetID); }

                        if (!string.IsNullOrEmpty(obj.Tweet_Source))
                        { objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Tweet_Source, DbType.String, obj.Tweet_Source); }

                        if (!string.IsNullOrEmpty(obj.Tweet_Text))
                        { objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Tweet_Text, DbType.String, obj.Tweet_Text); }

                        if (!string.IsNullOrEmpty(obj.Tweet_URL))
                        { objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Tweet_URL, DbType.String, obj.Tweet_URL); }

                        if (!string.IsNullOrEmpty(obj.TypeOfListening))
                        { objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.TypeOfListening, DbType.String, obj.TypeOfListening); }

                        if (obj.CT_TreeParse_LastUpdatedAt != DateTime.MinValue)
                        { objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.CT_TreeParse_LastUpdatedAt, DbType.DateTime, obj.CT_TreeParse_LastUpdatedAt); }

                        objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.CT_IsRelevant, DbType.Int16, obj.CT_IsRelevant);

                        if (!string.IsNullOrEmpty(obj.CT_Relevant_Reason))
                        { objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.CT_Relevant_Reason, DbType.String, obj.CT_Relevant_Reason); }

                        objDataAccessWrapper.ExecuteNonQuery(dbCommand);
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public void Twitter_InsertTweet_FS(eTwitter obj, string strRow)
        {
            try
            {
                using (DataAccessWrapper objDataAccessWrapper = new DataAccessWrapper(DataBaseConstants.MDBConnectionString))
                {
                    using (DbCommand dbCommand = objDataAccessWrapper.GetStoredProcCommand(Common.Constants.DataBaseConstants.USP_Twitter_Insert))
                    {
                        objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.EQID, DbType.Int32, obj.EQID);
                        objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.EntityID, DbType.Int32, obj.EntityID);
                        objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.TopicID, DbType.Int32, obj.TopicID);

                        objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Engagement_BookmarkCount, DbType.Int64, obj.Engagement_BookmarkCount);
                        objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Engagement_LikeCount, DbType.Int64, obj.Engagement_LikeCount);
                        objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Engagement_QuoteCount, DbType.Int64, obj.Engagement_QuoteCount);
                        objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Engagement_ReplyCount, DbType.Int64, obj.Engagement_ReplyCount);
                        objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Engagement_RetweetCount, DbType.Int64, obj.Engagement_RetweetCount);
                        objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Engagement_ViewCount, DbType.Int64, obj.Engagement_ViewCount);


                        if (!string.IsNullOrEmpty(obj.Mentioned_Handles))
                        { objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Mentioned_Handles, DbType.String, obj.Mentioned_Handles); }

                        if (!string.IsNullOrEmpty(obj.Mentioned_Hashtags))
                        { objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Mentioned_Hashtags, DbType.String, obj.Mentioned_Hashtags); }

                        if (!string.IsNullOrEmpty(obj.Mentioned_Hyperlinks))
                        { objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Mentioned_Hyperlinks, DbType.String, obj.Mentioned_Hyperlinks); }

                        if (!string.IsNullOrEmpty(obj.Mentioned_Images))
                        { objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Mentioned_Images, DbType.String, obj.Mentioned_Images); }

                        if (!string.IsNullOrEmpty(obj.Mentioned_Videos))
                        { objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Mentioned_Videos, DbType.String, obj.Mentioned_Videos); }

                        objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Mentioned_Video_DurationInMs, DbType.Int64, obj.Mentioned_Videos_DurationInMs);
                        objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Mentioned_Video_ViewsCount, DbType.Int64, obj.Mentioned_Videos_Views);


                        if (!string.IsNullOrEmpty(obj.Profile_Description))
                        { objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Profile_Description, DbType.String, obj.Profile_Description); }

                        if (!string.IsNullOrEmpty(obj.Profile_ExternalUrl))
                        { objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Profile_ExternalUrl, DbType.String, obj.Profile_ExternalUrl); }

                        if (!string.IsNullOrEmpty(obj.Profile_ID))
                        { objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Profile_ID, DbType.String, obj.Profile_ID); }

                        objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Profile_FollowersCount, DbType.Int64, obj.Profile_FollowersCount);
                        objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Profile_FollowingCount, DbType.Int64, obj.Profile_FollowingCount);


                        if (!string.IsNullOrEmpty(obj.Profile_Handle))
                        { objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Profile_Handle, DbType.String, obj.Profile_Handle); }

                        objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Profile_IsProtected, DbType.Int16, obj.Profile_IsProtected);
                        objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Profile_IsVerified, DbType.Int16, obj.Profile_IsVerified);

                        if (obj.Profile_JoinedDate != DateTime.MinValue)
                        { objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Profile_JoinedDate, DbType.DateTime, obj.Profile_JoinedDate); }

                        objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Profile_ListsCount, DbType.Int64, obj.Profile_ListsCount);

                        if (!string.IsNullOrEmpty(obj.Profile_Location))
                        { objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Profile_Location, DbType.String, obj.Profile_Location); }

                        if (!string.IsNullOrEmpty(obj.Profile_Name))
                        { objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Profile_Name, DbType.String, obj.Profile_Name); }

                        if (!string.IsNullOrEmpty(obj.Profile_ProfilePicUrl))
                        { objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Profile_ProfilePicUrl, DbType.String, obj.Profile_ProfilePicUrl); }

                        objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Profile_TweetsCount, DbType.Int64, obj.Profile_TweetsCount);

                        if (!string.IsNullOrEmpty(obj.Profile_VerifiedType))
                        { objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Profile_VerifiedType, DbType.String, obj.Profile_VerifiedType); }

                        if (!string.IsNullOrEmpty(obj.Tweet_ConversationID))
                        { objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Tweet_ConversationID, DbType.String, obj.Tweet_ConversationID); }

                        if (obj.Tweet_Date != DateTime.MinValue)
                        { objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Tweet_Date, DbType.DateTime, obj.Tweet_Date); }

                        if (!string.IsNullOrEmpty(obj.Tweet_ID))
                        { objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Tweet_ID, DbType.String, obj.Tweet_ID); }

                        objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Tweet_IsQuoted, DbType.Int16, obj.Tweet_IsQuoted);
                        objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Tweet_IsReplied, DbType.Int16, obj.Tweet_IsReplied);
                        objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Tweet_IsRetweeted, DbType.Int16, obj.Tweet_IsRetweeted);

                        if (!string.IsNullOrEmpty(obj.Tweet_Language))
                        { objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Tweet_Language, DbType.String, obj.Tweet_Language); }

                        if (!string.IsNullOrEmpty(obj.Tweet_QuotedTo))
                        { objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Tweet_QuotedTo, DbType.String, obj.Tweet_QuotedTo); }

                        if (!string.IsNullOrEmpty(obj.Tweet_QuotedToText))
                        { objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Tweet_QuotedToText, DbType.String, obj.Tweet_QuotedToText); }

                        if (!string.IsNullOrEmpty(obj.Tweet_QuotedToTweetID))
                        { objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Tweet_QuotedToTweetID, DbType.String, obj.Tweet_QuotedToTweetID); }

                        if (!string.IsNullOrEmpty(obj.Tweet_RepliedTo))
                        { objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Tweet_RepliedTo, DbType.String, obj.Tweet_RepliedTo); }

                        if (!string.IsNullOrEmpty(obj.Tweet_RepliedToText))
                        { objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Tweet_RepliedToText, DbType.String, obj.Tweet_RepliedToText); }

                        if (!string.IsNullOrEmpty(obj.Tweet_RepliedToTweetID))
                        { objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Tweet_RepliedToTweetID, DbType.String, obj.Tweet_RepliedToTweetID); }

                        if (!string.IsNullOrEmpty(obj.Tweet_RetweetedTo))
                        { objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Tweet_RetweetedTo, DbType.String, obj.Tweet_RetweetedTo); }

                        if (!string.IsNullOrEmpty(obj.Tweet_RetweetedToTweetID))
                        { objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Tweet_RetweetedToTweetID, DbType.String, obj.Tweet_RetweetedToTweetID); }

                        if (!string.IsNullOrEmpty(obj.Tweet_Source))
                        { objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Tweet_Source, DbType.String, obj.Tweet_Source); }

                        if (!string.IsNullOrEmpty(obj.Tweet_Text))
                        { objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Tweet_Text, DbType.String, obj.Tweet_Text); }

                        if (!string.IsNullOrEmpty(obj.Tweet_URL))
                        { objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Tweet_URL, DbType.String, obj.Tweet_URL); }

                        if (!string.IsNullOrEmpty(obj.TypeOfListening))
                        { objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.TypeOfListening, DbType.String, obj.TypeOfListening); }

                        if (obj.CT_TreeParse_LastUpdatedAt != DateTime.MinValue)
                        { objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.CT_TreeParse_LastUpdatedAt, DbType.DateTime, obj.CT_TreeParse_LastUpdatedAt); }

                        objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.CT_IsRelevant, DbType.Int16, obj.CT_IsRelevant);

                        if (!string.IsNullOrEmpty(obj.CT_Relevant_Reason))
                        { objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.CT_Relevant_Reason, DbType.String, obj.CT_Relevant_Reason); }

                        //if (!string.IsNullOrEmpty(strRow))
                        //{ objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Summary, DbType.String, strRow); }

                        objDataAccessWrapper.ExecuteNonQuery(dbCommand);
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public List<eTwitter> FetchConversationIds(string strType)
        {
            List<eTwitter> list = new List<eTwitter>();
            try
            {

                using (DataAccessWrapper DataAccessWrapper = new DataAccessWrapper(DataBaseConstants.MDBConnectionString))
                {
                    using (DbCommand dbCommand = DataAccessWrapper.GetStoredProcCommand(DataBaseConstants.USP_Twitter_FetchConversationIds))
                    {
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Type, DbType.String, strType);
                        #region DataSet
                        using (DataSet ds = DataAccessWrapper.ExecuteDataSet(dbCommand))
                        {
                            if (ds != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
                            {
                                DataTable dt = ds.Tables[0];
                                foreach (DataRow dr in dt.Rows)
                                {
                                    eTwitter objeEntityQuery = new eTwitter();

                                    if (!dr[DataBaseConstants.Tweet_ConversationID].Equals(DBNull.Value))
                                    {
                                        objeEntityQuery.Tweet_ConversationID = Convert.ToString(dr[DataBaseConstants.Tweet_ConversationID]);
                                    }

                                    if (!dr[DataBaseConstants.EntityID].Equals(DBNull.Value))
                                    {
                                        objeEntityQuery.EntityID = Convert.ToInt32(dr[DataBaseConstants.EntityID]);
                                    }

                                    if (!dr[DataBaseConstants.EQID].Equals(DBNull.Value))
                                    {
                                        objeEntityQuery.EQID = Convert.ToInt32(dr[DataBaseConstants.EQID]);
                                    }

                                    if (!dr[DataBaseConstants.TopicID].Equals(DBNull.Value))
                                    {
                                        objeEntityQuery.TopicID = Convert.ToInt32(dr[DataBaseConstants.TopicID]);
                                    }

                                    if (!dr[DataBaseConstants.CT_Is_Detail_Fetched].Equals(DBNull.Value))
                                    {
                                        objeEntityQuery.CT_Is_Detail_Fetched = Convert.ToInt32(dr[DataBaseConstants.CT_Is_Detail_Fetched]);
                                    }

                                    if (!dr[DataBaseConstants.CT_TreeParse_LastUpdatedAt].Equals(DBNull.Value))
                                    {
                                        objeEntityQuery.CT_TreeParse_LastUpdatedAt = Convert.ToDateTime(dr[DataBaseConstants.CT_TreeParse_LastUpdatedAt]);
                                    }

                                    if (!dr[DataBaseConstants.CT_Query].Equals(DBNull.Value))
                                    {
                                        objeEntityQuery.CT_Query = Convert.ToString(dr[DataBaseConstants.CT_Query]);
                                    }

                                    if (!dr[DataBaseConstants.Incident_StartDate].Equals(DBNull.Value))
                                    {
                                        objeEntityQuery.Incident_StartDate = Convert.ToDateTime(dr[DataBaseConstants.Incident_StartDate]);
                                    }

                                    //if (!dr[DataBaseConstants.GroupKey].Equals(DBNull.Value))
                                    //{
                                    //    objeEntityQuery.CT_GroupKey = Convert.ToString(dr[DataBaseConstants.GroupKey]);
                                    //}


                                    list.Add(objeEntityQuery);
                                }
                            }
                        }
                        #endregion
                    }
                }

            }
            catch (Exception ex)
            {

                throw ex;
            }

            return list;
        }

        public List<eTwitter> Twitter_FetchTweetIdsForEngagmentUpdate()
        {
            List<eTwitter> list = new List<eTwitter>();
            try
            {

                using (DataAccessWrapper DataAccessWrapper = new DataAccessWrapper(DataBaseConstants.MDBConnectionString))
                {
                    using (DbCommand dbCommand = DataAccessWrapper.GetStoredProcCommand(DataBaseConstants.USP_Twitter_FetchTweetIdsForEngagementUpdate))
                    {
                        #region DataSet
                        using (DataSet ds = DataAccessWrapper.ExecuteDataSet(dbCommand))
                        {
                            if (ds != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
                            {
                                DataTable dt = ds.Tables[0];
                                foreach (DataRow dr in dt.Rows)
                                {
                                    eTwitter objeEntityQuery = new eTwitter();

                                    if (!dr[DataBaseConstants.Tweet_ID].Equals(DBNull.Value))
                                    {
                                        objeEntityQuery.Tweet_ID = Convert.ToString(dr[DataBaseConstants.Tweet_ID]);
                                    }

                                    list.Add(objeEntityQuery);
                                }
                            }
                        }
                        #endregion
                    }
                }

            }
            catch (Exception ex)
            {

                throw ex;
            }

            return list;
        }

        public Int32 InsertEngagement_Twitter(DataTable dt)
        {
            Int32 Result = 0;
            try
            {
                using (DataAccessWrapper wrapper = new DataAccessWrapper(DataBaseConstants.MDBConnectionString))
                {
                    using (DbCommand cmd = wrapper.GetStoredProcCommand(DataBaseConstants.USP_Twitter_InsertEngagement))
                    {
                        cmd.CommandTimeout = 0;

                        System.Data.SqlClient.SqlParameter temp = new System.Data.SqlClient.SqlParameter("@" + DataBaseConstants.UDTT_Twitter_Engagement, SqlDbType.Structured);
                        temp.TypeName = "dbo." + DataBaseConstants.UDTT_Twitter_Engagement;
                        temp.Value = dt;
                        cmd.Parameters.Add(temp);

                        Result = Convert.ToInt32(wrapper.ExecuteScalar(cmd));
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return Result;
        }

        public List<eTwitter> Twitter_FetchHandlesForDetailsUpdate()
        {
            List<eTwitter> list = new List<eTwitter>();
            try
            {

                using (DataAccessWrapper DataAccessWrapper = new DataAccessWrapper(DataBaseConstants.MDBConnectionString))
                {
                    using (DbCommand dbCommand = DataAccessWrapper.GetStoredProcCommand(DataBaseConstants.USP_Twitter_FetchHandlesForDetailsUpdate))
                    {
                        #region DataSet
                        using (DataSet ds = DataAccessWrapper.ExecuteDataSet(dbCommand))
                        {
                            if (ds != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
                            {
                                DataTable dt = ds.Tables[0];
                                foreach (DataRow dr in dt.Rows)
                                {
                                    eTwitter objeEntityQuery = new eTwitter();

                                    if (!dr[DataBaseConstants.Profile_Handle].Equals(DBNull.Value))
                                    {
                                        objeEntityQuery.Profile_Handle = Convert.ToString(dr[DataBaseConstants.Profile_Handle]);
                                    }

                                    if (!dr[DataBaseConstants.Profile_ID].Equals(DBNull.Value))
                                    {
                                        objeEntityQuery.Profile_ID = Convert.ToString(dr[DataBaseConstants.Profile_ID]);
                                    }

                                    list.Add(objeEntityQuery);
                                }
                            }
                        }
                        #endregion
                    }
                }

            }
            catch (Exception ex)
            {

                throw ex;
            }

            return list;
        }

        public Int32 InsertProfileDetail_Twitter(DataTable dt)
        {
            Int32 Result = 0;
            try
            {
                using (DataAccessWrapper wrapper = new DataAccessWrapper(DataBaseConstants.MDBConnectionString))
                {
                    using (DbCommand cmd = wrapper.GetStoredProcCommand(DataBaseConstants.USP_Twitter_InsertProfileDetail))
                    {
                        cmd.CommandTimeout = 0;

                        System.Data.SqlClient.SqlParameter temp = new System.Data.SqlClient.SqlParameter("@" + DataBaseConstants.UDTT_Twitter_ProfileDetail, SqlDbType.Structured);
                        temp.TypeName = "dbo." + DataBaseConstants.UDTT_Twitter_ProfileDetail;
                        temp.Value = dt;
                        cmd.Parameters.Add(temp);

                        Result = Convert.ToInt32(wrapper.ExecuteScalar(cmd));
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return Result;
        }

        public List<eArticle_Online> Twitter_FetchMentionedLinks(Int32 TopicID)
        {
            List<eArticle_Online> lstArticles = new List<eArticle_Online>();

            try
            {
                using (DataAccessWrapper objDataAccessWrapper = new DataAccessWrapper(DataBaseConstants.MDBConnectionString))
                {
                    using (DbCommand dbCommand = objDataAccessWrapper.GetStoredProcCommand(DataBaseConstants.USP_Twitter_FetchMentionedLinks))
                    {
                        objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.TopicID, DbType.Int32, TopicID);

                        #region DataSet
                        using (DataSet ds = objDataAccessWrapper.ExecuteDataSet(dbCommand))
                        {
                            if (ds != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
                            {
                                DataTable dt = ds.Tables[0];
                                foreach (DataRow dr in dt.Rows)
                                {
                                    eArticle_Online oeArticle_Online = new eArticle_Online();
                                    if (!dr[DataBaseConstants.Url].Equals(DBNull.Value))
                                    {
                                        oeArticle_Online.Url = Convert.ToString(dr[DataBaseConstants.Url]);

                                        lstArticles.Add(oeArticle_Online);
                                    }
                                }
                            }
                        }
                        #endregion
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return lstArticles;
        }

        #endregion

        #region Log

        public void InsertLog(eLog obj)
        {
            try
            {
                using (DataAccessWrapper objDataAccessWrapper = new DataAccessWrapper(DataBaseConstants.MDBConnectionString))
                {
                    using (DbCommand dbCommand = objDataAccessWrapper.GetStoredProcCommand(Common.Constants.DataBaseConstants.USP_Log_Insert))
                    {
                        objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Count_DB_Failed, DbType.Int32, obj.Count_DB_Failed);
                        objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Count_DB_Successful, DbType.Int32, obj.Count_DB_Successful);

                        objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Count_Duplicate, DbType.Int32, obj.Count_Duplicate);
                        objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Count_Failed, DbType.Int32, obj.Count_Failed);

                        objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Count_Inserted, DbType.Int32, obj.Count_Inserted);
                        objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Count_Total, DbType.Int32, obj.Count_Total);

                        objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.EntityID, DbType.Int32, obj.EntityID);

                        if (!string.IsNullOrEmpty(Convert.ToString(obj.FromDate)))
                        { objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.FromDate, DbType.DateTime, obj.FromDate); }


                        if (!string.IsNullOrEmpty(Convert.ToString(obj.GUID)))
                        { objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.GUID, DbType.DateTime, obj.GUID); }

                        if (!string.IsNullOrEmpty(Convert.ToString(obj.ToDate)))
                        { objDataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.ToDate, DbType.DateTime, obj.ToDate); }




                        objDataAccessWrapper.ExecuteNonQuery(dbCommand);
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        #endregion

        //Summary
        public DataSet Summary_FetchJSON(Int32 TopicID, DateTime FromDate, DateTime ToDate, Int32 PeakID)
        {
            DataSet dt = new DataSet();
            try
            {

                using (DataAccessWrapper DataAccessWrapper = new DataAccessWrapper(DataBaseConstants.MDBConnectionString))
                {
                    using (DbCommand dbCommand = DataAccessWrapper.GetStoredProcCommand(DataBaseConstants.USP_Twitter_FetchToCreateSummaryJson))
                    {
                        dbCommand.CommandTimeout = 0;
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.TopicID, DbType.Int32, TopicID);

                        if (FromDate != DateTime.MinValue)
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.FromDate, DbType.DateTime, FromDate); }

                        if (ToDate != DateTime.MinValue)
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.ToDate, DbType.DateTime, ToDate); }

                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.PeakID, DbType.Int32, PeakID);

                        #region DataSet
                        using (DataSet ds = DataAccessWrapper.ExecuteDataSet(dbCommand))
                        {
                            if (ds != null && ds.Tables.Count > 0)
                            {
                                dt = ds;
                            }
                        }
                        #endregion
                    }
                }

            }
            catch (Exception ex)
            {

                throw ex;
            }

            return dt;
        }

        public DataSet Summary_FetchJSON_MJ()
        {
            DataSet dt = new DataSet();
            try
            {

                using (DataAccessWrapper DataAccessWrapper = new DataAccessWrapper(DataBaseConstants.MDBConnectionString))
                {
                    using (DbCommand dbCommand = DataAccessWrapper.GetStoredProcCommand(DataBaseConstants.USP_Twitter_FetchToCreateSummaryJson_MJ))
                    {
                        dbCommand.CommandTimeout = 0;
                        #region DataSet
                        using (DataSet ds = DataAccessWrapper.ExecuteDataSet(dbCommand))
                        {
                            if (ds != null && ds.Tables.Count > 0)
                            {
                                dt = ds;
                            }
                        }
                        #endregion
                    }
                }

            }
            catch (Exception ex)
            {

                throw ex;
            }

            return dt;
        }

        #region Summary Related

        //ArticleOnline
        public DataTable Incident_OverallSummary_Insert(Int32 TopicId, Int32 EntityId, DateTime FromDate, DateTime ToDate, string Summary, string SummaryType)
        {

            DataTable dt = new DataTable();
            try
            {

                using (DataAccessWrapper DataAccessWrapper = new DataAccessWrapper(DataBaseConstants.MDBConnectionString))
                {
                    using (DbCommand dbCommand = DataAccessWrapper.GetStoredProcCommand(DataBaseConstants.USP_OverallSummary_Insert))
                    {
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.TopicID, DbType.Int32, TopicId);
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.EntityID, DbType.Int32, EntityId);
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.FromDate, DbType.DateTime, FromDate);
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.ToDate, DbType.DateTime, ToDate);
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Summary, DbType.String, Summary);
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.SummaryType, DbType.String, SummaryType);

                        #region DataSet
                        using (DataSet ds = DataAccessWrapper.ExecuteDataSet(dbCommand))
                        {
                            if (ds != null && ds.Tables.Count > 0)
                            {
                                dt = ds.Tables[0];
                                //if (dt != null && dt.Rows.Count > 0)
                                //{
                                //    Result = Convert.ToInt32(dt.Rows[0]["AOSID"]);

                                //}
                            }
                        }
                        #endregion
                    }
                }

            }
            catch (Exception ex)
            {

                throw ex;
            }

            return dt;
        }

        //ArticleOnline
        public DataTable Incident_ArticleOnlineSummary_Insert(Int32 TopicId, Int32 EntityId, DateTime FromDate, DateTime ToDate, string Summary, string SummaryType, Int32 PeakID)
        {

            DataTable dt = new DataTable();
            try
            {

                using (DataAccessWrapper DataAccessWrapper = new DataAccessWrapper(DataBaseConstants.MDBConnectionString))
                {
                    using (DbCommand dbCommand = DataAccessWrapper.GetStoredProcCommand(DataBaseConstants.USP_ArticleOnlineSummary_Insert))
                    {
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.TopicID, DbType.Int32, TopicId);
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.EntityID, DbType.Int32, EntityId);
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.FromDate, DbType.DateTime, FromDate);
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.ToDate, DbType.DateTime, ToDate);
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Summary, DbType.String, Summary);
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.SummaryType, DbType.String, SummaryType);
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.PeakID, DbType.Int32, PeakID);

                        #region DataSet
                        using (DataSet ds = DataAccessWrapper.ExecuteDataSet(dbCommand))
                        {
                            if (ds != null && ds.Tables.Count > 0)
                            {
                                dt = ds.Tables[0];
                                //if (dt != null && dt.Rows.Count > 0)
                                //{
                                //    Result = Convert.ToInt32(dt.Rows[0]["AOSID"]);

                                //}
                            }
                        }
                        #endregion
                    }
                }

            }
            catch (Exception ex)
            {

                throw ex;
            }

            return dt;
        }

        //ArticlePrint
        public DataTable Incident_ArticlePrintSummary_Insert(Int32 TopicId, Int32 EntityId, DateTime FromDate, DateTime ToDate, string Summary, string SummaryType, Int32 PeakID)
        {
            DataTable dt = new DataTable();
            try
            {

                using (DataAccessWrapper DataAccessWrapper = new DataAccessWrapper(DataBaseConstants.MDBConnectionString))
                {
                    using (DbCommand dbCommand = DataAccessWrapper.GetStoredProcCommand(DataBaseConstants.USP_ArticlePrintSummary_Insert))
                    {
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.TopicID, DbType.Int32, TopicId);
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.EntityID, DbType.Int32, EntityId);
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.FromDate, DbType.DateTime, FromDate);
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.ToDate, DbType.DateTime, ToDate);
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Summary, DbType.String, Summary);
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.SummaryType, DbType.String, SummaryType);
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.PeakID, DbType.Int32, PeakID);

                        #region DataSet
                        using (DataSet ds = DataAccessWrapper.ExecuteDataSet(dbCommand))
                        {
                            if (ds != null && ds.Tables.Count > 0)
                            {
                                dt = ds.Tables[0];
                                //if (dt != null && dt.Rows.Count > 0)
                                //{
                                //    Result = Convert.ToInt32(dt.Rows[0]["APSID"]);

                                //}
                            }
                        }
                        #endregion
                    }
                }

            }
            catch (Exception ex)
            {

                throw ex;
            }

            return dt;
        }

        //Twitter

        #region Commented
        //public Int32 Incident_TwitterSummary_Insert(Int32 TopicId, Int32 EntityId, DateTime FromDate, DateTime ToDate, string Summary,string SummaryType,Int32 PeakID)
        //{
        //    Int32 Result = 0;
        //    DataTable dt = new DataTable();
        //    try
        //    {

        //        using (DataAccessWrapper DataAccessWrapper = new DataAccessWrapper(DataBaseConstants.MDBConnectionString))
        //        {
        //            using (DbCommand dbCommand = DataAccessWrapper.GetStoredProcCommand(DataBaseConstants.USP_TwitterSummary_Insert))
        //            {
        //                DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.TopicID, DbType.Int32, TopicId);
        //                DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.EntityID, DbType.Int32, EntityId);
        //                DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.FromDate, DbType.DateTime, FromDate);
        //                DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.ToDate, DbType.DateTime, ToDate);
        //                DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Summary, DbType.String, Summary);
        //                DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.SummaryType, DbType.String, SummaryType);
        //                DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.PeakID, DbType.Int32, PeakID);


        //                #region DataSet
        //                using (DataSet ds = DataAccessWrapper.ExecuteDataSet(dbCommand))
        //                {
        //                    if (ds != null && ds.Tables.Count > 0)
        //                    {
        //                        dt = ds.Tables[0];
        //                        if (dt != null && dt.Rows.Count > 0)
        //                        {
        //                            Result = Convert.ToInt32(dt.Rows[0]["TSID"]);

        //                        }
        //                    }
        //                }
        //                #endregion
        //            }
        //        }

        //    }
        //    catch (Exception ex)
        //    {

        //        throw ex;
        //    }

        //    return Result;
        //}
        #endregion

        public DataTable Incident_TwitterSummary_Insert_Intent(Int32 TopicId, Int32 EntityId, DateTime FromDate, DateTime ToDate, string Summary, string SummaryType, Int32 PeakID)
        {
            DataTable dt = new DataTable();
            try
            {

                using (DataAccessWrapper DataAccessWrapper = new DataAccessWrapper(DataBaseConstants.MDBConnectionString))
                {
                    using (DbCommand dbCommand = DataAccessWrapper.GetStoredProcCommand(DataBaseConstants.USP_TwitterSummary_Insert))
                    {
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.TopicID, DbType.Int32, TopicId);
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.EntityID, DbType.Int32, EntityId);
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.FromDate, DbType.DateTime, FromDate);
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.ToDate, DbType.DateTime, ToDate);
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Summary, DbType.String, Summary);
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.SummaryType, DbType.String, SummaryType);
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.PeakID, DbType.Int32, PeakID);


                        #region DataSet
                        using (DataSet ds = DataAccessWrapper.ExecuteDataSet(dbCommand))
                        {
                            if (ds != null && ds.Tables.Count > 0)
                            {
                                dt = ds.Tables[0];
                            }
                        }
                        #endregion
                    }
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }

            return dt;
        }

        public Int32 Incident_TwitterSummary_Insert(Int32 TopicId, Int32 EntityId, DateTime FromDate, DateTime ToDate, string Summary, string SummaryType, Int32 PeakID)
        {
            Int32 Result = 0;
            DataTable dt = new DataTable();
            try
            {

                using (DataAccessWrapper DataAccessWrapper = new DataAccessWrapper(DataBaseConstants.MDBConnectionString))
                {
                    using (DbCommand dbCommand = DataAccessWrapper.GetStoredProcCommand(DataBaseConstants.USP_TwitterSummary_Insert))
                    {
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.TopicID, DbType.Int32, TopicId);
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.EntityID, DbType.Int32, EntityId);
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.FromDate, DbType.DateTime, FromDate);
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.ToDate, DbType.DateTime, ToDate);
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Summary, DbType.String, Summary);
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.SummaryType, DbType.String, SummaryType);
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.PeakID, DbType.Int32, PeakID);


                        #region DataSet
                        using (DataSet ds = DataAccessWrapper.ExecuteDataSet(dbCommand))
                        {
                            if (ds != null && ds.Tables.Count > 0)
                            {
                                dt = ds.Tables[0];
                                if (dt != null && dt.Rows.Count > 0)
                                {
                                    Result = Convert.ToInt32(dt.Rows[0]["TSID"]);

                                }
                            }
                        }
                        #endregion
                    }
                }

            }
            catch (Exception ex)
            {

                throw ex;
            }

            return Result;
        }


        public DataTable SummaryPeak_FetchPeaks(Int32 TopicID)
        {
            DataTable dt = new DataTable();
            try
            {

                using (DataAccessWrapper DataAccessWrapper = new DataAccessWrapper(DataBaseConstants.MDBConnectionString))
                {
                    using (DbCommand dbCommand = DataAccessWrapper.GetStoredProcCommand(DataBaseConstants.USP_Peak_FetchPeaks))
                    {
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.TopicID, DbType.Int32, TopicID);
                        #region DataSet
                        using (DataSet ds = DataAccessWrapper.ExecuteDataSet(dbCommand))
                        {
                            if (ds != null && ds.Tables.Count > 0)
                            {
                                dt = ds.Tables[0];
                            }
                        }
                        #endregion
                    }
                }

            }
            catch (Exception ex)
            {

                throw ex;
            }

            return dt;
        }

        public DataTable Summary_FetchPeakSummaries(Int32 TopicId, Int32 EntityId, DateTime FromDate, DateTime ToDate, string Platform, string Type)
        {
            DataTable dt = new DataTable();
            try
            {

                using (DataAccessWrapper DataAccessWrapper = new DataAccessWrapper(DataBaseConstants.MDBConnectionString))
                {
                    using (DbCommand dbCommand = DataAccessWrapper.GetStoredProcCommand(DataBaseConstants.USP_Summary_FetchPeakSummaries))
                    {
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.TopicID, DbType.Int32, TopicId);
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.FromDate, DbType.DateTime, FromDate);
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.ToDate, DbType.DateTime, ToDate);
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Platform, DbType.String, Platform);
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Type, DbType.String, Type);

                        #region DataSet
                        using (DataSet ds = DataAccessWrapper.ExecuteDataSet(dbCommand))
                        {
                            if (ds != null && ds.Tables.Count > 0)
                            {
                                dt = ds.Tables[0];
                            }
                        }
                        #endregion
                    }
                }

            }
            catch (Exception ex)
            {

                throw ex;
            }

            return dt;
        }

        //YouTube
        public DataTable Incident_YouTubeSummary_Insert(Int32 TopicId, Int32 EntityId, DateTime FromDate, DateTime ToDate, string Summary, string SummaryType, Int32 PeakID)
        {
            DataTable dt = new DataTable();
            try
            {

                using (DataAccessWrapper DataAccessWrapper = new DataAccessWrapper(DataBaseConstants.MDBConnectionString))
                {
                    using (DbCommand dbCommand = DataAccessWrapper.GetStoredProcCommand(DataBaseConstants.USP_YouTubeSummary_Insert))
                    {
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.TopicID, DbType.Int32, TopicId);
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.EntityID, DbType.Int32, EntityId);
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.FromDate, DbType.DateTime, FromDate);
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.ToDate, DbType.DateTime, ToDate);
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Summary, DbType.String, Summary);
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.SummaryType, DbType.String, SummaryType);
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.PeakID, DbType.Int32, PeakID);

                        #region DataSet
                        using (DataSet ds = DataAccessWrapper.ExecuteDataSet(dbCommand))
                        {
                            if (ds != null && ds.Tables.Count > 0)
                            {
                                dt = ds.Tables[0];
                                //if (dt != null && dt.Rows.Count > 0)
                                //{
                                //    Result = Convert.ToInt32(dt.Rows[0]["APSID"]);

                                //}
                            }
                        }
                        #endregion
                    }
                }

            }
            catch (Exception ex)
            {

                throw ex;
            }

            return dt;
        }

        #endregion

        //Shiv
        public DataSet Twitter_FetchQueriesToCreateInFS()
        {
            DataSet dt = new DataSet();
            try
            {

                using (DataAccessWrapper DataAccessWrapper = new DataAccessWrapper(DataBaseConstants.MDBConnectionString))
                {
                    using (DbCommand dbCommand = DataAccessWrapper.GetStoredProcCommand(DataBaseConstants.USP_Twitter_FetchQueriesToCreateInFS))
                    {
                        dbCommand.CommandTimeout = 0;
                        
                        #region DataSet
                        using (DataSet ds = DataAccessWrapper.ExecuteDataSet(dbCommand))
                        {
                            if (ds != null && ds.Tables.Count > 0)
                            {
                                dt = ds;
                            }
                        }

                        DataAccessWrapper.Dispose();
                        #endregion
                    }
                }

            }
            catch (Exception ex)
            {

                throw ex;
            }

            return dt;
        }

        public void Twitter_UpdateTCQuery(Int32 TagQueryID, string Result)
        {
            DataSet dt = new DataSet();
            try
            {
                using (DataAccessWrapper DataAccessWrapper = new DataAccessWrapper(DataBaseConstants.MDBConnectionString))
                {
                    using (DbCommand dbCommand = DataAccessWrapper.GetStoredProcCommand(DataBaseConstants.USP_Twitter_UpdateTCQuery))
                    {
                        dbCommand.CommandTimeout = 0;
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.TagQueryID, DbType.Int32, TagQueryID);

                        if (!string.IsNullOrEmpty(Result))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Result, DbType.String, Result); }

                        DataAccessWrapper.ExecuteNonQuery(dbCommand);
                    }
                }

            }
            catch (Exception ex)
            {

                throw ex;
            }
        }


    }
}
