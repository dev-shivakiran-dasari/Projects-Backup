﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using Sahadeva.API.Common;
using System.Data.Common;
using Sahadeva.API.Common.Constants;
using System.Data.SqlClient;

namespace Sahadeva.API.DAL
{
    public class API_V2
    {

        public DataTable Client_FetchClientsByUserID(Int32 UserID)
        {
            DataTable dt = new DataTable();
            try
            {

                using (DataAccessWrapper DataAccessWrapper = new DataAccessWrapper(DataBaseConstants.SahadevConnectionString))
                {
                    using (DbCommand dbCommand = DataAccessWrapper.GetStoredProcCommand(DataBaseConstants.USP_API_SentryV2_Client_FetchClientsByUserID))
                    {
                        dbCommand.CommandTimeout = 0;
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.UserID, DbType.Int32, UserID);

                        #region DataSet
                        using (DataSet ds = DataAccessWrapper.ExecuteDataSet(dbCommand))
                        {
                            if (ds != null && ds.Tables.Count > 0)
                            {
                                dt = ds.Tables[0];
                            }
                        }

                        DataAccessWrapper.Dispose();
                        #endregion
                    }
                }

            }
            catch (Exception ex)
            {

                throw ex;
            }



            return dt;
        }

        //public DataTable Incident_FetchList(Int32 UserID)
        //{
        //    DataTable dt = new DataTable();
        //    try
        //    {

        //        using (DataAccessWrapper DataAccessWrapper = new DataAccessWrapper(DataBaseConstants.SahadevConnectionString))
        //        {
        //            using (DbCommand dbCommand = DataAccessWrapper.GetStoredProcCommand(DataBaseConstants.USP_API_SentryV2_Incident_FetchList))
        //            {
        //                dbCommand.CommandTimeout = 0;
        //                DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.UserID, DbType.Int32, UserID);

        //                #region DataSet
        //                using (DataSet ds = DataAccessWrapper.ExecuteDataSet(dbCommand))
        //                {
        //                    if (ds != null && ds.Tables.Count > 0)
        //                    {
        //                        dt = ds.Tables[0];
        //                    }
        //                }

        //                DataAccessWrapper.Dispose();
        //                #endregion
        //            }
        //        }

        //    }
        //    catch (Exception ex)
        //    {

        //        throw ex;
        //    }

        //    return dt;
        //}

        public DataSet Incident_FetchList(Int32 UserID,Int32 ClientID)
        {
            DataSet dataset = new DataSet();
            try
            {

                using (DataAccessWrapper DataAccessWrapper = new DataAccessWrapper(DataBaseConstants.SahadevConnectionString))
                {
                    using (DbCommand dbCommand = DataAccessWrapper.GetStoredProcCommand(DataBaseConstants.USP_API_SentryV2_Incident_FetchList))
                    {
                        dbCommand.CommandTimeout = 0;
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.UserID, DbType.Int32, UserID);
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.ClientID, DbType.Int32, ClientID);

                        #region DataSet
                        using (DataSet ds = DataAccessWrapper.ExecuteDataSet(dbCommand))
                        {
                            if (ds != null && ds.Tables.Count > 0)
                            {
                                dataset = ds;
                            }
                        }

                        DataAccessWrapper.Dispose();
                        #endregion
                    }
                }

            }
            catch (Exception ex)
            {

                throw ex;
            }

            return dataset;
        }

        public DataTable Incident_FetchDetail(Int32 TopicID)
        {
            DataTable dt = new DataTable();
            try
            {

                using (DataAccessWrapper DataAccessWrapper = new DataAccessWrapper(DataBaseConstants.SahadevConnectionString))
                {
                    using (DbCommand dbCommand = DataAccessWrapper.GetStoredProcCommand(DataBaseConstants.USP_API_SentryV2_Incident_FetchDetail))
                    {
                        dbCommand.CommandTimeout = 0;
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.TopicID, DbType.Int32, TopicID);
                        #region DataSet
                        using (DataSet ds = DataAccessWrapper.ExecuteDataSet(dbCommand))
                        {
                            if (ds != null && ds.Tables.Count > 0)
                            {
                                dt = ds.Tables[0];
                            }
                        }

                        DataAccessWrapper.Dispose();
                        #endregion
                    }
                }

            }
            catch (Exception ex)
            {

                throw ex;
            }

            return dt;
        }

        //Incident
        public DataSet Incident_FetchLanding(Int32 TopicID, DateTime FromDate, DateTime ToDate, DateTime BaseDate, string Hide_Denominator, string ShowPercentage, string strDevice)
        {
            DataSet dt = new DataSet();
            try
            {
                string strSP = DataBaseConstants.USP_API_SentryV2_Overview_FetchLanding;

                //if (strDevice != "web")
                //{
                //    strSP = DataBaseConstants.USP_API_SentryV2_Overview_FetchLanding_Mobile;
                //}

                using (DataAccessWrapper DataAccessWrapper = new DataAccessWrapper(DataBaseConstants.SahadevConnectionString))
                {
                    using (DbCommand dbCommand = DataAccessWrapper.GetStoredProcCommand(strSP))
                    {
                        dbCommand.CommandTimeout = 0;
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.TopicID, DbType.Int32, TopicID);

                        if (FromDate != DateTime.MinValue)
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.FromDate, DbType.DateTime, FromDate); }

                        if (ToDate != DateTime.MinValue)
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.ToDate, DbType.DateTime, ToDate); }

                        if (BaseDate != DateTime.MinValue)
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.BaseDate, DbType.DateTime, BaseDate); }

                        if (!string.IsNullOrEmpty(Hide_Denominator))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Hide_Denominator, DbType.String, Hide_Denominator); }

                        if (!string.IsNullOrEmpty(ShowPercentage))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.ShowPercentage, DbType.String, ShowPercentage); }


                        #region DataSet
                        using (DataSet ds = DataAccessWrapper.ExecuteDataSet(dbCommand))
                        {
                            if (ds != null && ds.Tables.Count > 0)
                            {
                                dt = ds;
                            }
                        }

                        DataAccessWrapper.Dispose();
                        #endregion
                    }
                }

            }
            catch (Exception ex)
            {

                throw ex;
            }

            return dt;
        }


        //ArticleOnline
        public DataSet ArticleOnline_FetchLanding(Int32 TopicID, DateTime FromDate, DateTime ToDate, DateTime BaseDate, string Hide_Denominator, string ShowPercentage, string strDevice)
        {
            DataSet dt = new DataSet();
            try
            {
                string strSP = DataBaseConstants.USP_API_SentryV2_ArticleOnline_FetchLanding;

                if (strDevice != "web")
                {
                    strSP = DataBaseConstants.USP_API_SentryV2_ArticleOnline_FetchLanding_Mobile;
                }

                using (DataAccessWrapper DataAccessWrapper = new DataAccessWrapper(DataBaseConstants.SahadevConnectionString))
                {
                    using (DbCommand dbCommand = DataAccessWrapper.GetStoredProcCommand(strSP))
                    {
                        dbCommand.CommandTimeout = 0;
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.TopicID, DbType.Int32, TopicID);

                        if (FromDate != DateTime.MinValue)
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.FromDate, DbType.DateTime, FromDate); }

                        if (ToDate != DateTime.MinValue)
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.ToDate, DbType.DateTime, ToDate); }

                        if (BaseDate != DateTime.MinValue)
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.BaseDate, DbType.DateTime, BaseDate); }

                        if (!string.IsNullOrEmpty(Hide_Denominator))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Hide_Denominator, DbType.String, Hide_Denominator); }

                        if (!string.IsNullOrEmpty(ShowPercentage))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.ShowPercentage, DbType.String, ShowPercentage); }


                        #region DataSet
                        using (DataSet ds = DataAccessWrapper.ExecuteDataSet(dbCommand))
                        {
                            if (ds != null && ds.Tables.Count > 0)
                            {
                                dt = ds;
                            }
                        }

                        DataAccessWrapper.Dispose();
                        #endregion
                    }
                }

            }
            catch (Exception ex)
            {

                throw ex;
            }

            return dt;
        }

        public DataTable ArticleOnline_FetchList(Int32 TopicID, DateTime FromDate, DateTime ToDate, string Sentiment, string Publication_Domain,
            string Publication_Type, string Publication_DA, string Publication_Traffic, string Publication_ImpactScore, string SortBy,
            string SortOrder, string SearchText, string Mention_Type, string Client_Mention, Int32 UserID, string Headline_Sentiment, string Article_Type, string Exclude_By_Text)
        {
            DataTable dt = new DataTable();
            try
            {

                using (DataAccessWrapper DataAccessWrapper = new DataAccessWrapper(DataBaseConstants.SahadevConnectionString))
                {
                    using (DbCommand dbCommand = DataAccessWrapper.GetStoredProcCommand(DataBaseConstants.USP_API_SentryV2_ArticleOnline_FetchList))
                    {
                        dbCommand.CommandTimeout = 0;
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.TopicID, DbType.Int32, TopicID);

                        if (FromDate != DateTime.MinValue)
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.FromDate, DbType.DateTime, FromDate); }

                        if (ToDate != DateTime.MinValue)
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.ToDate, DbType.DateTime, ToDate); }

                        if (!string.IsNullOrEmpty(Sentiment))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Sentiment, DbType.String, Sentiment); }

                        if (!string.IsNullOrEmpty(Publication_Domain))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Publication_Domain, DbType.String, Publication_Domain); }

                        if (!string.IsNullOrEmpty(Publication_Type))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Publication_Type, DbType.String, Publication_Type); }

                        if (!string.IsNullOrEmpty(Publication_DA))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Publication_DA, DbType.String, Publication_DA); }

                        if (!string.IsNullOrEmpty(Publication_Traffic))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Publication_Traffic, DbType.String, Publication_Traffic); }

                        if (!string.IsNullOrEmpty(Publication_ImpactScore))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Publication_ImpactScore, DbType.String, Publication_ImpactScore); }

                        if (!string.IsNullOrEmpty(SortBy))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.SortBy, DbType.String, SortBy); }

                        if (!string.IsNullOrEmpty(SortOrder))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.SortOrder, DbType.String, SortOrder); }

                        if (!string.IsNullOrEmpty(SearchText))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.SearchText, DbType.String, SearchText); }

                        if (!string.IsNullOrEmpty(Mention_Type))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Mention_Type, DbType.String, Mention_Type); }

                        if (!string.IsNullOrEmpty(Client_Mention))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Client_Mention, DbType.String, Client_Mention); }

                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.UserID, DbType.Int32, UserID);

                        if (!string.IsNullOrEmpty(Headline_Sentiment))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Headline_Sentiment, DbType.String, Headline_Sentiment); }

                        if (!string.IsNullOrEmpty(Article_Type))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Article_Type, DbType.String, Article_Type); }

                        if (!string.IsNullOrEmpty(Exclude_By_Text))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Exclude_By_Text, DbType.String, Exclude_By_Text); }


                        #region DataSet
                        using (DataSet ds = DataAccessWrapper.ExecuteDataSet(dbCommand))
                        {
                            if (ds != null && ds.Tables.Count > 0)
                            {
                                dt = ds.Tables[0];
                            }
                        }
                        #endregion
                    }
                }

            }
            catch (Exception ex)
            {

                throw ex;
            }

            return dt;
        }

        public DataSet ArticleOnline_FetchFilter(Int32 TopicID, DateTime FromDate, DateTime ToDate, Int32 TagID)
        {
            DataSet dt = new DataSet();
            try
            {

                using (DataAccessWrapper DataAccessWrapper = new DataAccessWrapper(DataBaseConstants.SahadevConnectionString))
                {
                    using (DbCommand dbCommand = DataAccessWrapper.GetStoredProcCommand(DataBaseConstants.USP_API_SentryV2_ArticleOnline_FetchFilter))
                    {
                        dbCommand.CommandTimeout = 0;
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.TopicID, DbType.Int32, TopicID);
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.TagID, DbType.Int32, TagID);

                        if (FromDate != DateTime.MinValue)
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.FromDate, DbType.DateTime, FromDate); }

                        if (ToDate != DateTime.MinValue)
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.ToDate, DbType.DateTime, ToDate); }

                        #region DataSet
                        using (DataSet ds = DataAccessWrapper.ExecuteDataSet(dbCommand))
                        {
                            if (ds != null && ds.Tables.Count > 0)
                            {
                                dt = ds;
                            }
                        }
                        #endregion
                    }
                }

            }
            catch (Exception ex)
            {

                throw ex;
            }

            return dt;
        }

        public DataSet ArticleOnline_FetchById(Int32 ArticleID, Int32 UserID)
        {
            DataSet dt = new DataSet();
            try
            {

                using (DataAccessWrapper DataAccessWrapper = new DataAccessWrapper(DataBaseConstants.SahadevConnectionString))
                {
                    using (DbCommand dbCommand = DataAccessWrapper.GetStoredProcCommand(DataBaseConstants.USP_API_SentryV2_ArticleOnline_FetchById))
                    {
                        dbCommand.CommandTimeout = 0;
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.ArticleID, DbType.Int32, ArticleID);
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.UserID, DbType.Int32, UserID);

                        #region DataSet
                        using (DataSet ds = DataAccessWrapper.ExecuteDataSet(dbCommand))
                        {
                            if (ds != null && ds.Tables.Count > 0)
                            {
                                dt = ds;
                            }
                        }
                        #endregion
                    }
                }

            }
            catch (Exception ex)
            {

                throw ex;
            }

            return dt;
        }


        //ArticlePrint
        public DataSet ArticlePrint_FetchLanding(Int32 TopicID, DateTime FromDate, DateTime ToDate, DateTime BaseDate, string Hide_Denominator, string ShowPercentage, string strDevice)
        {
            DataSet dt = new DataSet();
            try
            {
                string strSP = DataBaseConstants.USP_API_SentryV2_ArticlePrint_FetchLanding;

                if (strDevice != "web")
                {
                    strSP = DataBaseConstants.USP_API_SentryV2_ArticlePrint_FetchLanding_Mobile;
                }

                using (DataAccessWrapper DataAccessWrapper = new DataAccessWrapper(DataBaseConstants.SahadevConnectionString))
                {
                    using (DbCommand dbCommand = DataAccessWrapper.GetStoredProcCommand(strSP))
                    {
                        dbCommand.CommandTimeout = 0;
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.TopicID, DbType.Int32, TopicID);

                        if (FromDate != DateTime.MinValue)
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.FromDate, DbType.DateTime, FromDate); }

                        if (ToDate != DateTime.MinValue)
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.ToDate, DbType.DateTime, ToDate); }

                        if (BaseDate != DateTime.MinValue)
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.BaseDate, DbType.DateTime, BaseDate); }

                        if (!string.IsNullOrEmpty(Hide_Denominator))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Hide_Denominator, DbType.String, Hide_Denominator); }

                        if (!string.IsNullOrEmpty(ShowPercentage))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.ShowPercentage, DbType.String, ShowPercentage); }


                        #region DataSet
                        using (DataSet ds = DataAccessWrapper.ExecuteDataSet(dbCommand))
                        {
                            if (ds != null && ds.Tables.Count > 0)
                            {
                                dt = ds;
                            }
                        }
                        #endregion
                    }
                }

            }
            catch (Exception ex)
            {

                throw ex;
            }

            return dt;
        }

        public DataTable ArticlePrint_FetchList(Int32 TopicID, DateTime FromDate, DateTime ToDate, string Sentiment, string Publication_Name, string Publication_Edition,
            string Publication_Type, string Publication_Circulation, string Publication_ImpactScore, string SortBy,
            string SortOrder, string SearchText, string Mention_Type, string Client_Mention, Int32 UserID, string Headline_Sentiment, string Article_Type, string Author, string Exclude_By_Text, string Language)
        {
            DataTable dt = new DataTable();
            try
            {

                using (DataAccessWrapper DataAccessWrapper = new DataAccessWrapper(DataBaseConstants.SahadevConnectionString))
                {
                    using (DbCommand dbCommand = DataAccessWrapper.GetStoredProcCommand(DataBaseConstants.USP_API_SentryV2_ArticlePrint_FetchList))
                    {
                        dbCommand.CommandTimeout = 0;
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.TopicID, DbType.Int32, TopicID);

                        if (FromDate != DateTime.MinValue)
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.FromDate, DbType.DateTime, FromDate); }

                        if (ToDate != DateTime.MinValue)
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.ToDate, DbType.DateTime, ToDate); }

                        if (!string.IsNullOrEmpty(Sentiment))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Sentiment, DbType.String, Sentiment); }

                        if (!string.IsNullOrEmpty(Publication_Name))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Publication_Name, DbType.String, Publication_Name); }

                        if (!string.IsNullOrEmpty(Publication_Type))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Publication_Type, DbType.String, Publication_Type); }

                        if (!string.IsNullOrEmpty(Publication_Edition))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Publication_Edition, DbType.String, Publication_Edition); }

                        if (!string.IsNullOrEmpty(Publication_Circulation))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Publication_Circulation, DbType.String, Publication_Circulation); }

                        if (!string.IsNullOrEmpty(Publication_ImpactScore))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Publication_ImpactScore, DbType.String, Publication_ImpactScore); }

                        if (!string.IsNullOrEmpty(SortBy))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.SortBy, DbType.String, SortBy); }

                        if (!string.IsNullOrEmpty(SortOrder))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.SortOrder, DbType.String, SortOrder); }

                        if (!string.IsNullOrEmpty(SearchText))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.SearchText, DbType.String, SearchText); }

                        if (!string.IsNullOrEmpty(Mention_Type))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Mention_Type, DbType.String, Mention_Type); }

                        if (!string.IsNullOrEmpty(Client_Mention))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Client_Mention, DbType.String, Client_Mention); }

                        if (!string.IsNullOrEmpty(Headline_Sentiment))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Headline_Sentiment, DbType.String, Headline_Sentiment); }

                        if (!string.IsNullOrEmpty(Article_Type))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Article_Type, DbType.String, Article_Type); }

                        if (!string.IsNullOrEmpty(Author))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Author, DbType.String, Author); }

                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.UserID, DbType.Int32, UserID);

                        if (!string.IsNullOrEmpty(Language))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Language, DbType.String, Language); }

                        if (!string.IsNullOrEmpty(Exclude_By_Text))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Exclude_By_Text, DbType.String, Exclude_By_Text); }

                        #region DataSet
                        using (DataSet ds = DataAccessWrapper.ExecuteDataSet(dbCommand))
                        {
                            if (ds != null && ds.Tables.Count > 0)
                            {
                                dt = ds.Tables[0];
                            }
                        }
                        #endregion
                    }
                }

            }
            catch (Exception ex)
            {

                throw ex;
            }

            return dt;
        }

        public DataSet ArticlePrint_FetchFilter(Int32 TopicID, DateTime FromDate, DateTime ToDate, Int32 TagID)
        {
            DataSet dt = new DataSet();
            try
            {

                using (DataAccessWrapper DataAccessWrapper = new DataAccessWrapper(DataBaseConstants.SahadevConnectionString))
                {
                    using (DbCommand dbCommand = DataAccessWrapper.GetStoredProcCommand(DataBaseConstants.USP_API_SentryV2_ArticlePrint_FetchFilter))
                    {
                        dbCommand.CommandTimeout = 0;
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.TopicID, DbType.Int32, TopicID);
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.TagID, DbType.Int32, TagID);

                        if (FromDate != DateTime.MinValue)
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.FromDate, DbType.DateTime, FromDate); }

                        if (ToDate != DateTime.MinValue)
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.ToDate, DbType.DateTime, ToDate); }

                        #region DataSet
                        using (DataSet ds = DataAccessWrapper.ExecuteDataSet(dbCommand))
                        {
                            if (ds != null && ds.Tables.Count > 0)
                            {
                                dt = ds;
                            }
                        }
                        #endregion
                    }
                }

            }
            catch (Exception ex)
            {

                throw ex;
            }

            return dt;
        }

        public DataSet ArticlePrint_FetchById(Int32 ArticleID, Int32 UserID)
        {
            DataSet dt = new DataSet();
            try
            {

                using (DataAccessWrapper DataAccessWrapper = new DataAccessWrapper(DataBaseConstants.SahadevConnectionString))
                {
                    using (DbCommand dbCommand = DataAccessWrapper.GetStoredProcCommand(DataBaseConstants.USP_API_SentryV2_ArticlePrint_FetchById))
                    {
                        dbCommand.CommandTimeout = 0;
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.ArticleID, DbType.Int32, ArticleID);
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.UserID, DbType.Int32, UserID);

                        #region DataSet
                        using (DataSet ds = DataAccessWrapper.ExecuteDataSet(dbCommand))
                        {
                            if (ds != null && ds.Tables.Count > 0)
                            {
                                dt = ds;
                            }
                        }
                        #endregion
                    }
                }

            }
            catch (Exception ex)
            {

                throw ex;
            }

            return dt;
        }


        ////Twitter
        //public DataSet Twitter_FetchLanding(Int32 TopicID, DateTime FromDate, DateTime ToDate, DateTime BaseDate, string Hide_Denominator, string ShowPercentage)
        //{
        //    DataSet dt = new DataSet();
        //    try
        //    {

        //        using (DataAccessWrapper DataAccessWrapper = new DataAccessWrapper(DataBaseConstants.SahadevConnectionString))
        //        {
        //            using (DbCommand dbCommand = DataAccessWrapper.GetStoredProcCommand(DataBaseConstants.USP_API_SentryV2_Twitter_FetchLanding))
        //            {
        //                dbCommand.CommandTimeout = 0;
        //                DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.TopicID, DbType.Int32, TopicID);

        //                if (FromDate != DateTime.MinValue)
        //                { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.FromDate, DbType.DateTime, FromDate); }

        //                if (ToDate != DateTime.MinValue)
        //                { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.ToDate, DbType.DateTime, ToDate); }

        //                if (BaseDate != DateTime.MinValue)
        //                { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.BaseDate, DbType.DateTime, BaseDate); }


        //                if (!string.IsNullOrEmpty(Hide_Denominator))
        //                { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Hide_Denominator, DbType.String, Hide_Denominator); }

        //                if (!string.IsNullOrEmpty(ShowPercentage))
        //                { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.ShowPercentage, DbType.String, ShowPercentage); }

        //                #region DataSet
        //                using (DataSet ds = DataAccessWrapper.ExecuteDataSet(dbCommand))
        //                {
        //                    if (ds != null && ds.Tables.Count > 0)
        //                    {
        //                        dt = ds;
        //                    }
        //                }
        //                #endregion
        //            }
        //        }

        //    }
        //    catch (Exception ex)
        //    {

        //        throw ex;
        //    }

        //    return dt;
        //}


        //Twitter
        public DataSet Twitter_FetchLanding(Int32 TopicID, DateTime FromDate, DateTime ToDate, DateTime BaseDate, string Hide_Denominator, string ShowPercentage, string strDevice)
        {
            DataSet dt = new DataSet();
            try
            {
                string strSP = DataBaseConstants.USP_API_SentryV2_Twitter_FetchLanding;

                if (strDevice != "web")
                {
                    strSP = DataBaseConstants.USP_API_SentryV2_Twitter_FetchLanding_Mobile;
                }

                using (DataAccessWrapper DataAccessWrapper = new DataAccessWrapper(DataBaseConstants.SahadevConnectionString))
                {
                    using (DbCommand dbCommand = DataAccessWrapper.GetStoredProcCommand(strSP))
                    {
                        dbCommand.CommandTimeout = 0;
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.TopicID, DbType.Int32, TopicID);

                        if (FromDate != DateTime.MinValue)
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.FromDate, DbType.DateTime, FromDate); }

                        if (ToDate != DateTime.MinValue)
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.ToDate, DbType.DateTime, ToDate); }

                        if (BaseDate != DateTime.MinValue)
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.BaseDate, DbType.DateTime, BaseDate); }


                        if (!string.IsNullOrEmpty(Hide_Denominator))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Hide_Denominator, DbType.String, Hide_Denominator); }

                        if (!string.IsNullOrEmpty(ShowPercentage))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.ShowPercentage, DbType.String, ShowPercentage); }

                        #region DataSet
                        using (DataSet ds = DataAccessWrapper.ExecuteDataSet(dbCommand))
                        {
                            if (ds != null && ds.Tables.Count > 0)
                            {
                                dt = ds;
                            }
                        }
                        #endregion
                    }
                }

            }
            catch (Exception ex)
            {

                throw ex;
            }

            return dt;
        }

        public DataTable Twitter_FetchList(Int32 TopicID, DateTime BaseDate, DateTime FromDate, DateTime ToDate, string Sentiment, string Mentioned_Hashtag,
            string Mentioned_Handle, string Media_Type, string Profile_Category, string SortBy, string SortOrder, string Mention_Type, string Profile_Name,
            string Profile_Handle, string Profile_Followerscount, string Participant_Type, string Profile_VerifiedType, Int32 UserID, string Tonality, string Eng_Type, string SearchText, string Exclude_By_Text)
        {
            DataTable dt = new DataTable();
            try
            {
                using (DataAccessWrapper DataAccessWrapper = new DataAccessWrapper(DataBaseConstants.SahadevConnectionString))
                {
                    using (DbCommand dbCommand = DataAccessWrapper.GetStoredProcCommand(DataBaseConstants.USP_API_SentryV2_Twitter_FetchList))
                    {
                        dbCommand.CommandTimeout = 0;
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.TopicID, DbType.Int32, TopicID);

                        if (BaseDate != DateTime.MinValue)
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.BaseDate, DbType.DateTime, BaseDate); }

                        if (FromDate != DateTime.MinValue)
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.FromDate, DbType.DateTime, FromDate); }

                        if (ToDate != DateTime.MinValue)
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.ToDate, DbType.DateTime, ToDate); }

                        if (!string.IsNullOrEmpty(Sentiment))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Sentiment, DbType.String, Sentiment); }

                        if (!string.IsNullOrEmpty(Mentioned_Hashtag))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Mentioned_Hashtag, DbType.String, Mentioned_Hashtag); }

                        if (!string.IsNullOrEmpty(Mentioned_Handle))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Mentioned_Handle, DbType.String, Mentioned_Handle); }

                        if (!string.IsNullOrEmpty(Media_Type))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Media_Type, DbType.String, Media_Type); }

                        if (!string.IsNullOrEmpty(Profile_Category))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Profile_Category, DbType.String, Profile_Category); }

                        if (!string.IsNullOrEmpty(SortBy))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.SortBy, DbType.String, SortBy); }

                        if (!string.IsNullOrEmpty(SortOrder))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.SortOrder, DbType.String, SortOrder); }

                        if (!string.IsNullOrEmpty(Mention_Type))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Mention_Type, DbType.String, Mention_Type); }

                        if (!string.IsNullOrEmpty(Profile_Name))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Profile_Name, DbType.String, Profile_Name); }

                        if (!string.IsNullOrEmpty(Profile_Handle))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Profile_Handle, DbType.String, Profile_Handle); }

                        if (!string.IsNullOrEmpty(Participant_Type))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Participant_Type, DbType.String, Participant_Type); }

                        if (!string.IsNullOrEmpty(Profile_Followerscount))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Profile_Followerscount, DbType.String, Profile_Followerscount); }

                        if (!string.IsNullOrEmpty(Profile_VerifiedType))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Profile_VerifiedType, DbType.String, Profile_VerifiedType); }

                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.UserID, DbType.Int32, UserID);

                        if (!string.IsNullOrEmpty(Tonality))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Tonality, DbType.String, Tonality); }

                        if (!string.IsNullOrEmpty(Eng_Type))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Eng_Type, DbType.String, Eng_Type); }

                        if (!string.IsNullOrEmpty(SearchText))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.SearchText, DbType.String, SearchText); }

                        if (!string.IsNullOrEmpty(Exclude_By_Text))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Exclude_By_Text, DbType.String, Exclude_By_Text); }

                        #region DataSet
                        using (DataSet ds = DataAccessWrapper.ExecuteDataSet(dbCommand))
                        {
                            if (ds != null && ds.Tables.Count > 0)
                            {
                                dt = ds.Tables[0];
                            }
                        }
                        #endregion
                    }
                }

            }
            catch (Exception ex)
            {

                throw ex;
            }

            return dt;
        }

        public DataSet Twitter_FetchFilter(Int32 TopicID, DateTime BaseDate, DateTime FromDate, DateTime ToDate)
        {
            DataSet dt = new DataSet();
            try
            {

                using (DataAccessWrapper DataAccessWrapper = new DataAccessWrapper(DataBaseConstants.SahadevConnectionString))
                {
                    using (DbCommand dbCommand = DataAccessWrapper.GetStoredProcCommand(DataBaseConstants.USP_API_SentryV2_Twitter_FetchFilter))
                    {
                        dbCommand.CommandTimeout = 0;
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.TopicID, DbType.Int32, TopicID);

                        if (BaseDate != DateTime.MinValue)
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.BaseDate, DbType.DateTime, BaseDate); }

                        if (FromDate != DateTime.MinValue)
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.FromDate, DbType.DateTime, FromDate); }

                        if (ToDate != DateTime.MinValue)
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.ToDate, DbType.DateTime, ToDate); }

                        #region DataSet
                        using (DataSet ds = DataAccessWrapper.ExecuteDataSet(dbCommand))
                        {
                            if (ds != null && ds.Tables.Count > 0)
                            {
                                dt = ds;
                            }
                        }
                        #endregion
                    }
                }

            }
            catch (Exception ex)
            {

                throw ex;
            }

            return dt;
        }

        public DataSet Twitter_FetchById(Int32 TwitterID, Int32 UserID)
        {
            DataSet dt = new DataSet();
            try
            {

                using (DataAccessWrapper DataAccessWrapper = new DataAccessWrapper(DataBaseConstants.SahadevConnectionString))
                {
                    using (DbCommand dbCommand = DataAccessWrapper.GetStoredProcCommand(DataBaseConstants.USP_API_SentryV2_Twitter_FetchById))
                    {
                        dbCommand.CommandTimeout = 0;
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.TwitterID, DbType.Int32, TwitterID);
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.UserID, DbType.Int32, UserID);

                        #region DataSet
                        using (DataSet ds = DataAccessWrapper.ExecuteDataSet(dbCommand))
                        {
                            if (ds != null && ds.Tables.Count > 0)
                            {
                                dt = ds;
                            }
                        }
                        #endregion
                    }
                }

            }
            catch (Exception ex)
            {

                throw ex;
            }

            return dt;
        }

        public DataTable Twitter_FetchParticipant_FetchList(Int32 TopicID, DateTime BaseDate, DateTime FromDate, DateTime ToDate, string Sentiment, string Mentioned_Hashtag,
            string Mentioned_Handle, string Media_Type, string Profile_Category, string SortBy, string SortOrder, string Mention_Type, string Profile_Name,
            string Profile_Handle, string Profile_Followerscount, string Participant_Type, string Profile_VerifiedType, string Tonality, string Eng_Type, string SearchText, string Exclude_By_Text)
        {
            DataTable dt = new DataTable();
            try
            {
                using (DataAccessWrapper DataAccessWrapper = new DataAccessWrapper(DataBaseConstants.SahadevConnectionString))
                {
                    using (DbCommand dbCommand = DataAccessWrapper.GetStoredProcCommand(DataBaseConstants.USP_API_SentryV2_Twitter_FetchParticipant_List))
                    {
                        dbCommand.CommandTimeout = 0;
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.TopicID, DbType.Int32, TopicID);

                        if (BaseDate != DateTime.MinValue)
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.BaseDate, DbType.DateTime, BaseDate); }

                        if (FromDate != DateTime.MinValue)
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.FromDate, DbType.DateTime, FromDate); }

                        if (ToDate != DateTime.MinValue)
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.ToDate, DbType.DateTime, ToDate); }

                        if (!string.IsNullOrEmpty(Sentiment))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Sentiment, DbType.String, Sentiment); }

                        if (!string.IsNullOrEmpty(Mentioned_Hashtag))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Mentioned_Hashtag, DbType.String, Mentioned_Hashtag); }

                        if (!string.IsNullOrEmpty(Mentioned_Handle))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Mentioned_Handle, DbType.String, Mentioned_Handle); }

                        if (!string.IsNullOrEmpty(Media_Type))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Media_Type, DbType.String, Media_Type); }

                        if (!string.IsNullOrEmpty(Profile_Category))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Profile_Category, DbType.String, Profile_Category); }

                        if (!string.IsNullOrEmpty(SortBy))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.SortBy, DbType.String, SortBy); }

                        if (!string.IsNullOrEmpty(SortOrder))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.SortOrder, DbType.String, SortOrder); }

                        if (!string.IsNullOrEmpty(Mention_Type))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Mention_Type, DbType.String, Mention_Type); }

                        if (!string.IsNullOrEmpty(Profile_Name))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Profile_Name, DbType.String, Profile_Name); }

                        if (!string.IsNullOrEmpty(Profile_Handle))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Profile_Handle, DbType.String, Profile_Handle); }

                        if (!string.IsNullOrEmpty(Participant_Type))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Participant_Type, DbType.String, Participant_Type); }

                        if (!string.IsNullOrEmpty(Profile_Followerscount))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Profile_Followerscount, DbType.String, Profile_Followerscount); }

                        if (!string.IsNullOrEmpty(Profile_VerifiedType))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Profile_VerifiedType, DbType.String, Profile_VerifiedType); }

                        if (!string.IsNullOrEmpty(Tonality))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Tonality, DbType.String, Tonality); }

                        if (!string.IsNullOrEmpty(Eng_Type))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Eng_Type, DbType.String, Eng_Type); }

                        if (!string.IsNullOrEmpty(SearchText))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.SearchText, DbType.String, SearchText); }

                        if (!string.IsNullOrEmpty(Exclude_By_Text))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Exclude_By_Text, DbType.String, Exclude_By_Text); }

                        #region DataSet
                        using (DataSet ds = DataAccessWrapper.ExecuteDataSet(dbCommand))
                        {
                            if (ds != null && ds.Tables.Count > 0)
                            {
                                dt = ds.Tables[0];
                            }
                        }
                        #endregion
                    }
                }

            }
            catch (Exception ex)
            {

                throw ex;
            }

            return dt;
        }

        public DataSet Twitter_FetchParticipant_FetchById(Int32 TopicID, DateTime FromDate, DateTime ToDate, string Profile_Handle)
        {
            DataSet dt = new DataSet();
            try
            {
                using (DataAccessWrapper DataAccessWrapper = new DataAccessWrapper(DataBaseConstants.SahadevConnectionString))
                {
                    using (DbCommand dbCommand = DataAccessWrapper.GetStoredProcCommand(DataBaseConstants.USP_API_SentryV2_Twitter_FetchParticipant_FetchById))
                    {
                        dbCommand.CommandTimeout = 0;
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.TopicID, DbType.Int32, TopicID);

                        if (FromDate != DateTime.MinValue)
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.FromDate, DbType.DateTime, FromDate); }

                        if (ToDate != DateTime.MinValue)
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.ToDate, DbType.DateTime, ToDate); }

                        if (!string.IsNullOrEmpty(Profile_Handle))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Profile_Handle, DbType.String, Profile_Handle); }

                        #region DataSet
                        dt = DataAccessWrapper.ExecuteDataSet(dbCommand);
                        #endregion
                    }
                }

            }
            catch (Exception ex)
            {

                throw ex;
            }

            return dt;
        }

        public DataSet Twitter_FetchParticipant_FetchFilter(Int32 TopicID, DateTime BaseDate, DateTime FromDate, DateTime ToDate)
        {
            DataSet dt = new DataSet();
            try
            {

                using (DataAccessWrapper DataAccessWrapper = new DataAccessWrapper(DataBaseConstants.SahadevConnectionString))
                {
                    using (DbCommand dbCommand = DataAccessWrapper.GetStoredProcCommand(DataBaseConstants.USP_API_SentryV2_Twitter_FetchParticipant_FetchFilter))
                    {
                        dbCommand.CommandTimeout = 0;
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.TopicID, DbType.Int32, TopicID);

                        if (BaseDate != DateTime.MinValue)
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.BaseDate, DbType.DateTime, BaseDate); }

                        if (FromDate != DateTime.MinValue)
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.FromDate, DbType.DateTime, FromDate); }

                        if (ToDate != DateTime.MinValue)
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.ToDate, DbType.DateTime, ToDate); }

                        #region DataSet
                        using (DataSet ds = DataAccessWrapper.ExecuteDataSet(dbCommand))
                        {
                            if (ds != null && ds.Tables.Count > 0)
                            {
                                dt = ds;
                            }
                        }
                        #endregion
                    }
                }

            }
            catch (Exception ex)
            {

                throw ex;
            }

            return dt;
        }

        //Notification Settings
        public DataSet Incident_FetchNotificationSettings(Int32 UserID, Int32 TopicID)
        {
            DataSet dt = new DataSet();
            try
            {

                using (DataAccessWrapper DataAccessWrapper = new DataAccessWrapper(DataBaseConstants.C2ConnectionString))
                {
                    using (DbCommand dbCommand = DataAccessWrapper.GetStoredProcCommand(DataBaseConstants.USP_API_SentryV2_NotificationSettings_Fetch))
                    {
                        dbCommand.CommandTimeout = 0;
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.UserID, DbType.Int32, UserID);
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.TopicID, DbType.Int32, TopicID);

                        #region DataSet
                        using (DataSet ds = DataAccessWrapper.ExecuteDataSet(dbCommand))
                        {
                            if (ds != null && ds.Tables.Count > 0)
                            {
                                dt = ds;
                            }
                        }
                        #endregion
                    }
                }

            }
            catch (Exception ex)
            {

                throw ex;
            }

            return dt;
        }

        public DataSet Incident_FetchNotificationSettings_New(Int32 UserID, Int32 TopicID)
        {
            DataSet dt = new DataSet();
            try
            {

                using (DataAccessWrapper DataAccessWrapper = new DataAccessWrapper(DataBaseConstants.C2ConnectionString))
                {
                    using (DbCommand dbCommand = DataAccessWrapper.GetStoredProcCommand(DataBaseConstants.USP_API_SentryV2_NotificationSettings_Fetch_New))
                    {
                        dbCommand.CommandTimeout = 0;
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.UserID, DbType.Int32, UserID);
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.TopicID, DbType.Int32, TopicID);

                        #region DataSet
                        using (DataSet ds = DataAccessWrapper.ExecuteDataSet(dbCommand))
                        {
                            if (ds != null && ds.Tables.Count > 0)
                            {
                                dt = ds;
                            }
                        }
                        #endregion
                    }
                }

            }
            catch (Exception ex)
            {

                throw ex;
            }

            return dt;
        }

        public DataSet Incident_FetchNotificationSettings_BY_IncidentID(Int32 TopicID)
        {
            DataSet dt = new DataSet();
            try
            {

                using (DataAccessWrapper DataAccessWrapper = new DataAccessWrapper(DataBaseConstants.C2ConnectionString))
                {
                    using (DbCommand dbCommand = DataAccessWrapper.GetStoredProcCommand(DataBaseConstants.USP_API_SentryV2_NotificationSettings_Fetch_by_IncidentID))
                    {
                        dbCommand.CommandTimeout = 0;
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.TopicID, DbType.Int32, TopicID);

                        #region DataSet
                        using (DataSet ds = DataAccessWrapper.ExecuteDataSet(dbCommand))
                        {
                            if (ds != null && ds.Tables.Count > 0)
                            {
                                dt = ds;
                            }
                        }
                        #endregion
                    }
                }

            }
            catch (Exception ex)
            {

                throw ex;
            }

            return dt;
        }

        public DataSet Incident_FetchNotificationSettings_BY_IncidentID_New(Int32 TopicID)
        {
            DataSet dt = new DataSet();
            try
            {

                using (DataAccessWrapper DataAccessWrapper = new DataAccessWrapper(DataBaseConstants.C2ConnectionString))
                {
                    using (DbCommand dbCommand = DataAccessWrapper.GetStoredProcCommand(DataBaseConstants.USP_API_SentryV2_NotificationSettings_Fetch_by_IncidentID_New))
                    {
                        dbCommand.CommandTimeout = 0;
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.TopicID, DbType.Int32, TopicID);

                        #region DataSet
                        using (DataSet ds = DataAccessWrapper.ExecuteDataSet(dbCommand))
                        {
                            if (ds != null && ds.Tables.Count > 0)
                            {
                                dt = ds;
                            }
                        }
                        #endregion
                    }
                }

            }
            catch (Exception ex)
            {

                throw ex;
            }

            return dt;
        }

        //Notification Settings
        public Int32 Incident_UpdateNotificationSettings(Int32 TopicID, Int32 UserID, Int32 IsActive, Int32 PlatformID, Int32 Platform_IsActive, Int32 Platform_AsItHappens, Int32 Platform_Summarised, Int32 Platform_SummarisedInterval, Int32 Platform_Conditional)
        {
            Int32 Result = 0;
            try
            {

                using (DataAccessWrapper DataAccessWrapper = new DataAccessWrapper(DataBaseConstants.C2ConnectionString))
                {
                    using (DbCommand dbCommand = DataAccessWrapper.GetStoredProcCommand(DataBaseConstants.USP_API_SentryV2_NotificationSettings_Update))
                    {
                        dbCommand.CommandTimeout = 0;
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.UserID, DbType.Int32, UserID);
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.TopicID, DbType.Int32, TopicID);
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.IsActive, DbType.Int32, IsActive);
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.PlatformID, DbType.Int32, PlatformID);
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Platform_IsActive, DbType.Int32, Platform_IsActive);
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Platform_AsItHappens, DbType.Int32, Platform_AsItHappens);
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Platform_Summarised, DbType.Int32, Platform_Summarised);
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Platform_SummarisedInterval, DbType.Int32, Platform_SummarisedInterval);
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Platform_Conditional, DbType.Int32, Platform_Conditional);

                        DataAccessWrapper.ExecuteScalar(dbCommand);

                        Result = 1;
                    }
                }

            }
            catch (Exception ex)
            {

                throw ex;
            }

            return Result;
        }

        public Int32 Incident_UpdateNotificationSettings_New(Int32 TopicID, Int32 UserID, Int32 IsActive, Int32 PlatformID, Int32 Platform_IsActive, Int32 Platform_AsItHappens, Int32 Platform_Summarised, Int32 Platform_SummarisedInterval, Int32 Platform_Conditional)
        {
            Int32 Result = 0;
            try
            {

                using (DataAccessWrapper DataAccessWrapper = new DataAccessWrapper(DataBaseConstants.C2ConnectionString))
                {
                    using (DbCommand dbCommand = DataAccessWrapper.GetStoredProcCommand(DataBaseConstants.USP_API_SentryV2_NotificationSettings_Update_New))
                    {
                        dbCommand.CommandTimeout = 0;
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.UserID, DbType.Int32, UserID);
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.TopicID, DbType.Int32, TopicID);
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.IsActive, DbType.Int32, IsActive);
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.PlatformID, DbType.Int32, PlatformID);
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Platform_IsActive, DbType.Int32, Platform_IsActive);
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Platform_AsItHappens, DbType.Int32, Platform_AsItHappens);
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Platform_Summarised, DbType.Int32, Platform_Summarised);
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Platform_SummarisedInterval, DbType.Int32, Platform_SummarisedInterval);
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Platform_Conditional, DbType.Int32, Platform_Conditional);

                        DataAccessWrapper.ExecuteScalar(dbCommand);

                        Result = 1;
                    }
                }

            }
            catch (Exception ex)
            {

                throw ex;
            }

            return Result;
        }

        public Int32 Incident_ConditionalDetail_Insert(Int32 TopicID, Int32 UserID, Int32 PlatformID, Int32 ConditionID, Int32 Is_Deleted, string criteriaJson, string condition_name, Int32 is_active)
        {
            Int32 Result = 0;
            try
            {

                using (DataAccessWrapper DataAccessWrapper = new DataAccessWrapper(DataBaseConstants.C2ConnectionString))
                {
                    using (DbCommand dbCommand = DataAccessWrapper.GetStoredProcCommand(DataBaseConstants.USP_API_SentryV2_Event_NotificationSetting_ConditionalDetail_Insert))
                    {
                        dbCommand.CommandTimeout = 0;
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.UserID, DbType.Int32, UserID);
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.TopicID, DbType.Int32, TopicID);
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.PlatformID, DbType.Int32, PlatformID);
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.ConditionID, DbType.Int32, ConditionID);
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Is_Deleted, DbType.Int32, Is_Deleted);
                        if (!string.IsNullOrEmpty(criteriaJson))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.criteriaJson, DbType.String, criteriaJson); }
                        if (!string.IsNullOrEmpty(condition_name))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.ConditionName, DbType.String, condition_name); }
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.IsActive, DbType.Int32, is_active);


                        DataAccessWrapper.ExecuteScalar(dbCommand);

                        Result = 1;
                    }
                }

            }
            catch (Exception ex)
            {

                throw ex;
            }

            return Result;
        }

        public Int32 Incident_UserRequestTopic_Insert(Int32 UserID, Int32 client_id, string incident_title, string incident_description, string incident_keywords, string incident_platforms, string incident_reflinks, string incident_query, DateTime incident_start_date, DateTime incident_end_date, string incident_event_type)
        {
            Int32 Result = 0;
            DataTable dt = new DataTable();
            try
            {

                using (DataAccessWrapper DataAccessWrapper = new DataAccessWrapper(DataBaseConstants.C2ConnectionString))
                {
                    using (DbCommand dbCommand = DataAccessWrapper.GetStoredProcCommand(DataBaseConstants.USP_API_SentryV2_UserRequestTopic_Insert))
                    {
                        dbCommand.CommandTimeout = 0;
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.UserID, DbType.Int32, UserID);
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.EntityID, DbType.Int32, client_id);
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.TopicName, DbType.String, incident_title);
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.TopicDescription, DbType.String, incident_description);
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Reference_ArticleUrl, DbType.String, incident_reflinks);
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Query, DbType.String, incident_query);
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Keywords, DbType.String, incident_keywords);
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Platforms, DbType.String, incident_platforms);
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.StartDate, DbType.DateTime, incident_start_date);
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.EndDate, DbType.DateTime, incident_end_date);
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.TopicType, DbType.String, incident_event_type);
                        //DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Query, DbType.String, Query);
                        //DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.ns_is_active, DbType.Int32, ns_is_active);                       

                        #region DataSet
                        using (DataSet ds = DataAccessWrapper.ExecuteDataSet(dbCommand))
                        {
                            if (ds != null && ds.Tables.Count > 0)
                            {
                                dt = ds.Tables[0];
                                if (dt != null && dt.Rows.Count > 0)
                                {
                                    Result = Convert.ToInt32(dt.Rows[0]["URTID"]);

                                }
                            }
                        }
                        #endregion
                    }
                }

            }
            catch (Exception ex)
            {

                throw ex;
            }

            return Result;
        }

        public Int32 API_UserRequest_DataDownload_Insert(Int32 UserID, Int32 TopicID, string RequestJson)
        {
            Int32 Result = 0;
            DataTable dt = new DataTable();
            try
            {

                using (DataAccessWrapper DataAccessWrapper = new DataAccessWrapper(DataBaseConstants.C2ConnectionString))
                {
                    using (DbCommand dbCommand = DataAccessWrapper.GetStoredProcCommand(DataBaseConstants.USP_API_UserRequest_DataDownload_Insert))
                    {
                        dbCommand.CommandTimeout = 0;
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.UserID, DbType.Int32, UserID);
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.TopicID, DbType.Int32, TopicID);
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.RequestJson, DbType.String, RequestJson);


                        #region DataSet
                        using (DataSet ds = DataAccessWrapper.ExecuteDataSet(dbCommand))
                        {
                            if (ds != null && ds.Tables.Count > 0)
                            {
                                dt = ds.Tables[0];
                                if (dt != null && dt.Rows.Count > 0)
                                {
                                    Result = Convert.ToInt32(dt.Rows[0]["UDDRID"]);

                                }
                            }
                        }
                        #endregion
                    }
                }

            }
            catch (Exception ex)
            {

                throw ex;
            }

            return Result;
        }

        public DataTable ArticleOnline_FetchParticipant_FetchList(Int32 TopicID, DateTime FromDate, DateTime ToDate, string Sentiment, string Publication_Domain,
            string Publication_Type, string Publication_DA, string Publication_Traffic, string Publication_ImpactScore, string SortBy,
            string SortOrder, string SearchText, string Mention_Type, string Client_Mention, string Headline_Sentiment, string Article_Type, string Exclude_By_Text)
        {
            DataTable dt = new DataTable();
            try
            {
                using (DataAccessWrapper DataAccessWrapper = new DataAccessWrapper(DataBaseConstants.SahadevConnectionString))
                {
                    using (DbCommand dbCommand = DataAccessWrapper.GetStoredProcCommand(DataBaseConstants.USP_API_SentryV2_ArticleOnline_FetchParticipant_List))
                    {
                        dbCommand.CommandTimeout = 0;
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.TopicID, DbType.Int32, TopicID);
                        if (FromDate != DateTime.MinValue)
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.FromDate, DbType.DateTime, FromDate); }

                        if (ToDate != DateTime.MinValue)
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.ToDate, DbType.DateTime, ToDate); }

                        if (!string.IsNullOrEmpty(Sentiment))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Sentiment, DbType.String, Sentiment); }

                        if (!string.IsNullOrEmpty(Publication_Domain))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Publication_Domain, DbType.String, Publication_Domain); }

                        if (!string.IsNullOrEmpty(Publication_Type))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Publication_Type, DbType.String, Publication_Type); }

                        if (!string.IsNullOrEmpty(Publication_DA))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Publication_DA, DbType.String, Publication_DA); }

                        if (!string.IsNullOrEmpty(Publication_Traffic))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Publication_Traffic, DbType.String, Publication_Traffic); }

                        if (!string.IsNullOrEmpty(Publication_ImpactScore))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Publication_ImpactScore, DbType.String, Publication_ImpactScore); }

                        if (!string.IsNullOrEmpty(SortBy))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.SortBy, DbType.String, SortBy); }

                        if (!string.IsNullOrEmpty(SortOrder))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.SortOrder, DbType.String, SortOrder); }

                        if (!string.IsNullOrEmpty(SearchText))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.SearchText, DbType.String, SearchText); }

                        if (!string.IsNullOrEmpty(Mention_Type))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Mention_Type, DbType.String, Mention_Type); }

                        if (!string.IsNullOrEmpty(Client_Mention))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Client_Mention, DbType.String, Client_Mention); }

                        if (!string.IsNullOrEmpty(Headline_Sentiment))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Headline_Sentiment, DbType.String, Headline_Sentiment); }

                        if (!string.IsNullOrEmpty(Article_Type))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Article_Type, DbType.String, Article_Type); }

                        if (!string.IsNullOrEmpty(Exclude_By_Text))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Exclude_By_Text, DbType.String, Exclude_By_Text); }


                        #region DataSet
                        using (DataSet ds = DataAccessWrapper.ExecuteDataSet(dbCommand))
                        {
                            if (ds != null && ds.Tables.Count > 0)
                            {
                                dt = ds.Tables[0];
                            }
                        }
                        #endregion
                    }
                }

            }
            catch (Exception ex)
            {

                throw ex;
            }

            return dt;
        }

        public DataSet ArticleOnline_FetchParticipant_FetchById(Int32 TopicID, DateTime FromDate, DateTime ToDate, string Publication_Domain)
        {
            DataSet dt = new DataSet();
            try
            {
                using (DataAccessWrapper DataAccessWrapper = new DataAccessWrapper(DataBaseConstants.SahadevConnectionString))
                {
                    using (DbCommand dbCommand = DataAccessWrapper.GetStoredProcCommand(DataBaseConstants.USP_API_SentryV2_ArticleOnline_FetchParticipant_FetchById))
                    {
                        dbCommand.CommandTimeout = 0;
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.TopicID, DbType.Int32, TopicID);

                        if (FromDate != DateTime.MinValue)
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.FromDate, DbType.DateTime, FromDate); }

                        if (ToDate != DateTime.MinValue)
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.ToDate, DbType.DateTime, ToDate); }

                        if (!string.IsNullOrEmpty(Publication_Domain))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Publication_Domain, DbType.String, Publication_Domain); }

                        #region DataSet
                        dt = DataAccessWrapper.ExecuteDataSet(dbCommand);
                        #endregion
                    }
                }

            }
            catch (Exception ex)
            {

                throw ex;
            }

            return dt;
        }

        public DataSet ArticleOnline_FetchParticipant_FetchFilter(Int32 TopicID, DateTime FromDate, DateTime ToDate)
        {
            DataSet dt = new DataSet();
            try
            {

                using (DataAccessWrapper DataAccessWrapper = new DataAccessWrapper(DataBaseConstants.SahadevConnectionString))
                {
                    using (DbCommand dbCommand = DataAccessWrapper.GetStoredProcCommand(DataBaseConstants.USP_API_SentryV2_ArticleOnline_FetchParticipant_FetchFilter))
                    {
                        dbCommand.CommandTimeout = 0;
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.TopicID, DbType.Int32, TopicID);

                        if (FromDate != DateTime.MinValue)
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.FromDate, DbType.DateTime, FromDate); }

                        if (ToDate != DateTime.MinValue)
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.ToDate, DbType.DateTime, ToDate); }

                        #region DataSet
                        using (DataSet ds = DataAccessWrapper.ExecuteDataSet(dbCommand))
                        {
                            if (ds != null && ds.Tables.Count > 0)
                            {
                                dt = ds;
                            }
                        }
                        #endregion
                    }
                }

            }
            catch (Exception ex)
            {

                throw ex;
            }

            return dt;
        }

        public DataTable ArticlePrint_FetchParticipant_FetchList(Int32 TopicID, DateTime FromDate, DateTime ToDate, string Sentiment, string Publication_Name, string Publication_Edition,
            string Publication_Type, string Publication_Circulation, string Publication_ImpactScore, string SortBy, string SortOrder,
            string SearchText, string Mention_Type, string Client_Mention, string Headline_Sentiment, string Article_Type, string Author, string Exclude_By_Text, string Language)
        {
            DataTable dt = new DataTable();
            try
            {
                using (DataAccessWrapper DataAccessWrapper = new DataAccessWrapper(DataBaseConstants.SahadevConnectionString))
                {
                    using (DbCommand dbCommand = DataAccessWrapper.GetStoredProcCommand(DataBaseConstants.USP_API_SentryV2_ArticlePrint_FetchParticipant_List))
                    {
                        dbCommand.CommandTimeout = 0;
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.TopicID, DbType.Int32, TopicID);

                        if (FromDate != DateTime.MinValue)
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.FromDate, DbType.DateTime, FromDate); }

                        if (ToDate != DateTime.MinValue)
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.ToDate, DbType.DateTime, ToDate); }

                        if (!string.IsNullOrEmpty(Sentiment))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Sentiment, DbType.String, Sentiment); }

                        if (!string.IsNullOrEmpty(Publication_Name))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Publication_Name, DbType.String, Publication_Name); }

                        if (!string.IsNullOrEmpty(Publication_Type))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Publication_Type, DbType.String, Publication_Type); }

                        if (!string.IsNullOrEmpty(Publication_Edition))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Publication_Edition, DbType.String, Publication_Edition); }

                        if (!string.IsNullOrEmpty(Publication_Circulation))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Publication_Circulation, DbType.String, Publication_Circulation); }

                        if (!string.IsNullOrEmpty(Publication_ImpactScore))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Publication_ImpactScore, DbType.String, Publication_ImpactScore); }

                        if (!string.IsNullOrEmpty(SortBy))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.SortBy, DbType.String, SortBy); }

                        if (!string.IsNullOrEmpty(SortOrder))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.SortOrder, DbType.String, SortOrder); }

                        if (!string.IsNullOrEmpty(SearchText))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.SearchText, DbType.String, SearchText); }

                        if (!string.IsNullOrEmpty(Mention_Type))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Mention_Type, DbType.String, Mention_Type); }

                        if (!string.IsNullOrEmpty(Client_Mention))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Client_Mention, DbType.String, Client_Mention); }

                        if (!string.IsNullOrEmpty(Headline_Sentiment))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Headline_Sentiment, DbType.String, Headline_Sentiment); }

                        if (!string.IsNullOrEmpty(Article_Type))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Article_Type, DbType.String, Article_Type); }

                        if (!string.IsNullOrEmpty(Author))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Author, DbType.String, Author); }

                        if (!string.IsNullOrEmpty(Exclude_By_Text))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Exclude_By_Text, DbType.String, Exclude_By_Text); }

                        if (!string.IsNullOrEmpty(Language))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Language, DbType.String, Language); }

                        #region DataSet
                        using (DataSet ds = DataAccessWrapper.ExecuteDataSet(dbCommand))
                        {
                            if (ds != null && ds.Tables.Count > 0)
                            {
                                dt = ds.Tables[0];
                            }
                        }
                        #endregion
                    }
                }

            }
            catch (Exception ex)
            {

                throw ex;
            }

            return dt;
        }

        public DataSet ArticlePrint_FetchParticipant_FetchById(Int32 TopicID, DateTime FromDate, DateTime ToDate, string Publication_Name)
        {
            DataSet dt = new DataSet();
            try
            {
                using (DataAccessWrapper DataAccessWrapper = new DataAccessWrapper(DataBaseConstants.SahadevConnectionString))
                {
                    using (DbCommand dbCommand = DataAccessWrapper.GetStoredProcCommand(DataBaseConstants.USP_API_SentryV2_ArticlePrint_FetchParticipant_FetchById))
                    {
                        dbCommand.CommandTimeout = 0;
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.TopicID, DbType.Int32, TopicID);

                        if (FromDate != DateTime.MinValue)
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.FromDate, DbType.DateTime, FromDate); }

                        if (ToDate != DateTime.MinValue)
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.ToDate, DbType.DateTime, ToDate); }

                        if (!string.IsNullOrEmpty(Publication_Name))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Publication_Name, DbType.String, Publication_Name); }

                        #region DataSet
                        dt = DataAccessWrapper.ExecuteDataSet(dbCommand);
                        #endregion
                    }
                }

            }
            catch (Exception ex)
            {

                throw ex;
            }

            return dt;
        }

        public DataSet ArticlePrint_FetchParticipant_FetchFilter(Int32 TopicID, DateTime FromDate, DateTime ToDate)
        {
            DataSet dt = new DataSet();
            try
            {

                using (DataAccessWrapper DataAccessWrapper = new DataAccessWrapper(DataBaseConstants.SahadevConnectionString))
                {
                    using (DbCommand dbCommand = DataAccessWrapper.GetStoredProcCommand(DataBaseConstants.USP_API_SentryV2_ArticlePrint_FetchParticipant_FetchFilter))
                    {
                        dbCommand.CommandTimeout = 0;
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.TopicID, DbType.Int32, TopicID);

                        if (FromDate != DateTime.MinValue)
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.FromDate, DbType.DateTime, FromDate); }

                        if (ToDate != DateTime.MinValue)
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.ToDate, DbType.DateTime, ToDate); }

                        #region DataSet
                        using (DataSet ds = DataAccessWrapper.ExecuteDataSet(dbCommand))
                        {
                            if (ds != null && ds.Tables.Count > 0)
                            {
                                dt = ds;
                            }
                        }
                        #endregion
                    }
                }

            }
            catch (Exception ex)
            {

                throw ex;
            }

            return dt;
        }

        public Int32 Incident_UpdateNotificationSettings_Bulk(DataTable dtUpdates)
        {
            Int32 Result = 0;
            try
            {

                using (DataAccessWrapper dataAccessWrapper = new DataAccessWrapper(DataBaseConstants.C2ConnectionString))
                {
                    using (DbCommand dbCommand = dataAccessWrapper.GetStoredProcCommand(DataBaseConstants.USP_API_SentryV2_NotificationSettings_Update_Bulk))
                    {
                        dbCommand.CommandTimeout = 0;
                        dbCommand.CommandType = CommandType.StoredProcedure;

                        SqlCommand sqlCmd = dbCommand as SqlCommand;
                        if (sqlCmd == null)
                            throw new InvalidCastException("DbCommand is not a SqlCommand. Ensure DataAccessWrapper uses SqlClient internally.");

                        sqlCmd.Parameters.Clear();

                        SqlParameter tvpParam = sqlCmd.Parameters.Add("@Updates", SqlDbType.Structured);
                        tvpParam.TypeName = "dbo.NotificationSettingsUpdateType";
                        tvpParam.Value = dtUpdates;

                        dataAccessWrapper.ExecuteNonQuery(sqlCmd);
                        Result = 1;
                    }
                }


            }
            catch (Exception ex)
            {

                throw ex;
            }

            return Result;
        }
        public Int32 Incident_UpdateNotificationSettings_Bulk_New(DataTable dtUpdates)
        {
            Int32 Result = 0;
            try
            {

                using (DataAccessWrapper dataAccessWrapper = new DataAccessWrapper(DataBaseConstants.C2ConnectionString))
                {
                    using (DbCommand dbCommand = dataAccessWrapper.GetStoredProcCommand(DataBaseConstants.USP_API_SentryV2_NotificationSettings_Update_Bulk_New))
                    {
                        dbCommand.CommandTimeout = 0;
                        dbCommand.CommandType = CommandType.StoredProcedure;

                        SqlCommand sqlCmd = dbCommand as SqlCommand;
                        if (sqlCmd == null)
                            throw new InvalidCastException("DbCommand is not a SqlCommand. Ensure DataAccessWrapper uses SqlClient internally.");

                        sqlCmd.Parameters.Clear();

                        SqlParameter tvpParam = sqlCmd.Parameters.Add("@Updates", SqlDbType.Structured);
                        tvpParam.TypeName = "dbo.NotificationSettingsUpdateType";
                        tvpParam.Value = dtUpdates;

                        dataAccessWrapper.ExecuteNonQuery(sqlCmd);
                        Result = 1;
                    }
                }


            }
            catch (Exception ex)
            {

                throw ex;
            }

            return Result;
        }



        //USER
        public DataSet User_FetchDetails(string UserName, string Password, string AppName)
        {
            DataSet dt = new DataSet();
            try
            {

                using (DataAccessWrapper DataAccessWrapper = new DataAccessWrapper(DataBaseConstants.PRConnectionString))
                {
                    using (DbCommand dbCommand = DataAccessWrapper.GetStoredProcCommand(DataBaseConstants.USP_API_User_Fetch))
                    {
                        dbCommand.CommandTimeout = 0;
                        if (!string.IsNullOrEmpty(UserName))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.UserName, DbType.String, UserName); }

                        if (!string.IsNullOrEmpty(AppName))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.AppName, DbType.String, AppName); }

                        #region DataSet
                        using (DataSet ds = DataAccessWrapper.ExecuteDataSet(dbCommand))
                        {
                            if (ds != null && ds.Tables.Count > 0)
                            {
                                dt = ds;
                            }
                        }
                        #endregion
                    }
                }

            }
            catch (Exception ex)
            {

                throw ex;
            }

            return dt;
        }

        public DataSet User_FetchDetails_New(string UserName)
        {
            DataSet dt = new DataSet();
            try
            {

                using (DataAccessWrapper DataAccessWrapper = new DataAccessWrapper(DataBaseConstants.C2ConnectionString))
                {
                    using (DbCommand dbCommand = DataAccessWrapper.GetStoredProcCommand(DataBaseConstants.USP_API_SentryV2_User_Fetch))
                    {
                        dbCommand.CommandTimeout = 0;
                        if (!string.IsNullOrEmpty(UserName))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.UserName, DbType.String, UserName); }

                        #region DataSet
                        using (DataSet ds = DataAccessWrapper.ExecuteDataSet(dbCommand))
                        {
                            if (ds != null && ds.Tables.Count > 0)
                            {
                                dt = ds;
                            }
                        }
                        #endregion
                    }
                }

            }
            catch (Exception ex)
            {

                throw ex;
            }

            return dt;
        }

        //USER
        public void User_UpdateDeviceId(Int32 UserID, string DeviceID, string OS, string AppName)
        {
            try
            {

                using (DataAccessWrapper DataAccessWrapper = new DataAccessWrapper(DataBaseConstants.C2ConnectionString))
                {
                    using (DbCommand dbCommand = DataAccessWrapper.GetStoredProcCommand(DataBaseConstants.USP_API_UserDeviceIds_Update_AWS))
                    {
                        dbCommand.CommandTimeout = 0;

                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.UserID, DbType.Int32, UserID);

                        if (!string.IsNullOrEmpty(DeviceID))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.DeviceID, DbType.String, DeviceID); }

                        if (!string.IsNullOrEmpty(OS))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.OS, DbType.String, OS); }

                        if (!string.IsNullOrEmpty(AppName))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.AppName, DbType.String, AppName); }

                        DataAccessWrapper.ExecuteNonQuery(dbCommand);
                    }
                }

            }
            catch (Exception ex)
            {

                throw ex;
            }
        }



        public Int32 ZURT_Insert(Int32 client_id, string incident_title, string incident_description, string incident_keywords, string incident_platforms, string incident_reflinks, string incident_query, DateTime incident_start_date, DateTime incident_end_date)
        {
            Int32 Result = 0;
            DataTable dt = new DataTable();
            try
            {

                using (DataAccessWrapper DataAccessWrapper = new DataAccessWrapper(DataBaseConstants.SahadevConnectionString))
                {
                    using (DbCommand dbCommand = DataAccessWrapper.GetStoredProcCommand(DataBaseConstants.USP_ZURT_Insert))
                    {
                        dbCommand.CommandTimeout = 0;
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.EntityID, DbType.Int32, client_id);
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.TopicName, DbType.String, incident_title);
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.TopicDescription, DbType.String, incident_description);
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Reference_ArticleUrl, DbType.String, incident_reflinks);
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Query, DbType.String, incident_query);
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Keywords, DbType.String, incident_keywords);
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Platforms, DbType.String, incident_platforms);
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.StartDate, DbType.DateTime, incident_start_date);
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.EndDate, DbType.DateTime, incident_end_date);

                        #region DataSet
                        using (DataSet ds = DataAccessWrapper.ExecuteDataSet(dbCommand))
                        {
                            if (ds != null && ds.Tables.Count > 0)
                            {
                                dt = ds.Tables[0];
                                if (dt != null && dt.Rows.Count > 0)
                                {
                                    Result = Convert.ToInt32(dt.Rows[0]["URTID"]);

                                }
                            }
                        }
                        #endregion
                    }
                }

            }
            catch (Exception ex)
            {

                throw ex;
            }

            return Result;
        }

        public Int32 ZURT_Update(Int32 URTID, Int32 client_id, string incident_title, string incident_description, string incident_keywords, string incident_platforms, string incident_reflinks, string incident_query, DateTime incident_start_date, DateTime incident_end_date)
        {
            Int32 Result = 0;
            DataTable dt = new DataTable();
            try
            {

                using (DataAccessWrapper DataAccessWrapper = new DataAccessWrapper(DataBaseConstants.SahadevConnectionString))
                {
                    using (DbCommand dbCommand = DataAccessWrapper.GetStoredProcCommand(DataBaseConstants.USP_ZURT_Update))
                    {
                        dbCommand.CommandTimeout = 0;
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.URTID, DbType.Int32, URTID);
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.EntityID, DbType.Int32, client_id);
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.TopicName, DbType.String, incident_title);
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.TopicDescription, DbType.String, incident_description);
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Reference_ArticleUrl, DbType.String, incident_reflinks);
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Query, DbType.String, incident_query);
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Keywords, DbType.String, incident_keywords);
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Platforms, DbType.String, incident_platforms);
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.StartDate, DbType.DateTime, incident_start_date);
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.EndDate, DbType.DateTime, incident_end_date);

                        #region DataSet
                        using (DataSet ds = DataAccessWrapper.ExecuteDataSet(dbCommand))
                        {
                            if (ds != null && ds.Tables.Count > 0)
                            {
                                dt = ds.Tables[0];
                                if (dt != null && dt.Rows.Count > 0)
                                {
                                    Result = Convert.ToInt32(dt.Rows[0][0]);

                                }
                            }
                        }
                        #endregion
                    }
                }

            }
            catch (Exception ex)
            {

                throw ex;
            }

            return Result;
        }

        public Int32 ZURT_Delete(Int32 URTID)
        {
            Int32 Result = 0;
            DataTable dt = new DataTable();
            try
            {

                using (DataAccessWrapper DataAccessWrapper = new DataAccessWrapper(DataBaseConstants.SahadevConnectionString))
                {
                    using (DbCommand dbCommand = DataAccessWrapper.GetStoredProcCommand(DataBaseConstants.USP_ZURT_Delete))
                    {
                        dbCommand.CommandTimeout = 0;
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.URTID, DbType.Int32, URTID);

                        #region DataSet
                        using (DataSet ds = DataAccessWrapper.ExecuteDataSet(dbCommand))
                        {
                            if (ds != null && ds.Tables.Count > 0)
                            {
                                dt = ds.Tables[0];
                                if (dt != null && dt.Rows.Count > 0)
                                {
                                    Result = Convert.ToInt32(dt.Rows[0][0]);
                                }
                            }
                        }
                        #endregion
                    }
                }

            }
            catch (Exception ex)
            {

                throw ex;
            }

            return Result;
        }

        public DataTable ZURT_FetchAll()
        {
            DataTable dt = new DataTable();
            try
            {

                using (DataAccessWrapper DataAccessWrapper = new DataAccessWrapper(DataBaseConstants.SahadevConnectionString))
                {
                    using (DbCommand dbCommand = DataAccessWrapper.GetStoredProcCommand(DataBaseConstants.USP_ZURT_FetchAll))
                    {
                        dbCommand.CommandTimeout = 0;
                        #region DataSet
                        using (DataSet ds = DataAccessWrapper.ExecuteDataSet(dbCommand))
                        {
                            if (ds != null && ds.Tables.Count > 0)
                            {
                                dt = ds.Tables[0];
                            }
                        }
                        #endregion
                    }
                }

            }
            catch (Exception ex)
            {

                throw ex;
            }

            return dt;
        }

        public DataTable ZURT_FetchByID(Int32 URTID)
        {
            DataTable dt = new DataTable();
            try
            {

                using (DataAccessWrapper DataAccessWrapper = new DataAccessWrapper(DataBaseConstants.SahadevConnectionString))
                {
                    using (DbCommand dbCommand = DataAccessWrapper.GetStoredProcCommand(DataBaseConstants.USP_ZURT_FetchByID))
                    {
                        dbCommand.CommandTimeout = 0;
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.URTID, DbType.Int32, URTID);

                        #region DataSet
                        using (DataSet ds = DataAccessWrapper.ExecuteDataSet(dbCommand))
                        {
                            if (ds != null && ds.Tables.Count > 0)
                            {
                                dt = ds.Tables[0];
                            }
                        }
                        #endregion
                    }
                }

            }
            catch (Exception ex)
            {

                throw ex;
            }

            return dt;
        }


        //Twitter
        public Int32 T3_Dossier_Insert(Int32 TopicID, DateTime FromDate, DateTime ToDate, Int32 UserID, string UserName, string UserEmailID)
        {
            Int32 Result = 0;
            DataTable dt = new DataTable();
            try
            {

                using (DataAccessWrapper DataAccessWrapper = new DataAccessWrapper(DataBaseConstants.SahadevConnectionString))
                {
                    using (DbCommand dbCommand = DataAccessWrapper.GetStoredProcCommand("USP_Dossier_T3_Insert"))
                    {
                        dbCommand.CommandTimeout = 0;
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.TopicID, DbType.Int32, TopicID);
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.FromDate, DbType.DateTime, FromDate);
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.ToDate, DbType.DateTime, ToDate);
                        DataAccessWrapper.AddInParameter(dbCommand, "UserID", DbType.Int32, UserID);
                        DataAccessWrapper.AddInParameter(dbCommand, "UserName", DbType.String, UserName);
                        DataAccessWrapper.AddInParameter(dbCommand, "UserEmailID", DbType.String, UserEmailID);


                        #region DataSet
                        using (DataSet ds = DataAccessWrapper.ExecuteDataSet(dbCommand))
                        {
                            if (ds != null && ds.Tables.Count > 0)
                            {
                                dt = ds.Tables[0];
                                if (dt != null && dt.Rows.Count > 0)
                                {
                                    Result = Convert.ToInt32(dt.Rows[0]["CDID"]);

                                }
                            }
                        }
                        #endregion
                    }
                }

            }
            catch (Exception ex)
            {

                throw ex;
            }

            return Result;
        }

        public Int32 UserBookmark_Update(Int32 UserID, Int32 PlatformID, Int32 RecordID, string Type, string Title, Int32 TopicID)
        {
            Int32 Result = 0;
            DataTable dt = new DataTable();
            try
            {

                using (DataAccessWrapper DataAccessWrapper = new DataAccessWrapper(DataBaseConstants.C2ConnectionString))
                {
                    using (DbCommand dbCommand = DataAccessWrapper.GetStoredProcCommand(DataBaseConstants.USP_UserBookmark_Update))
                    {
                        dbCommand.CommandTimeout = 0;
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.UserID, DbType.Int32, UserID);
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.TopicID, DbType.Int32, TopicID);
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.PlatformID, DbType.Int32, PlatformID);
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.RecordID, DbType.Int32, RecordID);
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Type, DbType.String, Type);
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Title, DbType.String, Title);

                        #region DataSet
                        using (DataSet ds = DataAccessWrapper.ExecuteDataSet(dbCommand))
                        {
                            if (ds != null && ds.Tables.Count > 0)
                            {
                                dt = ds.Tables[0];
                                if (dt != null && dt.Rows.Count > 0)
                                {
                                    Result = Convert.ToInt32(dt.Rows[0]["RecordID"]);

                                }
                            }
                        }
                        #endregion
                    }
                }

            }
            catch (Exception ex)
            {

                throw ex;
            }

            return Result;
        }

        public DataTable UserBookmark_FetchList(Int32 UserID, string Platform, Int32 TopicID)
        {
            DataTable dt = new DataTable();
            try
            {

                using (DataAccessWrapper DataAccessWrapper = new DataAccessWrapper(DataBaseConstants.SahadevConnectionString))
                {
                    using (DbCommand dbCommand = DataAccessWrapper.GetStoredProcCommand(DataBaseConstants.USP_UserBookmark_FetchList))
                    {
                        dbCommand.CommandTimeout = 0;
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.UserID, DbType.Int32, UserID);

                        if (!string.IsNullOrEmpty(Platform))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Platform, DbType.String, Platform); }

                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.TopicID, DbType.Int32, TopicID);

                        #region DataSet
                        using (DataSet ds = DataAccessWrapper.ExecuteDataSet(dbCommand))
                        {
                            if (ds != null && ds.Tables.Count > 0)
                            {
                                dt = ds.Tables[0];
                            }
                        }
                        #endregion
                    }
                }

            }
            catch (Exception ex)
            {

                throw ex;
            }

            return dt;
        }

        //Notifications

        public DataSet Notifications_FetchList(Int32 UserID, string Platform, Int32 IsRead)
        {
            DataSet ds = new DataSet();
            try
            {

                using (DataAccessWrapper DataAccessWrapper = new DataAccessWrapper(DataBaseConstants.SahadevConnectionString))
                {
                    using (DbCommand dbCommand = DataAccessWrapper.GetStoredProcCommand(DataBaseConstants.USP_SentryV2_Fetch_NotificationList))
                    {
                        dbCommand.CommandTimeout = 0;
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.UserID, DbType.Int32, UserID);

                        if (!string.IsNullOrEmpty(Platform))
                        {
                            DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Platform, DbType.String, Platform);
                        }
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.IsRead, DbType.Int32, IsRead);

                        ds = DataAccessWrapper.ExecuteDataSet(dbCommand);
                    }
                }

            }
            catch (Exception ex)
            {

                throw ex;
            }

            return ds;
        }

        public DataSet Notifications_FetchList_New(Int32 UserID, string Platform, Int32 IsRead)
        {
            DataSet ds = new DataSet();
            try
            {

                using (DataAccessWrapper DataAccessWrapper = new DataAccessWrapper(DataBaseConstants.SahadevConnectionString))
                {
                    using (DbCommand dbCommand = DataAccessWrapper.GetStoredProcCommand(DataBaseConstants.USP_SentryV2_Fetch_NotificationList_New))
                    {
                        dbCommand.CommandTimeout = 0;
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.UserID, DbType.Int32, UserID);

                        if (!string.IsNullOrEmpty(Platform))
                        {
                            DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Platform, DbType.String, Platform);
                        }
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.IsRead, DbType.Int32, IsRead);

                        ds = DataAccessWrapper.ExecuteDataSet(dbCommand);
                    }
                }

            }
            catch (Exception ex)
            {

                throw ex;
            }

            return ds;
        }

        public Int32 Notifications_Update_IsRead(Int32 UserID, string PrimaryKey, string NotificationType)
        {
            Int32 Result = 0;
            try
            {

                using (DataAccessWrapper DataAccessWrapper = new DataAccessWrapper(DataBaseConstants.C2ConnectionString))
                {
                    using (DbCommand dbCommand = DataAccessWrapper.GetStoredProcCommand(DataBaseConstants.USP_SentryV2_Update_Notifications_IsRead))
                    {
                        dbCommand.CommandTimeout = 0;
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.UserID, DbType.Int32, UserID);
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.PrimaryKey, DbType.String, PrimaryKey);
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.NotificationType, DbType.String, NotificationType);

                        DataAccessWrapper.ExecuteScalar(dbCommand);

                        Result = 1;
                    }
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }

            try
            {

                using (DataAccessWrapper DataAccessWrapper = new DataAccessWrapper(DataBaseConstants.SahadevConnectionString))
                {
                    using (DbCommand dbCommand = DataAccessWrapper.GetStoredProcCommand(DataBaseConstants.USP_SentryV2_Update_Notifications_IsRead))
                    {
                        dbCommand.CommandTimeout = 0;
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.UserID, DbType.Int32, UserID);
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.PrimaryKey, DbType.String, PrimaryKey);
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.NotificationType, DbType.String, NotificationType);

                        DataAccessWrapper.ExecuteScalar(dbCommand);
                    }
                }

            }
            catch (Exception)
            {

            }

            return Result;
        }


        public string Fetch_NotificationDetail_ByNLID(string NotificationType, Int32 PrimaryKey)
        {
            string Result = string.Empty;
            try
            {

                using (DataAccessWrapper DataAccessWrapper = new DataAccessWrapper(DataBaseConstants.SahadevConnectionString))
                {
                    using (DbCommand dbCommand = DataAccessWrapper.GetStoredProcCommand(DataBaseConstants.USP_SentryV2_Fetch_NotificationDetail_ByNLID))
                    {
                        dbCommand.CommandTimeout = 0;
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.PrimaryKey, DbType.Int32, PrimaryKey);
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.NotificationType, DbType.String, NotificationType);

                        DataSet ds = DataAccessWrapper.ExecuteDataSet(dbCommand);

                        if (ds != null)
                        {
                            if (ds.Tables.Count > 0)
                            {
                                Result = Convert.ToString(ds.Tables[0].Rows[0]["json"]);

                            }
                        }
                    }
                }

            }
            catch (Exception ex)
            {

                throw ex;
            }

            return Result;
        }

        //Twitter
        public Int32 UserLog_Insert(Int32 UserID, string Screen_Name, Int32 RecordID)
        {
            Int32 Result = 0;
            //DataTable dt = new DataTable();
            //try
            //{

            //    using (DataAccessWrapper DataAccessWrapper = new DataAccessWrapper(DataBaseConstants.C2ConnectionString))
            //    {
            //        using (DbCommand dbCommand = DataAccessWrapper.GetStoredProcCommand(DataBaseConstants.USP_API_SentryV2_UserLog_Insert))
            //        {
            //            DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.UserID, DbType.Int32, UserID);
            //            DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Screen_Name, DbType.String, Screen_Name);
            //            DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.RecordID, DbType.Int32, RecordID);

            //            #region DataSet
            //            using (DataSet ds = DataAccessWrapper.ExecuteDataSet(dbCommand))
            //            {
            //                if (ds != null && ds.Tables.Count > 0)
            //                {
            //                    dt = ds.Tables[0];
            //                    if (dt != null && dt.Rows.Count > 0)
            //                    {
            //                        Result = Convert.ToInt32(dt.Rows[0]["ULID"]);
            //                    }
            //                }
            //            }
            //            #endregion
            //        }
            //    }

            //}
            //catch (Exception ex)
            //{

            //    throw ex;
            //}

            return Result;
        }


        //Mark As Relevant
        public Int32 UserRequest_Irrelavant(Int32 UserID, Int32 PlatformID, Int32 RecordID, string Reason)
        {
            Int32 Result = 0;
            DataTable dt = new DataTable();
            try
            {

                using (DataAccessWrapper DataAccessWrapper = new DataAccessWrapper(DataBaseConstants.SahadevConnectionString))
                {
                    using (DbCommand dbCommand = DataAccessWrapper.GetStoredProcCommand(DataBaseConstants.USP_API_Insert_UserRequest_Irrelavant))
                    {
                        dbCommand.CommandTimeout = 0;
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.UserID, DbType.Int32, UserID);
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.PlatformID, DbType.Int32, PlatformID);
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.RecordID, DbType.Int32, RecordID);
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Reason, DbType.String, Reason);

                        #region DataSet
                        using (DataSet ds = DataAccessWrapper.ExecuteDataSet(dbCommand))
                        {
                            if (ds != null && ds.Tables.Count > 0)
                            {
                                dt = ds.Tables[0];
                                if (dt != null && dt.Rows.Count > 0)
                                {
                                    Result = Convert.ToInt32(dt.Rows[0]["RecordID"]);

                                }
                            }
                        }
                        #endregion
                    }
                }

            }
            catch (Exception ex)
            {

                throw ex;
            }

            return Result;
        }

        //Percentage Landing and Overview 

        public DataSet Incident_FetchLanding_Percentage(Int32 TopicID, DateTime FromDate, DateTime ToDate, DateTime BaseDate, Int32 show_percentage)
        {
            DataSet dt = new DataSet();
            try
            {

                using (DataAccessWrapper DataAccessWrapper = new DataAccessWrapper(DataBaseConstants.SahadevConnectionString))
                {
                    using (DbCommand dbCommand = DataAccessWrapper.GetStoredProcCommand(DataBaseConstants.USP_API_SentryV2_Overview_FetchLanding_Percentage))
                    {
                        dbCommand.CommandTimeout = 0;
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.TopicID, DbType.Int32, TopicID);

                        if (FromDate != DateTime.MinValue)
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.FromDate, DbType.DateTime, FromDate); }

                        if (ToDate != DateTime.MinValue)
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.ToDate, DbType.DateTime, ToDate); }

                        if (BaseDate != DateTime.MinValue)
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.BaseDate, DbType.DateTime, BaseDate); }

                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.show_percentage, DbType.Int32, show_percentage);

                        #region DataSet
                        using (DataSet ds = DataAccessWrapper.ExecuteDataSet(dbCommand))
                        {
                            if (ds != null && ds.Tables.Count > 0)
                            {
                                dt = ds;
                            }
                        }
                        #endregion
                    }
                }

            }
            catch (Exception ex)
            {

                throw ex;
            }

            return dt;
        }

        public DataSet ArticleOnline_FetchLanding_Percentage(Int32 TopicID, DateTime FromDate, DateTime ToDate, DateTime BaseDate, Int32 show_percentage)
        {
            DataSet dt = new DataSet();
            try
            {

                using (DataAccessWrapper DataAccessWrapper = new DataAccessWrapper(DataBaseConstants.SahadevConnectionString))
                {
                    using (DbCommand dbCommand = DataAccessWrapper.GetStoredProcCommand(DataBaseConstants.USP_API_SentryV2_ArticleOnline_FetchLanding_Percentage))
                    {
                        dbCommand.CommandTimeout = 0;
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.TopicID, DbType.Int32, TopicID);

                        if (FromDate != DateTime.MinValue)
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.FromDate, DbType.DateTime, FromDate); }

                        if (ToDate != DateTime.MinValue)
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.ToDate, DbType.DateTime, ToDate); }

                        if (BaseDate != DateTime.MinValue)
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.BaseDate, DbType.DateTime, BaseDate); }

                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.show_percentage, DbType.Int32, show_percentage);

                        #region DataSet
                        using (DataSet ds = DataAccessWrapper.ExecuteDataSet(dbCommand))
                        {
                            if (ds != null && ds.Tables.Count > 0)
                            {
                                dt = ds;
                            }
                        }
                        #endregion
                    }
                }

            }
            catch (Exception ex)
            {

                throw ex;
            }

            return dt;
        }

        public DataSet ArticlePrint_FetchLanding_Percentage(Int32 TopicID, DateTime FromDate, DateTime ToDate, DateTime BaseDate, Int32 show_percentage)
        {
            DataSet dt = new DataSet();
            try
            {

                using (DataAccessWrapper DataAccessWrapper = new DataAccessWrapper(DataBaseConstants.SahadevConnectionString))
                {
                    using (DbCommand dbCommand = DataAccessWrapper.GetStoredProcCommand(DataBaseConstants.USP_API_SentryV2_ArticlePrint_FetchLanding_Percentage))
                    {
                        dbCommand.CommandTimeout = 0;
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.TopicID, DbType.Int32, TopicID);

                        if (FromDate != DateTime.MinValue)
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.FromDate, DbType.DateTime, FromDate); }

                        if (ToDate != DateTime.MinValue)
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.ToDate, DbType.DateTime, ToDate); }

                        if (BaseDate != DateTime.MinValue)
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.BaseDate, DbType.DateTime, BaseDate); }

                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.show_percentage, DbType.Int32, show_percentage);

                        #region DataSet
                        using (DataSet ds = DataAccessWrapper.ExecuteDataSet(dbCommand))
                        {
                            if (ds != null && ds.Tables.Count > 0)
                            {
                                dt = ds;
                            }
                        }
                        #endregion
                    }
                }

            }
            catch (Exception ex)
            {

                throw ex;
            }

            return dt;
        }

        public DataSet Twitter_FetchLanding_Percentage(Int32 TopicID, DateTime FromDate, DateTime ToDate, DateTime BaseDate, Int32 show_percentage)
        {
            DataSet dt = new DataSet();
            try
            {

                using (DataAccessWrapper DataAccessWrapper = new DataAccessWrapper(DataBaseConstants.SahadevConnectionString))
                {
                    using (DbCommand dbCommand = DataAccessWrapper.GetStoredProcCommand(DataBaseConstants.USP_API_SentryV2_Twitter_FetchLanding_percentage))
                    {
                        dbCommand.CommandTimeout = 0;

                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.TopicID, DbType.Int32, TopicID);

                        if (FromDate != DateTime.MinValue)
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.FromDate, DbType.DateTime, FromDate); }

                        if (ToDate != DateTime.MinValue)
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.ToDate, DbType.DateTime, ToDate); }

                        if (BaseDate != DateTime.MinValue)
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.BaseDate, DbType.DateTime, BaseDate); }

                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.show_percentage, DbType.Int32, show_percentage);

                        #region DataSet
                        using (DataSet ds = DataAccessWrapper.ExecuteDataSet(dbCommand))
                        {
                            if (ds != null && ds.Tables.Count > 0)
                            {
                                dt = ds;
                            }
                        }
                        #endregion
                    }
                }

            }
            catch (Exception ex)
            {

                throw ex;
            }

            return dt;
        }

        public DataSet YouTube_FetchLanding_Percentage(Int32 TopicID, DateTime FromDate, DateTime ToDate, DateTime BaseDate, Int32 show_percentage)
        {
            DataSet dt = new DataSet();
            try
            {

                using (DataAccessWrapper DataAccessWrapper = new DataAccessWrapper(DataBaseConstants.SahadevConnectionString))
                {
                    using (DbCommand dbCommand = DataAccessWrapper.GetStoredProcCommand(DataBaseConstants.USP_API_SentryV2_YouTube_FetchLanding_percentage))
                    {
                        dbCommand.CommandTimeout = 0;

                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.TopicID, DbType.Int32, TopicID);

                        if (FromDate != DateTime.MinValue)
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.FromDate, DbType.DateTime, FromDate); }

                        if (ToDate != DateTime.MinValue)
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.ToDate, DbType.DateTime, ToDate); }

                        if (BaseDate != DateTime.MinValue)
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.BaseDate, DbType.DateTime, BaseDate); }

                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.show_percentage, DbType.Int32, show_percentage);

                        #region DataSet
                        using (DataSet ds = DataAccessWrapper.ExecuteDataSet(dbCommand))
                        {
                            if (ds != null && ds.Tables.Count > 0)
                            {
                                dt = ds;
                            }
                        }
                        #endregion
                    }
                }

            }
            catch (Exception ex)
            {

                throw ex;
            }

            return dt;
        }

        //hide_denominator Landing and Overview 

        public DataSet Incident_FetchLanding_Hide_Denominator(Int32 TopicID, DateTime FromDate, DateTime ToDate, DateTime BaseDate)
        {
            DataSet dt = new DataSet();
            try
            {

                using (DataAccessWrapper DataAccessWrapper = new DataAccessWrapper(DataBaseConstants.SahadevConnectionString))
                {
                    using (DbCommand dbCommand = DataAccessWrapper.GetStoredProcCommand(DataBaseConstants.USP_API_SentryV2_Overview_FetchLanding_HideTotals))
                    {
                        dbCommand.CommandTimeout = 0;
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.TopicID, DbType.Int32, TopicID);

                        if (FromDate != DateTime.MinValue)
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.FromDate, DbType.DateTime, FromDate); }

                        if (ToDate != DateTime.MinValue)
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.ToDate, DbType.DateTime, ToDate); }

                        if (BaseDate != DateTime.MinValue)
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.BaseDate, DbType.DateTime, BaseDate); }

                        #region DataSet
                        using (DataSet ds = DataAccessWrapper.ExecuteDataSet(dbCommand))
                        {
                            if (ds != null && ds.Tables.Count > 0)
                            {
                                dt = ds;
                            }
                        }
                        #endregion
                    }
                }

            }
            catch (Exception ex)
            {

                throw ex;
            }

            return dt;
        }

        public DataSet ArticleOnline_FetchLanding_Hide_Denominator(Int32 TopicID, DateTime FromDate, DateTime ToDate, DateTime BaseDate)
        {
            DataSet dt = new DataSet();
            try
            {

                using (DataAccessWrapper DataAccessWrapper = new DataAccessWrapper(DataBaseConstants.SahadevConnectionString))
                {
                    using (DbCommand dbCommand = DataAccessWrapper.GetStoredProcCommand(DataBaseConstants.USP_API_SentryV2_ArticleOnline_FetchLanding_hide_denominator))
                    {
                        dbCommand.CommandTimeout = 0;
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.TopicID, DbType.Int32, TopicID);

                        if (FromDate != DateTime.MinValue)
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.FromDate, DbType.DateTime, FromDate); }

                        if (ToDate != DateTime.MinValue)
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.ToDate, DbType.DateTime, ToDate); }

                        if (BaseDate != DateTime.MinValue)
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.BaseDate, DbType.DateTime, BaseDate); }


                        #region DataSet
                        using (DataSet ds = DataAccessWrapper.ExecuteDataSet(dbCommand))
                        {
                            if (ds != null && ds.Tables.Count > 0)
                            {
                                dt = ds;
                            }
                        }
                        #endregion
                    }
                }

            }
            catch (Exception ex)
            {

                throw ex;
            }

            return dt;
        }

        public DataSet ArticlePrint_FetchLanding_Hide_Denominator(Int32 TopicID, DateTime FromDate, DateTime ToDate, DateTime BaseDate)
        {
            DataSet dt = new DataSet();
            try
            {

                using (DataAccessWrapper DataAccessWrapper = new DataAccessWrapper(DataBaseConstants.SahadevConnectionString))
                {
                    using (DbCommand dbCommand = DataAccessWrapper.GetStoredProcCommand(DataBaseConstants.USP_API_SentryV2_ArticlePrint_FetchLanding_hide_denominator))
                    {
                        dbCommand.CommandTimeout = 0;
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.TopicID, DbType.Int32, TopicID);

                        if (FromDate != DateTime.MinValue)
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.FromDate, DbType.DateTime, FromDate); }

                        if (ToDate != DateTime.MinValue)
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.ToDate, DbType.DateTime, ToDate); }

                        if (BaseDate != DateTime.MinValue)
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.BaseDate, DbType.DateTime, BaseDate); }


                        #region DataSet
                        using (DataSet ds = DataAccessWrapper.ExecuteDataSet(dbCommand))
                        {
                            if (ds != null && ds.Tables.Count > 0)
                            {
                                dt = ds;
                            }
                        }
                        #endregion
                    }
                }

            }
            catch (Exception ex)
            {

                throw ex;
            }

            return dt;
        }

        public DataSet Twitter_FetchLanding_Hide_Denominator(Int32 TopicID, DateTime FromDate, DateTime ToDate, DateTime BaseDate)
        {
            DataSet dt = new DataSet();
            try
            {

                using (DataAccessWrapper DataAccessWrapper = new DataAccessWrapper(DataBaseConstants.SahadevConnectionString))
                {
                    using (DbCommand dbCommand = DataAccessWrapper.GetStoredProcCommand(DataBaseConstants.USP_API_SentryV2_Twitter_FetchLanding_hide_denominator))
                    {
                        dbCommand.CommandTimeout = 0;
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.TopicID, DbType.Int32, TopicID);

                        if (FromDate != DateTime.MinValue)
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.FromDate, DbType.DateTime, FromDate); }

                        if (ToDate != DateTime.MinValue)
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.ToDate, DbType.DateTime, ToDate); }

                        if (BaseDate != DateTime.MinValue)
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.BaseDate, DbType.DateTime, BaseDate); }


                        #region DataSet
                        using (DataSet ds = DataAccessWrapper.ExecuteDataSet(dbCommand))
                        {
                            if (ds != null && ds.Tables.Count > 0)
                            {
                                dt = ds;
                            }
                        }
                        #endregion
                    }
                }

            }
            catch (Exception ex)
            {

                throw ex;
            }

            return dt;
        }

        public DataSet YouTube_FetchLanding_Hide_Denominator(Int32 TopicID, DateTime FromDate, DateTime ToDate, DateTime BaseDate)
        {
            DataSet dt = new DataSet();
            try
            {

                using (DataAccessWrapper DataAccessWrapper = new DataAccessWrapper(DataBaseConstants.SahadevConnectionString))
                {
                    using (DbCommand dbCommand = DataAccessWrapper.GetStoredProcCommand(DataBaseConstants.USP_API_SentryV2_YouTube_FetchLanding_hide_denominator))
                    {
                        dbCommand.CommandTimeout = 0;
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.TopicID, DbType.Int32, TopicID);

                        if (FromDate != DateTime.MinValue)
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.FromDate, DbType.DateTime, FromDate); }

                        if (ToDate != DateTime.MinValue)
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.ToDate, DbType.DateTime, ToDate); }

                        if (BaseDate != DateTime.MinValue)
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.BaseDate, DbType.DateTime, BaseDate); }


                        #region DataSet
                        using (DataSet ds = DataAccessWrapper.ExecuteDataSet(dbCommand))
                        {
                            if (ds != null && ds.Tables.Count > 0)
                            {
                                dt = ds;
                            }
                        }
                        #endregion
                    }
                }

            }
            catch (Exception ex)
            {

                throw ex;
            }

            return dt;
        }


        //YouTube

        public DataSet FetchLanding_YouTube(Int32 TopicID, DateTime FromDate, DateTime ToDate, DateTime BaseDate, string Hide_Denominator, string ShowPercentage, string strDevice)
        {
            DataSet dt = new DataSet();
            try
            {
                string strSP = DataBaseConstants.USP_API_SentryV2_YouTube_FetchLanding;

                if (strDevice != "web")
                {
                    strSP = DataBaseConstants.USP_API_SentryV2_YouTube_FetchLanding_Mobile;
                }

                using (DataAccessWrapper DataAccessWrapper = new DataAccessWrapper(DataBaseConstants.SahadevConnectionString))
                {
                    using (DbCommand dbCommand = DataAccessWrapper.GetStoredProcCommand(strSP))
                    {
                        dbCommand.CommandTimeout = 0;
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.TopicID, DbType.Int32, TopicID);

                        if (FromDate != DateTime.MinValue)
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.FromDate, DbType.DateTime, FromDate); }

                        if (ToDate != DateTime.MinValue)
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.ToDate, DbType.DateTime, ToDate); }

                        if (BaseDate != DateTime.MinValue)
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.BaseDate, DbType.DateTime, BaseDate); }

                        if (!string.IsNullOrEmpty(Hide_Denominator))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Hide_Denominator, DbType.String, Hide_Denominator); }

                        if (!string.IsNullOrEmpty(ShowPercentage))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.ShowPercentage, DbType.String, ShowPercentage); }


                        #region DataSet
                        using (DataSet ds = DataAccessWrapper.ExecuteDataSet(dbCommand))
                        {
                            if (ds != null && ds.Tables.Count > 0)
                            {
                                dt = ds;
                            }
                        }
                        #endregion
                    }
                }

            }
            catch (Exception ex)
            {

                throw ex;
            }

            return dt;
        }

        public DataTable YouTube_FetchList(Int32 TopicID, DateTime BaseDate, DateTime FromDate, DateTime ToDate, string VideoTags,
            string ChannelHandle, string ChannelName, string Sentiment, string Tonality, string ChannelCategory,
            string Mention_Type, string ProfileVerifiedType, string Participant_Type, string Channel_SubscriberCount, string DurationInMin, string VideoType,
            string DiscourseCategory, string Mentioned_Topics, string Publication_ImpactScore, string Mentioned_Locations,
            string SortBy, string SortOrder, Int32 UserID, string People_Brand_Mentions, string Language, string SearchText, string Exclude_By_Text)
        {
            DataTable dt = new DataTable();
            try
            {
                using (DataAccessWrapper DataAccessWrapper = new DataAccessWrapper(DataBaseConstants.SahadevConnectionString))
                {
                    using (DbCommand dbCommand = DataAccessWrapper.GetStoredProcCommand(DataBaseConstants.USP_API_SentryV2_YouTube_FetchList))
                    {
                        dbCommand.CommandTimeout = 0;

                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.TopicID, DbType.Int32, TopicID);

                        if (BaseDate != DateTime.MinValue)
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.BaseDate, DbType.DateTime, BaseDate); }

                        if (FromDate != DateTime.MinValue)
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.FromDate, DbType.DateTime, FromDate); }

                        if (ToDate != DateTime.MinValue)
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.ToDate, DbType.DateTime, ToDate); }

                        if (!string.IsNullOrEmpty(VideoTags))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Video_Tags, DbType.String, VideoTags); }

                        if (!string.IsNullOrEmpty(ChannelHandle))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Channel_Handle, DbType.String, ChannelHandle); }

                        if (!string.IsNullOrEmpty(ChannelName))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Channel_Name, DbType.String, ChannelName); }

                        if (!string.IsNullOrEmpty(Sentiment))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Sentiment, DbType.String, Sentiment); }

                        if (!string.IsNullOrEmpty(Tonality))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Tonality, DbType.String, Tonality); }

                        if (!string.IsNullOrEmpty(ChannelCategory))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Channel_Category, DbType.String, ChannelCategory); }

                        if (!string.IsNullOrEmpty(Mention_Type))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Mention_Type, DbType.String, Mention_Type); }

                        if (!string.IsNullOrEmpty(ProfileVerifiedType))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Profile_VerifiedType, DbType.String, ProfileVerifiedType); }

                        if (!string.IsNullOrEmpty(Participant_Type))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Participant_Type, DbType.String, Participant_Type); }

                        if (!string.IsNullOrEmpty(Channel_SubscriberCount))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Channel_Subscriber_Count, DbType.String, Channel_SubscriberCount); }

                        if (!string.IsNullOrEmpty(DurationInMin))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Duration_In_Min, DbType.String, DurationInMin); }

                        if (!string.IsNullOrEmpty(VideoType))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Video_Type, DbType.String, VideoType); }

                        if (!string.IsNullOrEmpty(DiscourseCategory))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Discourse_Category, DbType.String, DiscourseCategory); }

                        if (!string.IsNullOrEmpty(Mentioned_Topics))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Mentioned_Topics, DbType.String, Mentioned_Topics); }

                        if (!string.IsNullOrEmpty(Publication_ImpactScore))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Publication_ImpactScore, DbType.String, Publication_ImpactScore); }

                        if (!string.IsNullOrEmpty(Mentioned_Locations))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Mentioned_Locations, DbType.String, Mentioned_Locations); }

                        if (!string.IsNullOrEmpty(SortBy))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.SortBy, DbType.String, SortBy); }

                        if (!string.IsNullOrEmpty(SortOrder))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.SortOrder, DbType.String, SortOrder); }

                        if (!string.IsNullOrEmpty(People_Brand_Mentions))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.People_Brand_Mentions, DbType.String, People_Brand_Mentions); }

                        if (!string.IsNullOrEmpty(Language))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Language, DbType.String, Language); }

                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.UserID, DbType.Int32, UserID);

                        if (!string.IsNullOrEmpty(SearchText))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.SearchText, DbType.String, SearchText); }

                        if (!string.IsNullOrEmpty(Exclude_By_Text))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Exclude_By_Text, DbType.String, Exclude_By_Text); }


                        #region DataSet
                        using (DataSet ds = DataAccessWrapper.ExecuteDataSet(dbCommand))
                        {
                            if (ds != null && ds.Tables.Count > 0)
                            {
                                dt = ds.Tables[0];
                            }
                        }
                        #endregion
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return dt;
        }

        public DataSet YouTube_FetchById(Int32 Video_ID, Int32 UserID)
        {
            DataSet dt = new DataSet();
            try
            {

                using (DataAccessWrapper DataAccessWrapper = new DataAccessWrapper(DataBaseConstants.SahadevConnectionString))
                {
                    using (DbCommand dbCommand = DataAccessWrapper.GetStoredProcCommand(DataBaseConstants.USP_API_SentryV2_YouTube_FetchById))
                    {
                        dbCommand.CommandTimeout = 0;
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Video_ID, DbType.Int32, Video_ID);
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.UserID, DbType.Int32, UserID);

                        #region DataSet
                        using (DataSet ds = DataAccessWrapper.ExecuteDataSet(dbCommand))
                        {
                            if (ds != null && ds.Tables.Count > 0)
                            {
                                dt = ds;
                            }
                        }
                        #endregion
                    }
                }

            }
            catch (Exception ex)
            {

                throw ex;
            }

            return dt;
        }

        public DataSet YouTube_FetchFilter(Int32 TopicID, DateTime BaseDate, DateTime FromDate, DateTime ToDate)
        {
            DataSet dt = new DataSet();
            try
            {

                using (DataAccessWrapper DataAccessWrapper = new DataAccessWrapper(DataBaseConstants.SahadevConnectionString))
                {
                    using (DbCommand dbCommand = DataAccessWrapper.GetStoredProcCommand(DataBaseConstants.USP_API_SentryV2_YouTube_FetchFilter))
                    {
                        dbCommand.CommandTimeout = 0;
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.TopicID, DbType.Int32, TopicID);

                        if (BaseDate != DateTime.MinValue)
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.BaseDate, DbType.DateTime, BaseDate); }

                        if (FromDate != DateTime.MinValue)
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.FromDate, DbType.DateTime, FromDate); }

                        if (ToDate != DateTime.MinValue)
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.ToDate, DbType.DateTime, ToDate); }

                        #region DataSet
                        using (DataSet ds = DataAccessWrapper.ExecuteDataSet(dbCommand))
                        {
                            if (ds != null && ds.Tables.Count > 0)
                            {
                                dt = ds;
                            }
                        }
                        #endregion
                    }
                }

            }
            catch (Exception ex)
            {

                throw ex;
            }

            return dt;
        }

        public DataTable YouTube_FetchParticipant_FetchList(Int32 TopicID, DateTime BaseDate, DateTime FromDate, DateTime ToDate, string VideoTags,
            string ChannelHandle, string ChannelName, string Sentiment, string Tonality, string ChannelCategory,
            string Mention_Type, string ProfileVerifiedType, string Participant_Type, string Channel_SubscriberCount, string DurationInMin, string VideoType,
            string DiscourseCategory, string Mentioned_Topics, string Publication_ImpactScore, string Mentioned_Locations,
            string SortBy, string SortOrder, Int32 UserID, string People_Brand_Mentions, string Language, string SearchText, string Exclude_By_Text)
        {
            DataTable dt = new DataTable();
            try
            {
                using (DataAccessWrapper DataAccessWrapper = new DataAccessWrapper(DataBaseConstants.SahadevConnectionString))
                {
                    using (DbCommand dbCommand = DataAccessWrapper.GetStoredProcCommand(DataBaseConstants.USP_API_SentryV2_YouTube_FetchParticipant_List))
                    {
                        dbCommand.CommandTimeout = 0;
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.TopicID, DbType.Int32, TopicID);

                        if (BaseDate != DateTime.MinValue)
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.BaseDate, DbType.DateTime, BaseDate); }

                        if (FromDate != DateTime.MinValue)
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.FromDate, DbType.DateTime, FromDate); }

                        if (ToDate != DateTime.MinValue)
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.ToDate, DbType.DateTime, ToDate); }

                        if (!string.IsNullOrEmpty(VideoTags))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Video_Tags, DbType.String, VideoTags); }

                        if (!string.IsNullOrEmpty(ChannelHandle))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Channel_Handle, DbType.String, ChannelHandle); }

                        if (!string.IsNullOrEmpty(ChannelName))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Channel_Name, DbType.String, ChannelName); }

                        if (!string.IsNullOrEmpty(Sentiment))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Sentiment, DbType.String, Sentiment); }

                        if (!string.IsNullOrEmpty(Tonality))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Tonality, DbType.String, Tonality); }

                        if (!string.IsNullOrEmpty(ChannelCategory))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Channel_Category, DbType.String, ChannelCategory); }

                        if (!string.IsNullOrEmpty(Mention_Type))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Mention_Type, DbType.String, Mention_Type); }

                        if (!string.IsNullOrEmpty(ProfileVerifiedType))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Profile_VerifiedType, DbType.String, ProfileVerifiedType); }

                        if (!string.IsNullOrEmpty(Participant_Type))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Participant_Type, DbType.String, Participant_Type); }

                        if (!string.IsNullOrEmpty(Channel_SubscriberCount))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Channel_Subscriber_Count, DbType.String, Channel_SubscriberCount); }

                        if (!string.IsNullOrEmpty(DurationInMin))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Duration_In_Min, DbType.String, DurationInMin); }

                        if (!string.IsNullOrEmpty(VideoType))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Video_Type, DbType.String, VideoType); }

                        if (!string.IsNullOrEmpty(DiscourseCategory))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Discourse_Category, DbType.String, DiscourseCategory); }

                        if (!string.IsNullOrEmpty(Mentioned_Topics))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Mentioned_Topics, DbType.String, Mentioned_Topics); }

                        if (!string.IsNullOrEmpty(Publication_ImpactScore))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Publication_ImpactScore, DbType.String, Publication_ImpactScore); }

                        if (!string.IsNullOrEmpty(Mentioned_Locations))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Mentioned_Locations, DbType.String, Mentioned_Locations); }

                        if (!string.IsNullOrEmpty(SortBy))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.SortBy, DbType.String, SortBy); }

                        if (!string.IsNullOrEmpty(SortOrder))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.SortOrder, DbType.String, SortOrder); }

                        if (!string.IsNullOrEmpty(People_Brand_Mentions))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.People_Brand_Mentions, DbType.String, People_Brand_Mentions); }

                        if (!string.IsNullOrEmpty(Language))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Language, DbType.String, Language); }

                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.UserID, DbType.Int32, UserID);

                        if (!string.IsNullOrEmpty(SearchText))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.SearchText, DbType.String, SearchText); }

                        if (!string.IsNullOrEmpty(Exclude_By_Text))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Exclude_By_Text, DbType.String, Exclude_By_Text); }

                        #region DataSet
                        using (DataSet ds = DataAccessWrapper.ExecuteDataSet(dbCommand))
                        {
                            if (ds != null && ds.Tables.Count > 0)
                            {
                                dt = ds.Tables[0];
                            }
                        }
                        #endregion
                    }
                }

            }
            catch (Exception ex)
            {

                throw ex;
            }

            return dt;
        }

        public DataSet YouTube_FetchParticipant_FetchById(Int32 TopicID, DateTime FromDate, DateTime ToDate, string Channel_Handle)
        {
            DataSet dt = new DataSet();
            try
            {
                using (DataAccessWrapper DataAccessWrapper = new DataAccessWrapper(DataBaseConstants.SahadevConnectionString))
                {
                    using (DbCommand dbCommand = DataAccessWrapper.GetStoredProcCommand(DataBaseConstants.USP_API_SentryV2_YouTube_FetchParticipant_FetchById))
                    {
                        dbCommand.CommandTimeout = 0;
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.TopicID, DbType.Int32, TopicID);

                        if (FromDate != DateTime.MinValue)
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.FromDate, DbType.DateTime, FromDate); }

                        if (ToDate != DateTime.MinValue)
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.ToDate, DbType.DateTime, ToDate); }

                        if (!string.IsNullOrEmpty(Channel_Handle))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Channel_Handle, DbType.String, Channel_Handle); }

                        #region DataSet
                        dt = DataAccessWrapper.ExecuteDataSet(dbCommand);
                        #endregion
                    }
                }

            }
            catch (Exception ex)
            {

                throw ex;
            }

            return dt;
        }

        public DataSet YouTube_FetchParticipant_FetchFilter(Int32 TopicID, DateTime BaseDate, DateTime FromDate, DateTime ToDate)
        {
            DataSet dt = new DataSet();
            try
            {

                using (DataAccessWrapper DataAccessWrapper = new DataAccessWrapper(DataBaseConstants.SahadevConnectionString))
                {
                    using (DbCommand dbCommand = DataAccessWrapper.GetStoredProcCommand(DataBaseConstants.USP_API_SentryV2_YouTube_FetchParticipant_FetchFilter))
                    {
                        dbCommand.CommandTimeout = 0;
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.TopicID, DbType.Int32, TopicID);

                        if (BaseDate != DateTime.MinValue)
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.BaseDate, DbType.DateTime, BaseDate); }

                        if (FromDate != DateTime.MinValue)
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.FromDate, DbType.DateTime, FromDate); }

                        if (ToDate != DateTime.MinValue)
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.ToDate, DbType.DateTime, ToDate); }

                        #region DataSet
                        using (DataSet ds = DataAccessWrapper.ExecuteDataSet(dbCommand))
                        {
                            if (ds != null && ds.Tables.Count > 0)
                            {
                                dt = ds;
                            }
                        }
                        #endregion
                    }
                }

            }
            catch (Exception ex)
            {

                throw ex;
            }

            return dt;
        }

        //FeedMonitor

        public DataTable Fetch_FeedMonitor_Funnel(Int32 TopicID, DateTime FromDate, DateTime ToDate, string GoogleTab, string Source)
        {
            DataTable dt = new DataTable();
            try
            {

                using (DataAccessWrapper DataAccessWrapper = new DataAccessWrapper(DataBaseConstants.SahadevConnectionString))
                {
                    using (DbCommand dbCommand = DataAccessWrapper.GetStoredProcCommand(DataBaseConstants.USP_API_FeedMonitor_Funnel_Online))
                    {
                        //dbCommand.CommandTimeout = 0;
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.TopicID, DbType.Int32, TopicID);

                        if (FromDate != DateTime.MinValue)
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.FromDate, DbType.DateTime, FromDate); }

                        if (ToDate != DateTime.MinValue)
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.ToDate, DbType.DateTime, ToDate); }

                        if (!string.IsNullOrEmpty(GoogleTab))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.GoogleTab, DbType.String, GoogleTab); }

                        if (!string.IsNullOrEmpty(Source))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Source, DbType.String, Source); }


                        #region DataSet
                        using (DataSet ds = DataAccessWrapper.ExecuteDataSet(dbCommand))
                        {
                            if (ds != null && ds.Tables.Count > 0)
                            {
                                dt = ds.Tables[0];
                            }
                        }
                        #endregion
                    }
                }

            }
            catch (Exception ex)
            {

                throw ex;
            }

            return dt;
        }

        public DataTable Fetch_FeedMonitor_Funnel_Details(Int32 TopicID, DateTime FromDate, DateTime ToDate, string Comment, string GoogleTab, string URL, string Source)
        {
            DataTable dt = new DataTable();
            try
            {

                using (DataAccessWrapper DataAccessWrapper = new DataAccessWrapper(DataBaseConstants.SahadevConnectionString))
                {
                    using (DbCommand dbCommand = DataAccessWrapper.GetStoredProcCommand(DataBaseConstants.USP_API_FeedMonitor_Funnel_Online_Detail))
                    {
                        //dbCommand.CommandTimeout = 0;
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.TopicID, DbType.Int32, TopicID);

                        if (FromDate != DateTime.MinValue)
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.FromDate, DbType.DateTime, FromDate); }

                        if (ToDate != DateTime.MinValue)
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.ToDate, DbType.DateTime, ToDate); }

                        if (!string.IsNullOrEmpty(Comment))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Comment, DbType.String, Comment); }

                        if (!string.IsNullOrEmpty(GoogleTab))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.GoogleTab, DbType.String, GoogleTab); }

                        if (!string.IsNullOrEmpty(URL))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Url, DbType.String, URL); }

                        if (!string.IsNullOrEmpty(Source))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Source, DbType.String, Source); }


                        #region DataSet
                        using (DataSet ds = DataAccessWrapper.ExecuteDataSet(dbCommand))
                        {
                            if (ds != null && ds.Tables.Count > 0)
                            {
                                dt = ds.Tables[0];
                            }
                        }
                        #endregion
                    }
                }

            }
            catch (Exception ex)
            {

                throw ex;
            }

            return dt;
        }

        public DataTable FeedMonitor_Incident_FetchList(Int32 UserID, Int32 EntityID, string TopicIDs, string TopicName)
        {
            DataTable dt = new DataTable();
            try
            {

                using (DataAccessWrapper DataAccessWrapper = new DataAccessWrapper(DataBaseConstants.SahadevConnectionString))
                {
                    using (DbCommand dbCommand = DataAccessWrapper.GetStoredProcCommand(DataBaseConstants.USP_API_FeedMonitor_Incident_FetchList))
                    {
                        //dbCommand.CommandTimeout = 0;
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.UserID, DbType.Int32, UserID);
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.ClientID, DbType.Int32, EntityID);
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.TopicIDs, DbType.String, TopicIDs);

                        if (!string.IsNullOrEmpty(TopicName))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.TopicName, DbType.String, TopicName); }

                        #region DataSet
                        using (DataSet ds = DataAccessWrapper.ExecuteDataSet(dbCommand))
                        {
                            if (ds != null && ds.Tables.Count > 0)
                            {
                                dt = ds.Tables[0];
                            }
                        }

                        DataAccessWrapper.Dispose();
                        #endregion
                    }
                }

            }
            catch (Exception ex)
            {

                throw ex;
            }

            return dt;
        }

        public DataSet Fetch_FeedMonitor_UserEvent_Stats(Int32 UserID)
        {
            DataSet dt = new DataSet();
            try
            {

                using (DataAccessWrapper DataAccessWrapper = new DataAccessWrapper(DataBaseConstants.SahadevConnectionString))
                {
                    using (DbCommand dbCommand = DataAccessWrapper.GetStoredProcCommand(DataBaseConstants.USP_API_FeedMonitor_UserEvent_Stats))
                    {
                        //dbCommand.CommandTimeout = 0;
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.UserID, DbType.Int32, UserID);
                        //DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.ClientID, DbType.Int32, ClientID);
                        //DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.TopicID, DbType.Int32, TopicID);

                        #region DataSet
                        #region DataSet
                        using (DataSet ds = DataAccessWrapper.ExecuteDataSet(dbCommand))
                        {
                            if (ds != null && ds.Tables.Count > 0)
                            {
                                dt = ds;
                            }
                        }
                        #endregion
                        #endregion
                    }
                }

            }
            catch (Exception ex)
            {

                throw ex;
            }

            return dt;
        }

        public DataTable Fetch_FeedMonitor_Funnel_Twitter(Int32 TopicID, DateTime FromDate, DateTime ToDate)
        {
            DataTable dt = new DataTable();
            try
            {

                using (DataAccessWrapper DataAccessWrapper = new DataAccessWrapper(DataBaseConstants.SahadevConnectionString))
                {
                    using (DbCommand dbCommand = DataAccessWrapper.GetStoredProcCommand(DataBaseConstants.USP_API_FeedMonitor_Funnel_Twitter))
                    {
                        //dbCommand.CommandTimeout = 0;
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.TopicID, DbType.Int32, TopicID);

                        if (FromDate != DateTime.MinValue)
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.FromDate, DbType.DateTime, FromDate); }

                        if (ToDate != DateTime.MinValue)
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.ToDate, DbType.DateTime, ToDate); }


                        #region DataSet
                        using (DataSet ds = DataAccessWrapper.ExecuteDataSet(dbCommand))
                        {
                            if (ds != null && ds.Tables.Count > 0)
                            {
                                dt = ds.Tables[0];
                            }
                        }
                        #endregion
                    }
                }

            }
            catch (Exception ex)
            {

                throw ex;
            }

            return dt;
        }

        public DataTable Fetch_FeedMonitor_Funnel_Twitter_Details(Int32 TopicID, DateTime FromDate, DateTime ToDate, string Comment, string URL)
        {
            DataTable dt = new DataTable();
            try
            {

                using (DataAccessWrapper DataAccessWrapper = new DataAccessWrapper(DataBaseConstants.SahadevConnectionString))
                {
                    using (DbCommand dbCommand = DataAccessWrapper.GetStoredProcCommand(DataBaseConstants.USP_API_FeedMonitor_Funnel_Twitter_Detail))
                    {
                        //dbCommand.CommandTimeout = 0;
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.TopicID, DbType.Int32, TopicID);

                        if (FromDate != DateTime.MinValue)
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.FromDate, DbType.DateTime, FromDate); }

                        if (ToDate != DateTime.MinValue)
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.ToDate, DbType.DateTime, ToDate); }

                        if (!string.IsNullOrEmpty(Comment))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Comment, DbType.String, Comment); }

                        if (!string.IsNullOrEmpty(URL))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Url, DbType.String, URL); }

                        #region DataSet
                        using (DataSet ds = DataAccessWrapper.ExecuteDataSet(dbCommand))
                        {
                            if (ds != null && ds.Tables.Count > 0)
                            {
                                dt = ds.Tables[0];
                            }
                        }
                        #endregion
                    }
                }

            }
            catch (Exception ex)
            {

                throw ex;
            }

            return dt;
        }

        public DataTable Fetch_FeedMonitor_Funnel_YouTube(Int32 TopicID, DateTime FromDate, DateTime ToDate)
        {
            DataTable dt = new DataTable();
            try
            {

                using (DataAccessWrapper DataAccessWrapper = new DataAccessWrapper(DataBaseConstants.SahadevConnectionString))
                {
                    using (DbCommand dbCommand = DataAccessWrapper.GetStoredProcCommand(DataBaseConstants.USP_API_FeedMonitor_Funnel_YouTube))
                    {
                        //dbCommand.CommandTimeout = 0;
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.TopicID, DbType.Int32, TopicID);

                        if (FromDate != DateTime.MinValue)
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.FromDate, DbType.DateTime, FromDate); }

                        if (ToDate != DateTime.MinValue)
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.ToDate, DbType.DateTime, ToDate); }


                        #region DataSet
                        using (DataSet ds = DataAccessWrapper.ExecuteDataSet(dbCommand))
                        {
                            if (ds != null && ds.Tables.Count > 0)
                            {
                                dt = ds.Tables[0];
                            }
                        }
                        #endregion
                    }
                }

            }
            catch (Exception ex)
            {

                throw ex;
            }

            return dt;
        }

        public DataTable Fetch_FeedMonitor_Funnel_YouTube_Details(Int32 TopicID, DateTime FromDate, DateTime ToDate, string Comment, string URL)
        {
            DataTable dt = new DataTable();
            try
            {

                using (DataAccessWrapper DataAccessWrapper = new DataAccessWrapper(DataBaseConstants.SahadevConnectionString))
                {
                    using (DbCommand dbCommand = DataAccessWrapper.GetStoredProcCommand(DataBaseConstants.USP_API_FeedMonitor_Funnel_YouTube_Detail))
                    {
                        //dbCommand.CommandTimeout = 0;
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.TopicID, DbType.Int32, TopicID);

                        if (FromDate != DateTime.MinValue)
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.FromDate, DbType.DateTime, FromDate); }

                        if (ToDate != DateTime.MinValue)
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.ToDate, DbType.DateTime, ToDate); }

                        if (!string.IsNullOrEmpty(Comment))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Comment, DbType.String, Comment); }

                        if (!string.IsNullOrEmpty(URL))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Url, DbType.String, URL); }

                        #region DataSet
                        using (DataSet ds = DataAccessWrapper.ExecuteDataSet(dbCommand))
                        {
                            if (ds != null && ds.Tables.Count > 0)
                            {
                                dt = ds.Tables[0];
                            }
                        }
                        #endregion
                    }
                }

            }
            catch (Exception ex)
            {

                throw ex;
            }

            return dt;
        }

        //Twitter Optimization DAL

        public DataSet FetchLanding_Twitter_Optimized_StatCards(Int32 TopicID, DateTime FromDate, DateTime ToDate, DateTime BaseDate, string Hide_Denominator, string ShowPercentage, string strDevice)
        {
            DataSet dt = new DataSet();
            try
            {

                using (DataAccessWrapper DataAccessWrapper = new DataAccessWrapper(DataBaseConstants.SahadevConnectionString))
                {
                    using (DbCommand dbCommand = DataAccessWrapper.GetStoredProcCommand(DataBaseConstants.USP_API_SentryV2_Twitter_FetchLanding_Optimized_StatCards))
                    {
                        dbCommand.CommandTimeout = 0;
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.TopicID, DbType.Int32, TopicID);

                        if (FromDate != DateTime.MinValue)
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.FromDate, DbType.DateTime, FromDate); }

                        if (ToDate != DateTime.MinValue)
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.ToDate, DbType.DateTime, ToDate); }

                        if (BaseDate != DateTime.MinValue)
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.BaseDate, DbType.DateTime, BaseDate); }

                        if (!string.IsNullOrEmpty(Hide_Denominator))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Hide_Denominator, DbType.String, Hide_Denominator); }

                        if (!string.IsNullOrEmpty(ShowPercentage))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.ShowPercentage, DbType.String, ShowPercentage); }



                        #region DataSet
                        using (DataSet ds = DataAccessWrapper.ExecuteDataSet(dbCommand))
                        {
                            if (ds != null && ds.Tables.Count > 0)
                            {
                                dt = ds;
                            }
                        }
                        #endregion
                    }
                }

            }
            catch (Exception ex)
            {

                throw ex;
            }

            return dt;
        }

        public DataSet FetchLanding_Twitter_Optimized_Conversion_Themes(Int32 TopicID, DateTime FromDate, DateTime ToDate, DateTime BaseDate)
        {
            DataSet dt = new DataSet();
            try
            {

                using (DataAccessWrapper DataAccessWrapper = new DataAccessWrapper(DataBaseConstants.SahadevConnectionString))
                {
                    using (DbCommand dbCommand = DataAccessWrapper.GetStoredProcCommand(DataBaseConstants.USP_API_SentryV2_Twitter_FetchLanding_Optimized_conversion_themes))
                    {
                        dbCommand.CommandTimeout = 0;
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.TopicID, DbType.Int32, TopicID);

                        if (FromDate != DateTime.MinValue)
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.FromDate, DbType.DateTime, FromDate); }

                        if (ToDate != DateTime.MinValue)
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.ToDate, DbType.DateTime, ToDate); }

                        if (BaseDate != DateTime.MinValue)
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.BaseDate, DbType.DateTime, BaseDate); }

                        #region DataSet
                        using (DataSet ds = DataAccessWrapper.ExecuteDataSet(dbCommand))
                        {
                            if (ds != null && ds.Tables.Count > 0)
                            {
                                dt = ds;
                            }
                        }
                        #endregion
                    }
                }

            }
            catch (Exception ex)
            {

                throw ex;
            }

            return dt;
        }

        public DataSet FetchLanding_Twitter_Optimized_Active_Participants(Int32 TopicID, DateTime FromDate, DateTime ToDate, DateTime BaseDate)
        {
            DataSet dt = new DataSet();
            try
            {

                using (DataAccessWrapper DataAccessWrapper = new DataAccessWrapper(DataBaseConstants.SahadevConnectionString))
                {
                    using (DbCommand dbCommand = DataAccessWrapper.GetStoredProcCommand(DataBaseConstants.USP_API_SentryV2_Twitter_FetchLanding_Optimized_Active_Participants))
                    {
                        dbCommand.CommandTimeout = 0;
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.TopicID, DbType.Int32, TopicID);

                        if (FromDate != DateTime.MinValue)
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.FromDate, DbType.DateTime, FromDate); }

                        if (ToDate != DateTime.MinValue)
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.ToDate, DbType.DateTime, ToDate); }

                        if (BaseDate != DateTime.MinValue)
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.BaseDate, DbType.DateTime, BaseDate); }

                        #region DataSet
                        using (DataSet ds = DataAccessWrapper.ExecuteDataSet(dbCommand))
                        {
                            if (ds != null && ds.Tables.Count > 0)
                            {
                                dt = ds;
                            }
                        }
                        #endregion
                    }
                }

            }
            catch (Exception ex)
            {

                throw ex;
            }

            return dt;
        }

        public DataSet FetchLanding_Twitter_Optimized_Distribution_By_Engagement(Int32 TopicID, DateTime FromDate, DateTime ToDate, DateTime BaseDate)
        {
            DataSet dt = new DataSet();
            try
            {

                using (DataAccessWrapper DataAccessWrapper = new DataAccessWrapper(DataBaseConstants.SahadevConnectionString))
                {
                    using (DbCommand dbCommand = DataAccessWrapper.GetStoredProcCommand(DataBaseConstants.USP_API_SentryV2_Twitter_FetchLanding_Optimized_Distribution_By_Engagement))
                    {
                        dbCommand.CommandTimeout = 0;
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.TopicID, DbType.Int32, TopicID);

                        if (FromDate != DateTime.MinValue)
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.FromDate, DbType.DateTime, FromDate); }

                        if (ToDate != DateTime.MinValue)
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.ToDate, DbType.DateTime, ToDate); }

                        if (BaseDate != DateTime.MinValue)
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.BaseDate, DbType.DateTime, BaseDate); }

                        #region DataSet
                        using (DataSet ds = DataAccessWrapper.ExecuteDataSet(dbCommand))
                        {
                            if (ds != null && ds.Tables.Count > 0)
                            {
                                dt = ds;
                            }
                        }
                        #endregion
                    }
                }

            }
            catch (Exception ex)
            {

                throw ex;
            }

            return dt;
        }

        public DataSet FetchLanding_Twitter_Optimized_Distribution_By_Sentiment(Int32 TopicID, DateTime FromDate, DateTime ToDate, DateTime BaseDate)
        {
            DataSet dt = new DataSet();
            try
            {

                using (DataAccessWrapper DataAccessWrapper = new DataAccessWrapper(DataBaseConstants.SahadevConnectionString))
                {
                    using (DbCommand dbCommand = DataAccessWrapper.GetStoredProcCommand(DataBaseConstants.USP_API_SentryV2_Twitter_FetchLanding_Optimized_Distribution_By_Sentiment))
                    {
                        dbCommand.CommandTimeout = 0;
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.TopicID, DbType.Int32, TopicID);

                        if (FromDate != DateTime.MinValue)
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.FromDate, DbType.DateTime, FromDate); }

                        if (ToDate != DateTime.MinValue)
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.ToDate, DbType.DateTime, ToDate); }

                        if (BaseDate != DateTime.MinValue)
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.BaseDate, DbType.DateTime, BaseDate); }

                        #region DataSet
                        using (DataSet ds = DataAccessWrapper.ExecuteDataSet(dbCommand))
                        {
                            if (ds != null && ds.Tables.Count > 0)
                            {
                                dt = ds;
                            }
                        }
                        #endregion
                    }
                }

            }
            catch (Exception ex)
            {

                throw ex;
            }

            return dt;
        }

        public DataSet FetchLanding_Twitter_Optimized_Distribution_By_Tonaity(Int32 TopicID, DateTime FromDate, DateTime ToDate, DateTime BaseDate)
        {
            DataSet dt = new DataSet();
            try
            {

                using (DataAccessWrapper DataAccessWrapper = new DataAccessWrapper(DataBaseConstants.SahadevConnectionString))
                {
                    using (DbCommand dbCommand = DataAccessWrapper.GetStoredProcCommand(DataBaseConstants.USP_API_SentryV2_Twitter_FetchLanding_Optimized_Distribution_By_Tonaity))
                    {
                        dbCommand.CommandTimeout = 0;
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.TopicID, DbType.Int32, TopicID);

                        if (FromDate != DateTime.MinValue)
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.FromDate, DbType.DateTime, FromDate); }

                        if (ToDate != DateTime.MinValue)
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.ToDate, DbType.DateTime, ToDate); }

                        if (BaseDate != DateTime.MinValue)
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.BaseDate, DbType.DateTime, BaseDate); }

                        #region DataSet
                        using (DataSet ds = DataAccessWrapper.ExecuteDataSet(dbCommand))
                        {
                            if (ds != null && ds.Tables.Count > 0)
                            {
                                dt = ds;
                            }
                        }
                        #endregion
                    }
                }

            }
            catch (Exception ex)
            {

                throw ex;
            }

            return dt;
        }

        public DataSet FetchLanding_Twitter_Optimized_Heading_stats(Int32 TopicID, DateTime FromDate, DateTime ToDate, DateTime BaseDate, string Hide_Denominator, string ShowPercentage)
        {
            DataSet dt = new DataSet();
            try
            {

                using (DataAccessWrapper DataAccessWrapper = new DataAccessWrapper(DataBaseConstants.SahadevConnectionString))
                {
                    using (DbCommand dbCommand = DataAccessWrapper.GetStoredProcCommand(DataBaseConstants.USP_API_SentryV2_Twitter_FetchLanding_Optimized_Heading_stats))
                    {
                        dbCommand.CommandTimeout = 0;
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.TopicID, DbType.Int32, TopicID);

                        if (FromDate != DateTime.MinValue)
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.FromDate, DbType.DateTime, FromDate); }

                        if (ToDate != DateTime.MinValue)
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.ToDate, DbType.DateTime, ToDate); }

                        if (BaseDate != DateTime.MinValue)
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.BaseDate, DbType.DateTime, BaseDate); }

                        if (!string.IsNullOrEmpty(Hide_Denominator))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Hide_Denominator, DbType.String, Hide_Denominator); }

                        if (!string.IsNullOrEmpty(ShowPercentage))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.ShowPercentage, DbType.String, ShowPercentage); }

                        #region DataSet
                        using (DataSet ds = DataAccessWrapper.ExecuteDataSet(dbCommand))
                        {
                            if (ds != null && ds.Tables.Count > 0)
                            {
                                dt = ds;
                            }
                        }
                        #endregion
                    }
                }

            }
            catch (Exception ex)
            {

                throw ex;
            }

            return dt;
        }

        public DataSet FetchLanding_Twitter_Optimized_Media_Influencers(Int32 TopicID, DateTime FromDate, DateTime ToDate, DateTime BaseDate)
        {
            DataSet dt = new DataSet();
            try
            {

                using (DataAccessWrapper DataAccessWrapper = new DataAccessWrapper(DataBaseConstants.SahadevConnectionString))
                {
                    using (DbCommand dbCommand = DataAccessWrapper.GetStoredProcCommand(DataBaseConstants.USP_API_SentryV2_Twitter_FetchLanding_Optimized_Media_Influencers))
                    {
                        dbCommand.CommandTimeout = 0;
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.TopicID, DbType.Int32, TopicID);

                        if (FromDate != DateTime.MinValue)
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.FromDate, DbType.DateTime, FromDate); }

                        if (ToDate != DateTime.MinValue)
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.ToDate, DbType.DateTime, ToDate); }

                        if (BaseDate != DateTime.MinValue)
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.BaseDate, DbType.DateTime, BaseDate); }

                        #region DataSet
                        using (DataSet ds = DataAccessWrapper.ExecuteDataSet(dbCommand))
                        {
                            if (ds != null && ds.Tables.Count > 0)
                            {
                                dt = ds;
                            }
                        }
                        #endregion
                    }
                }

            }
            catch (Exception ex)
            {

                throw ex;
            }

            return dt;
        }

        public DataSet FetchLanding_Twitter_Optimized_Top_Mentioned_Hashtags(Int32 TopicID, DateTime FromDate, DateTime ToDate, DateTime BaseDate)
        {
            DataSet dt = new DataSet();
            try
            {

                using (DataAccessWrapper DataAccessWrapper = new DataAccessWrapper(DataBaseConstants.SahadevConnectionString))
                {
                    using (DbCommand dbCommand = DataAccessWrapper.GetStoredProcCommand(DataBaseConstants.USP_API_SentryV2_Twitter_FetchLanding_Optimized_Top_Mentioned_Hashtags))
                    {
                        dbCommand.CommandTimeout = 0;
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.TopicID, DbType.Int32, TopicID);

                        if (FromDate != DateTime.MinValue)
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.FromDate, DbType.DateTime, FromDate); }

                        if (ToDate != DateTime.MinValue)
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.ToDate, DbType.DateTime, ToDate); }

                        if (BaseDate != DateTime.MinValue)
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.BaseDate, DbType.DateTime, BaseDate); }

                        #region DataSet
                        using (DataSet ds = DataAccessWrapper.ExecuteDataSet(dbCommand))
                        {
                            if (ds != null && ds.Tables.Count > 0)
                            {
                                dt = ds;
                            }
                        }
                        #endregion
                    }
                }

            }
            catch (Exception ex)
            {

                throw ex;
            }

            return dt;
        }

        public DataSet FetchLanding_Twitter_Optimized_TopTenContributorsByEngagement(Int32 TopicID, DateTime FromDate, DateTime ToDate, DateTime BaseDate)
        {
            DataSet dt = new DataSet();
            try
            {

                using (DataAccessWrapper DataAccessWrapper = new DataAccessWrapper(DataBaseConstants.SahadevConnectionString))
                {
                    using (DbCommand dbCommand = DataAccessWrapper.GetStoredProcCommand(DataBaseConstants.USP_API_SentryV2_Twitter_FetchLanding_Optimized_TopTenContributorsByEngagement))
                    {
                        dbCommand.CommandTimeout = 0;
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.TopicID, DbType.Int32, TopicID);

                        if (FromDate != DateTime.MinValue)
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.FromDate, DbType.DateTime, FromDate); }

                        if (ToDate != DateTime.MinValue)
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.ToDate, DbType.DateTime, ToDate); }

                        if (BaseDate != DateTime.MinValue)
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.BaseDate, DbType.DateTime, BaseDate); }

                        #region DataSet
                        using (DataSet ds = DataAccessWrapper.ExecuteDataSet(dbCommand))
                        {
                            if (ds != null && ds.Tables.Count > 0)
                            {
                                dt = ds;
                            }
                        }
                        #endregion
                    }
                }

            }
            catch (Exception ex)
            {

                throw ex;
            }

            return dt;
        }

        public DataSet FetchLanding_Twitter_Optimized_TopTenContributorsByReach(Int32 TopicID, DateTime FromDate, DateTime ToDate, DateTime BaseDate)
        {
            DataSet dt = new DataSet();
            try
            {

                using (DataAccessWrapper DataAccessWrapper = new DataAccessWrapper(DataBaseConstants.SahadevConnectionString))
                {
                    using (DbCommand dbCommand = DataAccessWrapper.GetStoredProcCommand(DataBaseConstants.USP_API_SentryV2_Twitter_FetchLanding_Optimized_TopTenContributorsByReach))
                    {
                        dbCommand.CommandTimeout = 0;
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.TopicID, DbType.Int32, TopicID);

                        if (FromDate != DateTime.MinValue)
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.FromDate, DbType.DateTime, FromDate); }

                        if (ToDate != DateTime.MinValue)
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.ToDate, DbType.DateTime, ToDate); }

                        if (BaseDate != DateTime.MinValue)
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.BaseDate, DbType.DateTime, BaseDate); }

                        #region DataSet
                        using (DataSet ds = DataAccessWrapper.ExecuteDataSet(dbCommand))
                        {
                            if (ds != null && ds.Tables.Count > 0)
                            {
                                dt = ds;
                            }
                        }
                        #endregion
                    }
                }

            }
            catch (Exception ex)
            {

                throw ex;
            }

            return dt;
        }

        public DataSet FetchLanding_Twitter_Optimized_TweetsTimeline(Int32 TopicID, DateTime FromDate, DateTime ToDate, DateTime BaseDate)
        {
            DataSet dt = new DataSet();
            try
            {

                using (DataAccessWrapper DataAccessWrapper = new DataAccessWrapper(DataBaseConstants.SahadevConnectionString))
                {
                    using (DbCommand dbCommand = DataAccessWrapper.GetStoredProcCommand(DataBaseConstants.USP_API_SentryV2_Twitter_FetchLanding_Optimized_TweetsTimeline))
                    {
                        dbCommand.CommandTimeout = 0;
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.TopicID, DbType.Int32, TopicID);

                        if (FromDate != DateTime.MinValue)
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.FromDate, DbType.DateTime, FromDate); }

                        if (ToDate != DateTime.MinValue)
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.ToDate, DbType.DateTime, ToDate); }

                        if (BaseDate != DateTime.MinValue)
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.BaseDate, DbType.DateTime, BaseDate); }

                        #region DataSet
                        using (DataSet ds = DataAccessWrapper.ExecuteDataSet(dbCommand))
                        {
                            if (ds != null && ds.Tables.Count > 0)
                            {
                                dt = ds;
                            }
                        }
                        #endregion
                    }
                }

            }
            catch (Exception ex)
            {

                throw ex;
            }

            return dt;
        }

        public DataSet FetchLanding_Twitter_Optimized_Key_Highlights_Data(Int32 TopicID, DateTime FromDate, DateTime ToDate, DateTime BaseDate)
        {
            DataSet dt = new DataSet();
            try
            {

                using (DataAccessWrapper DataAccessWrapper = new DataAccessWrapper(DataBaseConstants.SahadevConnectionString))
                {
                    using (DbCommand dbCommand = DataAccessWrapper.GetStoredProcCommand(DataBaseConstants.USP_API_SentryV2_Twitter_FetchLanding_Optimized_Key_Highlights_Data))
                    {
                        dbCommand.CommandTimeout = 0;
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.TopicID, DbType.Int32, TopicID);

                        if (FromDate != DateTime.MinValue)
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.FromDate, DbType.DateTime, FromDate); }

                        if (ToDate != DateTime.MinValue)
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.ToDate, DbType.DateTime, ToDate); }

                        if (BaseDate != DateTime.MinValue)
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.BaseDate, DbType.DateTime, BaseDate); }

                        #region DataSet
                        using (DataSet ds = DataAccessWrapper.ExecuteDataSet(dbCommand))
                        {
                            if (ds != null && ds.Tables.Count > 0)
                            {
                                dt = ds;
                            }
                        }
                        #endregion
                    }
                }

            }
            catch (Exception ex)
            {

                throw ex;
            }

            return dt;
        }

        //New Online Optimization DAL

        public DataSet ArticleOnline_FetchLanding_Optimized_StatCards(Int32 TopicID, DateTime FromDate, DateTime ToDate, DateTime BaseDate, string Hide_Denominator, string ShowPercentage, string strDevice)
        {
            DataSet dt = new DataSet();
            try
            {
                string strSP = DataBaseConstants.USP_API_SentryV2_ArticleOnline_FL_Optimized_StatCards;

                using (DataAccessWrapper DataAccessWrapper = new DataAccessWrapper(DataBaseConstants.SahadevConnectionString))
                {
                    using (DbCommand dbCommand = DataAccessWrapper.GetStoredProcCommand(strSP))
                    {
                        dbCommand.CommandTimeout = 0;
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.TopicID, DbType.Int32, TopicID);

                        if (FromDate != DateTime.MinValue)
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.FromDate, DbType.DateTime, FromDate); }

                        if (ToDate != DateTime.MinValue)
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.ToDate, DbType.DateTime, ToDate); }

                        if (BaseDate != DateTime.MinValue)
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.BaseDate, DbType.DateTime, BaseDate); }

                        if (!string.IsNullOrEmpty(Hide_Denominator))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Hide_Denominator, DbType.String, Hide_Denominator); }

                        if (!string.IsNullOrEmpty(ShowPercentage))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.ShowPercentage, DbType.String, ShowPercentage); }


                        #region DataSet
                        using (DataSet ds = DataAccessWrapper.ExecuteDataSet(dbCommand))
                        {
                            if (ds != null && ds.Tables.Count > 0)
                            {
                                dt = ds;
                            }
                        }

                        DataAccessWrapper.Dispose();
                        #endregion
                    }
                }

            }
            catch (Exception ex)
            {

                throw ex;
            }

            return dt;
        }

        public DataSet FetchLanding_Online_Optimized_Data_By_Parameter(Int32 TopicID, DateTime FromDate, DateTime ToDate, DateTime BaseDate, string Parameter, string Hide_Denominator, string ShowPercentage)
        {
            DataSet dt = new DataSet();
            try
            {
                string strSP = string.Empty;
                if (!string.IsNullOrEmpty(Parameter))
                {
                    strSP = DataBaseConstants.USP_API_SentryV2_ArticleOnline_FL_ + Parameter;
                }

                using (DataAccessWrapper DataAccessWrapper = new DataAccessWrapper(DataBaseConstants.SahadevConnectionString))
                {
                    using (DbCommand dbCommand = DataAccessWrapper.GetStoredProcCommand(strSP))
                    {
                        dbCommand.CommandTimeout = 0;
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.TopicID, DbType.Int32, TopicID);

                        if (FromDate != DateTime.MinValue)
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.FromDate, DbType.DateTime, FromDate); }

                        if (ToDate != DateTime.MinValue)
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.ToDate, DbType.DateTime, ToDate); }

                        if (BaseDate != DateTime.MinValue)
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.BaseDate, DbType.DateTime, BaseDate); }

                        if (!string.IsNullOrEmpty(Hide_Denominator))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Hide_Denominator, DbType.String, Hide_Denominator); }

                        if (!string.IsNullOrEmpty(ShowPercentage))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.ShowPercentage, DbType.String, ShowPercentage); }


                        #region DataSet
                        using (DataSet ds = DataAccessWrapper.ExecuteDataSet(dbCommand))
                        {
                            if (ds != null && ds.Tables.Count > 0)
                            {
                                dt = ds;
                            }
                        }

                        DataAccessWrapper.Dispose();
                        #endregion
                    }
                }

            }
            catch (Exception ex)
            {

                throw ex;
            }

            return dt;
        }

        //New Print Optimization DAL

        public DataSet ArticlePrint_FetchLanding_Optimized_StatCards(Int32 TopicID, DateTime FromDate, DateTime ToDate, DateTime BaseDate, string Hide_Denominator, string ShowPercentage, string strDevice)
        {
            DataSet dt = new DataSet();
            try
            {
                string strSP = DataBaseConstants.USP_API_SentryV2_ArticlePrint_FL_Optimized_StatCards;

                using (DataAccessWrapper DataAccessWrapper = new DataAccessWrapper(DataBaseConstants.SahadevConnectionString))
                {
                    using (DbCommand dbCommand = DataAccessWrapper.GetStoredProcCommand(strSP))
                    {
                        dbCommand.CommandTimeout = 0;
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.TopicID, DbType.Int32, TopicID);

                        if (FromDate != DateTime.MinValue)
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.FromDate, DbType.DateTime, FromDate); }

                        if (ToDate != DateTime.MinValue)
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.ToDate, DbType.DateTime, ToDate); }

                        if (BaseDate != DateTime.MinValue)
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.BaseDate, DbType.DateTime, BaseDate); }

                        if (!string.IsNullOrEmpty(Hide_Denominator))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Hide_Denominator, DbType.String, Hide_Denominator); }

                        if (!string.IsNullOrEmpty(ShowPercentage))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.ShowPercentage, DbType.String, ShowPercentage); }


                        #region DataSet
                        using (DataSet ds = DataAccessWrapper.ExecuteDataSet(dbCommand))
                        {
                            if (ds != null && ds.Tables.Count > 0)
                            {
                                dt = ds;
                            }
                        }

                        DataAccessWrapper.Dispose();
                        #endregion
                    }
                }

            }
            catch (Exception ex)
            {

                throw ex;
            }

            return dt;
        }

        public DataSet FetchLanding_Print_Optimized_Data_By_Parameter(Int32 TopicID, DateTime FromDate, DateTime ToDate, DateTime BaseDate, string Parameter, string Hide_Denominator, string ShowPercentage)
        {
            DataSet dt = new DataSet();
            try
            {
                string strSP = string.Empty;
                if (!string.IsNullOrEmpty(Parameter))
                {
                    strSP = DataBaseConstants.USP_API_SentryV2_ArticlePrint_FL_Optimized_ + Parameter;
                }

                using (DataAccessWrapper DataAccessWrapper = new DataAccessWrapper(DataBaseConstants.SahadevConnectionString))
                {
                    using (DbCommand dbCommand = DataAccessWrapper.GetStoredProcCommand(strSP))
                    {
                        dbCommand.CommandTimeout = 0;
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.TopicID, DbType.Int32, TopicID);

                        if (FromDate != DateTime.MinValue)
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.FromDate, DbType.DateTime, FromDate); }

                        if (ToDate != DateTime.MinValue)
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.ToDate, DbType.DateTime, ToDate); }

                        if (BaseDate != DateTime.MinValue)
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.BaseDate, DbType.DateTime, BaseDate); }

                        if (!string.IsNullOrEmpty(Hide_Denominator))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Hide_Denominator, DbType.String, Hide_Denominator); }

                        if (!string.IsNullOrEmpty(ShowPercentage))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.ShowPercentage, DbType.String, ShowPercentage); }


                        #region DataSet
                        using (DataSet ds = DataAccessWrapper.ExecuteDataSet(dbCommand))
                        {
                            if (ds != null && ds.Tables.Count > 0)
                            {
                                dt = ds;
                            }
                        }

                        DataAccessWrapper.Dispose();
                        #endregion
                    }
                }

            }
            catch (Exception ex)
            {

                throw ex;
            }

            return dt;
        }

        //New YouTube Optimization DAL

        public DataSet FetchLanding_YouTube_Optimized_StatCards(Int32 TopicID, DateTime FromDate, DateTime ToDate, DateTime BaseDate, string Hide_Denominator, string ShowPercentage, string strDevice)
        {
            DataSet dt = new DataSet();
            try
            {
                string strSP = DataBaseConstants.USP_API_SentryV2_YouTube_FL_Optimized_StatCards;

                using (DataAccessWrapper DataAccessWrapper = new DataAccessWrapper(DataBaseConstants.SahadevConnectionString))
                {
                    using (DbCommand dbCommand = DataAccessWrapper.GetStoredProcCommand(strSP))
                    {
                        dbCommand.CommandTimeout = 0;
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.TopicID, DbType.Int32, TopicID);

                        if (FromDate != DateTime.MinValue)
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.FromDate, DbType.DateTime, FromDate); }

                        if (ToDate != DateTime.MinValue)
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.ToDate, DbType.DateTime, ToDate); }

                        if (BaseDate != DateTime.MinValue)
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.BaseDate, DbType.DateTime, BaseDate); }

                        if (!string.IsNullOrEmpty(Hide_Denominator))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Hide_Denominator, DbType.String, Hide_Denominator); }

                        if (!string.IsNullOrEmpty(ShowPercentage))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.ShowPercentage, DbType.String, ShowPercentage); }


                        #region DataSet
                        using (DataSet ds = DataAccessWrapper.ExecuteDataSet(dbCommand))
                        {
                            if (ds != null && ds.Tables.Count > 0)
                            {
                                dt = ds;
                            }
                        }

                        DataAccessWrapper.Dispose();
                        #endregion
                    }
                }

            }
            catch (Exception ex)
            {

                throw ex;
            }

            return dt;
        }

        public DataSet FetchLanding_YouTube_Optimized_Data_By_Parameter(Int32 TopicID, DateTime FromDate, DateTime ToDate, DateTime BaseDate, string Parameter, string Hide_Denominator, string ShowPercentage)
        {
            DataSet dt = new DataSet();
            try
            {
                string strSP = string.Empty;
                if (!string.IsNullOrEmpty(Parameter))
                {
                    strSP = DataBaseConstants.USP_API_SentryV2_YouTube_FL_Optimized_ + Parameter;
                }

                using (DataAccessWrapper DataAccessWrapper = new DataAccessWrapper(DataBaseConstants.SahadevConnectionString))
                {
                    using (DbCommand dbCommand = DataAccessWrapper.GetStoredProcCommand(strSP))
                    {
                        dbCommand.CommandTimeout = 0;
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.TopicID, DbType.Int32, TopicID);

                        if (FromDate != DateTime.MinValue)
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.FromDate, DbType.DateTime, FromDate); }

                        if (ToDate != DateTime.MinValue)
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.ToDate, DbType.DateTime, ToDate); }

                        if (BaseDate != DateTime.MinValue)
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.BaseDate, DbType.DateTime, BaseDate); }

                        if (!string.IsNullOrEmpty(Hide_Denominator))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Hide_Denominator, DbType.String, Hide_Denominator); }

                        if (!string.IsNullOrEmpty(ShowPercentage))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.ShowPercentage, DbType.String, ShowPercentage); }


                        #region DataSet
                        using (DataSet ds = DataAccessWrapper.ExecuteDataSet(dbCommand))
                        {
                            if (ds != null && ds.Tables.Count > 0)
                            {
                                dt = ds;
                            }
                        }

                        DataAccessWrapper.Dispose();
                        #endregion
                    }
                }

            }
            catch (Exception ex)
            {

                throw ex;
            }

            return dt;
        }

        //Heading Stats is common for all platforms 

        public DataSet FetchLanding_Optimized_HeadlingStats(Int32 TopicID, DateTime FromDate, DateTime ToDate, DateTime BaseDate, string Hide_Denominator, string ShowPercentage, string strDevice)
        {
            DataSet dt = new DataSet();
            try
            {

                using (DataAccessWrapper DataAccessWrapper = new DataAccessWrapper(DataBaseConstants.SahadevConnectionString))
                {
                    using (DbCommand dbCommand = DataAccessWrapper.GetStoredProcCommand(DataBaseConstants.USP_API_SentryV2_FetchLanding_Optimized_Heading_stats))
                    {
                        dbCommand.CommandTimeout = 0;
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.TopicID, DbType.Int32, TopicID);

                        if (FromDate != DateTime.MinValue)
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.FromDate, DbType.DateTime, FromDate); }

                        if (ToDate != DateTime.MinValue)
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.ToDate, DbType.DateTime, ToDate); }

                        if (BaseDate != DateTime.MinValue)
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.BaseDate, DbType.DateTime, BaseDate); }

                        if (!string.IsNullOrEmpty(Hide_Denominator))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Hide_Denominator, DbType.String, Hide_Denominator); }

                        if (!string.IsNullOrEmpty(ShowPercentage))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.ShowPercentage, DbType.String, ShowPercentage); }



                        #region DataSet
                        using (DataSet ds = DataAccessWrapper.ExecuteDataSet(dbCommand))
                        {
                            if (ds != null && ds.Tables.Count > 0)
                            {
                                dt = ds;
                            }
                        }
                        #endregion
                    }
                }

            }
            catch (Exception ex)
            {

                throw ex;
            }

            return dt;
        }

        #region Download Data

        public DataSet ArticleOnline_DownloadData(Int32 TopicID, DateTime FromDate, DateTime ToDate, string Sentiment, string Publication_Domain,
            string Publication_Type, string Publication_DA, string Publication_Traffic, string Publication_ImpactScore, string SortBy,
            string SortOrder, string SearchText, string Mention_Type, string Client_Mention, Int32 UserID, string Headline_Sentiment, string Article_Type, string Exclude_By_Text, string DataTag, string TML_Publication_Domain, string TML_Author, Int32 TagID, string SearchText_In)
        {
            DataSet dataset = new DataSet();
            try
            {

                using (DataAccessWrapper DataAccessWrapper = new DataAccessWrapper(DataBaseConstants.SahadevConnectionString))
                {
                    using (DbCommand dbCommand = DataAccessWrapper.GetStoredProcCommand(DataBaseConstants.USP_DownloadData_Online))
                    {
                        dbCommand.CommandTimeout = 0;
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.TopicID, DbType.Int32, TopicID);
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.TagID, DbType.Int32, TagID);

                        if (FromDate != DateTime.MinValue)
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.FromDate, DbType.DateTime, FromDate); }

                        if (ToDate != DateTime.MinValue)
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.ToDate, DbType.DateTime, ToDate); }

                        if (!string.IsNullOrEmpty(Sentiment))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Sentiment, DbType.String, Sentiment); }

                        if (!string.IsNullOrEmpty(Publication_Domain))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Publication_Domain, DbType.String, Publication_Domain); }

                        if (!string.IsNullOrEmpty(Publication_Type))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Publication_Type, DbType.String, Publication_Type); }

                        if (!string.IsNullOrEmpty(Publication_DA))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Publication_DA, DbType.String, Publication_DA); }

                        if (!string.IsNullOrEmpty(Publication_Traffic))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Publication_Traffic, DbType.String, Publication_Traffic); }

                        if (!string.IsNullOrEmpty(Publication_ImpactScore))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Publication_ImpactScore, DbType.String, Publication_ImpactScore); }

                        if (!string.IsNullOrEmpty(SortBy))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.SortBy, DbType.String, SortBy); }

                        if (!string.IsNullOrEmpty(SortOrder))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.SortOrder, DbType.String, SortOrder); }

                        if (!string.IsNullOrEmpty(SearchText))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.SearchText, DbType.String, SearchText); }

                        if (!string.IsNullOrEmpty(Mention_Type))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Mention_Type, DbType.String, Mention_Type); }

                        if (!string.IsNullOrEmpty(Client_Mention))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Client_Mention, DbType.String, Client_Mention); }

                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.UserID, DbType.Int32, UserID);

                        if (!string.IsNullOrEmpty(Headline_Sentiment))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Headline_Sentiment, DbType.String, Headline_Sentiment); }

                        if (!string.IsNullOrEmpty(Article_Type))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Article_Type, DbType.String, Article_Type); }

                        if (!string.IsNullOrEmpty(Exclude_By_Text))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Exclude_By_Text, DbType.String, Exclude_By_Text); }

                        if (!string.IsNullOrEmpty(DataTag))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.DataTag, DbType.String, DataTag); }

                        if (!string.IsNullOrEmpty(TML_Publication_Domain))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.TML_Publication_Domain, DbType.String, TML_Publication_Domain); }

                        if (!string.IsNullOrEmpty(TML_Author))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.TML_Author, DbType.String, TML_Author); }

                        if (!string.IsNullOrEmpty(SearchText_In))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.SearchText_In, DbType.String, SearchText_In); }

                        #region DataSet
                        using (DataSet ds = DataAccessWrapper.ExecuteDataSet(dbCommand))
                        {
                            if (ds != null && ds.Tables.Count > 0)
                            {
                                dataset = ds;
                            }
                        }
                        #endregion
                    }
                }

            }
            catch (Exception ex)
            {

                throw ex;
            }

            return dataset;
        }

        public DataSet ArticlePrint_DownloadData(Int32 TopicID, DateTime FromDate, DateTime ToDate, string Sentiment, string Publication_Name, string Publication_Edition,
            string Publication_Type, string Publication_Circulation, string Publication_ImpactScore, string SortBy,
            string SortOrder, string SearchText, string Mention_Type, string Client_Mention, Int32 UserID, string Headline_Sentiment, string Article_Type, string Author, string Exclude_By_Text, string Language, string DataTag, string TML_Publication_Name, string TML_Author, Int32 TagID, string SearchText_In)
        {
            DataSet dt = new DataSet();
            try
            {

                using (DataAccessWrapper DataAccessWrapper = new DataAccessWrapper(DataBaseConstants.SahadevConnectionString))
                {
                    using (DbCommand dbCommand = DataAccessWrapper.GetStoredProcCommand(DataBaseConstants.USP_DownloadData_Print))
                    {
                        dbCommand.CommandTimeout = 0;
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.TopicID, DbType.Int32, TopicID);
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.TagID, DbType.Int32, TagID);

                        if (FromDate != DateTime.MinValue)
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.FromDate, DbType.DateTime, FromDate); }

                        if (ToDate != DateTime.MinValue)
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.ToDate, DbType.DateTime, ToDate); }

                        if (!string.IsNullOrEmpty(Sentiment))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Sentiment, DbType.String, Sentiment); }

                        if (!string.IsNullOrEmpty(Publication_Name))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Publication_Name, DbType.String, Publication_Name); }

                        if (!string.IsNullOrEmpty(Publication_Type))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Publication_Type, DbType.String, Publication_Type); }

                        if (!string.IsNullOrEmpty(Publication_Edition))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Publication_Edition, DbType.String, Publication_Edition); }

                        if (!string.IsNullOrEmpty(Publication_Circulation))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Publication_Circulation, DbType.String, Publication_Circulation); }

                        if (!string.IsNullOrEmpty(Publication_ImpactScore))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Publication_ImpactScore, DbType.String, Publication_ImpactScore); }

                        if (!string.IsNullOrEmpty(SortBy))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.SortBy, DbType.String, SortBy); }

                        if (!string.IsNullOrEmpty(SortOrder))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.SortOrder, DbType.String, SortOrder); }

                        if (!string.IsNullOrEmpty(SearchText))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.SearchText, DbType.String, SearchText); }

                        if (!string.IsNullOrEmpty(Mention_Type))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Mention_Type, DbType.String, Mention_Type); }

                        if (!string.IsNullOrEmpty(Client_Mention))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Client_Mention, DbType.String, Client_Mention); }

                        if (!string.IsNullOrEmpty(Headline_Sentiment))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Headline_Sentiment, DbType.String, Headline_Sentiment); }

                        if (!string.IsNullOrEmpty(Article_Type))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Article_Type, DbType.String, Article_Type); }

                        if (!string.IsNullOrEmpty(Author))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Author, DbType.String, Author); }

                        if (!string.IsNullOrEmpty(Exclude_By_Text))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Exclude_By_Text, DbType.String, Exclude_By_Text); }

                        if (!string.IsNullOrEmpty(Language))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Language, DbType.String, Language); }

                        if (!string.IsNullOrEmpty(DataTag))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.DataTag, DbType.String, DataTag); }

                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.UserID, DbType.Int32, UserID);

                        if (!string.IsNullOrEmpty(TML_Publication_Name))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.TML_Publication_Name, DbType.String, TML_Publication_Name); }

                        if (!string.IsNullOrEmpty(TML_Author))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.TML_Author, DbType.String, TML_Author); }

                        if (!string.IsNullOrEmpty(SearchText_In))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.SearchText_In, DbType.String, SearchText_In); }

                        #region DataSet
                        using (DataSet ds = DataAccessWrapper.ExecuteDataSet(dbCommand))
                        {
                            if (ds != null && ds.Tables.Count > 0)
                            {
                                dt = ds;
                            }
                        }
                        #endregion
                    }
                }

            }
            catch (Exception ex)
            {

                throw ex;
            }

            return dt;
        }

        public DataSet Twitter_DownloadData(Int32 TopicID, DateTime BaseDate, DateTime FromDate, DateTime ToDate, string Sentiment, string Mentioned_Hashtag,
            string Mentioned_Handle, string Media_Type, string Profile_Category, string SortBy, string SortOrder, string Mention_Type, string Profile_Name,
            string Profile_Handle, string Profile_Followerscount, string Participant_Type, string Profile_VerifiedType, Int32 UserID, string Tonality, string Eng_Type, string SearchText, string Exclude_By_Text, string DataTag, string tml_handle)
        {
            DataSet dt = new DataSet();
            try
            {
                using (DataAccessWrapper DataAccessWrapper = new DataAccessWrapper(DataBaseConstants.SahadevConnectionString))
                {
                    using (DbCommand dbCommand = DataAccessWrapper.GetStoredProcCommand(DataBaseConstants.USP_DownloadData_Twitter))
                    {
                        dbCommand.CommandTimeout = 0;
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.TopicID, DbType.Int32, TopicID);

                        if (BaseDate != DateTime.MinValue)
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.BaseDate, DbType.DateTime, BaseDate); }

                        if (FromDate != DateTime.MinValue)
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.FromDate, DbType.DateTime, FromDate); }

                        if (ToDate != DateTime.MinValue)
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.ToDate, DbType.DateTime, ToDate); }

                        if (!string.IsNullOrEmpty(Sentiment))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Sentiment, DbType.String, Sentiment); }

                        if (!string.IsNullOrEmpty(Mentioned_Hashtag))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Mentioned_Hashtag, DbType.String, Mentioned_Hashtag); }

                        if (!string.IsNullOrEmpty(Mentioned_Handle))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Mentioned_Handle, DbType.String, Mentioned_Handle); }

                        if (!string.IsNullOrEmpty(Media_Type))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Media_Type, DbType.String, Media_Type); }

                        if (!string.IsNullOrEmpty(Profile_Category))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Profile_Category, DbType.String, Profile_Category); }

                        if (!string.IsNullOrEmpty(SortBy))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.SortBy, DbType.String, SortBy); }

                        if (!string.IsNullOrEmpty(SortOrder))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.SortOrder, DbType.String, SortOrder); }

                        if (!string.IsNullOrEmpty(Mention_Type))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Mention_Type, DbType.String, Mention_Type); }

                        if (!string.IsNullOrEmpty(Profile_Name))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Profile_Name, DbType.String, Profile_Name); }

                        if (!string.IsNullOrEmpty(Profile_Handle))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Profile_Handle, DbType.String, Profile_Handle); }

                        if (!string.IsNullOrEmpty(Participant_Type))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Participant_Type, DbType.String, Participant_Type); }

                        if (!string.IsNullOrEmpty(Profile_Followerscount))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Profile_Followerscount, DbType.String, Profile_Followerscount); }

                        if (!string.IsNullOrEmpty(Profile_VerifiedType))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Profile_VerifiedType, DbType.String, Profile_VerifiedType); }

                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.UserID, DbType.Int32, UserID);

                        if (!string.IsNullOrEmpty(Tonality))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Tonality, DbType.String, Tonality); }

                        if (!string.IsNullOrEmpty(Eng_Type))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Eng_Type, DbType.String, Eng_Type); }

                        if (!string.IsNullOrEmpty(SearchText))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.SearchText, DbType.String, SearchText); }

                        if (!string.IsNullOrEmpty(Exclude_By_Text))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Exclude_By_Text, DbType.String, Exclude_By_Text); }

                        if (!string.IsNullOrEmpty(DataTag))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.DataTag, DbType.String, DataTag); }

                        if (!string.IsNullOrEmpty(tml_handle))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.TML_Handle, DbType.String, tml_handle); }

                        #region DataSet
                        using (DataSet ds = DataAccessWrapper.ExecuteDataSet(dbCommand))
                        {
                            if (ds != null && ds.Tables.Count > 0)
                            {
                                dt = ds;
                            }
                        }
                        #endregion
                    }
                }

            }
            catch (Exception ex)
            {

                throw ex;
            }

            return dt;
        }

        public DataSet YouTube_DownloadData(Int32 TopicID, DateTime BaseDate, DateTime FromDate, DateTime ToDate, string VideoTags,
            string ChannelHandle, string ChannelName, string Sentiment, string Tonality, string ChannelCategory,
            string Mention_Type, string ProfileVerifiedType, string Participant_Type, string Channel_SubscriberCount, string DurationInMin, string VideoType,
            string DiscourseCategory, string Mentioned_Topics, string Publication_ImpactScore, string Mentioned_Locations,
            string SortBy, string SortOrder, Int32 UserID, string People_Brand_Mentions, string Language, string SearchText, string Exclude_By_Text, string DataTag, string tml_channel, string SearchText_In)
        {
            DataSet dt = new DataSet();
            try
            {
                using (DataAccessWrapper DataAccessWrapper = new DataAccessWrapper(DataBaseConstants.SahadevConnectionString))
                {
                    using (DbCommand dbCommand = DataAccessWrapper.GetStoredProcCommand(DataBaseConstants.USP_DownloadData_YouTube))
                    {
                        dbCommand.CommandTimeout = 0;

                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.TopicID, DbType.Int32, TopicID);

                        if (BaseDate != DateTime.MinValue)
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.BaseDate, DbType.DateTime, BaseDate); }

                        if (FromDate != DateTime.MinValue)
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.FromDate, DbType.DateTime, FromDate); }

                        if (ToDate != DateTime.MinValue)
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.ToDate, DbType.DateTime, ToDate); }

                        if (!string.IsNullOrEmpty(VideoTags))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Video_Tags, DbType.String, VideoTags); }

                        if (!string.IsNullOrEmpty(ChannelHandle))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Channel_Handle, DbType.String, ChannelHandle); }

                        if (!string.IsNullOrEmpty(ChannelName))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Channel_Name, DbType.String, ChannelName); }

                        if (!string.IsNullOrEmpty(Sentiment))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Sentiment, DbType.String, Sentiment); }

                        if (!string.IsNullOrEmpty(Tonality))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Tonality, DbType.String, Tonality); }

                        if (!string.IsNullOrEmpty(ChannelCategory))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Channel_Category, DbType.String, ChannelCategory); }

                        if (!string.IsNullOrEmpty(Mention_Type))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Mention_Type, DbType.String, Mention_Type); }

                        if (!string.IsNullOrEmpty(ProfileVerifiedType))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Profile_VerifiedType, DbType.String, ProfileVerifiedType); }

                        if (!string.IsNullOrEmpty(Participant_Type))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Participant_Type, DbType.String, Participant_Type); }

                        if (!string.IsNullOrEmpty(Channel_SubscriberCount))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Channel_Subscriber_Count, DbType.String, Channel_SubscriberCount); }

                        if (!string.IsNullOrEmpty(DurationInMin))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Duration_In_Min, DbType.String, DurationInMin); }

                        if (!string.IsNullOrEmpty(VideoType))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Video_Type, DbType.String, VideoType); }

                        if (!string.IsNullOrEmpty(DiscourseCategory))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Discourse_Category, DbType.String, DiscourseCategory); }

                        if (!string.IsNullOrEmpty(Mentioned_Topics))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Mentioned_Topics, DbType.String, Mentioned_Topics); }

                        if (!string.IsNullOrEmpty(Publication_ImpactScore))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Publication_ImpactScore, DbType.String, Publication_ImpactScore); }

                        if (!string.IsNullOrEmpty(Mentioned_Locations))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Mentioned_Locations, DbType.String, Mentioned_Locations); }

                        if (!string.IsNullOrEmpty(SortBy))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.SortBy, DbType.String, SortBy); }

                        if (!string.IsNullOrEmpty(SortOrder))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.SortOrder, DbType.String, SortOrder); }

                        if (!string.IsNullOrEmpty(People_Brand_Mentions))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.People_Brand_Mentions, DbType.String, People_Brand_Mentions); }

                        if (!string.IsNullOrEmpty(Language))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Language, DbType.String, Language); }

                        if (!string.IsNullOrEmpty(SearchText))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.SearchText, DbType.String, SearchText); }

                        if (!string.IsNullOrEmpty(Exclude_By_Text))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Exclude_By_Text, DbType.String, Exclude_By_Text); }

                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.UserID, DbType.Int32, UserID);

                        if (!string.IsNullOrEmpty(DataTag))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.DataTag, DbType.String, DataTag); }

                        if (!string.IsNullOrEmpty(tml_channel))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.TML_Channel, DbType.String, tml_channel); }

                        if (!string.IsNullOrEmpty(SearchText_In))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.SearchText_In, DbType.String, SearchText_In); }

                        #region DataSet
                        using (DataSet ds = DataAccessWrapper.ExecuteDataSet(dbCommand))
                        {
                            if (ds != null && ds.Tables.Count > 0)
                            {
                                dt = ds;
                            }
                        }
                        #endregion
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return dt;
        }

        #endregion

        #region List Pagination

        public DataSet ArticleOnline_FetchList_Pagination(Int32 TopicID, DateTime FromDate, DateTime ToDate, string Sentiment, string Publication_Domain,
            string Publication_Type, string Publication_DA, string Publication_Traffic, string Publication_ImpactScore, string SortBy,
            string SortOrder, string SearchText, string Mention_Type, string Client_Mention, Int32 UserID, string Headline_Sentiment, string Article_Type, string Exclude_By_Text, int Last_Seen_ID, int Page_Size, string DataTag, int show_ids, string TML_Publication_Domain, string TML_Author, Int32 TagID, string SearchText_In)
        {
            DataSet dt = new DataSet();
            try
            {

                using (DataAccessWrapper DataAccessWrapper = new DataAccessWrapper(DataBaseConstants.SahadevConnectionString))
                {
                    using (DbCommand dbCommand = DataAccessWrapper.GetStoredProcCommand(DataBaseConstants.USP_API_SentryV2_ArticleOnline_FetchList_Pagination))
                    {
                        dbCommand.CommandTimeout = 0;
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.TopicID, DbType.Int32, TopicID);
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.TagID, DbType.Int32, TagID);

                        if (FromDate != DateTime.MinValue)
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.FromDate, DbType.DateTime, FromDate); }

                        if (ToDate != DateTime.MinValue)
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.ToDate, DbType.DateTime, ToDate); }

                        if (!string.IsNullOrEmpty(Sentiment))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Sentiment, DbType.String, Sentiment); }

                        if (!string.IsNullOrEmpty(Publication_Domain))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Publication_Domain, DbType.String, Publication_Domain); }

                        if (!string.IsNullOrEmpty(Publication_Type))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Publication_Type, DbType.String, Publication_Type); }

                        if (!string.IsNullOrEmpty(Publication_DA))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Publication_DA, DbType.String, Publication_DA); }

                        if (!string.IsNullOrEmpty(Publication_Traffic))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Publication_Traffic, DbType.String, Publication_Traffic); }

                        if (!string.IsNullOrEmpty(Publication_ImpactScore))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Publication_ImpactScore, DbType.String, Publication_ImpactScore); }

                        if (!string.IsNullOrEmpty(SortBy))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.SortBy, DbType.String, SortBy); }

                        if (!string.IsNullOrEmpty(SortOrder))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.SortOrder, DbType.String, SortOrder); }

                        if (!string.IsNullOrEmpty(SearchText))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.SearchText, DbType.String, SearchText); }

                        if (!string.IsNullOrEmpty(Mention_Type))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Mention_Type, DbType.String, Mention_Type); }

                        if (!string.IsNullOrEmpty(Client_Mention))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Client_Mention, DbType.String, Client_Mention); }

                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.UserID, DbType.Int32, UserID);

                        if (!string.IsNullOrEmpty(Headline_Sentiment))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Headline_Sentiment, DbType.String, Headline_Sentiment); }

                        if (!string.IsNullOrEmpty(Article_Type))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Article_Type, DbType.String, Article_Type); }

                        if (!string.IsNullOrEmpty(Exclude_By_Text))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Exclude_By_Text, DbType.String, Exclude_By_Text); }

                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Last_Seen_ID, DbType.Int32, Last_Seen_ID);

                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Page_Size, DbType.Int32, Page_Size);

                        if (!string.IsNullOrEmpty(DataTag))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.DataTag, DbType.String, DataTag); }

                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Show_IDs, DbType.Int32, show_ids);

                        if (!string.IsNullOrEmpty(TML_Publication_Domain))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.TML_Publication_Domain, DbType.String, TML_Publication_Domain); }

                        if (!string.IsNullOrEmpty(TML_Author))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.TML_Author, DbType.String, TML_Author); }

                        if (!string.IsNullOrEmpty(SearchText_In))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.SearchText_In, DbType.String, SearchText_In); }

                        #region DataSet
                        using (DataSet ds = DataAccessWrapper.ExecuteDataSet(dbCommand))
                        {
                            if (ds != null && ds.Tables.Count > 0)
                            {
                                dt = ds;
                            }
                        }

                        DataAccessWrapper.Dispose();
                        #endregion
                    }
                }

            }
            catch (Exception ex)
            {

                throw ex;
            }

            return dt;
        }

        public DataSet ArticlePrint_FetchList_Pagination(Int32 TopicID, DateTime FromDate, DateTime ToDate, string Sentiment, string Publication_Name, string Publication_Edition,
            string Publication_Type, string Publication_Circulation, string Publication_ImpactScore, string SortBy,
            string SortOrder, string SearchText, string Mention_Type, string Client_Mention, Int32 UserID, string Headline_Sentiment, string Article_Type, string Author, string Exclude_By_Text, string Language, int Last_Seen_ID, int Page_Size, string DataTag, int show_ids, string TML_Publication_Name, string TML_Author, Int32 TagID, string SearchText_In)
        {
            DataSet ds = new DataSet();
            try
            {

                using (DataAccessWrapper DataAccessWrapper = new DataAccessWrapper(DataBaseConstants.SahadevConnectionString))
                {
                    using (DbCommand dbCommand = DataAccessWrapper.GetStoredProcCommand(DataBaseConstants.USP_API_SentryV2_ArticlePrint_FetchList_Pagination))
                    {
                        dbCommand.CommandTimeout = 0;
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.TopicID, DbType.Int32, TopicID);
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.TagID, DbType.Int32, TagID);

                        if (FromDate != DateTime.MinValue)
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.FromDate, DbType.DateTime, FromDate); }

                        if (ToDate != DateTime.MinValue)
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.ToDate, DbType.DateTime, ToDate); }

                        if (!string.IsNullOrEmpty(Sentiment))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Sentiment, DbType.String, Sentiment); }

                        if (!string.IsNullOrEmpty(Publication_Name))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Publication_Name, DbType.String, Publication_Name); }

                        if (!string.IsNullOrEmpty(Publication_Type))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Publication_Type, DbType.String, Publication_Type); }

                        if (!string.IsNullOrEmpty(Publication_Edition))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Publication_Edition, DbType.String, Publication_Edition); }

                        if (!string.IsNullOrEmpty(Publication_Circulation))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Publication_Circulation, DbType.String, Publication_Circulation); }

                        if (!string.IsNullOrEmpty(Publication_ImpactScore))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Publication_ImpactScore, DbType.String, Publication_ImpactScore); }

                        if (!string.IsNullOrEmpty(SortBy))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.SortBy, DbType.String, SortBy); }

                        if (!string.IsNullOrEmpty(SortOrder))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.SortOrder, DbType.String, SortOrder); }

                        if (!string.IsNullOrEmpty(SearchText))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.SearchText, DbType.String, SearchText); }

                        if (!string.IsNullOrEmpty(Mention_Type))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Mention_Type, DbType.String, Mention_Type); }

                        if (!string.IsNullOrEmpty(Client_Mention))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Client_Mention, DbType.String, Client_Mention); }

                        if (!string.IsNullOrEmpty(Headline_Sentiment))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Headline_Sentiment, DbType.String, Headline_Sentiment); }

                        if (!string.IsNullOrEmpty(Article_Type))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Article_Type, DbType.String, Article_Type); }

                        if (!string.IsNullOrEmpty(Author))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Author, DbType.String, Author); }

                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.UserID, DbType.Int32, UserID);

                        if (!string.IsNullOrEmpty(Language))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Language, DbType.String, Language); }

                        if (!string.IsNullOrEmpty(Exclude_By_Text))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Exclude_By_Text, DbType.String, Exclude_By_Text); }

                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Last_Seen_ID, DbType.Int32, Last_Seen_ID);

                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Page_Size, DbType.Int32, Page_Size);

                        if (!string.IsNullOrEmpty(DataTag))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.DataTag, DbType.String, DataTag); }

                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Show_IDs, DbType.Int32, show_ids);

                        if (!string.IsNullOrEmpty(TML_Publication_Name))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.TML_Publication_Name, DbType.String, TML_Publication_Name); }

                        if (!string.IsNullOrEmpty(TML_Author))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.TML_Author, DbType.String, TML_Author); }

                        if (!string.IsNullOrEmpty(SearchText_In))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.SearchText_In, DbType.String, SearchText_In); }

                        #region DataSet
                        ds = DataAccessWrapper.ExecuteDataSet(dbCommand);
                        //using (DataSet ds = DataAccessWrapper.ExecuteDataSet(dbCommand))
                        //{
                        //    if (ds != null && ds.Tables.Count > 0)
                        //    {
                        //        dt = ds.Tables[0];
                        //    }
                        //}
                        #endregion
                    }
                }

            }
            catch (Exception ex)
            {

                throw ex;
            }

            return ds;
        }

        public DataSet Twitter_FetchList_Pagination(Int32 TopicID, DateTime BaseDate, DateTime FromDate, DateTime ToDate, string Sentiment, string Mentioned_Hashtag,
            string Mentioned_Handle, string Media_Type, string Profile_Category, string SortBy, string SortOrder, string Mention_Type, string Profile_Name,
            string Profile_Handle, string Profile_Followerscount, string Participant_Type, string Profile_VerifiedType, Int32 UserID, string Tonality, string Eng_Type, string SearchText, string Exclude_By_Text, int Last_Seen_ID, int Page_Size, string DataTag, int show_ids, string tml_handle)
        {
            DataSet ds = new DataSet();
            try
            {
                using (DataAccessWrapper DataAccessWrapper = new DataAccessWrapper(DataBaseConstants.SahadevConnectionString))
                {
                    using (DbCommand dbCommand = DataAccessWrapper.GetStoredProcCommand(DataBaseConstants.USP_API_SentryV2_Twitter_FetchList_Pagination))
                    {
                        dbCommand.CommandTimeout = 0;
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.TopicID, DbType.Int32, TopicID);

                        if (BaseDate != DateTime.MinValue)
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.BaseDate, DbType.DateTime, BaseDate); }

                        if (FromDate != DateTime.MinValue)
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.FromDate, DbType.DateTime, FromDate); }

                        if (ToDate != DateTime.MinValue)
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.ToDate, DbType.DateTime, ToDate); }

                        if (!string.IsNullOrEmpty(Sentiment))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Sentiment, DbType.String, Sentiment); }

                        if (!string.IsNullOrEmpty(Mentioned_Hashtag))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Mentioned_Hashtag, DbType.String, Mentioned_Hashtag); }

                        if (!string.IsNullOrEmpty(Mentioned_Handle))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Mentioned_Handle, DbType.String, Mentioned_Handle); }

                        if (!string.IsNullOrEmpty(Media_Type))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Media_Type, DbType.String, Media_Type); }

                        if (!string.IsNullOrEmpty(Profile_Category))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Profile_Category, DbType.String, Profile_Category); }

                        if (!string.IsNullOrEmpty(SortBy))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.SortBy, DbType.String, SortBy); }

                        if (!string.IsNullOrEmpty(SortOrder))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.SortOrder, DbType.String, SortOrder); }

                        if (!string.IsNullOrEmpty(Mention_Type))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Mention_Type, DbType.String, Mention_Type); }

                        if (!string.IsNullOrEmpty(Profile_Name))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Profile_Name, DbType.String, Profile_Name); }

                        if (!string.IsNullOrEmpty(Profile_Handle))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Profile_Handle, DbType.String, Profile_Handle); }

                        if (!string.IsNullOrEmpty(Participant_Type))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Participant_Type, DbType.String, Participant_Type); }

                        if (!string.IsNullOrEmpty(Profile_Followerscount))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Profile_Followerscount, DbType.String, Profile_Followerscount); }

                        if (!string.IsNullOrEmpty(Profile_VerifiedType))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Profile_VerifiedType, DbType.String, Profile_VerifiedType); }

                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.UserID, DbType.Int32, UserID);

                        if (!string.IsNullOrEmpty(Tonality))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Tonality, DbType.String, Tonality); }

                        if (!string.IsNullOrEmpty(Eng_Type))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Eng_Type, DbType.String, Eng_Type); }

                        if (!string.IsNullOrEmpty(SearchText))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.SearchText, DbType.String, SearchText); }

                        if (!string.IsNullOrEmpty(Exclude_By_Text))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Exclude_By_Text, DbType.String, Exclude_By_Text); }

                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Last_Seen_ID, DbType.Int32, Last_Seen_ID);

                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Page_Size, DbType.Int32, Page_Size);

                        if (!string.IsNullOrEmpty(DataTag))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.DataTag, DbType.String, DataTag); }

                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Show_IDs, DbType.Int32, show_ids);

                        if (!string.IsNullOrEmpty(tml_handle))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.TML_Handle, DbType.String, tml_handle); }

                        #region DataSet
                        ds = DataAccessWrapper.ExecuteDataSet(dbCommand);
                        //using (DataSet ds = DataAccessWrapper.ExecuteDataSet(dbCommand))
                        //{
                        //    if (ds != null && ds.Tables.Count > 0)
                        //    {
                        //        dt = ds.Tables[0];
                        //    }
                        //}
                        #endregion
                    }
                }

            }
            catch (Exception ex)
            {

                throw ex;
            }

            return ds;
        }

        public DataSet YouTube_FetchList_Pagination(Int32 TopicID, DateTime BaseDate, DateTime FromDate, DateTime ToDate, string VideoTags,
            string ChannelHandle, string ChannelName, string Sentiment, string Tonality, string ChannelCategory,
            string Mention_Type, string ProfileVerifiedType, string Participant_Type, string Channel_SubscriberCount, string DurationInMin, string VideoType,
            string DiscourseCategory, string Mentioned_Topics, string Publication_ImpactScore, string Mentioned_Locations,
            string SortBy, string SortOrder, Int32 UserID, string People_Brand_Mentions, string Language, string SearchText, string Exclude_By_Text, int Last_Seen_ID, int Page_Size, string DataTag, int show_ids, string tml_channel, string SearchText_In)
        {
            DataSet ds = new DataSet();

            try
            {
                using (DataAccessWrapper DataAccessWrapper = new DataAccessWrapper(DataBaseConstants.SahadevConnectionString))
                {
                    using (DbCommand dbCommand = DataAccessWrapper.GetStoredProcCommand(DataBaseConstants.USP_API_SentryV2_YouTube_FetchList_Pagination))
                    {
                        dbCommand.CommandTimeout = 0;

                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.TopicID, DbType.Int32, TopicID);

                        if (BaseDate != DateTime.MinValue)
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.BaseDate, DbType.DateTime, BaseDate); }

                        if (FromDate != DateTime.MinValue)
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.FromDate, DbType.DateTime, FromDate); }

                        if (ToDate != DateTime.MinValue)
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.ToDate, DbType.DateTime, ToDate); }

                        if (!string.IsNullOrEmpty(VideoTags))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Video_Tags, DbType.String, VideoTags); }

                        if (!string.IsNullOrEmpty(ChannelHandle))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Channel_Handle, DbType.String, ChannelHandle); }

                        if (!string.IsNullOrEmpty(ChannelName))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Channel_Name, DbType.String, ChannelName); }

                        if (!string.IsNullOrEmpty(Sentiment))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Sentiment, DbType.String, Sentiment); }

                        if (!string.IsNullOrEmpty(Tonality))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Tonality, DbType.String, Tonality); }

                        if (!string.IsNullOrEmpty(ChannelCategory))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Channel_Category, DbType.String, ChannelCategory); }

                        if (!string.IsNullOrEmpty(Mention_Type))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Mention_Type, DbType.String, Mention_Type); }

                        if (!string.IsNullOrEmpty(ProfileVerifiedType))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Profile_VerifiedType, DbType.String, ProfileVerifiedType); }

                        if (!string.IsNullOrEmpty(Participant_Type))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Participant_Type, DbType.String, Participant_Type); }

                        if (!string.IsNullOrEmpty(Channel_SubscriberCount))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Channel_Subscriber_Count, DbType.String, Channel_SubscriberCount); }

                        if (!string.IsNullOrEmpty(DurationInMin))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Duration_In_Min, DbType.String, DurationInMin); }

                        if (!string.IsNullOrEmpty(VideoType))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Video_Type, DbType.String, VideoType); }

                        if (!string.IsNullOrEmpty(DiscourseCategory))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Discourse_Category, DbType.String, DiscourseCategory); }

                        if (!string.IsNullOrEmpty(Mentioned_Topics))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Mentioned_Topics, DbType.String, Mentioned_Topics); }

                        if (!string.IsNullOrEmpty(Publication_ImpactScore))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Publication_ImpactScore, DbType.String, Publication_ImpactScore); }

                        if (!string.IsNullOrEmpty(Mentioned_Locations))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Mentioned_Locations, DbType.String, Mentioned_Locations); }

                        if (!string.IsNullOrEmpty(SortBy))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.SortBy, DbType.String, SortBy); }

                        if (!string.IsNullOrEmpty(SortOrder))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.SortOrder, DbType.String, SortOrder); }

                        if (!string.IsNullOrEmpty(People_Brand_Mentions))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.People_Brand_Mentions, DbType.String, People_Brand_Mentions); }

                        if (!string.IsNullOrEmpty(Language))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Language, DbType.String, Language); }

                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.UserID, DbType.Int32, UserID);

                        if (!string.IsNullOrEmpty(SearchText))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.SearchText, DbType.String, SearchText); }

                        if (!string.IsNullOrEmpty(Exclude_By_Text))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Exclude_By_Text, DbType.String, Exclude_By_Text); }

                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Last_Seen_ID, DbType.Int32, Last_Seen_ID);

                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Page_Size, DbType.Int32, Page_Size);

                        if (!string.IsNullOrEmpty(DataTag))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.DataTag, DbType.String, DataTag); }

                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Show_IDs, DbType.Int32, show_ids);

                        if (!string.IsNullOrEmpty(tml_channel))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.TML_Channel, DbType.String, tml_channel); }

                        if (!string.IsNullOrEmpty(SearchText_In))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.SearchText_In, DbType.String, SearchText_In); }

                        #region DataSet

                        ds = DataAccessWrapper.ExecuteDataSet(dbCommand);

                        #endregion
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return ds;
        }

        public DataSet Reddit_FetchList_Pagination(Int32 UserID, Int32 TopicID, DateTime BaseDate, DateTime FromDate, DateTime ToDate, string Subreddit, string Subreddit_Name, string Sentiment,
            string Tonality, string Subreddit_Subscriber_Count, string Discourse_Category, string Mentioned_Topics, string People_Brand_Mentions, string SubredditCategory, bool? IsTop1Percent, string SortBy,
            string SortOrder, string SearchText, string Exclude_By_Text, int Last_Seen_ID, int Page_Size, string DataTag, bool Show_IDs, string TML_Subreddit, string HandleTextSearch)
        {
            DataSet ds = new DataSet();

            try
            {
                using (DataAccessWrapper DataAccessWrapper = new DataAccessWrapper(DataBaseConstants.SahadevConnectionString))
                {
                    using (DbCommand dbCommand = DataAccessWrapper.GetStoredProcCommand(DataBaseConstants.USP_API_SentryV2_Reddit_FetchList_Pagination))
                    {
                        dbCommand.CommandTimeout = 0;

                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.UserID, DbType.Int32, UserID);
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.TopicID, DbType.Int32, TopicID);

                        if (BaseDate != DateTime.MinValue)
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.BaseDate, DbType.DateTime, BaseDate); }

                        if (FromDate != DateTime.MinValue)
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.FromDate, DbType.DateTime, FromDate); }

                        if (ToDate != DateTime.MinValue)
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.ToDate, DbType.DateTime, ToDate); }

                        if (!string.IsNullOrEmpty(Subreddit))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Subreddit, DbType.String, Subreddit); }

                        if (!string.IsNullOrEmpty(Subreddit_Name))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Subreddit_Name, DbType.String, Subreddit_Name); }

                        if (!string.IsNullOrEmpty(Sentiment))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Sentiment, DbType.String, Sentiment); }

                        if (!string.IsNullOrEmpty(Tonality))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Tonality, DbType.String, Tonality); }

                        if (!string.IsNullOrEmpty(Subreddit_Subscriber_Count))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Subreddit_Subscriber_Count, DbType.String, Subreddit_Subscriber_Count); }

                        if (!string.IsNullOrEmpty(Discourse_Category))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Discourse_Category, DbType.String, Discourse_Category); }

                        if (!string.IsNullOrEmpty(Mentioned_Topics))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Mentioned_Topics, DbType.String, Mentioned_Topics); }

                        if (!string.IsNullOrEmpty(People_Brand_Mentions))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.People_Brand_Mentions, DbType.String, People_Brand_Mentions); }

                        if (!string.IsNullOrEmpty(SubredditCategory))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.SubredditCategory, DbType.String, SubredditCategory); }

                        if (IsTop1Percent.HasValue)
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.IsTop1Percent, DbType.Boolean, IsTop1Percent); }

                        if (!string.IsNullOrEmpty(SortBy))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.SortBy, DbType.String, SortBy); }

                        if (!string.IsNullOrEmpty(SortOrder))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.SortOrder, DbType.String, SortOrder); }

                        if (!string.IsNullOrEmpty(SearchText))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.SearchText, DbType.String, SearchText); }

                        if (!string.IsNullOrEmpty(Exclude_By_Text))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Exclude_By_Text, DbType.String, Exclude_By_Text); }

                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Last_Seen_ID, DbType.Int32, Last_Seen_ID);

                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Page_Size, DbType.Int32, Page_Size);

                        if (!string.IsNullOrEmpty(DataTag))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.DataTag, DbType.String, DataTag); }

                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Show_IDs, DbType.Boolean, Show_IDs);

                        if (!string.IsNullOrEmpty(TML_Subreddit))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.TML_Subreddit, DbType.String, TML_Subreddit); }

                        if (!string.IsNullOrEmpty(HandleTextSearch))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.HandleTextSearch, DbType.String, HandleTextSearch); }

                        ds = DataAccessWrapper.ExecuteDataSet(dbCommand);
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return ds;
        }

        #endregion

        #region Participant List Pagination

        public DataSet ArticleOnline_FetchParticipant_FetchList_Pagination(Int32 TopicID, DateTime FromDate, DateTime ToDate, string Sentiment, string Publication_Domain,
            string Publication_Type, string Publication_DA, string Publication_Traffic, string Publication_ImpactScore, string SortBy,
            string SortOrder, string SearchText, string Mention_Type, string Client_Mention, string Headline_Sentiment, string Article_Type, string Exclude_By_Text, int Last_Seen_ID, int Page_Size, string DataTag, string TML_Publication_Domain, string TML_Author, Int32 TagID, string SearchText_In)
        {
            DataSet ds = new DataSet();
            try
            {
                using (DataAccessWrapper DataAccessWrapper = new DataAccessWrapper(DataBaseConstants.SahadevConnectionString))
                {
                    using (DbCommand dbCommand = DataAccessWrapper.GetStoredProcCommand(DataBaseConstants.USP_API_SentryV2_ArticleOnline_FetchParticipant_List_Pagination))
                    {
                        dbCommand.CommandTimeout = 0;
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.TopicID, DbType.Int32, TopicID);
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.TagID, DbType.Int32, TagID);
                        if (FromDate != DateTime.MinValue)
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.FromDate, DbType.DateTime, FromDate); }

                        if (ToDate != DateTime.MinValue)
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.ToDate, DbType.DateTime, ToDate); }

                        if (!string.IsNullOrEmpty(Sentiment))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Sentiment, DbType.String, Sentiment); }

                        if (!string.IsNullOrEmpty(Publication_Domain))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Publication_Domain, DbType.String, Publication_Domain); }

                        if (!string.IsNullOrEmpty(Publication_Type))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Publication_Type, DbType.String, Publication_Type); }

                        if (!string.IsNullOrEmpty(Publication_DA))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Publication_DA, DbType.String, Publication_DA); }

                        if (!string.IsNullOrEmpty(Publication_Traffic))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Publication_Traffic, DbType.String, Publication_Traffic); }

                        if (!string.IsNullOrEmpty(Publication_ImpactScore))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Publication_ImpactScore, DbType.String, Publication_ImpactScore); }

                        if (!string.IsNullOrEmpty(SortBy))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.SortBy, DbType.String, SortBy); }

                        if (!string.IsNullOrEmpty(SortOrder))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.SortOrder, DbType.String, SortOrder); }

                        if (!string.IsNullOrEmpty(SearchText))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.SearchText, DbType.String, SearchText); }

                        if (!string.IsNullOrEmpty(Mention_Type))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Mention_Type, DbType.String, Mention_Type); }

                        if (!string.IsNullOrEmpty(Client_Mention))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Client_Mention, DbType.String, Client_Mention); }

                        if (!string.IsNullOrEmpty(Headline_Sentiment))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Headline_Sentiment, DbType.String, Headline_Sentiment); }

                        if (!string.IsNullOrEmpty(Article_Type))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Article_Type, DbType.String, Article_Type); }

                        if (!string.IsNullOrEmpty(Exclude_By_Text))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Exclude_By_Text, DbType.String, Exclude_By_Text); }

                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Last_Seen_ID, DbType.Int32, Last_Seen_ID);

                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Page_Size, DbType.Int32, Page_Size);

                        if (!string.IsNullOrEmpty(DataTag))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.DataTag, DbType.String, DataTag); }

                        if (!string.IsNullOrEmpty(TML_Publication_Domain))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.TML_Publication_Domain, DbType.String, TML_Publication_Domain); }

                        if (!string.IsNullOrEmpty(TML_Author))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.TML_Author, DbType.String, TML_Author); }

                        if (!string.IsNullOrEmpty(SearchText_In))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.SearchText_In, DbType.String, SearchText_In); }


                        #region DataSet

                        ds = DataAccessWrapper.ExecuteDataSet(dbCommand);
                        //using (DataSet ds = DataAccessWrapper.ExecuteDataSet(dbCommand))
                        //{
                        //    if (ds != null && ds.Tables.Count > 0)
                        //    {
                        //        dt = ds.Tables[0];
                        //    }
                        //}
                        #endregion
                    }
                }

            }
            catch (Exception ex)
            {

                throw ex;
            }

            return ds;
        }

        public DataSet ArticlePrint_FetchParticipant_FetchList_Pagination(Int32 TopicID, DateTime FromDate, DateTime ToDate, string Sentiment, string Publication_Name, string Publication_Edition,
            string Publication_Type, string Publication_Circulation, string Publication_ImpactScore, string SortBy, string SortOrder,
            string SearchText, string Mention_Type, string Client_Mention, string Headline_Sentiment, string Article_Type, string Author, string Exclude_By_Text, string Language, int Last_Seen_ID, int Page_Size, string DataTag, string TML_Publication_Name, string TML_Author, Int32 TagID, string SearchText_In)
        {
            DataSet ds = new DataSet();
            try
            {
                using (DataAccessWrapper DataAccessWrapper = new DataAccessWrapper(DataBaseConstants.SahadevConnectionString))
                {
                    using (DbCommand dbCommand = DataAccessWrapper.GetStoredProcCommand(DataBaseConstants.USP_API_SentryV2_ArticlePrint_FetchParticipant_List_Pagination))
                    {
                        dbCommand.CommandTimeout = 0;
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.TopicID, DbType.Int32, TopicID);
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.TagID, DbType.Int32, TagID);

                        if (FromDate != DateTime.MinValue)
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.FromDate, DbType.DateTime, FromDate); }

                        if (ToDate != DateTime.MinValue)
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.ToDate, DbType.DateTime, ToDate); }

                        if (!string.IsNullOrEmpty(Sentiment))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Sentiment, DbType.String, Sentiment); }

                        if (!string.IsNullOrEmpty(Publication_Name))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Publication_Name, DbType.String, Publication_Name); }

                        if (!string.IsNullOrEmpty(Publication_Type))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Publication_Type, DbType.String, Publication_Type); }

                        if (!string.IsNullOrEmpty(Publication_Edition))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Publication_Edition, DbType.String, Publication_Edition); }

                        if (!string.IsNullOrEmpty(Publication_Circulation))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Publication_Circulation, DbType.String, Publication_Circulation); }

                        if (!string.IsNullOrEmpty(Publication_ImpactScore))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Publication_ImpactScore, DbType.String, Publication_ImpactScore); }

                        if (!string.IsNullOrEmpty(SortBy))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.SortBy, DbType.String, SortBy); }

                        if (!string.IsNullOrEmpty(SortOrder))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.SortOrder, DbType.String, SortOrder); }

                        if (!string.IsNullOrEmpty(SearchText))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.SearchText, DbType.String, SearchText); }

                        if (!string.IsNullOrEmpty(Mention_Type))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Mention_Type, DbType.String, Mention_Type); }

                        if (!string.IsNullOrEmpty(Client_Mention))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Client_Mention, DbType.String, Client_Mention); }

                        if (!string.IsNullOrEmpty(Headline_Sentiment))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Headline_Sentiment, DbType.String, Headline_Sentiment); }

                        if (!string.IsNullOrEmpty(Article_Type))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Article_Type, DbType.String, Article_Type); }

                        if (!string.IsNullOrEmpty(Author))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Author, DbType.String, Author); }

                        if (!string.IsNullOrEmpty(Exclude_By_Text))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Exclude_By_Text, DbType.String, Exclude_By_Text); }

                        if (!string.IsNullOrEmpty(Language))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Language, DbType.String, Language); }

                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Last_Seen_ID, DbType.Int32, Last_Seen_ID);

                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Page_Size, DbType.Int32, Page_Size);

                        if (!string.IsNullOrEmpty(DataTag))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.DataTag, DbType.String, DataTag); }

                        if (!string.IsNullOrEmpty(TML_Publication_Name))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.TML_Publication_Name, DbType.String, TML_Publication_Name); }

                        if (!string.IsNullOrEmpty(TML_Author))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.TML_Author, DbType.String, TML_Author); }

                        if (!string.IsNullOrEmpty(SearchText_In))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.SearchText_In, DbType.String, SearchText_In); }

                        #region DataSet

                        ds = DataAccessWrapper.ExecuteDataSet(dbCommand);
                        //using (DataSet ds = DataAccessWrapper.ExecuteDataSet(dbCommand))
                        //{
                        //    if (ds != null && ds.Tables.Count > 0)
                        //    {
                        //        dt = ds.Tables[0];
                        //    }
                        //}
                        #endregion
                    }
                }

            }
            catch (Exception ex)
            {

                throw ex;
            }

            return ds;
        }

        public DataSet Twitter_FetchParticipant_FetchList_Pagination(Int32 TopicID, DateTime BaseDate, DateTime FromDate, DateTime ToDate, string Sentiment, string Mentioned_Hashtag,
            string Mentioned_Handle, string Media_Type, string Profile_Category, string SortBy, string SortOrder, string Mention_Type, string Profile_Name,
            string Profile_Handle, string Profile_Followerscount, string Participant_Type, string Profile_VerifiedType, string Tonality, string Eng_Type, string SearchText, string Exclude_By_Text, int Last_Seen_ID, int Page_Size, string DataTag, string tml_handle)
        {
            DataSet ds = new DataSet();
            try
            {
                using (DataAccessWrapper DataAccessWrapper = new DataAccessWrapper(DataBaseConstants.SahadevConnectionString))
                {
                    using (DbCommand dbCommand = DataAccessWrapper.GetStoredProcCommand(DataBaseConstants.USP_API_SentryV2_Twitter_FetchParticipant_List_Pagination))
                    {
                        dbCommand.CommandTimeout = 0;
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.TopicID, DbType.Int32, TopicID);

                        if (BaseDate != DateTime.MinValue)
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.BaseDate, DbType.DateTime, BaseDate); }

                        if (FromDate != DateTime.MinValue)
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.FromDate, DbType.DateTime, FromDate); }

                        if (ToDate != DateTime.MinValue)
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.ToDate, DbType.DateTime, ToDate); }

                        if (!string.IsNullOrEmpty(Sentiment))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Sentiment, DbType.String, Sentiment); }

                        if (!string.IsNullOrEmpty(Mentioned_Hashtag))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Mentioned_Hashtag, DbType.String, Mentioned_Hashtag); }

                        if (!string.IsNullOrEmpty(Mentioned_Handle))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Mentioned_Handle, DbType.String, Mentioned_Handle); }

                        if (!string.IsNullOrEmpty(Media_Type))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Media_Type, DbType.String, Media_Type); }

                        if (!string.IsNullOrEmpty(Profile_Category))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Profile_Category, DbType.String, Profile_Category); }

                        if (!string.IsNullOrEmpty(SortBy))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.SortBy, DbType.String, SortBy); }

                        if (!string.IsNullOrEmpty(SortOrder))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.SortOrder, DbType.String, SortOrder); }

                        if (!string.IsNullOrEmpty(Mention_Type))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Mention_Type, DbType.String, Mention_Type); }

                        if (!string.IsNullOrEmpty(Profile_Name))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Profile_Name, DbType.String, Profile_Name); }

                        if (!string.IsNullOrEmpty(Profile_Handle))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Profile_Handle, DbType.String, Profile_Handle); }

                        if (!string.IsNullOrEmpty(Participant_Type))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Participant_Type, DbType.String, Participant_Type); }

                        if (!string.IsNullOrEmpty(Profile_Followerscount))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Profile_Followerscount, DbType.String, Profile_Followerscount); }

                        if (!string.IsNullOrEmpty(Profile_VerifiedType))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Profile_VerifiedType, DbType.String, Profile_VerifiedType); }

                        if (!string.IsNullOrEmpty(Tonality))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Tonality, DbType.String, Tonality); }

                        if (!string.IsNullOrEmpty(Eng_Type))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Eng_Type, DbType.String, Eng_Type); }

                        if (!string.IsNullOrEmpty(SearchText))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.SearchText, DbType.String, SearchText); }

                        if (!string.IsNullOrEmpty(Exclude_By_Text))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Exclude_By_Text, DbType.String, Exclude_By_Text); }

                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Last_Seen_ID, DbType.Int32, Last_Seen_ID);

                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Page_Size, DbType.Int32, Page_Size);

                        if (!string.IsNullOrEmpty(DataTag))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.DataTag, DbType.String, DataTag); }

                        if (!string.IsNullOrEmpty(tml_handle))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.TML_Handle, DbType.String, tml_handle); }

                        #region DataSet

                        ds = DataAccessWrapper.ExecuteDataSet(dbCommand);

                        #endregion
                    }
                }

            }
            catch (Exception ex)
            {

                throw ex;
            }

            return ds;
        }

        public DataSet YouTube_FetchParticipant_FetchList_Pagination(Int32 TopicID, DateTime BaseDate, DateTime FromDate, DateTime ToDate, string VideoTags,
            string ChannelHandle, string ChannelName, string Sentiment, string Tonality, string ChannelCategory,
            string Mention_Type, string ProfileVerifiedType, string Participant_Type, string Channel_SubscriberCount, string DurationInMin, string VideoType,
            string DiscourseCategory, string Mentioned_Topics, string Publication_ImpactScore, string Mentioned_Locations,
            string SortBy, string SortOrder, Int32 UserID, string People_Brand_Mentions, string Language, string SearchText, string Exclude_By_Text, int Last_Seen_ID, int Page_Size, string DataTag, string tml_channel, string SearchText_In)
        {
            DataSet ds = new DataSet();
            try
            {
                using (DataAccessWrapper DataAccessWrapper = new DataAccessWrapper(DataBaseConstants.SahadevConnectionString))
                {
                    using (DbCommand dbCommand = DataAccessWrapper.GetStoredProcCommand(DataBaseConstants.USP_API_SentryV2_YouTube_FetchParticipant_List_Pagination))
                    {
                        dbCommand.CommandTimeout = 0;
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.TopicID, DbType.Int32, TopicID);

                        if (BaseDate != DateTime.MinValue)
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.BaseDate, DbType.DateTime, BaseDate); }

                        if (FromDate != DateTime.MinValue)
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.FromDate, DbType.DateTime, FromDate); }

                        if (ToDate != DateTime.MinValue)
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.ToDate, DbType.DateTime, ToDate); }

                        if (!string.IsNullOrEmpty(VideoTags))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Video_Tags, DbType.String, VideoTags); }

                        if (!string.IsNullOrEmpty(ChannelHandle))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Channel_Handle, DbType.String, ChannelHandle); }

                        if (!string.IsNullOrEmpty(ChannelName))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Channel_Name, DbType.String, ChannelName); }

                        if (!string.IsNullOrEmpty(Sentiment))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Sentiment, DbType.String, Sentiment); }

                        if (!string.IsNullOrEmpty(Tonality))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Tonality, DbType.String, Tonality); }

                        if (!string.IsNullOrEmpty(ChannelCategory))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Channel_Category, DbType.String, ChannelCategory); }

                        if (!string.IsNullOrEmpty(Mention_Type))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Mention_Type, DbType.String, Mention_Type); }

                        if (!string.IsNullOrEmpty(ProfileVerifiedType))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Profile_VerifiedType, DbType.String, ProfileVerifiedType); }

                        if (!string.IsNullOrEmpty(Participant_Type))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Participant_Type, DbType.String, Participant_Type); }

                        if (!string.IsNullOrEmpty(Channel_SubscriberCount))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Channel_Subscriber_Count, DbType.String, Channel_SubscriberCount); }

                        if (!string.IsNullOrEmpty(DurationInMin))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Duration_In_Min, DbType.String, DurationInMin); }

                        if (!string.IsNullOrEmpty(VideoType))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Video_Type, DbType.String, VideoType); }

                        if (!string.IsNullOrEmpty(DiscourseCategory))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Discourse_Category, DbType.String, DiscourseCategory); }

                        if (!string.IsNullOrEmpty(Mentioned_Topics))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Mentioned_Topics, DbType.String, Mentioned_Topics); }

                        if (!string.IsNullOrEmpty(Publication_ImpactScore))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Publication_ImpactScore, DbType.String, Publication_ImpactScore); }

                        if (!string.IsNullOrEmpty(Mentioned_Locations))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Mentioned_Locations, DbType.String, Mentioned_Locations); }

                        if (!string.IsNullOrEmpty(SortBy))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.SortBy, DbType.String, SortBy); }

                        if (!string.IsNullOrEmpty(SortOrder))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.SortOrder, DbType.String, SortOrder); }

                        if (!string.IsNullOrEmpty(People_Brand_Mentions))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.People_Brand_Mentions, DbType.String, People_Brand_Mentions); }

                        if (!string.IsNullOrEmpty(Language))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Language, DbType.String, Language); }

                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.UserID, DbType.Int32, UserID);

                        if (!string.IsNullOrEmpty(SearchText))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.SearchText, DbType.String, SearchText); }

                        if (!string.IsNullOrEmpty(Exclude_By_Text))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Exclude_By_Text, DbType.String, Exclude_By_Text); }

                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Last_Seen_ID, DbType.Int32, Last_Seen_ID);

                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Page_Size, DbType.Int32, Page_Size);

                        if (!string.IsNullOrEmpty(DataTag))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.DataTag, DbType.String, DataTag); }

                        if (!string.IsNullOrEmpty(tml_channel))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.TML_Channel, DbType.String, tml_channel); }

                        if (!string.IsNullOrEmpty(SearchText_In))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.SearchText_In, DbType.String, SearchText_In); }

                        #region DataSet

                        ds = DataAccessWrapper.ExecuteDataSet(dbCommand);

                        #endregion
                    }
                }

            }
            catch (Exception ex)
            {

                throw ex;
            }

            return ds;
        }

        #endregion

        #region List Page View Chart

        public DataTable ArticleOnline_FetchList_ListPage_ViewChart(Int32 TopicID, DateTime FromDate, DateTime ToDate, string Sentiment, string Publication_Domain,
            string Publication_Type, string Publication_DA, string Publication_Traffic, string Publication_ImpactScore, string SortBy,
            string SortOrder, string SearchText, string Mention_Type, string Client_Mention, Int32 UserID, string Headline_Sentiment, string Article_Type, string Exclude_By_Text, string DataTag, string TML_Publication_Domain, string TML_Author, Int32 TagID, string SearchText_In)
        {
            DataTable dt = new DataTable();
            try
            {

                using (DataAccessWrapper DataAccessWrapper = new DataAccessWrapper(DataBaseConstants.SahadevConnectionString))
                {
                    using (DbCommand dbCommand = DataAccessWrapper.GetStoredProcCommand(DataBaseConstants.USP_API_SentryV2_ArticleOnline_ListPage_ViewChart))
                    {
                        dbCommand.CommandTimeout = 0;
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.TopicID, DbType.Int32, TopicID);
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.TagID, DbType.Int32, TagID);

                        if (FromDate != DateTime.MinValue)
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.FromDate, DbType.DateTime, FromDate); }

                        if (ToDate != DateTime.MinValue)
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.ToDate, DbType.DateTime, ToDate); }

                        if (!string.IsNullOrEmpty(Sentiment))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Sentiment, DbType.String, Sentiment); }

                        if (!string.IsNullOrEmpty(Publication_Domain))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Publication_Domain, DbType.String, Publication_Domain); }

                        if (!string.IsNullOrEmpty(Publication_Type))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Publication_Type, DbType.String, Publication_Type); }

                        if (!string.IsNullOrEmpty(Publication_DA))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Publication_DA, DbType.String, Publication_DA); }

                        if (!string.IsNullOrEmpty(Publication_Traffic))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Publication_Traffic, DbType.String, Publication_Traffic); }

                        if (!string.IsNullOrEmpty(Publication_ImpactScore))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Publication_ImpactScore, DbType.String, Publication_ImpactScore); }

                        if (!string.IsNullOrEmpty(SortBy))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.SortBy, DbType.String, SortBy); }

                        if (!string.IsNullOrEmpty(SortOrder))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.SortOrder, DbType.String, SortOrder); }

                        if (!string.IsNullOrEmpty(SearchText))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.SearchText, DbType.String, SearchText); }

                        if (!string.IsNullOrEmpty(Mention_Type))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Mention_Type, DbType.String, Mention_Type); }

                        if (!string.IsNullOrEmpty(Client_Mention))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Client_Mention, DbType.String, Client_Mention); }

                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.UserID, DbType.Int32, UserID);

                        if (!string.IsNullOrEmpty(Headline_Sentiment))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Headline_Sentiment, DbType.String, Headline_Sentiment); }

                        if (!string.IsNullOrEmpty(Article_Type))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Article_Type, DbType.String, Article_Type); }

                        if (!string.IsNullOrEmpty(Exclude_By_Text))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Exclude_By_Text, DbType.String, Exclude_By_Text); }

                        if (!string.IsNullOrEmpty(DataTag))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.DataTag, DbType.String, DataTag); }

                        if (!string.IsNullOrEmpty(TML_Publication_Domain))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.TML_Publication_Domain, DbType.String, TML_Publication_Domain); }

                        if (!string.IsNullOrEmpty(TML_Author))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.TML_Author, DbType.String, TML_Author); }

                        if (!string.IsNullOrEmpty(SearchText_In))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.SearchText_In, DbType.String, SearchText_In); }

                        #region DataSet
                        using (DataSet ds = DataAccessWrapper.ExecuteDataSet(dbCommand))
                        {
                            if (ds != null && ds.Tables.Count > 0)
                            {
                                dt = ds.Tables[0];
                            }
                        }
                        #endregion
                    }
                }

            }
            catch (Exception ex)
            {

                throw ex;
            }

            return dt;
        }

        public DataTable ArticlePrint_FetchList_ListPage_ViewChart(Int32 TopicID, DateTime FromDate, DateTime ToDate, string Sentiment, string Publication_Name, string Publication_Edition,
            string Publication_Type, string Publication_Circulation, string Publication_ImpactScore, string SortBy,
            string SortOrder, string SearchText, string Mention_Type, string Client_Mention, Int32 UserID, string Headline_Sentiment, string Article_Type, string Author, string Exclude_By_Text, string Language, string DataTag, string TML_Publication_Name, string TML_Author, Int32 TagID, string SearchText_In)
        {
            DataTable dt = new DataTable();
            try
            {

                using (DataAccessWrapper DataAccessWrapper = new DataAccessWrapper(DataBaseConstants.SahadevConnectionString))
                {
                    using (DbCommand dbCommand = DataAccessWrapper.GetStoredProcCommand(DataBaseConstants.USP_API_SentryV2_ArticlePrint_ListPage_ViewChart))
                    {
                        dbCommand.CommandTimeout = 0;
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.TopicID, DbType.Int32, TopicID);
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.TagID, DbType.Int32, TagID);

                        if (FromDate != DateTime.MinValue)
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.FromDate, DbType.DateTime, FromDate); }

                        if (ToDate != DateTime.MinValue)
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.ToDate, DbType.DateTime, ToDate); }

                        if (!string.IsNullOrEmpty(Sentiment))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Sentiment, DbType.String, Sentiment); }

                        if (!string.IsNullOrEmpty(Publication_Name))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Publication_Name, DbType.String, Publication_Name); }

                        if (!string.IsNullOrEmpty(Publication_Type))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Publication_Type, DbType.String, Publication_Type); }

                        if (!string.IsNullOrEmpty(Publication_Edition))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Publication_Edition, DbType.String, Publication_Edition); }

                        if (!string.IsNullOrEmpty(Publication_Circulation))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Publication_Circulation, DbType.String, Publication_Circulation); }

                        if (!string.IsNullOrEmpty(Publication_ImpactScore))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Publication_ImpactScore, DbType.String, Publication_ImpactScore); }

                        if (!string.IsNullOrEmpty(SortBy))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.SortBy, DbType.String, SortBy); }

                        if (!string.IsNullOrEmpty(SortOrder))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.SortOrder, DbType.String, SortOrder); }

                        if (!string.IsNullOrEmpty(SearchText))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.SearchText, DbType.String, SearchText); }

                        if (!string.IsNullOrEmpty(Mention_Type))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Mention_Type, DbType.String, Mention_Type); }

                        if (!string.IsNullOrEmpty(Client_Mention))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Client_Mention, DbType.String, Client_Mention); }

                        if (!string.IsNullOrEmpty(Headline_Sentiment))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Headline_Sentiment, DbType.String, Headline_Sentiment); }

                        if (!string.IsNullOrEmpty(Article_Type))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Article_Type, DbType.String, Article_Type); }

                        if (!string.IsNullOrEmpty(Author))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Author, DbType.String, Author); }

                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.UserID, DbType.Int32, UserID);

                        if (!string.IsNullOrEmpty(Language))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Language, DbType.String, Language); }

                        if (!string.IsNullOrEmpty(Exclude_By_Text))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Exclude_By_Text, DbType.String, Exclude_By_Text); }

                        if (!string.IsNullOrEmpty(DataTag))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.DataTag, DbType.String, DataTag); }

                        if (!string.IsNullOrEmpty(TML_Publication_Name))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.TML_Publication_Name, DbType.String, TML_Publication_Name); }

                        if (!string.IsNullOrEmpty(TML_Author))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.TML_Author, DbType.String, TML_Author); }

                        if (!string.IsNullOrEmpty(SearchText_In))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.SearchText_In, DbType.String, SearchText_In); }

                        #region DataSet
                        using (DataSet ds = DataAccessWrapper.ExecuteDataSet(dbCommand))
                        {
                            if (ds != null && ds.Tables.Count > 0)
                            {
                                dt = ds.Tables[0];
                            }
                        }
                        #endregion
                    }
                }

            }
            catch (Exception ex)
            {

                throw ex;
            }

            return dt;
        }

        public DataTable Twitter_FetchList_ListPage_ViewChart(Int32 TopicID, DateTime BaseDate, DateTime FromDate, DateTime ToDate, string Sentiment, string Mentioned_Hashtag,
            string Mentioned_Handle, string Media_Type, string Profile_Category, string SortBy, string SortOrder, string Mention_Type, string Profile_Name,
            string Profile_Handle, string Profile_Followerscount, string Participant_Type, string Profile_VerifiedType, Int32 UserID, string Tonality, string Eng_Type, string SearchText, string Exclude_By_Text, string DataTag, string tml_handle)
        {
            DataTable dt = new DataTable();
            try
            {
                using (DataAccessWrapper DataAccessWrapper = new DataAccessWrapper(DataBaseConstants.SahadevConnectionString))
                {
                    using (DbCommand dbCommand = DataAccessWrapper.GetStoredProcCommand(DataBaseConstants.USP_API_SentryV2_Twitter_ListPage_ViewChart))
                    {
                        dbCommand.CommandTimeout = 0;
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.TopicID, DbType.Int32, TopicID);

                        if (BaseDate != DateTime.MinValue)
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.BaseDate, DbType.DateTime, BaseDate); }

                        if (FromDate != DateTime.MinValue)
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.FromDate, DbType.DateTime, FromDate); }

                        if (ToDate != DateTime.MinValue)
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.ToDate, DbType.DateTime, ToDate); }

                        if (!string.IsNullOrEmpty(Sentiment))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Sentiment, DbType.String, Sentiment); }

                        if (!string.IsNullOrEmpty(Mentioned_Hashtag))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Mentioned_Hashtag, DbType.String, Mentioned_Hashtag); }

                        if (!string.IsNullOrEmpty(Mentioned_Handle))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Mentioned_Handle, DbType.String, Mentioned_Handle); }

                        if (!string.IsNullOrEmpty(Media_Type))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Media_Type, DbType.String, Media_Type); }

                        if (!string.IsNullOrEmpty(Profile_Category))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Profile_Category, DbType.String, Profile_Category); }

                        if (!string.IsNullOrEmpty(SortBy))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.SortBy, DbType.String, SortBy); }

                        if (!string.IsNullOrEmpty(SortOrder))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.SortOrder, DbType.String, SortOrder); }

                        if (!string.IsNullOrEmpty(Mention_Type))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Mention_Type, DbType.String, Mention_Type); }

                        if (!string.IsNullOrEmpty(Profile_Name))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Profile_Name, DbType.String, Profile_Name); }

                        if (!string.IsNullOrEmpty(Profile_Handle))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Profile_Handle, DbType.String, Profile_Handle); }

                        if (!string.IsNullOrEmpty(Participant_Type))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Participant_Type, DbType.String, Participant_Type); }

                        if (!string.IsNullOrEmpty(Profile_Followerscount))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Profile_Followerscount, DbType.String, Profile_Followerscount); }

                        if (!string.IsNullOrEmpty(Profile_VerifiedType))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Profile_VerifiedType, DbType.String, Profile_VerifiedType); }

                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.UserID, DbType.Int32, UserID);

                        if (!string.IsNullOrEmpty(Tonality))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Tonality, DbType.String, Tonality); }

                        if (!string.IsNullOrEmpty(Eng_Type))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Eng_Type, DbType.String, Eng_Type); }

                        if (!string.IsNullOrEmpty(SearchText))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.SearchText, DbType.String, SearchText); }

                        if (!string.IsNullOrEmpty(Exclude_By_Text))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Exclude_By_Text, DbType.String, Exclude_By_Text); }

                        if (!string.IsNullOrEmpty(DataTag))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.DataTag, DbType.String, DataTag); }

                        if (!string.IsNullOrEmpty(tml_handle))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.TML_Handle, DbType.String, tml_handle); }

                        #region DataSet
                        using (DataSet ds = DataAccessWrapper.ExecuteDataSet(dbCommand))
                        {
                            if (ds != null && ds.Tables.Count > 0)
                            {
                                dt = ds.Tables[0];
                            }
                        }
                        #endregion
                    }
                }

            }
            catch (Exception ex)
            {

                throw ex;
            }

            return dt;
        }

        public DataTable YouTube_FetchList_ListPage_ViewChart(Int32 TopicID, DateTime BaseDate, DateTime FromDate, DateTime ToDate, string VideoTags,
            string ChannelHandle, string ChannelName, string Sentiment, string Tonality, string ChannelCategory,
            string Mention_Type, string ProfileVerifiedType, string Participant_Type, string Channel_SubscriberCount, string DurationInMin, string VideoType,
            string DiscourseCategory, string Mentioned_Topics, string Publication_ImpactScore, string Mentioned_Locations,
            string SortBy, string SortOrder, Int32 UserID, string People_Brand_Mentions, string Language, string SearchText, string Exclude_By_Text, string DataTag, string tml_channel, string SearchText_In)
        {
            DataTable dt = new DataTable();
            try
            {
                using (DataAccessWrapper DataAccessWrapper = new DataAccessWrapper(DataBaseConstants.SahadevConnectionString))
                {
                    using (DbCommand dbCommand = DataAccessWrapper.GetStoredProcCommand(DataBaseConstants.USP_API_SentryV2_YouTube_ListPage_ViewChart))
                    {
                        dbCommand.CommandTimeout = 0;

                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.TopicID, DbType.Int32, TopicID);

                        if (BaseDate != DateTime.MinValue)
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.BaseDate, DbType.DateTime, BaseDate); }

                        if (FromDate != DateTime.MinValue)
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.FromDate, DbType.DateTime, FromDate); }

                        if (ToDate != DateTime.MinValue)
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.ToDate, DbType.DateTime, ToDate); }

                        if (!string.IsNullOrEmpty(VideoTags))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Video_Tags, DbType.String, VideoTags); }

                        if (!string.IsNullOrEmpty(ChannelHandle))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Channel_Handle, DbType.String, ChannelHandle); }

                        if (!string.IsNullOrEmpty(ChannelName))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Channel_Name, DbType.String, ChannelName); }

                        if (!string.IsNullOrEmpty(Sentiment))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Sentiment, DbType.String, Sentiment); }

                        if (!string.IsNullOrEmpty(Tonality))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Tonality, DbType.String, Tonality); }

                        if (!string.IsNullOrEmpty(ChannelCategory))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Channel_Category, DbType.String, ChannelCategory); }

                        if (!string.IsNullOrEmpty(Mention_Type))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Mention_Type, DbType.String, Mention_Type); }

                        if (!string.IsNullOrEmpty(ProfileVerifiedType))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Profile_VerifiedType, DbType.String, ProfileVerifiedType); }

                        if (!string.IsNullOrEmpty(Participant_Type))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Participant_Type, DbType.String, Participant_Type); }

                        if (!string.IsNullOrEmpty(Channel_SubscriberCount))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Channel_Subscriber_Count, DbType.String, Channel_SubscriberCount); }

                        if (!string.IsNullOrEmpty(DurationInMin))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Duration_In_Min, DbType.String, DurationInMin); }

                        if (!string.IsNullOrEmpty(VideoType))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Video_Type, DbType.String, VideoType); }

                        if (!string.IsNullOrEmpty(DiscourseCategory))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Discourse_Category, DbType.String, DiscourseCategory); }

                        if (!string.IsNullOrEmpty(Mentioned_Topics))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Mentioned_Topics, DbType.String, Mentioned_Topics); }

                        if (!string.IsNullOrEmpty(Publication_ImpactScore))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Publication_ImpactScore, DbType.String, Publication_ImpactScore); }

                        if (!string.IsNullOrEmpty(Mentioned_Locations))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Mentioned_Locations, DbType.String, Mentioned_Locations); }

                        if (!string.IsNullOrEmpty(SortBy))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.SortBy, DbType.String, SortBy); }

                        if (!string.IsNullOrEmpty(SortOrder))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.SortOrder, DbType.String, SortOrder); }

                        if (!string.IsNullOrEmpty(People_Brand_Mentions))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.People_Brand_Mentions, DbType.String, People_Brand_Mentions); }

                        if (!string.IsNullOrEmpty(Language))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Language, DbType.String, Language); }

                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.UserID, DbType.Int32, UserID);

                        if (!string.IsNullOrEmpty(SearchText))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.SearchText, DbType.String, SearchText); }

                        if (!string.IsNullOrEmpty(Exclude_By_Text))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Exclude_By_Text, DbType.String, Exclude_By_Text); }

                        if (!string.IsNullOrEmpty(DataTag))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.DataTag, DbType.String, DataTag); }

                        if (!string.IsNullOrEmpty(tml_channel))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.TML_Channel, DbType.String, tml_channel); }

                        if (!string.IsNullOrEmpty(SearchText_In))
                        { DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.SearchText_In, DbType.String, SearchText_In); }

                        #region DataSet
                        using (DataSet ds = DataAccessWrapper.ExecuteDataSet(dbCommand))
                        {
                            if (ds != null && ds.Tables.Count > 0)
                            {
                                dt = ds.Tables[0];
                            }
                        }
                        #endregion
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return dt;
        }

        #endregion

        //Mark Relevancy
        public Int32 MarkRelevancy(Int32 UserID, Int32 PlatformID, string RecordIDs, string Reason, int IsRelevant, int IncidentID)
        {
            Int32 Result = 0;
            DataTable dt = new DataTable();
            try
            {

                using (DataAccessWrapper DataAccessWrapper = new DataAccessWrapper(DataBaseConstants.SahadevConnectionString))
                {
                    using (DbCommand dbCommand = DataAccessWrapper.GetStoredProcCommand(DataBaseConstants.USP_UserMarkedIrrelevantList_Insert))
                    {
                        dbCommand.CommandTimeout = 0;
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.UserID, DbType.Int32, UserID);
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.PlatformID, DbType.Int32, PlatformID);
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.RecordIDs, DbType.String, RecordIDs);
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Reason, DbType.String, Reason);
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.IsRelevant, DbType.Int32, IsRelevant);
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.IncidentID, DbType.Int32, IncidentID);

                        #region DataSet
                        using (DataSet ds = DataAccessWrapper.ExecuteDataSet(dbCommand))
                        {
                            if (ds != null && ds.Tables.Count > 0)
                            {
                                dt = ds.Tables[0];
                                if (dt != null && dt.Rows.Count > 0)
                                {
                                    Result = Convert.ToInt32(dt.Rows[0]["RecordID"]);

                                }
                            }
                        }
                        #endregion
                    }
                }

            }
            catch (Exception ex)
            {

                throw ex;
            }

            return Result;
        }

        public DataTable Fetch_User_Marked_Irrelevant_List(Int32 UserID, Int32 PlatformID, Int32 IncidentID)
        {
            DataTable dt = new DataTable();
            try
            {

                using (DataAccessWrapper DataAccessWrapper = new DataAccessWrapper(DataBaseConstants.SahadevConnectionString))
                {
                    using (DbCommand dbCommand = DataAccessWrapper.GetStoredProcCommand(DataBaseConstants.USP_UserMarkedIrrelevantList_Fetch))
                    {
                        dbCommand.CommandTimeout = 0;
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.UserID, DbType.Int32, UserID);
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.PlatformID, DbType.Int32, PlatformID);
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.IncidentID, DbType.Int32, IncidentID);

                        #region DataSet
                        using (DataSet ds = DataAccessWrapper.ExecuteDataSet(dbCommand))
                        {
                            if (ds != null && ds.Tables.Count > 0)
                            {
                                dt = ds.Tables[0];
                            }
                        }
                        #endregion
                    }
                }

            }
            catch (Exception ex)
            {

                throw ex;
            }

            return dt;
        }

        public DataTable DataTag_Fetch_List(Int32 TopicID, Int32 PlatformID)
        {
            DataTable dt = new DataTable();
            try
            {

                using (DataAccessWrapper DataAccessWrapper = new DataAccessWrapper(DataBaseConstants.SahadevConnectionString))
                {
                    using (DbCommand dbCommand = DataAccessWrapper.GetStoredProcCommand(DataBaseConstants.USP_DataTag_Fetch_All))
                    {
                        dbCommand.CommandTimeout = 0;
                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.TopicID, DbType.Int32, TopicID);

                        DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.PlatformID, DbType.Int32, PlatformID);

                        #region DataSet
                        using (DataSet ds = DataAccessWrapper.ExecuteDataSet(dbCommand))
                        {
                            if (ds != null && ds.Tables.Count > 0)
                            {
                                dt = ds.Tables[0];
                            }
                        }
                        #endregion
                    }
                }

            }
            catch (Exception ex)
            {

                throw ex;
            }

            return dt;
        }

        #region Data Tag
        //public Int32 DataTag_Insert(string Data_Tag, Int32 Topic_type_ID, Int32 Platform_ID, Int32 IncidentID, Int32 UserID, string Colour, string Colour_Code, string Data_Tag_Desc)
        //{
        //    Int32 Result = 0;
        //    DataTable dt = new DataTable();
        //    try
        //    {

        //        using (DataAccessWrapper DataAccessWrapper = new DataAccessWrapper(DataBaseConstants.C1ConnectionString))
        //        {
        //            using (DbCommand dbCommand = DataAccessWrapper.GetStoredProcCommand(DataBaseConstants.USP_DataTag_Insert))
        //            {
        //                dbCommand.CommandTimeout = 0;
        //                DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.DataTag, DbType.String, Data_Tag);
        //                DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.TopicTypeID, DbType.Int32, Topic_type_ID);
        //                DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.PlatformID, DbType.Int32, Platform_ID);
        //                DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.RefID, DbType.Int32, IncidentID);
        //                DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.UserID, DbType.Int32, UserID);
        //                DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Colour, DbType.String, Colour);
        //                DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.ColourCode, DbType.String, Colour_Code);
        //                DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.DataTagDesc, DbType.String, Data_Tag_Desc);

        //                #region DataSet
        //                using (DataSet ds = DataAccessWrapper.ExecuteDataSet(dbCommand))
        //                {
        //                    if (ds != null && ds.Tables.Count > 0)
        //                    {
        //                        dt = ds.Tables[0];
        //                        if (dt != null && dt.Rows.Count > 0)
        //                        {
        //                            Result = Convert.ToInt32(dt.Rows[0]["RecordID"]);

        //                        }
        //                    }
        //                }
        //                #endregion
        //            }
        //        }

        //    }
        //    catch (Exception ex)
        //    {

        //        throw ex;
        //    }

        //    return Result;
        //}

        //public List<dynamic> GetDataTagPattern(int DTID)
        //{
        //    DataTable dt = new DataTable();
        //    try
        //    {

        //        using (DataAccessWrapper DataAccessWrapper = new DataAccessWrapper(DataBaseConstants.C1ConnectionString))
        //        {
        //            using (DbCommand dbCommand = DataAccessWrapper.GetStoredProcCommand(DataBaseConstants.USP_DataTagPattern_Fetch))
        //            {
        //                dbCommand.CommandTimeout = 0;
        //                DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.DTID, DbType.Int32, DTID);

        //                #region DataSet
        //                using (DataSet ds = DataAccessWrapper.ExecuteDataSet(dbCommand))
        //                {
        //                    if (ds != null && ds.Tables.Count > 0)
        //                    {
        //                        dt = ds.Tables[0];
        //                    }
        //                }
        //                #endregion
        //            }
        //        }

        //        //Convert DataTable → List<dynamic>
        //        var data = new List<dynamic>();
        //        foreach (DataRow row in dt.Rows)
        //        {
        //            IDictionary<string, object> dyn = new ExpandoObject();
        //            foreach (DataColumn col in dt.Columns)
        //            {
        //                dyn[col.ColumnName] = row[col];
        //            }
        //            data.Add(dyn);
        //        }

        //        return data;
        //    }
        //    catch (Exception ex)
        //    {
        //        throw ex;
        //    }
        //}

        //public int DataTagPattern_Insert(int DTID, string Pattern, string Filter, Boolean IsSelectAll)
        //{
        //    Int32 Result = 0;
        //    DataTable dt = new DataTable();
        //    try
        //    {

        //        using (DataAccessWrapper DataAccessWrapper = new DataAccessWrapper(DataBaseConstants.C1ConnectionString))
        //        {
        //            using (DbCommand dbCommand = DataAccessWrapper.GetStoredProcCommand(DataBaseConstants.USP_DataTagPattern_Insert))
        //            {
        //                dbCommand.CommandTimeout = 0;
        //                DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.DTID, DbType.Int32, DTID);
        //                DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Pattern, DbType.String, Pattern);
        //                DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Filter, DbType.String, Filter);
        //                DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.IsSelectAll, DbType.Boolean, IsSelectAll);

        //                #region DataSet
        //                using (DataSet ds = DataAccessWrapper.ExecuteDataSet(dbCommand))
        //                {
        //                    if (ds != null && ds.Tables.Count > 0)
        //                    {
        //                        dt = ds.Tables[0];
        //                        if (dt != null && dt.Rows.Count > 0)
        //                        {
        //                            Result = Convert.ToInt32(dt.Rows[0]["DTPID"]);

        //                        }
        //                    }
        //                }
        //                #endregion
        //            }
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        throw ex;
        //    }
        //    return Result;
        //}

        //public bool DataTagPattern_Update(int DTPID, string Pattern, int IsPattern)
        //{
        //    Int32 Result = 0;
        //    DataTable dt = new DataTable();
        //    bool bReturn = false;
        //    try
        //    {
        //        using (DataAccessWrapper DataAccessWrapper = new DataAccessWrapper(DataBaseConstants.C1ConnectionString))
        //        {
        //            using (DbCommand dbCommand = DataAccessWrapper.GetStoredProcCommand(DataBaseConstants.USP_DataTagPattern_Update))
        //            {
        //                dbCommand.CommandTimeout = 0;
        //                DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.DTPID, DbType.Int32, DTPID);
        //                DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.Pattern, DbType.String, Pattern);
        //                DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.IsPattern, DbType.Int32, IsPattern);

        //                #region DataSet
        //                using (DataSet ds = DataAccessWrapper.ExecuteDataSet(dbCommand))
        //                {
        //                    if (ds != null && ds.Tables.Count > 0)
        //                    {
        //                        dt = ds.Tables[0];
        //                        if (dt != null && dt.Rows.Count > 0)
        //                        {
        //                            Result = Convert.ToInt32(dt.Rows[0]["DTPID"]);

        //                        }
        //                    }
        //                }
        //                #endregion
        //            }
        //        }

        //        if (Result != 0)
        //            bReturn = true;
        //    }
        //    catch (Exception ex)
        //    {
        //        throw ex;
        //    }
        //    return bReturn;
        //}

        //public bool DataTagDetail_Insert(int DTID, int DTPID, int RecordID, int PlatformID, string BatchNo, int DTTID)
        //{
        //    Int32 Result = 0;
        //    DataTable dt = new DataTable();
        //    bool bReturn = false;
        //    try
        //    {

        //        using (DataAccessWrapper DataAccessWrapper = new DataAccessWrapper(DataBaseConstants.SahadevConnectionString))
        //        {
        //            using (DbCommand dbCommand = DataAccessWrapper.GetStoredProcCommand(DataBaseConstants.USP_DataTagDetail_Insert))
        //            {
        //                dbCommand.CommandTimeout = 0;
        //                DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.DTID, DbType.Int32, DTID);
        //                DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.DTPID, DbType.Int32, DTPID);
        //                DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.RecordID, DbType.Int32, RecordID);
        //                DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.PlatformID, DbType.Int32, PlatformID);
        //                DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.BatchNo, DbType.String, BatchNo);
        //                DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.DTTID, DbType.Int32, DTTID);

        //                #region DataSet
        //                using (DataSet ds = DataAccessWrapper.ExecuteDataSet(dbCommand))
        //                {
        //                    if (ds != null && ds.Tables.Count > 0)
        //                    {
        //                        dt = ds.Tables[0];
        //                        if (dt != null && dt.Rows.Count > 0)
        //                        {
        //                            Result = Convert.ToInt32(dt.Rows[0]["RecordID"]);

        //                        }
        //                    }
        //                }
        //                #endregion
        //            }
        //        }

        //        if (Result != 0)
        //            bReturn = true;
        //    }
        //    catch (Exception ex)
        //    {
        //        throw ex;
        //    }
        //    return bReturn;
        //}

        //public DataTable DataTag_Fetch(int TopicTypeID, int RefID, int PlatformID)
        //{
        //    DataTable dt = new DataTable();
        //    try
        //    {

        //        using (DataAccessWrapper DataAccessWrapper = new DataAccessWrapper(DataBaseConstants.SahadevConnectionString))
        //        {
        //            using (DbCommand dbCommand = DataAccessWrapper.GetStoredProcCommand(DataBaseConstants.USP_DataTag_Fetch))
        //            {
        //                dbCommand.CommandTimeout = 0;
        //                DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.TopicTypeID, DbType.Int32, TopicTypeID);
        //                DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.RefID, DbType.Int32, RefID);
        //                DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.PlatformID, DbType.Int32, PlatformID);

        //                #region DataSet
        //                using (DataSet ds = DataAccessWrapper.ExecuteDataSet(dbCommand))
        //                {
        //                    if (ds != null && ds.Tables.Count > 0)
        //                    {
        //                        dt = ds.Tables[0];
        //                    }
        //                }
        //                #endregion
        //            }
        //        }

        //        return dt;
        //    }
        //    catch (Exception ex)
        //    {
        //        throw ex;
        //    }
        //}

        //public bool DataTagDetail_Delete(int DTID)
        //{
        //    Int32 Result = 0;
        //    DataTable dt = new DataTable();
        //    bool bReturn = false;
        //    try
        //    {

        //        using (DataAccessWrapper DataAccessWrapper = new DataAccessWrapper(DataBaseConstants.C1ConnectionString))
        //        {
        //            using (DbCommand dbCommand = DataAccessWrapper.GetStoredProcCommand(DataBaseConstants.USP_DataTag_Delete))
        //            {
        //                dbCommand.CommandTimeout = 0;
        //                DataAccessWrapper.AddInParameter(dbCommand, Common.Constants.DataBaseConstants.DTID, DbType.Int32, DTID);

        //                #region DataSet
        //                using (DataSet ds = DataAccessWrapper.ExecuteDataSet(dbCommand))
        //                {
        //                    if (ds != null && ds.Tables.Count > 0)
        //                    {
        //                        dt = ds.Tables[0];
        //                        if (dt != null && dt.Rows.Count > 0)
        //                        {
        //                            Result = Convert.ToInt32(dt.Rows[0]["RecordID"]);

        //                        }
        //                    }
        //                }
        //                #endregion
        //            }
        //        }

        //        if (Result != 0)
        //            bReturn = true;
        //    }
        //    catch (Exception ex)
        //    {
        //        throw ex;
        //    }
        //    return bReturn;
        //}
        #endregion
    }

}
