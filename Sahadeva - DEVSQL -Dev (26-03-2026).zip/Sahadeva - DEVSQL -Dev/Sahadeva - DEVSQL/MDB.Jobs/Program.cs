﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MDB.Jobs
{
    class Program
    {
        static void Main(string[] args)
        {
            new TwitterFSQueryCreator().Process();
        }
    }
}
