﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Configuration;
using System.IO;
using System.Net;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System.Net.Mail;
using System.Globalization;


namespace MDB.Jobs
{
    public class TwitterFSQueryCreator
    {
        public void Process()
        {
            try
            {
                List<Rule> rules = GetFilteredStreamRules();

                return;
                DataSet ds =  new MDB.DAL.DAL().Twitter_FetchQueriesToCreateInFS();

                if (ds!=null)
                {
                    if (ds.Tables!=null)
                    {
                        DataTable dt = ds.Tables[0];
                        for (int i = 0; i < dt.Rows.Count; i++)
                        {
                            string strRule = Convert.ToString(dt.Rows[i]["Rule"]);

                            Int32 TagQueryID =Convert.ToInt32(Convert.ToString(dt.Rows[i]["TagQueryID"]));

                            string strResult = AddRule(strRule);

                            if (strResult.ToLower().Contains("successrule"))
                            {
                                strResult = strResult.Replace("SuccessRule", "");
                                new MDB.DAL.DAL().Twitter_UpdateTCQuery(TagQueryID, strResult);
                                SendMail(ConfigurationManager.AppSettings["TOEmailID"].ToString(),strRule + "  ---->  "+ strResult, "TWITTER FS - New Rule Created", null, ConfigurationManager.AppSettings["CCEmailID"].ToString(), ConfigurationManager.AppSettings["BCCEmailID"].ToString());
                            }
                            else if (strResult.ToLower().Contains("error is"))
                            {
                                strResult = strResult.Replace("Error Is", "");
                                new MDB.DAL.DAL().Twitter_UpdateTCQuery(TagQueryID, "Error In Creating Rule");

                                string strToEmailIds = ConfigurationManager.AppSettings["TOEmailID"].ToString();

                                //if (!strResult.Contains(DuplicateRule))
                                //{
                                //    strToEmailIds += ""
                                //}

                                SendMail(ConfigurationManager.AppSettings["TOEmailID"].ToString(), strResult, "TWITTER FS - Error In Creating Rule", null, ConfigurationManager.AppSettings["CCEmailID"].ToString(), ConfigurationManager.AppSettings["BCCEmailID"].ToString());

                            } 
                        }
                    }
                    
                }


            }
            catch (Exception ex)
            {
                
                throw ex;
            }
        }

        private string AddRule(string Rule)
        {
            string json = string.Empty;

            try
            {
                string strRequestUrl = ConfigurationManager.AppSettings["Twitter_AddUrl"];
                string strBearerToken = ConfigurationManager.AppSettings["Twitter_BearerToken"];

                ServicePointManager.SecurityProtocol = (SecurityProtocolType)3072;
                HttpWebRequest request = (HttpWebRequest)WebRequest.Create(strRequestUrl);

                request.Headers.Add("Authorization", strBearerToken);

                //Create bytes array to send Input as parameter
                byte[] bytes = bytes = Encoding.UTF8.GetBytes(Rule);

                //Set request options
                request.ContentType = "application/json; charset=utf8";
                request.ContentLength = bytes.Length;
                request.Method = "POST";
                request.Timeout = Convert.ToInt32(ConfigurationManager.AppSettings["Twitter_TimeOutIntervalForOperation"]);
                
                //Upload bytes array to request
                using (Stream os = request.GetRequestStream())
                {
                    os.Write(bytes, 0, bytes.Length);
                }



                //Get response from TextProcessingPipeline
                using (System.Net.WebResponse resp = request.GetResponse())
                {
                    using (StreamReader sr = new StreamReader(resp.GetResponseStream()))
                    {
                        json = sr.ReadToEnd().Trim();

                        if (!String.IsNullOrEmpty(json))
                        {
                            JObject obj = JObject.Parse(json);
                            if (obj != null)
                            {

                                JObject jMeta = (JObject)obj["meta"];

                                if (obj["data"] != null)
                                {
                                    JArray data = (JArray)obj["data"];

                                    if (data != null)
                                    {
                                        foreach (JToken jItem in data)
                                        {
                                            if (!string.IsNullOrEmpty(Convert.ToString(jItem["id"])))
                                            {
                                                json ="SuccessRule"+ Convert.ToString(jItem["id"].ToString());
                                                return json;
                                            }
                                        }
                                        
                                    }
                                }

                                if (obj["errors"] != null)
                                {
                                    JArray errors = (JArray)obj["errors"];

                                    if (errors != null)
                                    {
                                        foreach (JToken jItem in errors)
                                        {
                                            string strValue = string.Empty;
                                            if (!string.IsNullOrEmpty(Convert.ToString(jItem["value"])))
                                            {
                                                strValue = Convert.ToString(jItem["value"].ToString());
                                            }

                                            string strdetails = string.Empty;
                                            if (!string.IsNullOrEmpty(Convert.ToString(jItem["details"])))
                                            {
                                                strdetails = Convert.ToString(jItem["details"].ToString());
                                            }

                                            string strtitle = string.Empty;
                                            if (!string.IsNullOrEmpty(Convert.ToString(jItem["title"])))
                                            {
                                                strtitle = Convert.ToString(jItem["title"].ToString());
                                            }

                                            string strtype = string.Empty;
                                            if (!string.IsNullOrEmpty(Convert.ToString(jItem["type"])))
                                            {
                                                strtype = Convert.ToString(jItem["type"].ToString());
                                            }

                                            json = "Error Is " + "<table><tr><td>Query :</td><td>" + strValue + "</td></tr><tr><td>" + "Details :</td><td> " + strdetails + "</td></tr><tr><td>" + "Title :</td><td> " + strtitle + "</td></tr><tr><td>" + "Type :</td><td> " + strtype + "</td></tr></table>";
                                            return json;
                                        }

                                    }

                                }


                                if (jMeta != null)
                                {
                                    JObject summary = (JObject)jMeta["summary"];

                                    string created = "";
                                    if (summary["created"] != null && !string.IsNullOrEmpty(Convert.ToString(summary["created"])))
                                    {
                                        created = Convert.ToString(summary["created"].ToString());
                                    }

                                    string not_created = "";
                                    if (summary["not_created"] != null && !string.IsNullOrEmpty(Convert.ToString(summary["not_created"])))
                                    {
                                        not_created = Convert.ToString(summary["not_created"].ToString());
                                    }

                                    string valid = "";
                                    if (summary["valid"] != null && !string.IsNullOrEmpty(Convert.ToString(summary["valid"])))
                                    {
                                        valid = Convert.ToString(summary["valid"].ToString());
                                    }

                                    string invalid = "";
                                    if (summary["invalid"] != null && !string.IsNullOrEmpty(Convert.ToString(summary["invalid"])))
                                    {
                                        invalid = Convert.ToString(summary["invalid"].ToString());
                                    }
                                }
                            }
                            


                        }
                    }
                }

                return json;
            }
            catch (Exception ex)
            {

                throw ex;            
            }
        }

        private List<Rule> GetFilteredStreamRules()
        {
            string bearerToken = ConfigurationManager.AppSettings["Twitter_BearerToken"];
            string url = "https://api.twitter.com/2/tweets/search/stream/rules";
            var rulesList = new List<Rule>();

            try
            {
                ServicePointManager.SecurityProtocol = (SecurityProtocolType)3072;

                HttpWebRequest request = (HttpWebRequest)WebRequest.Create(url);
                request.Method = "GET";
                request.Headers.Add("Authorization", bearerToken);
                request.ContentType = "application/json";

                using (HttpWebResponse response = (HttpWebResponse)request.GetResponse())
                using (StreamReader sr = new StreamReader(response.GetResponseStream()))
                {
                    string json = sr.ReadToEnd();
                    RuleResponse ruleResponse = JsonConvert.DeserializeObject<RuleResponse>(json);

                    if (ruleResponse != null && ruleResponse.Data != null)
                    {
                        rulesList = ruleResponse.Data;
                    }
                }
            }
            catch (WebException ex)
            {
                using (StreamReader sr = new StreamReader(ex.Response.GetResponseStream()))
                {
                    string error = sr.ReadToEnd();
                    Console.WriteLine("API Error: " + error);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("General Error: " + ex.Message);
            }

            return rulesList;
        }


        private bool SendMail(string ToMailID, string Body, string Subject, string FilePath, string CCMailID, string BCCMailID)
        {
            bool IsSent = false;
            try
            {
                //Get From App Config From MailID
                string FromMailID = ConfigurationManager.AppSettings["FromMailAddress"].ToString();
                //Set From Mail ID To MailAddress Properties
                MailAddress ObjFrom = new MailAddress(FromMailID, ConfigurationManager.AppSettings["FromDisplayName"].ToString());
                //Call the refrence of ddll system.net.mail.MailMessage which help to send you mail
                System.Net.Mail.MailMessage mails = new System.Net.Mail.MailMessage();
                //Define all proprties related mail configration
                //Set from mail ID here
                mails.From = ObjFrom;
                //Multiple TO Mailid which available comma sepreated the split bu (,)
                string[] SplitTOMailID = ToMailID.Split(',');
                //if array is available the using foreach loop get one by one id 
                foreach (string ToMailIDValues in SplitTOMailID)
                {
                    //Check here if id is not null or blank
                    if (!string.IsNullOrEmpty(ToMailIDValues))
                    {
                        //Here add in To MailID Properites
                        mails.To.Add(ToMailIDValues);
                    }
                }
                //Multiple CC Mailid which available comma sepreated the split bu (,)
                string[] SplitCCMailID = CCMailID.Split(',');
                foreach (string CCMailIDValues in SplitCCMailID)
                {
                    //Check here if id is not null or blank
                    if (!string.IsNullOrEmpty(CCMailIDValues))
                    {
                        //Here add in CC MailID Properites
                        mails.CC.Add(CCMailIDValues);
                    }
                }
                //Multiple BCC Mailid which available comma sepreated the split bu (,)
                string[] SplitBCCMailID = BCCMailID.Split(',');
                foreach (string CCMailIDValues in SplitBCCMailID)
                {
                    //Check here if id is not null or blank
                    if (!string.IsNullOrEmpty(CCMailIDValues))
                    {
                        //Here add in BCC MailID Properites
                        mails.Bcc.Add(CCMailIDValues);
                    }
                }
                // Set Subject
                mails.Subject = Subject.Replace('\r', ' ').Replace('\n', ' ');
                //if Set html body then always set true
                mails.IsBodyHtml = true;
                //set Message Body
                mails.Body = Body;

                #region Attachment
                //attachment file is exist or not check
                if (File.Exists(FilePath))
                {
                    //if yes the attach the excel sheet
                    Attachment attach = new Attachment(FilePath);
                    //add in mail
                    mails.Attachments.Add(attach);
                }
                #endregion


                //Call SMTP as alias objSMTP
                SmtpClient objSMTP = new SmtpClient();

                //SET SMTP Host from mail Config
                objSMTP.Host = ConfigurationManager.AppSettings["MailServer"].ToString();
                //SET SMTP Port From Mail Config
                objSMTP.Port = Convert.ToInt32(ConfigurationManager.AppSettings["MailPort"]);
                //SET SMTP Userdefault credentails
                objSMTP.UseDefaultCredentials = true;

                if (ConfigurationManager.AppSettings["MailServer"].ToString() == "smtp1.projectstoday.com")
                {
                    objSMTP = new SmtpClient();
                    objSMTP.Host = ConfigurationManager.AppSettings["Host"].ToString();
                    objSMTP.Port = Convert.ToInt32(ConfigurationManager.AppSettings["Port"]);
                    objSMTP.EnableSsl = true;
                    objSMTP.DeliveryMethod = SmtpDeliveryMethod.Network;
                    var fromAddress = new MailAddress(ConfigurationManager.AppSettings["FromMailAddress"].ToString(), ConfigurationManager.AppSettings["FromDisplayName"].ToString());
                    objSMTP.Credentials = new NetworkCredential(fromAddress.Address, ConfigurationManager.AppSettings["Password"].ToString());
                }


                TimeLog("Sending Mail To Server");
                // and finally send mail
                objSMTP.Send(mails);
                TimeLog("Mail Sent");
                IsSent = true;
            }
            catch (Exception ex)
            {
                ErrorLog("SendMail ", ex.ToString() + " ->> " + ex.Message + " ->> " + ex.StackTrace);

                //throw err;
            }

            return IsSent;
        }

        #region LOGGING

        //For error logging
        private void ErrorLog(string functionName, string error)
        {
            try
            {
                string LogPath = ConfigurationManager.AppSettings["Twitter_ErrorLogPath"];
                using (TextWriter myWriter = File.AppendText(LogPath))
                {

                    TextWriter.Synchronized(myWriter).WriteLine("<--> :{0}", string.Empty);
                    TextWriter.Synchronized(myWriter).WriteLine("Function Name :{0}", functionName);
                    TextWriter.Synchronized(myWriter).WriteLine("Error :{0}", error);
                    TextWriter.Synchronized(myWriter).WriteLine("Date :{0}", DateTime.Now.ToString());
                    TextWriter.Synchronized(myWriter).WriteLine("<--> :{0}", string.Empty);
                    TextWriter.Synchronized(myWriter).Flush();
                    TextWriter.Synchronized(myWriter).Close();
                }
            }
            catch (Exception ex)
            {
            }
        }

        //For debugging purpose
        private void TimeLog(string strtext)
        {
            try
            {
                string LogPath = ConfigurationManager.AppSettings["Twitter_TimeLogPath"];
                using (TextWriter myWriter = File.AppendText(LogPath))
                {

                    TextWriter.Synchronized(myWriter).WriteLine("<--> :{0}", string.Empty);
                    TextWriter.Synchronized(myWriter).WriteLine("TimeLog :{0}", strtext);
                    TextWriter.Synchronized(myWriter).WriteLine("Date :{0}", DateTime.Now.ToString());
                    TextWriter.Synchronized(myWriter).WriteLine("<--> :{0}", string.Empty);
                    TextWriter.Synchronized(myWriter).Flush();
                    TextWriter.Synchronized(myWriter).Close();
                }
            }
            catch (Exception ex)
            {
                ErrorLog("TimeLog", ex.ToString());
            }
        }

        #endregion


        public class Rule
        {
            public string Id { get; set; }
            public string Value { get; set; }
            public string Tag { get; set; }
        }

        public class Meta
        {
            public int Sent { get; set; }
        }

        public class RuleResponse
        {
            public List<Rule> Data { get; set; }
            public Meta Meta { get; set; }
        }

    }
}
