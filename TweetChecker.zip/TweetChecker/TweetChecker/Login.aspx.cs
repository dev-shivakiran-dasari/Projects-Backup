﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace TweetChecker
{
    public partial class Login : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        protected void btnLogin_Click(object sender, EventArgs e)
        {
            string username = txtUsername.Text.Trim();
            string password = txtPassword.Text.Trim();

            if (username == "admin" && password == "Kalki2026")
            {
                Session["User"] = username;
                Response.Redirect("TweetsCounts.aspx");
            }
            else
            {
                lblError.Text = "Invalid Username or Password";
            }
        }
    }
}