﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="Login.aspx.cs" Inherits="TweetChecker.Login" %>

<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head id="Head1" runat="server">
    <title>Login</title>
    <style>
        body { font-family: Arial; margin-top:100px; }
        table { border-collapse: collapse; margin:auto; }
        td { padding:10px; }
        .title { font-size:20px; font-weight:bold; text-align:center; }
        .error { color:red; }
    </style>
</head>

<body>
<form id="form1" runat="server">

<table border="1">
    
<tr>
<td colspan="2" class="title">Login</td>
</tr>

<tr>
<td>Username</td>
<td>
<asp:TextBox ID="txtUsername" runat="server"></asp:TextBox>
</td>
</tr>

<tr>
<td>Password</td>
<td>
<asp:TextBox ID="txtPassword" runat="server" TextMode="Password"></asp:TextBox>
</td>
</tr>

<tr>
<td colspan="2" align="center">
<asp:Button ID="btnLogin" runat="server" Text="Login" OnClick="btnLogin_Click" />
</td>
</tr>

<tr>
<td colspan="2" align="center">
<asp:Label ID="lblError" runat="server" CssClass="error"></asp:Label>
</td>
</tr>

</table>

</form>
</body>
</html>