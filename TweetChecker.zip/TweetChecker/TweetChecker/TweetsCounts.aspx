﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="TweetCounts.aspx.cs" Inherits="TweetChecker.TweetCounts" %>

<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head id="Head1" runat="server">
    <title>Twitter Tweet Counts</title>
    <style type="text/css">
        body { font-family: Arial; margin: 20px; }
        table { border-collapse: collapse; width: 100%; }
        td { padding: 8px; vertical-align: top; }
        .lbl { width: 140px; font-size:medium; font-weight: bold; }
        .tb  { width: 720px; }
        .result { font-weight: bold; }
        .error { color: #b00020; }
        .muted { color: #666; }
       
        .style1
        {
            width: 30%;
        }
        .style2
        {
            width: 942px;
        }
       
    </style>
</head>
<body>
    <form id="form1" runat="server">
        <table border="0">
            <tr>
                <td class="style1">Query:</td>
                <td class="style2">
                    <asp:TextBox ID="txtQuery" runat="server" CssClass="tb" TextMode="MultiLine" />
                </td>
            </tr>
            <tr>
<td class="label">From Date</td>
<td>
<asp:TextBox ID="txtFromDate" runat="server" TextMode="DateTimeLocal"></asp:TextBox>
</td>
</tr>

<tr>
<td class="label">To Date</td>
<td>
<asp:TextBox ID="txtToDate" runat="server" TextMode="DateTimeLocal"></asp:TextBox>
</td>
</tr>
            <tr>
                <td class="style1"></td>
                <td class="style2">
                    <asp:Button ID="btnGetCount" runat="server" Text="Get Count" OnClick="btnGetCount_Click" />
                </td>
            </tr>

            <tr>
                <td class="style1">Final Query:</td>
                <td class="style2">
                    <asp:Label ID="lblFinalQuery" runat="server" />
                </td>
            </tr>

            <tr>
                <td class="style1">Total Count in last 7 Days without Retweets:</td>
                <td class="style2">
                    <asp:Label ID="lblCount" runat="server" CssClass="result" />
                </td>
            </tr>

            <tr>
                <td class="style1">Message:</td>
                <td class="style2">
                    <asp:Label ID="lblError" runat="server" CssClass="error" />
                </td>
            </tr>

            <div class="grid">
            <asp:GridView ID="gvDayWiseCount" runat="server" AutoGenerateColumns="false" BorderWidth="1" CellPadding="6">
                <Columns>
                    <asp:BoundField DataField="StartDate" HeaderText="Start Date" />
                    <asp:BoundField DataField="EndDate" HeaderText="End Date" />
                    <asp:BoundField DataField="TweetCount" HeaderText="Tweet Count" />
                </Columns>
            </asp:GridView>
        </div>
        </table>
    </form>
</body>
</html>