﻿using System;
using System.Configuration;
using System.IO;
using System.Net;
using System.Text;
using Newtonsoft.Json.Linq;

namespace TweetChecker
{
    public partial class TweetCounts : System.Web.UI.Page
    {
        // Twitter v2 counts endpoint (recent = last 7 days)
        private const string CountsRecentEndpoint = "https://api.twitter.com/2/tweets/counts/all";

        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["User"] == null)
            {
                Response.Redirect("Login.aspx");
            }
        }

        protected void btnGetCount_Click(object sender, EventArgs e)
        {
            lblError.Text = "";
            lblCount.Text = "";
            lblFinalQuery.Text = "";
            gvDayWiseCount.DataSource = null;
            gvDayWiseCount.DataBind();

            try
            {
                string inputQuery = (txtQuery.Text ?? "").Trim();
                if (string.IsNullOrWhiteSpace(inputQuery))
                {
                    lblError.Text = "Please enter a query.";
                    return;
                }

                // Build final query: (userQuery) -is:retweet
                string finalQuery = "(" + inputQuery + ") -is:retweet";
                lblFinalQuery.Text = finalQuery;

                DateTime fromDate;
                DateTime toDate;

                if (!DateTime.TryParse(txtFromDate.Text, out fromDate))
                {
                    lblError.Text = "Please enter valid From Date.";
                    return;
                }

                if (!DateTime.TryParse(txtToDate.Text, out toDate))
                {
                    lblError.Text = "Please enter valid To Date.";
                    return;
                }

                if (toDate <= fromDate)
                {
                    lblError.Text = "To Date should be greater than From Date.";
                    return;
                }

                string startTime = fromDate.ToUniversalTime().ToString("yyyy-MM-ddTHH:mm:ssZ");
                string endTime = toDate.ToUniversalTime().ToString("yyyy-MM-ddTHH:mm:ssZ");

                // Read Bearer Token from web.config
                string bearerToken = "AAAAAAAAAAAAAAAAAAAAANX73wEAAAAAdjVdtQe2QwvTAZu%2FPMW4Drgnh9I%3DTvIzpVLz7VxbB6Or9N9lfwFps30xrsSeRl8FLj8rtK4XWazmFD";// ConfigurationManager.AppSettings["TwitterBearerToken"];
                if (string.IsNullOrWhiteSpace(bearerToken))
                {
                    lblError.Text = "TwitterBearerToken is missing in web.config AppSettings.";
                    return;
                }

                long total = GetTweetCountSumDayWise(CountsRecentEndpoint, bearerToken, finalQuery, startTime, endTime);

                lblCount.Text = total.ToString();
            }
            catch (WebException wex)
            {
                lblError.Text = "API error: " + ReadWebException(wex);
            }
            catch (Exception ex)
            {
                lblError.Text = "Error: " + ex.Message;
            }
        }

        /// <summary>
        /// Fetch counts with granularity=day and sum tweet_count.
        /// Includes pagination (next_token) just in case.
        /// </summary>
        private long GetTweetCountSumDayWise(string endpointBaseUrl, string bearerToken, string finalQuery,string startTime,string endTime)
        {
            long total = 0;
            string nextToken = null;

           

            string json = "";

            string url = endpointBaseUrl
                    + "?query=" + Uri.EscapeDataString(finalQuery)
                    + "&start_time=" + Uri.EscapeDataString(startTime)
                    + "&end_time=" + Uri.EscapeDataString(endTime)
                    + "&granularity=day";

            ServicePointManager.SecurityProtocol = (SecurityProtocolType)3072; // TLS 1.2

            try
            {
                HttpWebRequest request = (HttpWebRequest)WebRequest.Create(url);
                request.Method = "GET";
                request.ContentType = "application/json";

                request.Headers.Add("Authorization", "Bearer " + bearerToken);

                using (HttpWebResponse response = (HttpWebResponse)request.GetResponse())
                {
                    using (StreamReader reader = new StreamReader(response.GetResponseStream()))
                    {
                        json = reader.ReadToEnd();
                    }
                }
            }
            catch (WebException ex)
            {
                if (ex.Response != null)
                {
                    using (StreamReader reader = new StreamReader(ex.Response.GetResponseStream()))
                    {
                        json = reader.ReadToEnd();
                    }
                }
                else
                {
                    json = ex.Message;
                }
            }

            do
            {

                JObject root = JObject.Parse(json);

                // Sum day-wise tweet_count
                JToken dataToken = root["data"];
                if (dataToken != null && dataToken.Type == JTokenType.Array)
                {
                    foreach (JToken item in dataToken)
                    {
                        long count = SafeLong(item["tweet_count"]);
                        total += count;
                    }
                }

                // Pagination
                nextToken = null;
                JToken meta = root["meta"];
                if (meta != null && meta["next_token"] != null)
                {
                    nextToken = meta["next_token"].ToString();
                    if (string.IsNullOrWhiteSpace(nextToken))
                        nextToken = null;
                }

            } while (!string.IsNullOrEmpty(nextToken));

            return total;
        }

        

        private static long SafeLong(JToken token)
        {
            if (token == null) return 0;
            long v;
            return long.TryParse(token.ToString(), out v) ? v : 0;
        }

        private static string ReadWebException(WebException wex)
        {
            try
            {
                if (wex.Response == null) return wex.Message;

                using (var resp = (HttpWebResponse)wex.Response)
                using (var sr = new StreamReader(resp.GetResponseStream()))
                {
                    string body = sr.ReadToEnd();
                    return resp.StatusCode + " - " + body;
                }
            }
            catch
            {
                return wex.Message;
            }
        }
    }
}