﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net;
using System.IO;

namespace APITester
{
    class Program
    {
        static void Main(string[] args)
        {
            string url = "https://sso.pranapr.com/api/Common/SSO_Check_Token";
                    

                    try
                    {

                        

                        // Create the request
                        ServicePointManager.Expect100Continue = true;
                        ServicePointManager.SecurityProtocol = (SecurityProtocolType)3072;
                        ServicePointManager.ServerCertificateValidationCallback +=(sender, cert, chain, sslPolicyErrors) => true;
                        HttpWebRequest request = (HttpWebRequest)WebRequest.Create(url);
                        request.Method = "POST";
                        request.ContentType = "text/plain";


                        // Authorization Header
                        request.Headers.Add(
                            HttpRequestHeader.Authorization,
                            "Bearer " + "eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsImtpZCI6InNNMV95QXhWOEdWNHlOLUI2ajJ4em1pazVBbyJ9.eyJhdWQiOiIwYjM4NzFiMS1iYWNiLTQ5ZjEtOGQ1Ny0xMjQ4OTAxNzAwYTAiLCJpc3MiOiJodHRwczovL2xvZ2luLm1pY3Jvc29mdG9ubGluZS5jb20vMTlkZjc5MDEtYjY1Mi00ZTc0LWI4NzEtMzJjZGVhOGM3YTdjL3YyLjAiLCJpYXQiOjE3NzE1ODAzNzAsIm5iZiI6MTc3MTU4MDM3MCwiZXhwIjoxNzcxNTg0MjcwLCJhaW8iOiJBWFFBaS84YkFBQUFNS3F6SCsrNzQ4WjBNWGNLTTFJVFc3bm9JbDJrZTlObTFiR3ZpM1hXaEhlZG1NQlJiNUlDVHdxMkhnQklIdzVOYXJYckJvbHBRb0tJOGVyL3prNE1wemhWT0owRWt4dm1CMDVPV0tUeE8vZVVTcHhwR0pXREw3dkYzNXkxRFVWTHNUcU5YaXVaNEY3SzR2dTFaZG5QbEE9PSIsImVtYWlsIjoibWF5dXJlc2guam9zaGlAYWRmYWN0b3JzcHIuY29tIiwibmFtZSI6Ik1heXVyZXNoIEpvc2hpIiwibm9uY2UiOiIwMTljN2E2Zi1hZGRkLTcxNDctYjY2Mi1iYzkxYmRjNDc0NDgiLCJvaWQiOiI4ZTE3NzVlZC04NWRjLTQyNTYtYjgzZi1hZWJhYmU1NDJlYWYiLCJwcmVmZXJyZWRfdXNlcm5hbWUiOiJtYXl1cmVzaC5qb3NoaUBhZGZhY3RvcnNwci5jb20iLCJyaCI6IjEuQVZVQUFYbmZHVksyZEU2NGNUTE42b3g2ZkxGeE9Bdkx1dkZKalZjU1NKQVhBS0F5QVdGVkFBLiIsInNpZCI6IjAwMTQwNTFhLWJhMmMtMjQ4Mi04NjI3LTFiYmJmYjUxNzk2MyIsInN1YiI6IjR0eEtVQ084X0lkU2FNbHRNeVJVa2pqb1M3TkdlbkQyRklqQThJRWRHLVUiLCJ0aWQiOiIxOWRmNzkwMS1iNjUyLTRlNzQtYjg3MS0zMmNkZWE4YzdhN2MiLCJ1dGkiOiJlREluaVpPR05VU1Z4d1M5Y25nakFBIiwidmVyIjoiMi4wIn0.H_glZG97hUwtZ2Bx7F52F8wKkYRIAQmphdP8bHdf1PIF8cVYJt3TOcnXLFykcVlR8BwmsN0a7_vAY158aoKpyeieOyNbQBdpWSmMWyqw4HAD-duk2U0NowO2IAyUwYfuP9pVKYz57I-ra-K0fWo0E4OXhgVjA6Coi1dAu669SWRzI6yPZqyMgo2crRsRZFYAP8EdWMT3FTY7Z68RM8dcGfF2tiyitp0TnymlzPP9GyPb_SEWh9nHOYx8vjC6fXLlatLfQz4ieXz8KOYd3LT4m7TWC_CJpu0bLcOiLIclBAiJnHAOUl2P0rguvJXjoeryIlMdODCc92YdFS5mmDD5iA"
                        );

                        // Empty body
                        byte[] data = Encoding.UTF8.GetBytes("");
                        request.ContentLength = data.Length;

                        using (Stream stream = request.GetRequestStream())
                        {
                            stream.Write(data, 0, data.Length);
                        }

                        // Get response
                        using (HttpWebResponse response = (HttpWebResponse)request.GetResponse())
                        {
                            using (StreamReader reader = new StreamReader(response.GetResponseStream()))
                            {
                                bool flag = false;
                                string responseText = reader.ReadToEnd();
                                //Log("FetchUser_AD_Azure responseText", responseText);

                                // Basic check for "status":"success"
                                if (responseText.Contains("\"message\":\"Token is valid\""))
                                {
                                    //Console.WriteLine("✅ Login successful!");
                                    flag = true;
                                }
                                else
                                {
                                    //Console.WriteLine("❌ Login failed.");
                                    flag = false;
                                }
                            }
                        }
                    }
                    catch (WebException ex)
                    {
                    }
            
        }

    }
}
