﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.IO;
using System.Diagnostics;
using System.Threading.Tasks;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json;
using System.Runtime.Serialization;
using System.Net.Mail;
using System.Web;
using OfficeOpenXml;
using OfficeOpenXml.Style;
using System.Drawing;
using System.Net;
using OfficeOpenXml.ConditionalFormatting;
using OfficeOpenXml.Drawing.Chart;

namespace UserRequest_DataDownload
{
    public class DownloadData
    {
        public void DoProcess()
        {
            try
            {
                var stopWatch = Stopwatch.StartNew();
                ParallelOptions po = new ParallelOptions();
                po.MaxDegreeOfParallelism = Convert.ToInt32(ConfigurationManager.AppSettings["MaxDegreeOfParallelism"].ToString());
                System.Net.ServicePointManager.DefaultConnectionLimit = Convert.ToInt32(ConfigurationManager.AppSettings["MaxDegreeOfParallelism"].ToString());

                ErrorLog("Program", "Start");
                ErrorLog("FetchPending_UserRequest_DataDownload", "Start");

                DataTable _dt = new DataTable();
                _dt = FetchPending_UserRequest_DataDownload();

                ErrorLog("FetchPending_UserRequest_DataDownload", "End");
                ErrorLog("FetchPending_UserRequest_DataDownload Table Rows", Convert.ToString(_dt.Rows.Count));


                if (_dt.Rows.Count > 0)
                {
                    var setting = new JsonSerializerSettings { MaxDepth = int.MaxValue };

                    Parallel.For(0, _dt.Rows.Count, po, i =>
                    {
                        try
                        {
                            Int32 UDDRID = Convert.ToInt32(_dt.Rows[i]["UDDRID"].ToString());
                            string strEmail = _dt.Rows[i]["Email"].ToString();
                            //strEmail = "mayuresh.joshi@adfactorspr.com";
                            string strRequestJson = _dt.Rows[i]["RequestJson"].ToString();
                            string strTopicName = _dt.Rows[i]["TopicName"].ToString();
                            string UserName = _dt.Rows[i]["UserName"].ToString();
                            string UserEmailID = _dt.Rows[i]["Email"].ToString();

                            dynamic stuff = JObject.Parse(strRequestJson);

                            TimeLog("UDDRID Data Is " + UDDRID + " -> " + JsonConvert.SerializeObject(stuff, setting));

                            DataTable dtHtml = JsonConvert.DeserializeObject<DataTable>("[" + strRequestJson + "]");
                            //dtHtml.Columns.Remove("UserID");
                            //dtHtml.Columns.Remove("incident_id");

                            string[] columnsToRemove = { "UserID", "incident_id", "data_tag", "tag_id" };

                            foreach (string col in columnsToRemove)
                            {
                                if (dtHtml.Columns.Contains(col))
                                {
                                    dtHtml.Columns.Remove(col);
                                }
                            }

                            string strFilterDetails = string.Empty;
                            Int32 FilterColSpan = 1;
                            if (dtHtml.Rows.Count > 0)
                            {
                                strFilterDetails = "<tr>";
                                for (int c = 0; c < dtHtml.Columns.Count; c++)
                                {
                                    if (dtHtml.Rows[0][c].ToString() != "")
                                    {
                                        strFilterDetails = strFilterDetails + "<td>" + dtHtml.Columns[c].ColumnName + "</td>";
                                        FilterColSpan++;
                                    }
                                }
                                strFilterDetails = strFilterDetails + "</tr><tr>";

                                for (int r = 0; r < dtHtml.Rows.Count; r++)
                                {
                                    for (int c = 0; c < dtHtml.Columns.Count; c++)
                                    {
                                        if (dtHtml.Rows[0][c].ToString() != "")
                                        {
                                            strFilterDetails = strFilterDetails + "<td>" + Convert.ToString(dtHtml.Rows[r][c]) + "</td>";
                                        }
                                    }
                                }
                                strFilterDetails = strFilterDetails + "</tr>";
                            }


                            string platform = stuff.platform;
                            Int32 TopicID = Convert.ToInt32(Convert.ToString(stuff.incident_id));
                            Int32 UserID = Convert.ToInt32(Convert.ToString(stuff.UserID));

                            string FocusUserString = Convert.ToString(ConfigurationManager.AppSettings["FocusUserList"]);

                            List<int> focusUsers = FocusUserString.Split(',').Select(int.Parse).ToList();

                            bool isFocusUser = focusUsers.Contains(UserID);

                            if (platform.ToLower() == "twitter" || platform.ToLower() == "online" || platform.ToLower() == "print" || platform.ToLower() == "youtube")
                            {
                                #region Individual

                                DataSet ds = new DataSet();
                                Dictionary<string, DataSet> sources = new Dictionary<string, DataSet>();


                                if (platform.ToLower() == "twitter")
                                {
                                    ds = FetchData(ConfigurationManager.AppSettings["URL_API_Twitter"], strRequestJson);
                                    sources.Add("Twitter", CreateTwitterAnalyticsDataSet(strRequestJson));

                                    DataTable Twitter = new DataTable();
                                    DataTable Twitter_TML = new DataTable();

                                    if (ds != null)
                                    {
                                        if (ds.Tables.Count > 0)
                                        {
                                            if (ds.Tables[0] != null && ds.Tables[0].Rows.Count > 0)
                                            {
                                                Twitter = ds.Tables[0];
                                            }
                                            if (ds.Tables.Count > 1)
                                            {
                                                if (ds.Tables[1] != null && ds.Tables[1].Rows.Count > 0)
                                                {
                                                    Twitter_TML = ds.Tables[1];
                                                }
                                            }
                                        }

                                    }

                                    DataSet data = new DataSet();
                                    data.Tables.Clear();

                                    DataTable dtCopy_Twitter = new DataTable();
                                    DataTable dtCopy_Twitter_TML = new DataTable();

                                    dtCopy_Twitter = Twitter.Copy();
                                    dtCopy_Twitter_TML = Twitter_TML.Copy();

                                    dtCopy_Twitter.TableName = "Twitter";
                                    dtCopy_Twitter_TML.TableName = "TML_Info_Twitter";

                                    if (dtCopy_Twitter != null && dtCopy_Twitter.Rows.Count > 0)
                                    {
                                        data.Tables.Add(dtCopy_Twitter);
                                    }
                                    else
                                    {
                                        DataTable dt = new DataTable("Twitter");
                                        dt.Columns.Add("Message");
                                        dt.Rows.Add("No records found.");
                                        data.Tables.Add(dt);
                                    }

                                    //if (dtCopy_Twitter != null && dtCopy_Twitter.Rows.Count > 0 && isFocusUser)
                                    if (dtCopy_Twitter != null && dtCopy_Twitter.Rows.Count > 0)
                                    {
                                        data.Tables.Add(dtCopy_Twitter_TML);
                                    }
                                    //else
                                    //{
                                    //    DataTable dt = new DataTable("TML_Info_Twitter");
                                    //    dt.Columns.Add("Message");
                                    //    dt.Rows.Add("No records found.");
                                    //    data.Tables.Add(dt);
                                    //}

                                    Excel_Output_Final(data, strTopicName, strFilterDetails, FilterColSpan, strEmail, UDDRID, isFocusUser, sources);
                                }
                                else if (platform.ToLower() == "online")
                                {
                                    ds = FetchData(ConfigurationManager.AppSettings["URL_API_Online"], strRequestJson);
                                    sources.Add("Online", CreateOnlineAnalyticsDataSet(strRequestJson));

                                    DataTable Online = new DataTable();
                                    DataTable Online_TML = new DataTable();

                                    if (ds != null)
                                    {
                                        if (ds.Tables.Count > 0)
                                        {
                                            if (ds.Tables[0] != null && ds.Tables[0].Rows.Count > 0)
                                            {
                                                Online = ds.Tables[0];
                                            }
                                            if (ds.Tables.Count > 1)
                                            {
                                                if (ds.Tables[1] != null && ds.Tables[1].Rows.Count > 0)
                                                {
                                                    Online_TML = ds.Tables[1];
                                                }
                                            }
                                        }

                                    }

                                    DataSet data = new DataSet();
                                    data.Tables.Clear();

                                    DataTable dtCopy_Online = new DataTable();
                                    DataTable dtCopy_Online_TML = new DataTable();

                                    dtCopy_Online = Online.Copy();
                                    dtCopy_Online_TML = Online_TML.Copy();

                                    dtCopy_Online.TableName = "Online";
                                    dtCopy_Online_TML.TableName = "TML_Info_Online";

                                    if (dtCopy_Online != null && dtCopy_Online.Rows.Count > 0)
                                    {
                                        data.Tables.Add(dtCopy_Online);
                                    }
                                    else
                                    {
                                        DataTable dt = new DataTable("Online");
                                        dt.Columns.Add("Message");
                                        dt.Rows.Add("No records found.");
                                        data.Tables.Add(dt);
                                    }

                                    //if (dtCopy_Online_TML != null && dtCopy_Online_TML.Rows.Count > 0 && isFocusUser)
                                    if (dtCopy_Online_TML != null && dtCopy_Online_TML.Rows.Count > 0)
                                    {
                                        data.Tables.Add(dtCopy_Online_TML);
                                    }
                                    //else
                                    //{
                                    //    DataTable dt = new DataTable("TML_Info_Online");
                                    //    dt.Columns.Add("Message");
                                    //    dt.Rows.Add("No records found.");
                                    //    data.Tables.Add(dt);
                                    //}

                                    Excel_Output_Final(data, strTopicName, strFilterDetails, FilterColSpan, strEmail, UDDRID, isFocusUser, sources);
                                }
                                else if (platform.ToLower() == "print")
                                {
                                    ds = FetchData(ConfigurationManager.AppSettings["URL_API_Print"], strRequestJson);
                                    sources.Add("Print", CreatePrintAnalyticsDataSet(strRequestJson));

                                    DataTable Print = new DataTable();
                                    DataTable Print_TML = new DataTable();

                                    if (ds != null)
                                    {
                                        if (ds.Tables.Count > 0)
                                        {
                                            if (ds.Tables[0] != null && ds.Tables[0].Rows.Count > 0)
                                            {
                                                Print = ds.Tables[0];
                                            }
                                            if (ds.Tables.Count > 1)
                                            {
                                                if (ds.Tables[1] != null && ds.Tables[1].Rows.Count > 0)
                                                {
                                                    Print_TML = ds.Tables[1];
                                                }
                                            }
                                        }
                                    }

                                    DataSet data = new DataSet();
                                    data.Tables.Clear();

                                    DataTable dtCopy_Print = new DataTable();
                                    DataTable dtCopy_Print_TML = new DataTable();

                                    dtCopy_Print = Print.Copy();
                                    dtCopy_Print_TML = Print_TML.Copy();

                                    dtCopy_Print.TableName = "Print";
                                    dtCopy_Print_TML.TableName = "TML_Info_Print";

                                    if (dtCopy_Print != null && dtCopy_Print.Rows.Count > 0)
                                    {
                                        data.Tables.Add(dtCopy_Print);
                                    }
                                    else
                                    {
                                        DataTable dt = new DataTable("Print");
                                        dt.Columns.Add("Message");
                                        dt.Rows.Add("No records found.");
                                        data.Tables.Add(dt);
                                    }

                                    //if (dtCopy_Print_TML != null && dtCopy_Print_TML.Rows.Count > 0 && isFocusUser)
                                    if (dtCopy_Print_TML != null && dtCopy_Print_TML.Rows.Count > 0)
                                    {
                                        data.Tables.Add(dtCopy_Print_TML);
                                    }
                                    //else
                                    //{
                                    //    DataTable dt = new DataTable("TML_Info_Print");
                                    //    dt.Columns.Add("Message");
                                    //    dt.Rows.Add("No records found.");
                                    //    data.Tables.Add(dt);
                                    //}

                                    Excel_Output_Final(data, strTopicName, strFilterDetails, FilterColSpan, strEmail, UDDRID, isFocusUser, sources);
                                }
                                else if (platform.ToLower() == "youtube")
                                {
                                    ErrorLog("In YouTube", "");
                                    ds = FetchData(ConfigurationManager.AppSettings["URL_API_YouTube"], strRequestJson);
                                    sources.Add("YouTube", CreateYouTubeAnalyticsDataSet(strRequestJson));

                                    DataTable YouTube = new DataTable();
                                    DataTable YouTube_TML = new DataTable();

                                    if (ds != null)
                                    {
                                        if (ds.Tables.Count > 0)
                                        {
                                            if (ds.Tables[0] != null && ds.Tables[0].Rows.Count > 0)
                                            {
                                                YouTube = ds.Tables[0];
                                            }
                                            if (ds.Tables.Count > 1)
                                            {
                                                if (ds.Tables[1] != null && ds.Tables[1].Rows.Count > 0)
                                                {
                                                    YouTube_TML = ds.Tables[1];
                                                }
                                            }
                                        }
                                    }

                                    DataSet data = new DataSet();
                                    data.Tables.Clear();

                                    DataTable dtCopy_YouTube = new DataTable();
                                    DataTable dtCopy_YouTube_TML = new DataTable();

                                    dtCopy_YouTube = YouTube.Copy();
                                    dtCopy_YouTube_TML = YouTube_TML.Copy();

                                    dtCopy_YouTube.TableName = "YouTube";
                                    dtCopy_YouTube_TML.TableName = "TML_Info_YouTube";

                                    if (YouTube != null && YouTube.Rows.Count > 0)
                                    {
                                        data.Tables.Add(dtCopy_YouTube);
                                    }
                                    else
                                    {
                                        DataTable dt = new DataTable("YouTube");
                                        dt.Columns.Add("Message");
                                        dt.Rows.Add("No records found.");
                                        data.Tables.Add(dt);
                                    }

                                    //if (dtCopy_YouTube_TML != null && dtCopy_YouTube_TML.Rows.Count > 0 && isFocusUser)
                                    if (dtCopy_YouTube_TML != null && dtCopy_YouTube_TML.Rows.Count > 0)
                                    {
                                        data.Tables.Add(dtCopy_YouTube_TML);
                                    }
                                    //else
                                    //{
                                    //    DataTable dt = new DataTable("TML_Info_YouTube");
                                    //    dt.Columns.Add("Message");
                                    //    dt.Rows.Add("No records found.");
                                    //    data.Tables.Add(dt);
                                    //}

                                    Excel_Output_Final(data, strTopicName, strFilterDetails, FilterColSpan, strEmail, UDDRID, isFocusUser, sources);
                                }

                                //if (ds != null && ds.Tables.Count > 0)
                                //{


                                //    string FileName = "SentryV2_Data_" + DateTime.Now.ToString("dd_MM_yyyy_HH_mm_ss") + ".xlsx";
                                //    string strReturnFileName = ExportToExcel(dtData, platform.ToLower(), FileName);
                                //    if (!String.IsNullOrEmpty(strReturnFileName))
                                //    {
                                //        string ReadFile = File.ReadAllText(ConfigurationManager.AppSettings["MailBody"]);
                                //        ReadFile = ReadFile.Replace("#ClientName#", strTopicName);
                                //        ReadFile = ReadFile.Replace("#FilterDetails#", strFilterDetails);
                                //        ReadFile = ReadFile.Replace("#FilterColSpan#", FilterColSpan.ToString());
                                //        bool IsSent = SendMail(strEmail, ReadFile, ConfigurationManager.AppSettings["MailSubject"].ToString() + " -> " + strTopicName, strReturnFileName, ConfigurationManager.AppSettings["CCEmailID"].ToString(), ConfigurationManager.AppSettings["BCCEmailID"].ToString());
                                //        if (IsSent == true)
                                //        {
                                //            Update_UserRequest_DataDownload(UDDRID);
                                //        }
                                //    }
                                //}
                                #endregion
                            }
                            else if (platform.ToLower() == "event_report")
                            {
                                #region Combined

                                bool Is_Data_Available_Online = false;
                                bool Is_Data_Available_Print = false;
                                bool Is_Data_Available_Twitter = false;
                                bool Is_Data_Available_YouTube = false;

                                Dictionary<string, DataSet> sources = new Dictionary<string, DataSet>();
                                DataSet ds = new DataSet();
                                ds.Tables.Clear();

                                DataSet Twitter_ds = FetchData(ConfigurationManager.AppSettings["URL_API_Twitter"], strRequestJson);
                                DataSet Online_ds = FetchData(ConfigurationManager.AppSettings["URL_API_Online"], strRequestJson);
                                DataSet Print_ds = FetchData(ConfigurationManager.AppSettings["URL_API_Print"], strRequestJson);
                                DataSet YouTube_ds = FetchData(ConfigurationManager.AppSettings["URL_API_YouTube"], strRequestJson);

                                sources.Add("Online", CreateOnlineAnalyticsDataSet(strRequestJson));
                                sources.Add("Print", CreatePrintAnalyticsDataSet(strRequestJson));
                                sources.Add("Twitter", CreateTwitterAnalyticsDataSet(strRequestJson));
                                sources.Add("YouTube", CreateYouTubeAnalyticsDataSet(strRequestJson));

                                DataTable Twitter = new DataTable();
                                DataTable Twitter_TML = new DataTable();
                                DataTable Online = new DataTable();
                                DataTable Online_TML = new DataTable();
                                DataTable Print = new DataTable();
                                DataTable Print_TML = new DataTable();
                                DataTable YouTube = new DataTable();
                                DataTable YouTube_TML = new DataTable();

                                if (Twitter_ds != null)
                                {
                                    if (Twitter_ds.Tables.Count > 0)
                                    {
                                        if (Twitter_ds.Tables[0] != null && Twitter_ds.Tables[0].Rows.Count > 0)
                                        {
                                            Twitter = Twitter_ds.Tables[0];
                                        }
                                        if (Twitter_ds.Tables.Count > 1)
                                        {
                                            if (Twitter_ds.Tables[1] != null && Twitter_ds.Tables[1].Rows.Count > 0)
                                            {
                                                Twitter_TML = Twitter_ds.Tables[1];
                                            }
                                        }
                                    }

                                }
                                if (Online_ds != null)
                                {
                                    if (Online_ds.Tables.Count > 0)
                                    {
                                        if (Online_ds.Tables[0] != null && Online_ds.Tables[0].Rows.Count > 0)
                                        {
                                            Online = Online_ds.Tables[0];
                                        }
                                        if (Online_ds.Tables.Count > 1)
                                        {
                                            if (Online_ds.Tables[1] != null && Online_ds.Tables[1].Rows.Count > 0)
                                            {
                                                Online_TML = Online_ds.Tables[1];
                                            }
                                        }
                                    }

                                }
                                if (Print_ds != null)
                                {
                                    if (Print_ds.Tables.Count > 0)
                                    {
                                        if (Print_ds.Tables[0] != null && Print_ds.Tables[0].Rows.Count > 0)
                                        {
                                            Print = Print_ds.Tables[0];
                                        }
                                        if (Print_ds.Tables.Count > 1)
                                        {
                                            if (Print_ds.Tables[1] != null && Print_ds.Tables[1].Rows.Count > 0)
                                            {
                                                Print_TML = Print_ds.Tables[1];
                                            }
                                        }

                                    }

                                }
                                if (YouTube_ds != null)
                                {
                                    if (YouTube_ds.Tables.Count > 0)
                                    {
                                        if (YouTube_ds.Tables[0] != null && YouTube_ds.Tables[0].Rows.Count > 0)
                                        {
                                            YouTube = YouTube_ds.Tables[0];
                                        }
                                        if (YouTube_ds.Tables.Count > 1)
                                        {
                                            if (YouTube_ds.Tables[1] != null && YouTube_ds.Tables[1].Rows.Count > 0)
                                            {
                                                YouTube_TML = YouTube_ds.Tables[1];
                                            }
                                        }
                                    }

                                }



                                DataTable dtCopy_Twitter = new DataTable();
                                DataTable dtCopy_Online = new DataTable();
                                DataTable dtCopy_Print = new DataTable();
                                DataTable dtCopy_YouTube = new DataTable();

                                DataTable dtCopy_Twitter_TML = new DataTable();
                                DataTable dtCopy_Online_TML = new DataTable();
                                DataTable dtCopy_Print_TML = new DataTable();
                                DataTable dtCopy_YouTube_TML = new DataTable();

                                ds.Tables.Clear();

                                dtCopy_Twitter = Twitter.Copy();
                                dtCopy_Online = Online.Copy();
                                dtCopy_Print = Print.Copy();
                                dtCopy_YouTube = YouTube.Copy();

                                dtCopy_Twitter_TML = Twitter_TML.Copy();
                                dtCopy_Online_TML = Online_TML.Copy();
                                dtCopy_Print_TML = Print_TML.Copy();
                                dtCopy_YouTube_TML = YouTube_TML.Copy();

                                dtCopy_Twitter.TableName = "Twitter";
                                dtCopy_Online.TableName = "Online";
                                dtCopy_Print.TableName = "Print";
                                dtCopy_YouTube.TableName = "YouTube";

                                dtCopy_Twitter_TML.TableName = "TML_Info_Twitter";
                                dtCopy_Online_TML.TableName = "TML_Info_Online";
                                dtCopy_Print_TML.TableName = "TML_Info_Print";
                                dtCopy_YouTube_TML.TableName = "TML_Info_YouTube";

                                if (dtCopy_Online != null)
                                {
                                    if (dtCopy_Online.Rows.Count > 0)
                                    {
                                        ds.Tables.Add(dtCopy_Online);
                                        //if (dtCopy_Online_TML != null && dtCopy_Online_TML.Rows.Count > 0 && isFocusUser)
                                        if (dtCopy_Online_TML != null && dtCopy_Online_TML.Rows.Count > 0)
                                        {
                                            ds.Tables.Add(dtCopy_Online_TML);
                                        }
                                        Is_Data_Available_Online = true;
                                    }
                                    //else
                                    //{
                                    //    DataTable dt = new DataTable("Online");
                                    //    dt.Columns.Add("Message");
                                    //    dt.Rows.Add("No records found.");
                                    //    ds.Tables.Add(dt);
                                    //}

                                }
                                if (dtCopy_Print != null)
                                {
                                    if (dtCopy_Print.Rows.Count > 0)
                                    {
                                        ds.Tables.Add(dtCopy_Print);
                                        //if (dtCopy_Print_TML != null && dtCopy_Print_TML.Rows.Count > 0 && isFocusUser)
                                        if (dtCopy_Print_TML != null && dtCopy_Print_TML.Rows.Count > 0)
                                        {
                                            ds.Tables.Add(dtCopy_Print_TML);
                                        }
                                        Is_Data_Available_Print = true;
                                    }
                                    //else
                                    //{
                                    //    DataTable dt = new DataTable("Print");
                                    //    dt.Columns.Add("Message");
                                    //    dt.Rows.Add("No records found.");
                                    //    ds.Tables.Add(dt);
                                    //}

                                }
                                if (dtCopy_Twitter != null)
                                {
                                    if (dtCopy_Twitter.Rows.Count > 0)
                                    {
                                        ds.Tables.Add(dtCopy_Twitter);
                                        //if (dtCopy_Twitter_TML != null && dtCopy_Twitter_TML.Rows.Count > 0 && isFocusUser)
                                        if (dtCopy_Twitter_TML != null && dtCopy_Twitter_TML.Rows.Count > 0)
                                        {
                                            ds.Tables.Add(dtCopy_Twitter_TML);
                                        }
                                        Is_Data_Available_Twitter = true;
                                    }
                                    //else
                                    //{
                                    //    DataTable dt = new DataTable("Twitter");
                                    //    dt.Columns.Add("Message");
                                    //    dt.Rows.Add("No records found.");
                                    //    ds.Tables.Add(dt);
                                    //}
                                }
                                if (dtCopy_YouTube != null)
                                {
                                    if (dtCopy_YouTube.Rows.Count > 0)
                                    {
                                        ds.Tables.Add(dtCopy_YouTube);
                                        //if (dtCopy_YouTube_TML != null && dtCopy_YouTube_TML.Rows.Count > 0 && isFocusUser)
                                        if (dtCopy_YouTube_TML != null && dtCopy_YouTube_TML.Rows.Count > 0)
                                        {
                                            ds.Tables.Add(dtCopy_YouTube_TML);
                                        }
                                        Is_Data_Available_YouTube = true;
                                    }
                                    //else
                                    //{
                                    //    DataTable dt = new DataTable("YouTube");
                                    //    dt.Columns.Add("Message");
                                    //    dt.Rows.Add("No records found.");
                                    //    ds.Tables.Add(dt);
                                    //}

                                }

                                if (Is_Data_Available_Online || Is_Data_Available_Print || Is_Data_Available_Twitter || Is_Data_Available_YouTube)
                                {
                                    Excel_Output_Final(ds, strTopicName, strFilterDetails, FilterColSpan, strEmail, UDDRID, isFocusUser, sources);
                                }

                                #endregion
                            }

                        }
                        catch (Exception ex)
                        {
                            ErrorLog("Parallel Error for " + Convert.ToInt32(_dt.Rows[i]["UDDRID"].ToString()), ex.ToString());
                        }
                        finally
                        {
                            Update_TryCount(Convert.ToInt32(_dt.Rows[i]["UDDRID"].ToString()));
                        }

                    }

                    );
                    TimeLog("End Parallel.For");
                    TimeLog("Parallel.For() execution time for " + " = {0} seconds:" + stopWatch.Elapsed.TotalSeconds);
                }
            }
            catch (Exception ex)
            {
                ErrorLog("DoProcess", ex.ToString());
            }
        }

        public DataTable FetchPending_UserRequest_DataDownload()
        {

            DataTable _dt = new DataTable();
            DataSet _dtSet = new DataSet();
            SqlCommand _sqlCommand = new SqlCommand();

            try
            {
                SqlConnection _sqlConnection = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ToString());

                _sqlCommand.Connection = _sqlConnection;
                _sqlCommand.Connection.Open();
                _sqlCommand.CommandText = "USP_Service_SentryV2_FetchPending_URDataDownload";
                _sqlCommand.CommandType = CommandType.Text;
                _sqlCommand.CommandTimeout = Convert.ToInt32(ConfigurationManager.AppSettings["SP_Timeout"]);
                //_sqlCommand.Parameters.AddWithValue("@MessageID", "Select");
                SqlDataAdapter _sqlDataAdapter = new SqlDataAdapter(_sqlCommand);

                _sqlDataAdapter.Fill(_dtSet);

                if (_dtSet != null && _dtSet.Tables.Count > 0)
                {
                    _dt = _dtSet.Tables[0];
                }

            }
            catch (Exception ex)
            {
                ErrorLog("FetchPending_UserRequest_DataDownload", ex.Message + " ->> " + ex.StackTrace);
            }

            return _dt;
        }

        public bool Update_UserRequest_DataDownload(Int32 UDDRID)
        {
            bool IsResult = false;
            DataTable _dt = new DataTable();
            DataSet _dtSet = new DataSet();
            SqlCommand _sqlCommand = new SqlCommand();

            try
            {
                SqlConnection _sqlConnection = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ToString());

                _sqlCommand.Connection = _sqlConnection;
                _sqlCommand.Connection.Open();
                _sqlCommand.CommandText = "USP_Service_SentryV2_Update_UR_DataDownload";
                _sqlCommand.CommandType = CommandType.StoredProcedure;
                _sqlCommand.Parameters.AddWithValue("@UDDRID", UDDRID);
                int result = Convert.ToInt32(_sqlCommand.ExecuteNonQuery());
                if (result > 0)
                {
                    IsResult = true;
                }

            }
            catch (Exception ex)
            {
                ErrorLog("Update_UserRequest_DataDownload", ex.Message + " ->> " + ex.StackTrace);
            }
            finally
            {
                _sqlCommand.Connection.Close();
                _sqlCommand.Connection.Dispose();
            }

            return IsResult;
        }

        //public DataTable FetchData(string strUrl,string strJson)
        //{

        //    DataTable dt = new DataTable();
        //    try
        //    {
        //        string strToken = ConfigurationManager.AppSettings["URL_API_Token"];

        //        HttpWebRequest request = (HttpWebRequest)WebRequest.Create(strUrl);
        //        request.Headers["token"] = strToken;


        //        //Create bytes array to send Input as parameter
        //        byte[] bytes = bytes = Encoding.UTF8.GetBytes(strJson);

        //        //Set request options
        //        request.ContentType = "application/json; charset=utf8";
        //        request.ContentLength = bytes.Length;
        //        request.Method = "POST";
        //        request.Timeout = Convert.ToInt32(ConfigurationManager.AppSettings["API_Timeout"]);

        //        //Upload bytes array to request
        //        using (Stream os = request.GetRequestStream())
        //        {
        //            os.Write(bytes, 0, bytes.Length);
        //        }



        //        //Get response from TextProcessingPipeline
        //        using (System.Net.WebResponse resp = request.GetResponse())
        //        {
        //            using (StreamReader sr = new StreamReader(resp.GetResponseStream()))
        //            {
        //                string strOutput = sr.ReadToEnd().Trim();
        //                ErrorLog("In - " + strUrl.ToString(), strOutput);
        //                if (!String.IsNullOrEmpty(strOutput))
        //                {
        //                    JObject obj = JObject.Parse(strOutput);
        //                    if (obj != null)
        //                    {
        //                        JArray jItems = (JArray)obj["data"];
        //                        if (jItems != null)
        //                        {
        //                            dt = (DataTable)JsonConvert.DeserializeObject(jItems.ToString(), (typeof(DataTable)));
        //                        }
        //                    }
        //                }
        //            }
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        ErrorLog("FetchData", ex.Message + " ->> " + ex.StackTrace);
        //    }

        //    return dt;
        //}

        public DataSet FetchData(string strUrl, string strJson)
        {

            DataSet ds = new DataSet();
            try
            {
                string strToken = ConfigurationManager.AppSettings["URL_API_Token"];

                HttpWebRequest request = (HttpWebRequest)WebRequest.Create(strUrl);
                request.Headers["token"] = strToken;


                //Create bytes array to send Input as parameter
                byte[] bytes = bytes = Encoding.UTF8.GetBytes(strJson);

                //Set request options
                request.ContentType = "application/json; charset=utf8";
                request.ContentLength = bytes.Length;
                request.Method = "POST";
                request.Timeout = Convert.ToInt32(ConfigurationManager.AppSettings["API_Timeout"]);

                //Upload bytes array to request
                using (Stream os = request.GetRequestStream())
                {
                    os.Write(bytes, 0, bytes.Length);
                }



                //Get response from TextProcessingPipeline
                using (System.Net.WebResponse resp = request.GetResponse())
                {
                    using (StreamReader sr = new StreamReader(resp.GetResponseStream()))
                    {
                        string strOutput = sr.ReadToEnd().Trim();
                        //ErrorLog("In - " + strUrl.ToString(), strOutput);
                        if (!String.IsNullOrEmpty(strOutput))
                        {
                            JObject obj = JObject.Parse(strOutput);
                            if (obj != null)
                            {
                                JArray jItems = (JArray)obj["data"];
                                if (jItems != null)
                                {
                                    DataTable dt = (DataTable)JsonConvert.DeserializeObject(jItems.ToString(), (typeof(DataTable)));
                                    ds.Tables.Add(dt);
                                }
                                JArray jItems_tml = (JArray)obj["tml_data"];
                                if (jItems_tml != null)
                                {
                                    DataTable dt = (DataTable)JsonConvert.DeserializeObject(jItems_tml.ToString(), (typeof(DataTable)));
                                    ds.Tables.Add(dt);
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorLog("FetchData", ex.Message + " ->> " + ex.StackTrace);
            }

            return ds;
        }

        #region ValidateRequest & Log & Email & Excel

        //For error logging
        private static void ErrorLog(string functionName, string error)
        {
            try
            {
                string LogPath = ConfigurationManager.AppSettings["ErrorLogPath"];
                using (TextWriter myWriter = File.AppendText(LogPath))
                {

                    TextWriter.Synchronized(myWriter).WriteLine("<--> :{0}", string.Empty);
                    TextWriter.Synchronized(myWriter).WriteLine("Function Name :{0}", functionName);
                    TextWriter.Synchronized(myWriter).WriteLine("Error :{0}", error);
                    TextWriter.Synchronized(myWriter).WriteLine("Date :{0}", DateTime.Now.ToString());
                    TextWriter.Synchronized(myWriter).WriteLine("<--> :{0}", string.Empty);
                    TextWriter.Synchronized(myWriter).Flush();
                    TextWriter.Synchronized(myWriter).Close();
                }
            }
            catch (Exception ex)
            {
            }
        }

        //For debugging purpose
        private static void TimeLog(string strtext)
        {
            try
            {
                string LogPath = ConfigurationManager.AppSettings["TimeLogPath"];
                using (TextWriter myWriter = File.AppendText(LogPath))
                {

                    TextWriter.Synchronized(myWriter).WriteLine("<--> :{0}", string.Empty);
                    TextWriter.Synchronized(myWriter).WriteLine("TimeLog :{0}", strtext);
                    TextWriter.Synchronized(myWriter).WriteLine("Date :{0}", DateTime.Now.ToString());
                    TextWriter.Synchronized(myWriter).WriteLine("<--> :{0}", string.Empty);
                    TextWriter.Synchronized(myWriter).Flush();
                    TextWriter.Synchronized(myWriter).Close();
                }
            }
            catch (Exception ex)
            {
                ErrorLog("TimeLog", ex.ToString());
            }
        }

        private bool SendMail(string ToMailID, string Body, string Subject, string FilePath, string CCMailID, string BCCMailID)
        {

            bool IsSent = false;
            try
            {
                //Get From App Config From MailID
                string FromMailID = ConfigurationManager.AppSettings["FromMailAddress"].ToString();
                //Set From Mail ID To MailAddress Properties
                MailAddress ObjFrom = new MailAddress(FromMailID, ConfigurationManager.AppSettings["FromDisplayName"].ToString());
                //Call the refrence of ddll system.net.mail.MailMessage which help to send you mail
                System.Net.Mail.MailMessage mails = new System.Net.Mail.MailMessage();
                //Define all proprties related mail configration
                //Set from mail ID here
                mails.From = ObjFrom;
                //Multiple TO Mailid which available comma sepreated the split bu (,)
                string[] SplitTOMailID = ToMailID.Split(',');
                //if array is available the using foreach loop get one by one id 
                foreach (string ToMailIDValues in SplitTOMailID)
                {
                    //Check here if id is not null or blank
                    if (!string.IsNullOrEmpty(ToMailIDValues))
                    {
                        //Here add in To MailID Properites
                        mails.To.Add(ToMailIDValues);
                    }
                }
                //Multiple CC Mailid which available comma sepreated the split bu (,)
                string[] SplitCCMailID = CCMailID.Split(',');
                foreach (string CCMailIDValues in SplitCCMailID)
                {
                    //Check here if id is not null or blank
                    if (!string.IsNullOrEmpty(CCMailIDValues))
                    {
                        //Here add in CC MailID Properites
                        mails.CC.Add(CCMailIDValues);
                    }
                }
                //Multiple BCC Mailid which available comma sepreated the split bu (,)
                string[] SplitBCCMailID = BCCMailID.Split(',');
                foreach (string CCMailIDValues in SplitBCCMailID)
                {
                    //Check here if id is not null or blank
                    if (!string.IsNullOrEmpty(CCMailIDValues))
                    {
                        //Here add in BCC MailID Properites
                        mails.Bcc.Add(CCMailIDValues);
                    }
                }
                // Set Subject
                mails.Subject = Subject.Replace('\r', ' ').Replace('\n', ' ');
                mails.Subject = HttpUtility.HtmlDecode(mails.Subject);
                //if Set html body then always set true
                mails.IsBodyHtml = true;
                //set Message Body
                mails.Body = Body;

                #region Attachment
                //attachment file is exist or not check
                if (File.Exists(FilePath))
                {
                    //if yes the attach the excel sheet
                    Attachment attach = new Attachment(FilePath);
                    //add in mail
                    mails.Attachments.Add(attach);
                }
                #endregion


                //Call SMTP as alias objSMTP
                SmtpClient objSMTP = new SmtpClient();


                if (ConfigurationManager.AppSettings["MailServer"].ToString() == "smtp1.projectstoday.com")
                {
                    objSMTP = new SmtpClient();
                    objSMTP.Host = ConfigurationManager.AppSettings["Host"].ToString();
                    objSMTP.Port = Convert.ToInt32(ConfigurationManager.AppSettings["Port"]);
                    objSMTP.EnableSsl = true;
                    objSMTP.DeliveryMethod = SmtpDeliveryMethod.Network;
                    var fromAddress = new MailAddress(ConfigurationManager.AppSettings["FromMailAddress"].ToString(), ConfigurationManager.AppSettings["FromDisplayName"].ToString());
                    objSMTP.Credentials = new NetworkCredential(fromAddress.Address, ConfigurationManager.AppSettings["Password"].ToString());
                }




                // and finally send mail
                objSMTP.Send(mails);
                IsSent = true;
            }
            //catch (SmtpException ex)
            //{
            //    ErrorLog("SendMail ", ex.ToString() + " ->> " + ex.Message + " ->> " + ex.StackTrace);
            //    //SendMail(ConfigurationManager.AppSettings["MailErrorID"].ToString(), ex.ToString(), "Error In SendMail Function", "", "", "");
            //}
            catch (Exception ex)
            {
                ErrorLog("SendMail ", ex.ToString() + " ->> " + ex.Message + " ->> " + ex.StackTrace);
                //throw err;
            }

            return IsSent;
        }

        private string ExportToExcel(DataTable dtData, string SheetName, string FileName)
        {
            string FilePath = ConfigurationManager.AppSettings["ExcelSavePath"];

            if (dtData.Columns.Contains("incident_id"))
            {
                dtData.Columns.Remove("incident_id");
            }
            if (dtData.Columns.Contains("article_id"))
            {
                dtData.Columns.Remove("article_id");
            }
            if (dtData.Columns.Contains("twitter_id"))
            {
                dtData.Columns.Remove("twitter_id");
            }
            if (dtData.Columns.Contains("video_id"))
            {
                dtData.Columns.Remove("video_id");
            }

            string strReturn = FilePath + FileName;
            DataTable dtCopyTable = new DataTable();
            try
            {
                ExcelPackage pck = new ExcelPackage();
                ExcelWorksheet workSheet1 = pck.Workbook.Worksheets.Add(SheetName);

                var dataRange = workSheet1.Cells["A1"].LoadFromDataTable(dtData, true);

                int colNumber = 1;

                foreach (DataColumn col in dtData.Columns)
                {
                    if (col.DataType == typeof(DateTime))
                    {
                        workSheet1.Column(colNumber).Style.Numberformat.Format = "yyyy-MM-dd HH:mm:ss";//MM/dd/yyyy hh:mm:ss AM/PM
                    }
                    colNumber++;
                }

                var headerCells = workSheet1.Cells[1, 1, 1, workSheet1.Dimension.Columns];
                headerCells.Style.Font.Bold = true;
                headerCells.Style.Fill.PatternType = OfficeOpenXml.Style.ExcelFillStyle.Solid;
                headerCells.Style.Fill.BackgroundColor.SetColor(System.Drawing.Color.Yellow);

                //workSheet1.Cells[workSheet1.Dimension.Address].AutoFitColumns();

                var RowsCells = workSheet1.Cells[1, 1, dtData.Rows.Count + 1, workSheet1.Dimension.Columns];
                RowsCells.Style.Border.Top.Style = ExcelBorderStyle.Thin;
                RowsCells.Style.Border.Top.Color.SetColor(Color.Black);
                RowsCells.Style.Border.Left.Style = ExcelBorderStyle.Thin;
                RowsCells.Style.Border.Left.Color.SetColor(Color.Black);
                RowsCells.Style.Border.Right.Style = ExcelBorderStyle.Thin;
                RowsCells.Style.Border.Right.Color.SetColor(Color.Black);
                RowsCells.Style.Border.Bottom.Style = ExcelBorderStyle.Thin;
                RowsCells.Style.Border.Bottom.Color.SetColor(Color.Black);


                pck.SaveAs(new FileInfo(FilePath + FileName));

            }
            catch (Exception ex)
            {
                strReturn = string.Empty;
                ErrorLog("ExportToExcel", ex.ToString());
            }

            return strReturn;
        }

        private string ExportDataSetToExcel(DataSet dsData, string FileName, bool isFocusUser, Dictionary<string, DataSet> sources)
        {
            // Color scheme for professional look
            Color HeaderColor = Color.FromArgb(68, 114, 196);        // Professional Blue
            Color AlternateRowColor = Color.FromArgb(217, 225, 242); // Light Blue
            Color TitleColor = Color.FromArgb(31, 78, 120);          // Dark Blue
            Color BorderColor = Color.FromArgb(149, 179, 215);       // Medium Blue

            string filePath = ConfigurationManager.AppSettings["ExcelSavePath"];
            string fullPath = Path.Combine(filePath, FileName);

            try
            {
                using (ExcelPackage pck = new ExcelPackage())
                {
                    /* =========================
                       ARTICLE / TML DATA
                    ==========================*/
                    foreach (DataTable originalDt in dsData.Tables)
                    {
                        if (originalDt == null || originalDt.Rows.Count == 0)
                            continue;

                        // 🔹 Clone to avoid side-effects
                        DataTable dt = originalDt.Copy();

                        string[] removeCols = { "incident_id", "article_id", "twitter_id", "video_id" };
                        foreach (var col in removeCols)
                            if (dt.Columns.Contains(col))
                                dt.Columns.Remove(col);

                        string sheetName = GetUniqueSheetName(pck, dt.TableName);
                        ExcelWorksheet ws = pck.Workbook.Worksheets.Add(sheetName);

                        // Load data
                        ws.Cells["A1"].LoadFromDataTable(dt, true);

                        int totalRows = dt.Rows.Count + 1;   // +1 for header
                        int totalCols = dt.Columns.Count;

                        /* ============================
                           Date formatting
                           ============================ */
                        for (int i = 0; i < dt.Columns.Count; i++)
                        {
                            if (dt.Columns[i].DataType == typeof(DateTime))
                                ws.Column(i + 1).Style.Numberformat.Format = "yyyy-MM-dd HH:mm:ss";
                        }

                        /* ============================
                           Header Style
                           ============================ */
                        var headerCells = ws.Cells[1, 1, 1, totalCols];
                        headerCells.Style.Font.Bold = true;
                        headerCells.Style.Fill.PatternType = ExcelFillStyle.Solid;
                        headerCells.Style.Fill.BackgroundColor.SetColor(Color.Yellow);

                        /* ============================
                           Borders for full table
                           ============================ */
                        var tableCells = ws.Cells[1, 1, totalRows, totalCols];
                        tableCells.Style.Border.Top.Style = ExcelBorderStyle.Thin;
                        tableCells.Style.Border.Left.Style = ExcelBorderStyle.Thin;
                        tableCells.Style.Border.Right.Style = ExcelBorderStyle.Thin;
                        tableCells.Style.Border.Bottom.Style = ExcelBorderStyle.Thin;

                        tableCells.Style.Border.Top.Color.SetColor(Color.Black);
                        tableCells.Style.Border.Left.Color.SetColor(Color.Black);
                        tableCells.Style.Border.Right.Color.SetColor(Color.Black);
                        tableCells.Style.Border.Bottom.Color.SetColor(Color.Black);

                        /* ============================
                           Set column widths manually (no GDI+ dependency)
                           ============================ */
                        //ws.Cells.AutoFitColumns();

                        for (int c = 1; c <= totalCols; c++)
                        {
                            ws.Column(c).Width = 20; // Fixed width for all columns
                        }
                    }

                    #region Charts
                    /* =========================
               GRAPH DATA (ENHANCED VERSION)
            ==========================*/
                    foreach (var src in sources)
                    {
                        if (src.Value == null || src.Value.Tables.Count == 0)
                            continue;

                        // ✅ check if ANY table has data
                        bool hasData = src.Value.Tables
                            .Cast<DataTable>()
                            .Any(t => t != null && t.Rows.Count > 0);

                        // ❌ No data → NO SHEET
                        if (!hasData)
                            continue;

                        string sheetName = GetUniqueSheetName(pck, src.Key + "_Charts");
                        ExcelWorksheet ws = pck.Workbook.Worksheets.Add(sheetName);

                        // Set worksheet properties for better visual appearance
                        ws.View.ShowGridLines = false;
                        ws.DefaultColWidth = 15;
                        ws.DefaultRowHeight = 15;

                        int currentRow = 1;

                        foreach (DataTable originalDt in src.Value.Tables)
                        {
                            if (originalDt == null || originalDt.Rows.Count == 0)
                                continue;

                            DataTable dt = originalDt.Copy();

                            // ========== Enhanced Section Title ==========
                            string chartTitle = Convert.ToString(dt.Rows[0]["ChartName"]);
                            string chartType = Convert.ToString(dt.Rows[0]["ChartType"]);

                            ws.Cells[currentRow, 1].Value = chartTitle;

                            // Title styling - more prominent
                            var titleCell = ws.Cells[currentRow, 1];
                            titleCell.Style.Font.Bold = true;
                            titleCell.Style.Font.Size = 14;
                            titleCell.Style.Font.Color.SetColor(TitleColor);
                            titleCell.Style.Font.Name = "Calibri";

                            // Add background and border to title
                            titleCell.Style.Fill.PatternType = ExcelFillStyle.Solid;
                            titleCell.Style.Fill.BackgroundColor.SetColor(Color.FromArgb(242, 242, 242));
                            titleCell.Style.Border.Bottom.Style = ExcelBorderStyle.Medium;
                            titleCell.Style.Border.Bottom.Color.SetColor(HeaderColor);

                            currentRow++;

                            // Remove meta columns
                            dt.Columns.Remove("ChartName");
                            dt.Columns.Remove("ChartType");

                            // ========== Enhanced Table Styling ==========
                            ws.Cells[currentRow, 1].LoadFromDataTable(dt, true);

                            int rows = dt.Rows.Count + 1;
                            int cols = dt.Columns.Count;

                            // Header row styling - more vibrant
                            var headerRange = ws.Cells[currentRow, 1, currentRow, cols];
                            headerRange.Style.Font.Bold = true;
                            headerRange.Style.Font.Size = 11;
                            headerRange.Style.Font.Color.SetColor(Color.White);
                            headerRange.Style.Font.Name = "Calibri";
                            headerRange.Style.Fill.PatternType = ExcelFillStyle.Solid;
                            headerRange.Style.Fill.BackgroundColor.SetColor(HeaderColor);
                            headerRange.Style.HorizontalAlignment = ExcelHorizontalAlignment.Center;
                            headerRange.Style.VerticalAlignment = ExcelVerticalAlignment.Center;

                            // Border around header
                            headerRange.Style.Border.Top.Style = ExcelBorderStyle.Medium;
                            headerRange.Style.Border.Left.Style = ExcelBorderStyle.Medium;
                            headerRange.Style.Border.Right.Style = ExcelBorderStyle.Medium;
                            headerRange.Style.Border.Bottom.Style = ExcelBorderStyle.Medium;
                            headerRange.Style.Border.Top.Color.SetColor(BorderColor);
                            headerRange.Style.Border.Left.Color.SetColor(BorderColor);
                            headerRange.Style.Border.Right.Color.SetColor(BorderColor);
                            headerRange.Style.Border.Bottom.Color.SetColor(BorderColor);

                            // Data rows styling with alternating colors
                            for (int r = 1; r < rows; r++)
                            {
                                var rowRange = ws.Cells[currentRow + r, 1, currentRow + r, cols];

                                // Alternating row colors
                                if (r % 2 == 0)
                                {
                                    rowRange.Style.Fill.PatternType = ExcelFillStyle.Solid;
                                    rowRange.Style.Fill.BackgroundColor.SetColor(AlternateRowColor);
                                }

                                // Font styling
                                rowRange.Style.Font.Size = 10;
                                rowRange.Style.Font.Name = "Calibri";

                                // Borders
                                rowRange.Style.Border.Left.Style = ExcelBorderStyle.Thin;
                                rowRange.Style.Border.Right.Style = ExcelBorderStyle.Thin;
                                rowRange.Style.Border.Left.Color.SetColor(BorderColor);
                                rowRange.Style.Border.Right.Color.SetColor(BorderColor);

                                // Number formatting for numeric columns
                                for (int c = 1; c <= cols; c++)
                                {
                                    var cell = ws.Cells[currentRow + r, c];
                                    if (cell.Value != null && IsNumeric(cell.Value))
                                    {
                                        cell.Style.HorizontalAlignment = ExcelHorizontalAlignment.Right;

                                        // Format numbers with thousand separators
                                        if (dt.Columns[c - 1].ColumnName.Contains("Percentage"))
                                        {
                                            // Values are already in percentage format (20.96 means 20.96%)
                                            // So just format as number with 2 decimals and % sign
                                            cell.Style.Numberformat.Format = "0.00\"%\"";
                                        }
                                        else if (cell.Value is decimal || cell.Value is double || cell.Value is float)
                                        {
                                            cell.Style.Numberformat.Format = "#,##0.00";
                                        }
                                        else
                                        {
                                            cell.Style.Numberformat.Format = "#,##0";
                                        }
                                    }
                                    else
                                    {
                                        cell.Style.HorizontalAlignment = ExcelHorizontalAlignment.Left;
                                    }
                                }
                            }

                            // Bottom border for last row
                            var lastRowRange = ws.Cells[currentRow + rows - 1, 1, currentRow + rows - 1, cols];
                            lastRowRange.Style.Border.Bottom.Style = ExcelBorderStyle.Medium;
                            lastRowRange.Style.Border.Bottom.Color.SetColor(BorderColor);

                            //// Auto-fit columns with min/max constraints
                            //for (int c = 1; c <= cols; c++)
                            //{
                            //    ws.Column(c).AutoFit(10, 35);
                            //}

                            // Set column widths manually (no GDI+ dependency)
                            for (int c = 1; c <= cols; c++)
                            {
                                // Set different widths based on column content type
                                if (dt.Columns[c - 1].ColumnName.Contains("Percentage"))
                                {
                                    ws.Column(c).Width = 15;
                                }
                                else if (dt.Columns[c - 1].DataType == typeof(string))
                                {
                                    ws.Column(c).Width = 25;
                                }
                                else
                                {
                                    ws.Column(c).Width = 15;
                                }
                            }

                            // Chart should be in a fixed column position for alignment
                            int chartCol = 5; // Always start charts in column E for consistent alignment

                            // ========== Create Chart with Enhanced Styling ==========
                            // Position chart to align with the section title (currentRow - 1)
                            int chartStartRow = currentRow - 1; // Align with title row

                            // Calculate dynamic chart height based on table rows
                            int chartHeight = Math.Max(280, (rows + 1) * 20); // Minimum 280px, or match table height

                            // Charts
                            switch (chartType.ToLower())
                            {
                                case "pie":
                                    CreatePieChart(ws, chartTitle, currentRow, rows, chartCol, chartStartRow, chartHeight);
                                    break;
                                case "bar":
                                    CreateStackedBarChart(ws, chartTitle, currentRow, rows, cols, chartCol, chartStartRow, chartHeight);
                                    break;
                                case "column":
                                    CreateColumnChart(ws, chartTitle, currentRow, rows, cols, chartCol, chartStartRow, chartHeight);
                                    break;
                                case "line_percentage":
                                    CreateLineChart_Percentage(ws, chartTitle, currentRow, rows, chartCol, chartStartRow, chartHeight);
                                    break;
                                case "line_count":
                                    CreateLineChart_Count(ws, chartTitle, currentRow, rows, chartCol, chartStartRow, chartHeight);
                                    break;
                                case "heat":
                                    CreateHeatMap(ws, currentRow + 1, 2, rows - 1, 1);
                                    break;
                            }

                            // Calculate spacing based on the taller of table or chart
                            int chartRowSpan = (chartHeight / 20) + 2; // Convert pixels to approximate rows
                            int tableRowSpan = rows + 2; // Table rows + title + spacing
                            int sectionHeight = Math.Max(chartRowSpan, tableRowSpan);

                            currentRow += sectionHeight + 3; // Add extra spacing between sections
                        }

                        // Freeze top row for better navigation 
                        // ws.View.FreezePanes(2, 1);
                    }
                    #endregion

                    pck.SaveAs(new FileInfo(fullPath));
                }
            }
            catch (Exception ex)
            {
                ErrorLog("ExportDataSetToExcel", ex.ToString());
                return string.Empty;
            }

            return fullPath;
        }

        private string GetUniqueSheetName(ExcelPackage pck, string baseName)
        {
            string name = baseName;
            int count = 1;

            while (pck.Workbook.Worksheets
                   .Any(w => w.Name.Equals(name, StringComparison.OrdinalIgnoreCase)))
            {
                name = baseName + "_" + count;
                count++;
            }

            return name;
        }


        #endregion

        #region Parameters deserialization

        [JsonObject(MemberSerialization.OptIn)]
        [DataContract]
        public class eParameters
        {
            [JsonProperty]
            [DataMember(Name = "search_text")]
            public string SearchText { get; set; }

            [JsonProperty]
            [DataMember(Name = "UserID")]
            public string UserID { get; set; }

            [JsonProperty]
            [DataMember(Name = "platform")]
            public string Platform { get; set; }

            [JsonProperty]
            [DataMember(Name = "article_id")]
            public string ArticleID { get; set; }

            [JsonProperty]
            [DataMember(Name = "twitter_id")]
            public string TwitterID { get; set; }

            [JsonProperty]
            [DataMember(Name = "from_date")]
            public string FromDate { get; set; }

            [JsonProperty]
            [DataMember(Name = "to_date")]
            public string ToDate { get; set; }

            [JsonProperty]
            [DataMember(Name = "base_date")]
            public string BaseDate { get; set; }

            #region Incident

            [JsonProperty]
            [DataMember(Name = "incident_id")]
            public string TopicID { get; set; }

            [JsonProperty]
            [DataMember(Name = "client_id")]
            public string EntityID { get; set; }

            [JsonProperty]
            [DataMember(Name = "incident_title")]
            public string Topic_Title { get; set; }

            [JsonProperty]
            [DataMember(Name = "incident_description")]
            public string Topic_Description { get; set; }

            [JsonProperty]
            [DataMember(Name = "incident_keywords")]
            public string Topic_Keywords { get; set; }

            [JsonProperty]
            [DataMember(Name = "incident_platforms")]
            public string Topic_Platforms { get; set; }

            [JsonProperty]
            [DataMember(Name = "incident_reflinks")]
            public string Topic_RefLinks { get; set; }

            [JsonProperty]
            [DataMember(Name = "incident_query")]
            public string Topic_Query { get; set; }

            [JsonProperty]
            [DataMember(Name = "incident_start_date")]
            public string Topic_StartDate { get; set; }

            [JsonProperty]
            [DataMember(Name = "incident_end_date")]
            public string Topic_EndDate { get; set; }

            [JsonProperty]
            [DataMember(Name = "incident_reactivate_date")]
            public string Topic_ReactivateDate { get; set; }

            #endregion

            [JsonProperty]
            [DataMember(Name = "sentiment")]
            public string Sentiment { get; set; }

            [JsonProperty]
            [DataMember(Name = "tonality")]
            public string Tonality { get; set; }

            [JsonProperty]
            [DataMember(Name = "publication_domain")]
            public string Publication_Domain { get; set; }

            [JsonProperty]
            [DataMember(Name = "publication_type")]
            public string Publication_Type { get; set; }

            [JsonProperty]
            [DataMember(Name = "publication_da")]
            public string Publication_DA { get; set; }

            [JsonProperty]
            [DataMember(Name = "publication_traffic")]
            public string Publication_Traffic { get; set; }

            [JsonProperty]
            [DataMember(Name = "publication_impactscore")]
            public string Publication_ImpactScore { get; set; }

            [JsonProperty]
            [DataMember(Name = "publication_edition")]
            public string Publication_Edition { get; set; }

            [JsonProperty]
            [DataMember(Name = "publication_circulation")]
            public string Publication_Circulation { get; set; }

            [JsonProperty]
            [DataMember(Name = "publication_name")]
            public string Publication_Name { get; set; }

            [JsonProperty]
            [DataMember(Name = "sort_by")]
            public string Sort_By { get; set; }

            [JsonProperty]
            [DataMember(Name = "sort_order")]
            public string Sort_Order { get; set; }

            [JsonProperty]
            [DataMember(Name = "media_type")]
            public string Media_Type { get; set; }

            [JsonProperty]
            [DataMember(Name = "profile_category")]
            public string Profile_Category { get; set; }

            [JsonProperty]
            [DataMember(Name = "mentioned_hashtag")]
            public string Mentioned_Hashtag { get; set; }

            [JsonProperty]
            [DataMember(Name = "mentioned_handle")]
            public string Mentioned_Handle { get; set; }

            [JsonProperty]
            [DataMember(Name = "mention_type")]
            public string Mention_Type { get; set; }

            [JsonProperty]
            [DataMember(Name = "profile_name")]
            public string Profile_Name { get; set; }

            [JsonProperty]
            [DataMember(Name = "profile_handle")]
            public string Profile_Handle { get; set; }

            [JsonProperty]
            [DataMember(Name = "participant_type")]
            public string Participant_Type { get; set; }

            [JsonProperty]
            [DataMember(Name = "profile_followerscount")]
            public string Profile_Followerscount { get; set; }

            [JsonProperty]
            [DataMember(Name = "profile_verifiedType")]
            public string Profile_VerifiedType { get; set; }

            [JsonProperty]
            [DataMember(Name = "client_mention")]
            public string client_mention { get; set; }

            [JsonProperty]
            [DataMember(Name = "headline_sentiment")]
            public string headline_sentiment { get; set; }

            #region User
            [JsonProperty]
            [DataMember(Name = "AppName")]
            public string AppName { get; set; }

            [JsonProperty]
            [DataMember(Name = "UserName")]
            public string UserName { get; set; }

            [JsonProperty]
            [DataMember(Name = "Password")]
            public string Password { get; set; }

            [JsonProperty]
            [DataMember(Name = "DeviceId")]
            public string DeviceId { get; set; }

            [JsonProperty]
            [DataMember(Name = "OS")]
            public string OS { get; set; }

            [JsonProperty]
            [DataMember(Name = "IsNotificationActive")]
            public Int32 IsNotificationActive { get; set; }
            #endregion
        }

        public eParameters GetParameters(string strJson)
        {
            eParameters obj = new eParameters();
            try
            {
                JObject o = new JObject();
                o = JObject.Parse(strJson);

                obj = JsonConvert.DeserializeObject<eParameters>(o.ToString());
            }
            catch (Exception ex)
            {
                ErrorLog("GetParameters", ex.Message + " ->> " + ex.StackTrace + " Detail : " + strJson);
            }
            return obj;
        }

        #endregion

        public void Update_TryCount(Int32 UDDRID)
        {
            SqlCommand _sqlCommand = new SqlCommand();

            try
            {
                SqlConnection _sqlConnection = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ToString());

                _sqlCommand.Connection = _sqlConnection;
                _sqlCommand.Connection.Open();
                _sqlCommand.CommandText = "USP_API_SentryV2_DataRequest_Update_TryCount";
                _sqlCommand.CommandType = CommandType.StoredProcedure;
                _sqlCommand.Parameters.AddWithValue("@UDDRID", UDDRID);
                Convert.ToInt32(_sqlCommand.ExecuteNonQuery());
            }
            catch (Exception ex)
            {
                ErrorLog("Update_UserRequest_DataDownload", ex.Message + " ->> " + ex.StackTrace);
            }
            finally
            {
                _sqlCommand.Connection.Close();
                _sqlCommand.Connection.Dispose();
            }

        }

        private void Excel_Output_Final(DataSet data, string strTopicName, string strFilterDetails, int FilterColSpan, string strEmail, int UDDRID, bool isFocusUser, Dictionary<string, DataSet> GraphDataSources)
        {
            string safeTopicName = SanitizeFileName(strTopicName);

            string FileName = "XLinsights_" + safeTopicName + "_" + DateTime.Now.ToString("dd_MM_yyyy_HH_mm_ss") + ".xlsx";
            string strReturnFileName = ExportDataSetToExcel(data, FileName, isFocusUser, GraphDataSources);
            if (!String.IsNullOrEmpty(strReturnFileName))
            {
                string ReadFile = File.ReadAllText(ConfigurationManager.AppSettings["MailBody"]);
                ReadFile = ReadFile.Replace("#ClientName#", strTopicName);
                ReadFile = ReadFile.Replace("#FilterDetails#", strFilterDetails);
                ReadFile = ReadFile.Replace("#FilterColSpan#", FilterColSpan.ToString());
                bool IsSent = SendMail(strEmail, ReadFile, ConfigurationManager.AppSettings["MailSubject"].ToString() + " -> " + strTopicName, strReturnFileName, ConfigurationManager.AppSettings["CCEmailID"].ToString(), ConfigurationManager.AppSettings["BCCEmailID"].ToString());
                if (IsSent == true)
                {
                    Update_UserRequest_DataDownload(UDDRID);
                }
            }
        }

        private static string SanitizeFileName(string fileName)
        {
            var invalidChars = Path.GetInvalidFileNameChars();
            return string.Concat(
                fileName.Select(ch => invalidChars.Contains(ch) ? '_' : ch)
            );
        }


        #region Graph Data

        static DataSet CreateSampleDataSet(string strRequestJson)
        {
            DataSet ds = Fetch_OnlineData(strRequestJson);

            DataTable pie = new DataTable("Source Distribution");
            pie.Columns.Add("ChartName", typeof(string));
            pie.Columns.Add("ChartType", typeof(string));
            pie.Columns.Add("Category");
            pie.Columns.Add("Count", typeof(int));
            pie.Rows.Add("Source Distribution", "Pie", "News", 120);
            pie.Rows.Add("Source Distribution", "Pie", "Blogs", 80);
            pie.Rows.Add("Source Distribution", "Pie", "Social", 60);
            pie.Rows.Add("Source Distribution", "Pie", "Forums", 40);

            DataTable column = new DataTable("Monthly Product Sales");
            column.Columns.Add("ChartName", typeof(string));
            column.Columns.Add("ChartType", typeof(string));
            column.Columns.Add("Month");
            column.Columns.Add("ProductA", typeof(int));
            column.Columns.Add("ProductB", typeof(int));
            column.Columns.Add("ProductC", typeof(int));
            column.Rows.Add("Monthly Product Sales", "Column", "Jan", 120, 90, 60);
            column.Rows.Add("Monthly Product Sales", "Column", "Feb", 140, 110, 80);
            column.Rows.Add("Monthly Product Sales", "Column", "Mar", 160, 130, 100);

            DataTable stacked = new DataTable("Yearly Regional Sales");
            stacked.Columns.Add("ChartName", typeof(string));
            stacked.Columns.Add("ChartType", typeof(string));
            stacked.Columns.Add("Year");
            stacked.Columns.Add("US", typeof(int));
            stacked.Columns.Add("EU", typeof(int));
            stacked.Columns.Add("APAC", typeof(int));
            stacked.Rows.Add("Yearly Regional Sales", "Bar", "2022", 200, 150, 100);
            stacked.Rows.Add("Yearly Regional Sales", "Bar", "2023", 260, 190, 140);
            stacked.Rows.Add("Yearly Regional Sales", "Bar", "2024", 300, 230, 180);

            ds.Tables.Add(pie);
            ds.Tables.Add(column);
            ds.Tables.Add(stacked);

            return ds;
        }

        static DataSet CreateOnlineAnalyticsDataSet(string strRequestJson)
        {
            ErrorLog("CreateOnlineAnalyticsDataSet", "Inside the function");

            DataSet dsDb = Fetch_OnlineData(strRequestJson);
            DataSet ds = new DataSet();

            ErrorLog("Fetch_OnlineData", Convert.ToString(dsDb.Tables.Count));

            int i = 0;

            // 1. Top 10 publications by Volume
            // SQL: ChartName, ChartType, Publication, Count
            var tbl = SafeTable(dsDb, i++);
            if (tbl != null)
                ds.Tables.Add(CreateBarTable(tbl, "Top 10 Publication by Volume", "Publication", "Count"));

            // 2. Top 10 publications by Reach
            // SQL: ChartName, ChartType, Publication, Reach
            tbl = SafeTable(dsDb, i++);
            if (tbl != null)
                ds.Tables.Add(CreateBarTable(tbl, "Top 10 Publication by Reach", "Publication", "Reach"));

            // 3. Weekly distribution by Mention
            // SQL: ChartName, ChartType, Week, Count
            tbl = SafeTable(dsDb, i++);
            if (tbl != null)
            {
                DataTable weeklyMention = new DataTable("Weekly distribution by Mention");
                weeklyMention.Columns.Add("ChartName", typeof(string));
                weeklyMention.Columns.Add("ChartType", typeof(string));
                weeklyMention.Columns.Add("Week", typeof(string));
                weeklyMention.Columns.Add("Count", typeof(int));

                foreach (DataRow r in tbl.Rows)
                {
                    weeklyMention.Rows.Add(
                        r["ChartName"],
                        r["ChartType"],
                        r["Week"],
                        r["Count"]
                    );
                }
                ds.Tables.Add(weeklyMention);
            }

            // 4. Distribution by Publication Type
            // SQL: ChartName, ChartType, Publication Type, Count, Percentage
            tbl = SafeTable(dsDb, i++);
            if (tbl != null)
                ds.Tables.Add(CreatePiePercentageTable(tbl, "Distribution by Publication type", "Publication Type"));

            // 5. Distribution by Sentiment
            // SQL: ChartName, ChartType, Sentiment, Count, Percentage
            tbl = SafeTable(dsDb, i++);
            if (tbl != null)
                ds.Tables.Add(CreatePiePercentageTable(tbl, "Distribution by Sentiment", "Sentiment"));

            // 6. Industry vs Exclusive mention type
            // SQL: ChartName, ChartType, Type, Count, Percentage
            tbl = SafeTable(dsDb, i++);
            if (tbl != null)
                ds.Tables.Add(CreatePiePercentageTable(tbl, "Industry vs Exclusive mention type", "Type"));

            // 7. Distribution by Article Type
            // SQL: ChartName, ChartType, Type, Count, Percentage
            tbl = SafeTable(dsDb, i++);
            if (tbl != null)
                ds.Tables.Add(CreatePiePercentageTable(tbl, "Distribution by Article Type", "Type"));

            // 8. Distribution by Discourse Category
            // SQL: ChartName, ChartType, Category, Count, Percentage
            tbl = SafeTable(dsDb, i++);
            if (tbl != null)
                ds.Tables.Add(CreatePiePercentageTable(tbl, "Distribution by Discourse Category", "Category"));

            // 9. Distribution by Headline Mention
            // SQL: ChartName, ChartType, Headline Mention, Count, Percentage
            tbl = SafeTable(dsDb, i++);
            if (tbl != null)
                ds.Tables.Add(CreatePiePercentageTable(tbl, "Distribution by Headline Mention", "Headline Mention"));

            // 10. Daily Distribution by Mention
            // SQL: ChartName, ChartType, Day, Count, value
            tbl = SafeTable(dsDb, i++);
            if (tbl != null)
            {
                DataTable dailyMention = new DataTable("Daily Distribution by Mention");
                dailyMention.Columns.Add("ChartName", typeof(string));
                dailyMention.Columns.Add("ChartType", typeof(string));
                dailyMention.Columns.Add("Day", typeof(string));
                dailyMention.Columns.Add("Count", typeof(int));
                dailyMention.Columns.Add("percentage", typeof(decimal));

                foreach (DataRow r in tbl.Rows)
                {
                    dailyMention.Rows.Add(
                        r["ChartName"],
                        r["ChartType"],
                        r["Day"],
                        r["Count"],
                        r["percentage"]
                    );
                }
                ds.Tables.Add(dailyMention);
            }

            // 11. Distribution by Tags
            // SQL: ChartName, ChartType, Tag, Count
            tbl = SafeTable(dsDb, i++);
            if (tbl != null)
                ds.Tables.Add(CreatePieCountTable(tbl, "Distribution by Tags", "Tag"));

            // 12. Distribution by TML
            // SQL: ChartName, ChartType, publication, Count
            tbl = SafeTable(dsDb, i++);
            if (tbl != null)
                ds.Tables.Add(CreatePieCountTable(tbl, "Distribution by TML", "publication"));

            // 13. Product mention (placeholder)
            // SQL: ChartName, ChartType, title, value
            ds.Tables.Add(CreateEmptyPieTable("Distribution by Product mention"));
            i++;

            // 14. CXO mention (placeholder)
            // SQL: ChartName, ChartType, title, value
            ds.Tables.Add(CreateEmptyPieTable("Distribution by CXO mention"));
            i++;

            // 15. Distribution by Traffic
            // SQL: ChartName, ChartType, Range, Count
            tbl = SafeTable(dsDb, i++);
            if (tbl != null)
            {
                DataTable trafficRange = new DataTable("Distribution by Traffic (range-wise categories)");
                trafficRange.Columns.Add("ChartName", typeof(string));
                trafficRange.Columns.Add("ChartType", typeof(string));
                trafficRange.Columns.Add("Range", typeof(string));
                trafficRange.Columns.Add("Count", typeof(int));

                foreach (DataRow r in tbl.Rows)
                {
                    trafficRange.Rows.Add(
                        r["ChartName"],
                        r["ChartType"],
                        r["Range"],
                        r["Count"]
                    );
                }
                ds.Tables.Add(trafficRange);
            }

            // 16. Distribution by Domain Authority
            // SQL: ChartName, ChartType, Range, Count
            tbl = SafeTable(dsDb, i++);
            if (tbl != null)
            {
                DataTable domainAuthority = new DataTable("Distribution by Domain Authority (range-wise categories)");
                domainAuthority.Columns.Add("ChartName", typeof(string));
                domainAuthority.Columns.Add("ChartType", typeof(string));
                domainAuthority.Columns.Add("Range", typeof(string));
                domainAuthority.Columns.Add("Count", typeof(int));

                foreach (DataRow r in tbl.Rows)
                {
                    domainAuthority.Rows.Add(
                        r["ChartName"],
                        r["ChartType"],
                        r["Range"],
                        r["Count"]
                    );
                }
                ds.Tables.Add(domainAuthority);
            }

            return ds;
        }

        static DataSet CreatePrintAnalyticsDataSet(string strRequestJson)
        {
            DataSet dsDb = Fetch_PrintData(strRequestJson);
            DataSet ds = new DataSet();

            int i = 0;
            DataTable tbl;

            // 1. Top 10 publications by Volume
            // SQL: ChartName, ChartType, Publication Name, Count
            tbl = SafeTable(dsDb, i++);
            if (tbl != null)
                ds.Tables.Add(CreateBarTable(tbl, "Top 10 publications by Volume", "Publication", "Count"));

            // 2. Top 10 publications by Reach
            // SQL: ChartName, ChartType, Publication Name, Publication Circulation (Reach)
            tbl = SafeTable(dsDb, i++);
            if (tbl != null)
                ds.Tables.Add(CreateBarTable(tbl, "Top 10 publications by Reach", "Publication", "Reach"));

            // 3. Weekly distribution by Mention
            // SQL: ChartName, ChartType, Week, Count
            tbl = SafeTable(dsDb, i++);
            if (tbl != null)
            {
                DataTable weeklyMention = new DataTable("Weekly distribution by Mention");
                weeklyMention.Columns.Add("ChartName", typeof(string));
                weeklyMention.Columns.Add("ChartType", typeof(string));
                weeklyMention.Columns.Add("Week", typeof(string));
                weeklyMention.Columns.Add("Count", typeof(int));

                foreach (DataRow r in tbl.Rows)
                {
                    weeklyMention.Rows.Add(
                        r["ChartName"],
                        r["ChartType"],
                        r["Week"],
                        r["Count"]
                    );
                }
                ds.Tables.Add(weeklyMention);
            }

            // 4. Distribution by Publication type
            // SQL: ChartName, ChartType, Publication Type, Count, Percentage
            tbl = SafeTable(dsDb, i++);
            if (tbl != null)
                ds.Tables.Add(CreatePiePercentageTable(tbl, "Distribution by Publication type", "Publication Type"));

            // 5. Distribution by Sentiment
            // SQL: ChartName, ChartType, Sentiment, Count, Percentage
            tbl = SafeTable(dsDb, i++);
            if (tbl != null)
                ds.Tables.Add(CreatePiePercentageTable(tbl, "Distribution by Sentiment", "Sentiment"));

            // 6. Industry vs Exclusive mention type
            // SQL: ChartName, ChartType, Type, Count, Percentage
            tbl = SafeTable(dsDb, i++);
            if (tbl != null)
                ds.Tables.Add(CreatePiePercentageTable(tbl, "Industry vs Exclusive mention type", "Type"));

            // 7. Distribution by Article Type
            // SQL: ChartName, ChartType, Type, Count, Percentage
            tbl = SafeTable(dsDb, i++);
            if (tbl != null)
                ds.Tables.Add(CreatePiePercentageTable(tbl, "Distribution by Article Type", "Type"));

            // 8. Distribution by Discourse Category
            // SQL: ChartName, ChartType, Category, Count, Percentage
            tbl = SafeTable(dsDb, i++);
            if (tbl != null)
                ds.Tables.Add(CreatePiePercentageTable(tbl, "Distribution by Discourse Category", "Category"));

            // 9. Distribution by Headline Mention
            // SQL: ChartName, ChartType, Type, Count, Percentage
            //tbl = SafeTable(dsDb, i++);
            //if (tbl != null)
            //    ds.Tables.Add(CreatePiePercentageTable(tbl, "Distribution by Headline Mention", "Type"));

            // 10. Distribution by Language
            // SQL: ChartName, ChartType, language, Count
            tbl = SafeTable(dsDb, i++);
            if (tbl != null)
                ds.Tables.Add(CreatePieCountTable(tbl, "Distribution by Language", "language"));

            // 11. Distribution by Page Category
            // SQL: ChartName, ChartType, Page Category, Count (placeholder with empty data)
            tbl = SafeTable(dsDb, i++);
            if (tbl != null)
                ds.Tables.Add(CreatePieCountTable(tbl, "Distribution by Page Category", "Page No"));

            // 12. Distribution by Edition
            // SQL: ChartName, ChartType, Edition, Count
            tbl = SafeTable(dsDb, i++);
            if (tbl != null)
                ds.Tables.Add(CreatePieCountTable(tbl, "Distribution by Edition", "Edition"));

            // 13. Daily Distribution by Mention
            // SQL: ChartName, ChartType, Day, Count, value
            tbl = SafeTable(dsDb, i++);
            if (tbl != null)
            {
                DataTable dailyMention = new DataTable("Daily Distribution by Mention");
                dailyMention.Columns.Add("ChartName", typeof(string));
                dailyMention.Columns.Add("ChartType", typeof(string));
                dailyMention.Columns.Add("Day", typeof(string));
                dailyMention.Columns.Add("Count", typeof(int));
                dailyMention.Columns.Add("percentage", typeof(decimal));

                foreach (DataRow r in tbl.Rows)
                {
                    dailyMention.Rows.Add(
                        r["ChartName"],
                        r["ChartType"],
                        r["Day"],
                        r["Count"],
                        r["percentage"]
                    );
                }
                ds.Tables.Add(dailyMention);
            }

            // 14. Distribution by Tags
            // SQL: ChartName, ChartType, Tags, Count
            tbl = SafeTable(dsDb, i++);
            if (tbl != null)
                ds.Tables.Add(CreatePieCountTable(tbl, "Distribution by Tags", "Tags"));

            // 15. Distribution by TML
            // SQL: ChartName, ChartType, TML_Publication, Count
            tbl = SafeTable(dsDb, i++);
            if (tbl != null)
                ds.Tables.Add(CreatePieCountTable(tbl, "Distribution by TML", "TML_Publication"));

            // 16. Distribution by Circulation
            // SQL: ChartName, ChartType, Range, Count
            tbl = SafeTable(dsDb, i++);
            if (tbl != null)
            {
                DataTable circulation = new DataTable("Distribution by Circulation (range-wise categories)");
                circulation.Columns.Add("ChartName", typeof(string));
                circulation.Columns.Add("ChartType", typeof(string));
                circulation.Columns.Add("Range", typeof(string));
                circulation.Columns.Add("Count", typeof(int));

                foreach (DataRow r in tbl.Rows)
                {
                    circulation.Rows.Add(
                        r["ChartName"],
                        r["ChartType"],
                        r["Range"],
                        r["Count"]
                    );
                }
                ds.Tables.Add(circulation);
            }

            // 17. Product mention (placeholder)
            // SQL: ChartName, ChartType, Discourse_Category, Volume
            ds.Tables.Add(CreateEmptyPieTable("Distribution by Product mention (basis system tags for client system event)"));
            i++;

            // 18. CXO mention (placeholder)
            // SQL: ChartName, ChartType, Discourse_Category, Volume
            ds.Tables.Add(CreateEmptyPieTable("Distribution by CXO mention (basis system tags for client system event)"));
            i++;

            return ds;
        }

        static DataSet CreateTwitterAnalyticsDataSet(string strRequestJson)
        {
            DataSet dsDb = Fetch_TwitterData(strRequestJson);
            DataSet ds = new DataSet();

            int i = 0;
            DataTable tbl;

            /* =========================================================
               1. Weekly distribution by Mention (Line)
               SQL: ChartName, ChartType, Week, Count
               ========================================================= */
            tbl = SafeTable(dsDb, i++);
            if (tbl != null)
            {
                DataTable weeklyMention = new DataTable("Weekly distribution by Mention");
                weeklyMention.Columns.Add("ChartName", typeof(string));
                weeklyMention.Columns.Add("ChartType", typeof(string));
                weeklyMention.Columns.Add("Week", typeof(string));
                weeklyMention.Columns.Add("Count", typeof(int));

                foreach (DataRow r in tbl.Rows)
                {
                    weeklyMention.Rows.Add(
                        r["ChartName"],
                        r["ChartType"],
                        r["Week"],
                        r["Count"]
                    );
                }
                ds.Tables.Add(weeklyMention);
            }

            /* =========================================================
               2. Distribution by Sentiment (Pie)
               SQL: ChartName, ChartType, Sentiment, Count, Percentage
               ========================================================= */
            tbl = SafeTable(dsDb, i++);
            if (tbl != null)
                ds.Tables.Add(CreatePiePercentageTable(tbl, "Distribution by Sentiment", "Sentiment"));

            /* =========================================================
               3. Distribution by Post Tonality (Pie)
               SQL: ChartName, ChartType, Tonality, Count, Percentage
               ========================================================= */
            tbl = SafeTable(dsDb, i++);
            if (tbl != null)
                ds.Tables.Add(CreatePiePercentageTable(tbl, "Distribution by Post Tonality", "Tonality"));

            /* =========================================================
               4. Distribution by Profile Category (Pie)
               SQL: ChartName, ChartType, Profile Category, Count, Percentage
               ========================================================= */
            tbl = SafeTable(dsDb, i++);
            if (tbl != null)
                ds.Tables.Add(CreatePiePercentageTable(tbl, "Distribution by Profile Category", "Profile Category"));

            /* =========================================================
               5. Top 10 contributors by Reach (Bar)
               SQL: ChartName, ChartType, Profile_Handle, Reach
               ========================================================= */
            tbl = SafeTable(dsDb, i++);
            if (tbl != null)
                ds.Tables.Add(CreateBarTable(tbl, "Top 10 contributors by Reach", "Profile_Handle", "Reach"));

            /* =========================================================
               6. Top 10 mentioned Hashtags (Bar)
               SQL: ChartName, ChartType, Mentioned_Hashtags, Count
               ========================================================= */
            tbl = SafeTable(dsDb, i++);
            if (tbl != null)
                ds.Tables.Add(CreateBarTable(tbl, "Top 10 mentioned Hashtags", "Mentioned_Hashtags", "Count"));

            /* =========================================================
               7. Distribution by Engagement (Pie)
               SQL: ChartName, ChartType, Engagement, Count
               ========================================================= */
            tbl = SafeTable(dsDb, i++);
            if (tbl != null)
                ds.Tables.Add(CreatePieCountTable(tbl, "Distribution by Engagement", "Engagement"));

            /* =========================================================
               8. Top 10 contributors by Engagement (Bar)
               SQL: ChartName, ChartType, Profile_Handle, Count
               ========================================================= */
            tbl = SafeTable(dsDb, i++);
            if (tbl != null)
                ds.Tables.Add(CreateBarTable(tbl, "Top 10 contributors by Engagement", "Profile_Handle", "Count"));

            /* =========================================================
               9. Distribution by Verified / Not Verified (Pie)
               SQL: ChartName, ChartType, Type, Count, Percentage
               ========================================================= */
            tbl = SafeTable(dsDb, i++);
            if (tbl != null)
                ds.Tables.Add(CreatePiePercentageTable(tbl, "Distribution by Verified and not verified accounts", "Type"));

            /* =========================================================
               10. Distribution by Verified Type (Pie)
               SQL: ChartName, ChartType, Profile verified type, Count, Percentage
               ========================================================= */
            tbl = SafeTable(dsDb, i++);
            if (tbl != null)
                ds.Tables.Add(CreatePiePercentageTable(tbl, "Distribution by Verified Type", "Profile verified type"));

            /* =========================================================
               11. Daily Distribution by Mention (Line)
               SQL: ChartName, ChartType, Day, Count, value
               ========================================================= */
            tbl = SafeTable(dsDb, i++);
            if (tbl != null)
            {
                DataTable dailyMention = new DataTable("Daily Distribution by Mention");
                dailyMention.Columns.Add("ChartName", typeof(string));
                dailyMention.Columns.Add("ChartType", typeof(string));
                dailyMention.Columns.Add("Day", typeof(string));
                dailyMention.Columns.Add("Count", typeof(int));
                dailyMention.Columns.Add("percentage", typeof(decimal));

                foreach (DataRow r in tbl.Rows)
                {
                    dailyMention.Rows.Add(
                        r["ChartName"],
                        r["ChartType"],
                        r["Day"],
                        r["Count"],
                        r["percentage"]
                    );
                }
                ds.Tables.Add(dailyMention);
            }

            /* =========================================================
               12. Distribution by Tags (Pie)
               SQL: ChartName, ChartType, Tags, Count
               ========================================================= */
            tbl = SafeTable(dsDb, i++);
            if (tbl != null)
                ds.Tables.Add(CreatePieCountTable(tbl, "Distribution by Tags", "Tags"));

            /* =========================================================
               13. Product mention (Empty Placeholder)
               SQL: ChartName, ChartType, Discourse_Category, Count
               ========================================================= */
            ds.Tables.Add(CreateEmptyPieTable("Distribution by Product mention (basis system tags for client system event)"));
            i++; // intentional skip

            /* =========================================================
               14. CXO mention (Empty Placeholder)
               SQL: ChartName, ChartType, Discourse_Category, Count
               ========================================================= */
            ds.Tables.Add(CreateEmptyPieTable("Distribution by CXO mention (basis system tags for client system event)"));
            i++; // intentional skip

            return ds;
        }

        static DataSet CreateYouTubeAnalyticsDataSet(string strRequestJson)
        {
            DataSet dsDb = Fetch_YouTubeData(strRequestJson);
            DataSet ds = new DataSet();

            int i = 0;
            DataTable tbl;

            /* =========================================================
               1. Weekly distribution by Mention (Line)
               SQL: ChartName, ChartType, Week, Count
               ========================================================= */
            tbl = SafeTable(dsDb, i++);
            if (tbl != null)
            {
                DataTable weeklyMention = new DataTable("Weekly distribution by Mention");
                weeklyMention.Columns.Add("ChartName", typeof(string));
                weeklyMention.Columns.Add("ChartType", typeof(string));
                weeklyMention.Columns.Add("Week", typeof(string));
                weeklyMention.Columns.Add("Count", typeof(int));

                foreach (DataRow r in tbl.Rows)
                {
                    weeklyMention.Rows.Add(
                        r["ChartName"],
                        r["ChartType"],
                        r["Week"],
                        r["Count"]
                    );
                }
                ds.Tables.Add(weeklyMention);
            }

            /* =========================================================
               2. Distribution by Sentiment (Pie)
               SQL: ChartName, ChartType, Sentiment, Count, Percentage
               ========================================================= */
            tbl = SafeTable(dsDb, i++);
            if (tbl != null)
                ds.Tables.Add(CreatePiePercentageTable(tbl, "Distribution by Sentiment", "Sentiment"));

            /* =========================================================
               3. Industry vs Exclusive mention type (Pie)
               SQL: ChartName, ChartType, Type, Count, Percentage
               ========================================================= */
            tbl = SafeTable(dsDb, i++);
            if (tbl != null)
                ds.Tables.Add(CreatePiePercentageTable(tbl, "Industry vs Exclusive mention type", "Type"));

            /* =========================================================
               4. Distribution by Discourse Category (Pie)
               SQL: ChartName, ChartType, Category, Count, Percentage
               ========================================================= */
            tbl = SafeTable(dsDb, i++);
            if (tbl != null)
                ds.Tables.Add(CreatePiePercentageTable(tbl, "Distribution by Discourse Category", "Category"));

            /* =========================================================
               5. Distribution by Language (Pie – Count)
               SQL: ChartName, ChartType, language, Count
               ========================================================= */
            tbl = SafeTable(dsDb, i++);
            if (tbl != null)
                ds.Tables.Add(CreatePieCountTable(tbl, "Distribution by Language", "language"));

            /* =========================================================
               6. Distribution by Post Tonality (Pie)
               SQL: ChartName, ChartType, Tonality, Count, Percentage
               ========================================================= */
            tbl = SafeTable(dsDb, i++);
            if (tbl != null)
                ds.Tables.Add(CreatePiePercentageTable(tbl, "Distribution by Post Tonality", "Tonality"));

            /* =========================================================
               7. Distribution by Engagement (Pie – Count)
               SQL: ChartName, ChartType, Engagement, Count
               ========================================================= */
            tbl = SafeTable(dsDb, i++);
            if (tbl != null)
                ds.Tables.Add(CreatePieCountTable(tbl, "Distribution by Engagement", "Engagement"));

            /* =========================================================
               8. Top 10 contributors by Engagement (Bar)
               SQL: ChartName, ChartType, Channel Name, Engagement
               ========================================================= */
            tbl = SafeTable(dsDb, i++);
            if (tbl != null)
                ds.Tables.Add(CreateBarTable(tbl, "Top 10 contributors by Engagement", "Channel Name", "Engagement"));

            /* =========================================================
               9. Daily Distribution by Mention (Line)
               SQL: ChartName, ChartType, Day, Count, value
               ========================================================= */
            tbl = SafeTable(dsDb, i++);
            if (tbl != null)
            {
                DataTable dailyMention = new DataTable("Daily Distribution by Mention");
                dailyMention.Columns.Add("ChartName", typeof(string));
                dailyMention.Columns.Add("ChartType", typeof(string));
                dailyMention.Columns.Add("Day", typeof(string));
                dailyMention.Columns.Add("Count", typeof(int));
                dailyMention.Columns.Add("percentage", typeof(decimal));

                foreach (DataRow r in tbl.Rows)
                {
                    dailyMention.Rows.Add(
                        r["ChartName"],
                        r["ChartType"],
                        r["Day"],
                        r["Count"],
                        r["percentage"]
                    );
                }
                ds.Tables.Add(dailyMention);
            }

            /* =========================================================
               10. Distribution by Tags (Pie – Count)
               SQL: ChartName, ChartType, Tags, Count
               ========================================================= */
            tbl = SafeTable(dsDb, i++);
            if (tbl != null)
                ds.Tables.Add(CreatePieCountTable(tbl, "Distribution by Tags", "Tags"));

            /* =========================================================
               11. Product mention (Empty Placeholder)
               SQL: ChartName, ChartType, Discourse_Category, Count
               ========================================================= */
            ds.Tables.Add(CreateEmptyPieTable("Distribution by Product mention (basis system tags for client system event)"));
            i++; // intentional skip

            /* =========================================================
               12. CXO mention (Empty Placeholder)
               SQL: ChartName, ChartType, Discourse_Category, Count
               ========================================================= */
            ds.Tables.Add(CreateEmptyPieTable("Distribution by CXO mention (basis system tags for client system event)"));
            i++; // intentional skip

            /* =========================================================
               13. Distribution by Types of Video (Pie)
               SQL: ChartName, ChartType, Type of video, Count, Percentage
               ========================================================= */
            tbl = SafeTable(dsDb, i++);
            if (tbl != null)
                ds.Tables.Add(CreatePiePercentageTable(tbl, "Distribution by Types of Video", "Type of video"));

            /* =========================================================
               14. Distribution by Location (Pie – Count)
               SQL: ChartName, ChartType, Channel Location, Count
               ========================================================= */
            tbl = SafeTable(dsDb, i++);
            if (tbl != null)
                ds.Tables.Add(CreatePieCountTable(tbl, "Distribution by Location", "Channel Location"));

            /* =========================================================
               15. Distribution by Channel Category (Pie)
               SQL: ChartName, ChartType, Channel Category, Count, Percentage
               ========================================================= */
            tbl = SafeTable(dsDb, i++);
            if (tbl != null)
                ds.Tables.Add(CreatePiePercentageTable(tbl, "Distribution by Channel Category", "Channel Category"));

            /* =========================================================
               16. Top 10 contributors by Views (Bar)
               SQL: ChartName, ChartType, Channel Name, Count
               ========================================================= */
            tbl = SafeTable(dsDb, i++);
            if (tbl != null)
                ds.Tables.Add(CreateBarTable(tbl, "Top 10 contributors by Views", "Channel Name", "Count"));

            return ds;
        }


        static void CreatePieChart(ExcelWorksheet ws, string title, int startRow, int rows, int chartCol, int chartStartRow, int chartHeight)
        {
            ExcelPieChart chart = ws.Drawings.AddChart(
                "Pie_" + Guid.NewGuid().ToString("N").Substring(0, 8),
                eChartType.Pie) as ExcelPieChart;

            chart.Title.Text = title;
            chart.Title.Font.Bold = true;
            chart.Title.Font.Size = 12;
            chart.Title.Font.Color = Color.FromArgb(31, 78, 120);

            // Check if Percentage column exists (column 3), otherwise use Count column (column 2)
            int valueColumn = 3; // Try Percentage column first

            // If there are only 2 columns total (Category + Count), use column 2
            // If there are 3+ columns (Category + Count + Percentage), use column 3
            var headerCell = ws.Cells[startRow, 3].Value;
            if (headerCell != null && headerCell.ToString().Contains("Percentage"))
            {
                valueColumn = 3; // Use Percentage column
            }
            else
            {
                valueColumn = 2; // Use Count column
            }

            chart.Series.Add(
                ws.Cells[startRow + 1, valueColumn, startRow + rows - 1, valueColumn],
                ws.Cells[startRow + 1, 1, startRow + rows - 1, 1]
            );

            // Enhanced data labels
            chart.DataLabel.ShowPercent = true;
            chart.DataLabel.ShowCategory = false;
            chart.DataLabel.ShowValue = false;

            // Legend styling
            chart.Legend.Position = eLegendPosition.Right;
            chart.Legend.Font.Size = 9;

            // Position chart to align with title
            chart.SetPosition(chartStartRow, 0, chartCol - 1, 0);
            chart.SetSize(400, chartHeight);
        }

        static void CreateColumnChart(ExcelWorksheet ws, string title, int startRow, int rows, int cols, int chartCol, int chartStartRow, int chartHeight)
        {
            var chart = ws.Drawings.AddChart(
                "Column_" + Guid.NewGuid().ToString("N").Substring(0, 8),
                eChartType.ColumnClustered);

            chart.Title.Text = title;
            chart.Title.Font.Bold = true;
            chart.Title.Font.Size = 12;
            chart.Title.Font.Color = Color.FromArgb(31, 78, 120);

            for (int c = 2; c <= cols; c++)
            {
                var series = chart.Series.Add(
                    ws.Cells[startRow + 1, c, startRow + rows - 1, c],
                    ws.Cells[startRow + 1, 1, startRow + rows - 1, 1]
                );
                series.Header = ws.Cells[startRow, c].Text;
            }

            // Axis styling
            chart.XAxis.Font.Size = 9;
            chart.YAxis.Font.Size = 9;

            // Legend
            chart.Legend.Position = eLegendPosition.Bottom;
            chart.Legend.Font.Size = 9;

            // Position chart to align with title
            chart.SetPosition(chartStartRow, 0, chartCol - 1, 0);
            chart.SetSize(450, chartHeight);
        }

        static void CreateStackedBarChart(ExcelWorksheet ws, string title, int startRow, int rows, int cols, int chartCol, int chartStartRow, int chartHeight)
        {
            var chart = ws.Drawings.AddChart(
                "Bar_" + Guid.NewGuid().ToString("N").Substring(0, 8),
                eChartType.BarStacked);

            chart.Title.Text = title;
            chart.Title.Font.Bold = true;
            chart.Title.Font.Size = 12;
            chart.Title.Font.Color = Color.FromArgb(31, 78, 120);

            for (int c = 2; c <= cols; c++)
            {
                var series = chart.Series.Add(
                    ws.Cells[startRow + 1, c, startRow + rows - 1, c],
                    ws.Cells[startRow + 1, 1, startRow + rows - 1, 1]
                );
                series.Header = ws.Cells[startRow, c].Text;
            }

            // Axis styling
            chart.XAxis.Font.Size = 9;
            chart.YAxis.Font.Size = 9;

            // Remove legend if stacked (data labels show values)
            chart.Legend.Remove();

            // Position chart to align with title
            chart.SetPosition(chartStartRow, 0, chartCol - 1, 0);
            chart.SetSize(450, chartHeight);
        }

        static void CreateLineChart_Percentage(ExcelWorksheet ws, string title, int startRow, int rows, int chartCol, int chartStartRow, int chartHeight)
        {
            var chart = ws.Drawings.AddChart(
                "Line_" + Guid.NewGuid().ToString("N").Substring(0, 8),
                eChartType.LineMarkers);

            chart.Title.Text = title;
            chart.Title.Font.Bold = true;
            chart.Title.Font.Size = 12;
            chart.Title.Font.Color = Color.FromArgb(31, 78, 120);

            var series = chart.Series.Add(
                ws.Cells[startRow + 1, 3, startRow + rows - 1, 3],
                ws.Cells[startRow + 1, 1, startRow + rows - 1, 1]
            );
            series.Header = "Percentage";

            // Axis styling
            chart.YAxis.Title.Text = "Percentage (%)";
            chart.YAxis.Title.Font.Bold = true;
            chart.YAxis.Title.Font.Size = 10;
            chart.YAxis.Font.Size = 9;

            chart.XAxis.Title.Text = "Period";
            chart.XAxis.Title.Font.Bold = true;
            chart.XAxis.Title.Font.Size = 10;
            chart.XAxis.Font.Size = 9;

            // Legend
            chart.Legend.Remove();

            // Position chart to align with title
            chart.SetPosition(chartStartRow, 0, chartCol - 1, 0);
            chart.SetSize(500, chartHeight);
        }

        static void CreateLineChart_Count(ExcelWorksheet ws, string title, int startRow, int rows, int chartCol, int chartStartRow, int chartHeight)
        {
            var chart = ws.Drawings.AddChart(
                "Line_" + Guid.NewGuid().ToString("N").Substring(0, 8),
                eChartType.LineMarkers);

            chart.Title.Text = title;
            chart.Title.Font.Bold = true;
            chart.Title.Font.Size = 12;
            chart.Title.Font.Color = Color.FromArgb(31, 78, 120);

            var series = chart.Series.Add(
                ws.Cells[startRow + 1, 2, startRow + rows - 1, 2],
                ws.Cells[startRow + 1, 1, startRow + rows - 1, 1]
            );
            series.Header = "Count";

            // Axis styling
            chart.YAxis.Title.Text = "Count";
            chart.YAxis.Title.Font.Bold = true;
            chart.YAxis.Title.Font.Size = 10;
            chart.YAxis.Font.Size = 9;

            chart.XAxis.Title.Text = "Period";
            chart.XAxis.Title.Font.Bold = true;
            chart.XAxis.Title.Font.Size = 10;
            chart.XAxis.Font.Size = 9;

            // Legend
            chart.Legend.Remove();

            // Position chart to align with title
            chart.SetPosition(chartStartRow, 0, chartCol - 1, 0);
            chart.SetSize(500, chartHeight);
        }

        static void CreateHeatMap(ExcelWorksheet ws, int startRow, int startCol, int rows, int cols)
        {
            var range = ws.Cells[
                startRow,
                startCol,
                startRow + rows - 1,
                startCol + cols - 1
            ];

            var cf = ws.ConditionalFormatting.AddThreeColorScale(range);

            // Reversed: Low = Red, Mid = Yellow, High = Green

            // Low → Red (lowest numbers)
            cf.LowValue.Type = eExcelConditionalFormattingValueObjectType.Min;
            cf.LowValue.Color = Color.FromArgb(248, 105, 107);   // Red

            // Mid → Yellow (middle values)
            cf.MiddleValue.Type = eExcelConditionalFormattingValueObjectType.Percentile;
            cf.MiddleValue.Value = 50;
            cf.MiddleValue.Color = Color.FromArgb(255, 235, 132); // Yellow

            // High → Green (highest numbers)
            cf.HighValue.Type = eExcelConditionalFormattingValueObjectType.Max;
            cf.HighValue.Color = Color.FromArgb(99, 190, 123);   // Green

            // Add borders to heatmap cells
            range.Style.Border.Top.Style = ExcelBorderStyle.Thin;
            range.Style.Border.Left.Style = ExcelBorderStyle.Thin;
            range.Style.Border.Right.Style = ExcelBorderStyle.Thin;
            range.Style.Border.Bottom.Style = ExcelBorderStyle.Thin;
            range.Style.Border.Top.Color.SetColor(Color.White);
            range.Style.Border.Left.Color.SetColor(Color.White);
            range.Style.Border.Right.Color.SetColor(Color.White);
            range.Style.Border.Bottom.Color.SetColor(Color.White);

            // Center align and bold the values
            range.Style.HorizontalAlignment = ExcelHorizontalAlignment.Center;
            range.Style.Font.Bold = true;
            range.Style.Font.Size = 10;
        }

        // -------------------------------------------------
        // Database Fetch Methods
        // -------------------------------------------------
        public static DataSet Fetch_OnlineData(string strRequestJson)
        {
            DataTable _dt = new DataTable();
            DataSet _dtSet = new DataSet();
            SqlCommand _sqlCommand = new SqlCommand();

            try
            {
                SqlConnection _sqlConnection = new SqlConnection(ConfigurationManager.ConnectionStrings["Sahadev_ConnectionString"].ToString());

                _sqlCommand.Connection = _sqlConnection;
                _sqlCommand.CommandTimeout = 300;
                _sqlCommand.Connection.Open();
                _sqlCommand.CommandText = "USP_DownloadData_Online_GraphsData";
                _sqlCommand.CommandType = CommandType.StoredProcedure;
                _sqlCommand.Parameters.AddWithValue("@strRequestJson", strRequestJson);
                SqlDataAdapter _sqlDataAdapter = new SqlDataAdapter(_sqlCommand);

                _sqlDataAdapter.Fill(_dtSet);
            }
            catch (Exception ex)
            {
                Log("FetchAlerts_DB_Online", ex.Message + " ->> " + ex.StackTrace);
            }
            finally
            {
                _sqlCommand.Connection.Close();
                _sqlCommand.Connection.Dispose();
            }

            return _dtSet;
        }

        public static DataSet Fetch_PrintData(string strRequestJson)
        {
            DataTable _dt = new DataTable();
            DataSet _dtSet = new DataSet();
            SqlCommand _sqlCommand = new SqlCommand();

            try
            {
                SqlConnection _sqlConnection = new SqlConnection(ConfigurationManager.ConnectionStrings["Sahadev_ConnectionString"].ToString());

                _sqlCommand.Connection = _sqlConnection;
                _sqlCommand.CommandTimeout = 300;
                _sqlCommand.Connection.Open();
                _sqlCommand.CommandText = "USP_DownloadData_Print_GraphsData";
                _sqlCommand.CommandType = CommandType.StoredProcedure;
                _sqlCommand.Parameters.AddWithValue("@strRequestJson", strRequestJson);
                SqlDataAdapter _sqlDataAdapter = new SqlDataAdapter(_sqlCommand);

                _sqlDataAdapter.Fill(_dtSet);
            }
            catch (Exception ex)
            {
                Log("FetchAlerts_DB_Print", ex.Message + " ->> " + ex.StackTrace);
            }
            finally
            {
                _sqlCommand.Connection.Close();
                _sqlCommand.Connection.Dispose();
            }

            return _dtSet;
        }

        public static DataSet Fetch_TwitterData(string strRequestJson)
        {
            DataTable _dt = new DataTable();
            DataSet _dtSet = new DataSet();
            SqlCommand _sqlCommand = new SqlCommand();

            try
            {
                SqlConnection _sqlConnection = new SqlConnection(ConfigurationManager.ConnectionStrings["Sahadev_ConnectionString"].ToString());

                _sqlCommand.Connection = _sqlConnection;
                _sqlCommand.CommandTimeout = 300;
                _sqlCommand.Connection.Open();
                _sqlCommand.CommandText = "USP_DownloadData_Twitter_GraphsData";
                _sqlCommand.CommandType = CommandType.StoredProcedure;
                _sqlCommand.Parameters.AddWithValue("@strRequestJson", strRequestJson);
                SqlDataAdapter _sqlDataAdapter = new SqlDataAdapter(_sqlCommand);

                _sqlDataAdapter.Fill(_dtSet);
            }
            catch (Exception ex)
            {
                Log("FetchAlerts_DB_Twitter", ex.Message + " ->> " + ex.StackTrace);
            }
            finally
            {
                _sqlCommand.Connection.Close();
                _sqlCommand.Connection.Dispose();
            }

            return _dtSet;
        }

        public static DataSet Fetch_YouTubeData(string strRequestJson)
        {
            DataTable _dt = new DataTable();
            DataSet _dtSet = new DataSet();
            SqlCommand _sqlCommand = new SqlCommand();

            try
            {
                SqlConnection _sqlConnection = new SqlConnection(ConfigurationManager.ConnectionStrings["Sahadev_ConnectionString"].ToString());

                _sqlCommand.Connection = _sqlConnection;
                _sqlCommand.CommandTimeout = 300;
                _sqlCommand.Connection.Open();
                _sqlCommand.CommandText = "USP_DownloadData_YouTube_GraphsData";
                _sqlCommand.CommandType = CommandType.StoredProcedure;
                _sqlCommand.Parameters.AddWithValue("@strRequestJson", strRequestJson);
                SqlDataAdapter _sqlDataAdapter = new SqlDataAdapter(_sqlCommand);

                _sqlDataAdapter.Fill(_dtSet);
            }
            catch (Exception ex)
            {
                Log("FetchAlerts_DB_YouTube", ex.Message + " ->> " + ex.StackTrace);
            }
            finally
            {
                _sqlCommand.Connection.Close();
                _sqlCommand.Connection.Dispose();
            }

            return _dtSet;
        }

        // -------------------------------------------------
        // Helper Methods
        // -------------------------------------------------

        private static void Log(string functionName, string error)
        {
            try
            {
                string LogPath = ConfigurationManager.AppSettings["ErrorLogPath"].ToString();
                using (TextWriter myWriter = File.AppendText(LogPath))
                {
                    TextWriter.Synchronized(myWriter).WriteLine("<--> :{0}", string.Empty);
                    TextWriter.Synchronized(myWriter).WriteLine("Function Name :{0}", functionName);
                    if (!String.IsNullOrEmpty(error))
                    {
                        TextWriter.Synchronized(myWriter).WriteLine("Error :{0}", error);
                    }
                    TextWriter.Synchronized(myWriter).WriteLine("Date :{0}", DateTime.Now.ToString());
                    TextWriter.Synchronized(myWriter).WriteLine("<--> :{0}", string.Empty);
                    TextWriter.Synchronized(myWriter).Flush();
                    TextWriter.Synchronized(myWriter).Close();
                }
            }
            catch (Exception ex)
            {
            }
        }

        static DataTable CreateBarTable(DataTable src, string name, string labelCol, string valueCol)
        {
            DataTable dt = new DataTable(name);
            dt.Columns.Add("ChartName", typeof(string));
            dt.Columns.Add("ChartType", typeof(string));
            dt.Columns.Add(labelCol, typeof(string));
            dt.Columns.Add(valueCol, typeof(Int64));

            foreach (DataRow r in src.Rows)
                dt.Rows.Add(r["ChartName"], r["ChartType"], r[labelCol], r[valueCol]);

            return dt;
        }

        static DataTable CreatePiePercentageTable(DataTable src, string name, string labelCol)
        {
            DataTable dt = new DataTable(name);
            dt.Columns.Add("ChartName", typeof(string));
            dt.Columns.Add("ChartType", typeof(string));
            dt.Columns.Add(labelCol, typeof(string));
            dt.Columns.Add("Count", typeof(int));
            dt.Columns.Add("Percentage", typeof(decimal));

            foreach (DataRow r in src.Rows)
                dt.Rows.Add(
                    r["ChartName"],
                    r["ChartType"],
                    r[labelCol],
                    r["Count"],
                    r["Percentage"]
                );

            return dt;
        }

        static DataTable CreatePieCountTable(DataTable src, string name, string labelCol)
        {
            DataTable dt = new DataTable(name);
            dt.Columns.Add("ChartName", typeof(string));
            dt.Columns.Add("ChartType", typeof(string));
            dt.Columns.Add(labelCol, typeof(string));
            dt.Columns.Add("Count", typeof(int));

            foreach (DataRow r in src.Rows)
                dt.Rows.Add(r["ChartName"], r["ChartType"], r[labelCol], r["Count"]);

            return dt;
        }

        static DataTable CreateEmptyPieTable(string name)
        {
            DataTable dt = new DataTable(name);
            dt.Columns.Add("ChartName", typeof(string));
            dt.Columns.Add("ChartType", typeof(string));
            dt.Columns.Add("Title", typeof(string));
            dt.Columns.Add("Value", typeof(string));
            return dt;
        }

        static bool IsNumeric(object value)
        {
            return value is sbyte || value is byte || value is short || value is ushort ||
                   value is int || value is uint || value is long || value is ulong ||
                   value is float || value is double || value is decimal;
        }

        private static DataTable SafeTable(DataSet ds, int index)
        {
            return (ds != null && ds.Tables.Count > index)
                ? ds.Tables[index]
                : null;
        }

        #endregion

    }
}
