﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.IO;
using System.Diagnostics;
using System.Threading.Tasks;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json;
using System.Runtime.Serialization;
using System.Net.Mail;
using System.Web;
using OfficeOpenXml;
using OfficeOpenXml.Style;
using System.Drawing;
using System.Net;

namespace UserRequest_DataDownload
{
    public class DownloadData_09_12_2025
    {
        public void DoProcess()
        {
            try
            {
                var stopWatch = Stopwatch.StartNew();
                ParallelOptions po = new ParallelOptions();
                po.MaxDegreeOfParallelism = Convert.ToInt32(ConfigurationManager.AppSettings["MaxDegreeOfParallelism"].ToString());
                System.Net.ServicePointManager.DefaultConnectionLimit = Convert.ToInt32(ConfigurationManager.AppSettings["MaxDegreeOfParallelism"].ToString());

                ErrorLog("Program", "Start");
                ErrorLog("FetchPending_UserRequest_DataDownload", "Start");

                DataTable _dt = new DataTable();
                _dt = FetchPending_UserRequest_DataDownload();

                ErrorLog("FetchPending_UserRequest_DataDownload", "End");
                ErrorLog("FetchPending_UserRequest_DataDownload Table Rows", Convert.ToString(_dt.Rows.Count));


                if (_dt.Rows.Count > 0)
                {
                    var setting = new JsonSerializerSettings { MaxDepth = int.MaxValue };

                    Parallel.For(0, _dt.Rows.Count, po, i =>
                    {
                        try
                        {
                            Int32 UDDRID = Convert.ToInt32(_dt.Rows[i]["UDDRID"].ToString());
                            string strEmail = _dt.Rows[i]["Email"].ToString();
                            //strEmail = "mayuresh.joshi@adfactorspr.com";
                            string strRequestJson = _dt.Rows[i]["RequestJson"].ToString();
                            string strTopicName = _dt.Rows[i]["TopicName"].ToString();
                            string UserName = _dt.Rows[i]["UserName"].ToString();
                            string UserEmailID = _dt.Rows[i]["Email"].ToString();

                            dynamic stuff = JObject.Parse(strRequestJson);

                            TimeLog("UDDRID Data Is " + UDDRID + " -> " + JsonConvert.SerializeObject(stuff, setting));

                            DataTable dtHtml = JsonConvert.DeserializeObject<DataTable>("[" + strRequestJson + "]");
                            //dtHtml.Columns.Remove("UserID");
                            //dtHtml.Columns.Remove("incident_id");

                            string[] columnsToRemove = { "UserID", "incident_id", "data_tag" };

                            foreach (string col in columnsToRemove)
                            {
                                if (dtHtml.Columns.Contains(col))
                                {
                                    dtHtml.Columns.Remove(col);
                                }
                            }

                            string strFilterDetails = string.Empty;
                            Int32 FilterColSpan = 1;
                            if (dtHtml.Rows.Count > 0)
                            {
                                strFilterDetails = "<tr>";
                                for (int c = 0; c < dtHtml.Columns.Count; c++)
                                {
                                    if (dtHtml.Rows[0][c].ToString() != "")
                                    {
                                        strFilterDetails = strFilterDetails + "<td>" + dtHtml.Columns[c].ColumnName + "</td>";
                                        FilterColSpan++;
                                    }
                                }
                                strFilterDetails = strFilterDetails + "</tr><tr>";

                                for (int r = 0; r < dtHtml.Rows.Count; r++)
                                {
                                    for (int c = 0; c < dtHtml.Columns.Count; c++)
                                    {
                                        if (dtHtml.Rows[0][c].ToString() != "")
                                        {
                                            strFilterDetails = strFilterDetails + "<td>" + Convert.ToString(dtHtml.Rows[r][c]) + "</td>";
                                        }
                                    }
                                }
                                strFilterDetails = strFilterDetails + "</tr>";
                            }


                            string platform = stuff.platform;
                            Int32 TopicID = Convert.ToInt32(Convert.ToString(stuff.incident_id));
                            Int32 UserID = Convert.ToInt32(Convert.ToString(stuff.UserID));

                            if (platform.ToLower() == "twitter" || platform.ToLower() == "online" || platform.ToLower() == "print" || platform.ToLower() == "youtube")
                            {
                                #region Individual

                                DataTable dtData = new DataTable();

                                if (platform.ToLower() == "twitter")
                                {
                                    dtData = FetchData(ConfigurationManager.AppSettings["URL_API_Twitter"], strRequestJson);
                                }
                                else if (platform.ToLower() == "online")
                                {
                                    dtData = FetchData(ConfigurationManager.AppSettings["URL_API_Online"], strRequestJson);
                                }
                                else if (platform.ToLower() == "print")
                                {
                                    dtData = FetchData(ConfigurationManager.AppSettings["URL_API_Print"], strRequestJson);
                                }
                                else if (platform.ToLower() == "youtube")
                                {
                                    ErrorLog("In YouTube", "");
                                    dtData = FetchData(ConfigurationManager.AppSettings["URL_API_YouTube"], strRequestJson);
                                }

                                if (dtData != null && dtData.Rows.Count > 0)
                                {
                                    string FileName = "SentryV2_Data_" + DateTime.Now.ToString("dd_MM_yyyy_HH_mm_ss") + ".xlsx";
                                    string strReturnFileName = ExportToExcel(dtData, platform.ToLower(), FileName);
                                    if (!String.IsNullOrEmpty(strReturnFileName))
                                    {
                                        string ReadFile = File.ReadAllText(ConfigurationManager.AppSettings["MailBody"]);
                                        ReadFile = ReadFile.Replace("#ClientName#", strTopicName);
                                        ReadFile = ReadFile.Replace("#FilterDetails#", strFilterDetails);
                                        ReadFile = ReadFile.Replace("#FilterColSpan#", FilterColSpan.ToString());
                                        bool IsSent = SendMail(strEmail, ReadFile, ConfigurationManager.AppSettings["MailSubject"].ToString() + " -> " + strTopicName, strReturnFileName, ConfigurationManager.AppSettings["CCEmailID"].ToString(), ConfigurationManager.AppSettings["BCCEmailID"].ToString());
                                        if (IsSent == true)
                                        {
                                            Update_UserRequest_DataDownload(UDDRID);
                                        }
                                    }
                                }
                                #endregion
                            }
                            else if (platform.ToLower() == "event_report")
                            {
                                #region Combined

                                bool Is_Data_Available_Online = false;
                                bool Is_Data_Available_Print = false;
                                bool Is_Data_Available_Twitter = false;
                                bool Is_Data_Available_YouTube = false;

                                DataSet ds = new DataSet();
                                ds.Tables.Clear();

                                DataTable Twitter = FetchData(ConfigurationManager.AppSettings["URL_API_Twitter"], strRequestJson);
                                DataTable Online = FetchData(ConfigurationManager.AppSettings["URL_API_Online"], strRequestJson);
                                DataTable Print = FetchData(ConfigurationManager.AppSettings["URL_API_Print"], strRequestJson);
                                DataTable YouTube = FetchData(ConfigurationManager.AppSettings["URL_API_YouTube"], strRequestJson);

                                DataTable dtCopy_Twitter = new DataTable();
                                DataTable dtCopy_Online = new DataTable();
                                DataTable dtCopy_Print = new DataTable();
                                DataTable dtCopy_YouTube = new DataTable();

                                ds.Tables.Clear();

                                dtCopy_Twitter = Twitter.Copy();
                                dtCopy_Online = Online.Copy();
                                dtCopy_Print = Print.Copy();
                                dtCopy_YouTube = YouTube.Copy();

                                dtCopy_Twitter.TableName = "Twitter";
                                dtCopy_Online.TableName = "Online";
                                dtCopy_Print.TableName = "Print";
                                dtCopy_YouTube.TableName = "YouTube";

                                if (dtCopy_Online != null)
                                {
                                    if (dtCopy_Online.Rows.Count > 0)
                                    {
                                        ds.Tables.Add(dtCopy_Online);
                                        Is_Data_Available_Online = true;
                                    }
                                    else
                                    {
                                        DataTable dt = new DataTable("Online");
                                        dt.Columns.Add("Message");
                                        dt.Rows.Add("No records found.");
                                        ds.Tables.Add(dt);
                                    }

                                }
                                if (dtCopy_Print != null)
                                {
                                    if (dtCopy_Print.Rows.Count > 0)
                                    {
                                        ds.Tables.Add(dtCopy_Print);
                                        Is_Data_Available_Print = true;
                                    }
                                    else
                                    {
                                        DataTable dt = new DataTable("Print");
                                        dt.Columns.Add("Message");
                                        dt.Rows.Add("No records found.");
                                        ds.Tables.Add(dt);
                                    }

                                }
                                if (dtCopy_Twitter != null)
                                {
                                    if (dtCopy_Twitter.Rows.Count > 0)
                                    {
                                        ds.Tables.Add(dtCopy_Twitter);
                                        Is_Data_Available_Twitter = true;
                                    }
                                    else
                                    {
                                        DataTable dt = new DataTable("Twitter");
                                        dt.Columns.Add("Message");
                                        dt.Rows.Add("No records found.");
                                        ds.Tables.Add(dt);
                                    }
                                }
                                if (dtCopy_YouTube != null)
                                {
                                    if (dtCopy_YouTube.Rows.Count > 0)
                                    {
                                        ds.Tables.Add(dtCopy_YouTube);
                                        Is_Data_Available_YouTube = true;
                                    }
                                    else
                                    {
                                        DataTable dt = new DataTable("YouTube");
                                        dt.Columns.Add("Message");
                                        dt.Rows.Add("No records found.");
                                        ds.Tables.Add(dt);
                                    }

                                }

                                if (Is_Data_Available_Online || Is_Data_Available_Print || Is_Data_Available_Twitter || Is_Data_Available_YouTube)
                                {
                                    string FileName = "SentryV2_Data_" + DateTime.Now.ToString("dd_MM_yyyy_HH_mm_ss") + ".xlsx";
                                    string strReturnFileName = ExportDataSetToExcel(ds, FileName);
                                    if (!String.IsNullOrEmpty(strReturnFileName))
                                    {
                                        string ReadFile = File.ReadAllText(ConfigurationManager.AppSettings["MailBody"]);
                                        ReadFile = ReadFile.Replace("#ClientName#", strTopicName);
                                        ReadFile = ReadFile.Replace("#FilterDetails#", strFilterDetails);
                                        ReadFile = ReadFile.Replace("#FilterColSpan#", FilterColSpan.ToString());
                                        bool IsSent = SendMail(strEmail, ReadFile, ConfigurationManager.AppSettings["MailSubject"].ToString() + " -> " + strTopicName, strReturnFileName, ConfigurationManager.AppSettings["CCEmailID"].ToString(), ConfigurationManager.AppSettings["BCCEmailID"].ToString());
                                        if (IsSent == true)
                                        {
                                            Update_UserRequest_DataDownload(UDDRID);
                                        }
                                    }
                                }

                                #endregion
                            }

                        }
                        catch (Exception ex)
                        {
                            ErrorLog("Parallel Error for " + Convert.ToInt32(_dt.Rows[i]["UDDRID"].ToString()), ex.ToString());
                        }
                        finally
                        {
                            Update_TryCount(Convert.ToInt32(_dt.Rows[i]["UDDRID"].ToString()));
                        }

                    }

                    );
                    TimeLog("End Parallel.For");
                    TimeLog("Parallel.For() execution time for " + " = {0} seconds:" + stopWatch.Elapsed.TotalSeconds);
                }
            }
            catch (Exception ex)
            {
                ErrorLog("DoProcess", ex.ToString());
            }
        }

        public DataTable FetchPending_UserRequest_DataDownload()
        {

            DataTable _dt = new DataTable();
            DataSet _dtSet = new DataSet();
            SqlCommand _sqlCommand = new SqlCommand();

            try
            {
                SqlConnection _sqlConnection = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ToString());

                _sqlCommand.Connection = _sqlConnection;
                _sqlCommand.Connection.Open();
                _sqlCommand.CommandText = "USP_Service_SentryV2_FetchPending_URDataDownload";
                _sqlCommand.CommandType = CommandType.Text;
                _sqlCommand.CommandTimeout = Convert.ToInt32(ConfigurationManager.AppSettings["SP_Timeout"]);
                //_sqlCommand.Parameters.AddWithValue("@MessageID", "Select");
                SqlDataAdapter _sqlDataAdapter = new SqlDataAdapter(_sqlCommand);

                _sqlDataAdapter.Fill(_dtSet);

                if (_dtSet != null && _dtSet.Tables.Count > 0)
                {
                    _dt = _dtSet.Tables[0];
                }

            }
            catch (Exception ex)
            {
                ErrorLog("FetchPending_UserRequest_DataDownload", ex.Message + " ->> " + ex.StackTrace);
            }

            return _dt;
        }

        public bool Update_UserRequest_DataDownload(Int32 UDDRID)
        {
            bool IsResult = false;
            DataTable _dt = new DataTable();
            DataSet _dtSet = new DataSet();
            SqlCommand _sqlCommand = new SqlCommand();

            try
            {
                SqlConnection _sqlConnection = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ToString());

                _sqlCommand.Connection = _sqlConnection;
                _sqlCommand.Connection.Open();
                _sqlCommand.CommandText = "USP_Service_SentryV2_Update_UR_DataDownload";
                _sqlCommand.CommandType = CommandType.StoredProcedure;
                _sqlCommand.Parameters.AddWithValue("@UDDRID", UDDRID);
                int result = Convert.ToInt32(_sqlCommand.ExecuteNonQuery());
                if (result > 0)
                {
                    IsResult = true;
                }

            }
            catch (Exception ex)
            {
                ErrorLog("Update_UserRequest_DataDownload", ex.Message + " ->> " + ex.StackTrace);
            }
            finally
            {
                _sqlCommand.Connection.Close();
                _sqlCommand.Connection.Dispose();
            }

            return IsResult;
        }

        public DataTable FetchData(string strUrl, string strJson)
        {

            DataTable dt = new DataTable();
            try
            {
                string strToken = ConfigurationManager.AppSettings["URL_API_Token"];

                HttpWebRequest request = (HttpWebRequest)WebRequest.Create(strUrl);
                request.Headers["token"] = strToken;


                //Create bytes array to send Input as parameter
                byte[] bytes = bytes = Encoding.UTF8.GetBytes(strJson);

                //Set request options
                request.ContentType = "application/json; charset=utf8";
                request.ContentLength = bytes.Length;
                request.Method = "POST";
                request.Timeout = Convert.ToInt32(ConfigurationManager.AppSettings["API_Timeout"]);

                //Upload bytes array to request
                using (Stream os = request.GetRequestStream())
                {
                    os.Write(bytes, 0, bytes.Length);
                }



                //Get response from TextProcessingPipeline
                using (System.Net.WebResponse resp = request.GetResponse())
                {
                    using (StreamReader sr = new StreamReader(resp.GetResponseStream()))
                    {
                        string strOutput = sr.ReadToEnd().Trim();
                        ErrorLog("In - " + strUrl.ToString(), strOutput);
                        if (!String.IsNullOrEmpty(strOutput))
                        {
                            JObject obj = JObject.Parse(strOutput);
                            if (obj != null)
                            {
                                JArray jItems = (JArray)obj["data"];
                                if (jItems != null)
                                {
                                    dt = (DataTable)JsonConvert.DeserializeObject(jItems.ToString(), (typeof(DataTable)));
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorLog("FetchData", ex.Message + " ->> " + ex.StackTrace);
            }

            return dt;
        }


        #region ValidateRequest & Log & Email & Excel

        //For error logging
        private static void ErrorLog(string functionName, string error)
        {
            try
            {
                string LogPath = ConfigurationManager.AppSettings["ErrorLogPath"];
                using (TextWriter myWriter = File.AppendText(LogPath))
                {

                    TextWriter.Synchronized(myWriter).WriteLine("<--> :{0}", string.Empty);
                    TextWriter.Synchronized(myWriter).WriteLine("Function Name :{0}", functionName);
                    TextWriter.Synchronized(myWriter).WriteLine("Error :{0}", error);
                    TextWriter.Synchronized(myWriter).WriteLine("Date :{0}", DateTime.Now.ToString());
                    TextWriter.Synchronized(myWriter).WriteLine("<--> :{0}", string.Empty);
                    TextWriter.Synchronized(myWriter).Flush();
                    TextWriter.Synchronized(myWriter).Close();
                }
            }
            catch (Exception ex)
            {
            }
        }

        //For debugging purpose
        private static void TimeLog(string strtext)
        {
            try
            {
                string LogPath = ConfigurationManager.AppSettings["TimeLogPath"];
                using (TextWriter myWriter = File.AppendText(LogPath))
                {

                    TextWriter.Synchronized(myWriter).WriteLine("<--> :{0}", string.Empty);
                    TextWriter.Synchronized(myWriter).WriteLine("TimeLog :{0}", strtext);
                    TextWriter.Synchronized(myWriter).WriteLine("Date :{0}", DateTime.Now.ToString());
                    TextWriter.Synchronized(myWriter).WriteLine("<--> :{0}", string.Empty);
                    TextWriter.Synchronized(myWriter).Flush();
                    TextWriter.Synchronized(myWriter).Close();
                }
            }
            catch (Exception ex)
            {
                ErrorLog("TimeLog", ex.ToString());
            }
        }

        private bool SendMail(string ToMailID, string Body, string Subject, string FilePath, string CCMailID, string BCCMailID)
        {

            bool IsSent = false;
            try
            {
                //Get From App Config From MailID
                string FromMailID = ConfigurationManager.AppSettings["FromMailAddress"].ToString();
                //Set From Mail ID To MailAddress Properties
                MailAddress ObjFrom = new MailAddress(FromMailID, ConfigurationManager.AppSettings["FromDisplayName"].ToString());
                //Call the refrence of ddll system.net.mail.MailMessage which help to send you mail
                System.Net.Mail.MailMessage mails = new System.Net.Mail.MailMessage();
                //Define all proprties related mail configration
                //Set from mail ID here
                mails.From = ObjFrom;
                //Multiple TO Mailid which available comma sepreated the split bu (,)
                string[] SplitTOMailID = ToMailID.Split(',');
                //if array is available the using foreach loop get one by one id 
                foreach (string ToMailIDValues in SplitTOMailID)
                {
                    //Check here if id is not null or blank
                    if (!string.IsNullOrEmpty(ToMailIDValues))
                    {
                        //Here add in To MailID Properites
                        mails.To.Add(ToMailIDValues);
                    }
                }
                //Multiple CC Mailid which available comma sepreated the split bu (,)
                string[] SplitCCMailID = CCMailID.Split(',');
                foreach (string CCMailIDValues in SplitCCMailID)
                {
                    //Check here if id is not null or blank
                    if (!string.IsNullOrEmpty(CCMailIDValues))
                    {
                        //Here add in CC MailID Properites
                        mails.CC.Add(CCMailIDValues);
                    }
                }
                //Multiple BCC Mailid which available comma sepreated the split bu (,)
                string[] SplitBCCMailID = BCCMailID.Split(',');
                foreach (string CCMailIDValues in SplitBCCMailID)
                {
                    //Check here if id is not null or blank
                    if (!string.IsNullOrEmpty(CCMailIDValues))
                    {
                        //Here add in BCC MailID Properites
                        mails.Bcc.Add(CCMailIDValues);
                    }
                }
                // Set Subject
                mails.Subject = Subject.Replace('\r', ' ').Replace('\n', ' ');
                mails.Subject = HttpUtility.HtmlDecode(mails.Subject);
                //if Set html body then always set true
                mails.IsBodyHtml = true;
                //set Message Body
                mails.Body = Body;

                #region Attachment
                //attachment file is exist or not check
                if (File.Exists(FilePath))
                {
                    //if yes the attach the excel sheet
                    Attachment attach = new Attachment(FilePath);
                    //add in mail
                    mails.Attachments.Add(attach);
                }
                #endregion


                //Call SMTP as alias objSMTP
                SmtpClient objSMTP = new SmtpClient();


                if (ConfigurationManager.AppSettings["MailServer"].ToString() == "smtp1.projectstoday.com")
                {
                    objSMTP = new SmtpClient();
                    objSMTP.Host = ConfigurationManager.AppSettings["Host"].ToString();
                    objSMTP.Port = Convert.ToInt32(ConfigurationManager.AppSettings["Port"]);
                    objSMTP.EnableSsl = true;
                    objSMTP.DeliveryMethod = SmtpDeliveryMethod.Network;
                    var fromAddress = new MailAddress(ConfigurationManager.AppSettings["FromMailAddress"].ToString(), ConfigurationManager.AppSettings["FromDisplayName"].ToString());
                    objSMTP.Credentials = new NetworkCredential(fromAddress.Address, ConfigurationManager.AppSettings["Password"].ToString());
                }




                // and finally send mail
                objSMTP.Send(mails);
                IsSent = true;
            }
            //catch (SmtpException ex)
            //{
            //    ErrorLog("SendMail ", ex.ToString() + " ->> " + ex.Message + " ->> " + ex.StackTrace);
            //    //SendMail(ConfigurationManager.AppSettings["MailErrorID"].ToString(), ex.ToString(), "Error In SendMail Function", "", "", "");
            //}
            catch (Exception ex)
            {
                ErrorLog("SendMail ", ex.ToString() + " ->> " + ex.Message + " ->> " + ex.StackTrace);
                //throw err;
            }

            return IsSent;
        }

        private string ExportToExcel(DataTable dtData, string SheetName, string FileName)
        {
            string FilePath = ConfigurationManager.AppSettings["ExcelSavePath"];

            if (dtData.Columns.Contains("incident_id"))
            {
                dtData.Columns.Remove("incident_id");
            }
            if (dtData.Columns.Contains("article_id"))
            {
                dtData.Columns.Remove("article_id");
            }
            if (dtData.Columns.Contains("twitter_id"))
            {
                dtData.Columns.Remove("twitter_id");
            }
            if (dtData.Columns.Contains("video_id"))
            {
                dtData.Columns.Remove("video_id");
            }

            string strReturn = FilePath + FileName;
            DataTable dtCopyTable = new DataTable();
            try
            {
                ExcelPackage pck = new ExcelPackage();
                ExcelWorksheet workSheet1 = pck.Workbook.Worksheets.Add(SheetName);

                var dataRange = workSheet1.Cells["A1"].LoadFromDataTable(dtData, true);

                int colNumber = 1;

                foreach (DataColumn col in dtData.Columns)
                {
                    if (col.DataType == typeof(DateTime))
                    {
                        workSheet1.Column(colNumber).Style.Numberformat.Format = "yyyy-MM-dd HH:mm:ss";//MM/dd/yyyy hh:mm:ss AM/PM
                    }
                    colNumber++;
                }

                var headerCells = workSheet1.Cells[1, 1, 1, workSheet1.Dimension.Columns];
                headerCells.Style.Font.Bold = true;
                headerCells.Style.Fill.PatternType = OfficeOpenXml.Style.ExcelFillStyle.Solid;
                headerCells.Style.Fill.BackgroundColor.SetColor(System.Drawing.Color.Yellow);

                //workSheet1.Cells[workSheet1.Dimension.Address].AutoFitColumns();

                var RowsCells = workSheet1.Cells[1, 1, dtData.Rows.Count + 1, workSheet1.Dimension.Columns];
                RowsCells.Style.Border.Top.Style = ExcelBorderStyle.Thin;
                RowsCells.Style.Border.Top.Color.SetColor(Color.Black);
                RowsCells.Style.Border.Left.Style = ExcelBorderStyle.Thin;
                RowsCells.Style.Border.Left.Color.SetColor(Color.Black);
                RowsCells.Style.Border.Right.Style = ExcelBorderStyle.Thin;
                RowsCells.Style.Border.Right.Color.SetColor(Color.Black);
                RowsCells.Style.Border.Bottom.Style = ExcelBorderStyle.Thin;
                RowsCells.Style.Border.Bottom.Color.SetColor(Color.Black);


                pck.SaveAs(new FileInfo(FilePath + FileName));

            }
            catch (Exception ex)
            {
                strReturn = string.Empty;
                ErrorLog("ExportToExcel", ex.ToString());
            }

            return strReturn;
        }

        private string ExportDataSetToExcel(DataSet dsData, string FileName)
        {
            string FilePath = ConfigurationManager.AppSettings["ExcelSavePath"];
            string strReturn = FilePath + FileName;

            try
            {
                using (ExcelPackage pck = new ExcelPackage())
                {
                    foreach (DataTable dtData in dsData.Tables)
                    {

                        if (dtData.Columns.Contains("incident_id"))
                        {
                            dtData.Columns.Remove("incident_id");
                        }
                        if (dtData.Columns.Contains("article_id"))
                        {
                            dtData.Columns.Remove("article_id");
                        }
                        if (dtData.Columns.Contains("twitter_id"))
                        {
                            dtData.Columns.Remove("twitter_id");
                        }
                        if (dtData.Columns.Contains("video_id"))
                        {
                            dtData.Columns.Remove("video_id");
                        }

                        // Use the DataTable name as the sheet name
                        string sheetName = dtData.TableName;
                        ExcelWorksheet workSheet = pck.Workbook.Worksheets.Add(sheetName);

                        // Load the DataTable data into the worksheet starting from cell A1
                        var dataRange = workSheet.Cells["A1"].LoadFromDataTable(dtData, true);

                        // Format columns as needed
                        int colNumber = 1;
                        foreach (DataColumn col in dtData.Columns)
                        {
                            if (col.DataType == typeof(DateTime))
                            {
                                workSheet.Column(colNumber).Style.Numberformat.Format = "yyyy-MM-dd HH:mm:ss";
                            }
                            colNumber++;
                        }

                        // Style the header row
                        var headerCells = workSheet.Cells[1, 1, 1, workSheet.Dimension.Columns];
                        headerCells.Style.Font.Bold = true;
                        headerCells.Style.Fill.PatternType = OfficeOpenXml.Style.ExcelFillStyle.Solid;
                        headerCells.Style.Fill.BackgroundColor.SetColor(System.Drawing.Color.Yellow);

                        // Style the borders of all data cells
                        var rowsCells = workSheet.Cells[1, 1, dtData.Rows.Count + 1, workSheet.Dimension.Columns];
                        rowsCells.Style.Border.Top.Style = ExcelBorderStyle.Thin;
                        rowsCells.Style.Border.Top.Color.SetColor(Color.Black);
                        rowsCells.Style.Border.Left.Style = ExcelBorderStyle.Thin;
                        rowsCells.Style.Border.Left.Color.SetColor(Color.Black);
                        rowsCells.Style.Border.Right.Style = ExcelBorderStyle.Thin;
                        rowsCells.Style.Border.Right.Color.SetColor(Color.Black);
                        rowsCells.Style.Border.Bottom.Style = ExcelBorderStyle.Thin;
                        rowsCells.Style.Border.Bottom.Color.SetColor(Color.Black);
                    }

                    // Save the Excel file
                    pck.SaveAs(new FileInfo(FilePath + FileName));
                }
            }
            catch (Exception ex)
            {
                strReturn = string.Empty;
                ErrorLog("ExportDataSetToExcel", ex.ToString());
            }

            return strReturn;
        }

        #endregion

        #region Parameters deserialization

        [JsonObject(MemberSerialization.OptIn)]
        [DataContract]
        public class eParameters
        {
            [JsonProperty]
            [DataMember(Name = "search_text")]
            public string SearchText { get; set; }

            [JsonProperty]
            [DataMember(Name = "UserID")]
            public string UserID { get; set; }

            [JsonProperty]
            [DataMember(Name = "platform")]
            public string Platform { get; set; }

            [JsonProperty]
            [DataMember(Name = "article_id")]
            public string ArticleID { get; set; }

            [JsonProperty]
            [DataMember(Name = "twitter_id")]
            public string TwitterID { get; set; }

            [JsonProperty]
            [DataMember(Name = "from_date")]
            public string FromDate { get; set; }

            [JsonProperty]
            [DataMember(Name = "to_date")]
            public string ToDate { get; set; }

            [JsonProperty]
            [DataMember(Name = "base_date")]
            public string BaseDate { get; set; }

            #region Incident

            [JsonProperty]
            [DataMember(Name = "incident_id")]
            public string TopicID { get; set; }

            [JsonProperty]
            [DataMember(Name = "client_id")]
            public string EntityID { get; set; }

            [JsonProperty]
            [DataMember(Name = "incident_title")]
            public string Topic_Title { get; set; }

            [JsonProperty]
            [DataMember(Name = "incident_description")]
            public string Topic_Description { get; set; }

            [JsonProperty]
            [DataMember(Name = "incident_keywords")]
            public string Topic_Keywords { get; set; }

            [JsonProperty]
            [DataMember(Name = "incident_platforms")]
            public string Topic_Platforms { get; set; }

            [JsonProperty]
            [DataMember(Name = "incident_reflinks")]
            public string Topic_RefLinks { get; set; }

            [JsonProperty]
            [DataMember(Name = "incident_query")]
            public string Topic_Query { get; set; }

            [JsonProperty]
            [DataMember(Name = "incident_start_date")]
            public string Topic_StartDate { get; set; }

            [JsonProperty]
            [DataMember(Name = "incident_end_date")]
            public string Topic_EndDate { get; set; }

            [JsonProperty]
            [DataMember(Name = "incident_reactivate_date")]
            public string Topic_ReactivateDate { get; set; }

            #endregion

            [JsonProperty]
            [DataMember(Name = "sentiment")]
            public string Sentiment { get; set; }

            [JsonProperty]
            [DataMember(Name = "tonality")]
            public string Tonality { get; set; }

            [JsonProperty]
            [DataMember(Name = "publication_domain")]
            public string Publication_Domain { get; set; }

            [JsonProperty]
            [DataMember(Name = "publication_type")]
            public string Publication_Type { get; set; }

            [JsonProperty]
            [DataMember(Name = "publication_da")]
            public string Publication_DA { get; set; }

            [JsonProperty]
            [DataMember(Name = "publication_traffic")]
            public string Publication_Traffic { get; set; }

            [JsonProperty]
            [DataMember(Name = "publication_impactscore")]
            public string Publication_ImpactScore { get; set; }

            [JsonProperty]
            [DataMember(Name = "publication_edition")]
            public string Publication_Edition { get; set; }

            [JsonProperty]
            [DataMember(Name = "publication_circulation")]
            public string Publication_Circulation { get; set; }

            [JsonProperty]
            [DataMember(Name = "publication_name")]
            public string Publication_Name { get; set; }

            [JsonProperty]
            [DataMember(Name = "sort_by")]
            public string Sort_By { get; set; }

            [JsonProperty]
            [DataMember(Name = "sort_order")]
            public string Sort_Order { get; set; }

            [JsonProperty]
            [DataMember(Name = "media_type")]
            public string Media_Type { get; set; }

            [JsonProperty]
            [DataMember(Name = "profile_category")]
            public string Profile_Category { get; set; }

            [JsonProperty]
            [DataMember(Name = "mentioned_hashtag")]
            public string Mentioned_Hashtag { get; set; }

            [JsonProperty]
            [DataMember(Name = "mentioned_handle")]
            public string Mentioned_Handle { get; set; }

            [JsonProperty]
            [DataMember(Name = "mention_type")]
            public string Mention_Type { get; set; }

            [JsonProperty]
            [DataMember(Name = "profile_name")]
            public string Profile_Name { get; set; }

            [JsonProperty]
            [DataMember(Name = "profile_handle")]
            public string Profile_Handle { get; set; }

            [JsonProperty]
            [DataMember(Name = "participant_type")]
            public string Participant_Type { get; set; }

            [JsonProperty]
            [DataMember(Name = "profile_followerscount")]
            public string Profile_Followerscount { get; set; }

            [JsonProperty]
            [DataMember(Name = "profile_verifiedType")]
            public string Profile_VerifiedType { get; set; }

            [JsonProperty]
            [DataMember(Name = "client_mention")]
            public string client_mention { get; set; }

            [JsonProperty]
            [DataMember(Name = "headline_sentiment")]
            public string headline_sentiment { get; set; }

            #region User
            [JsonProperty]
            [DataMember(Name = "AppName")]
            public string AppName { get; set; }

            [JsonProperty]
            [DataMember(Name = "UserName")]
            public string UserName { get; set; }

            [JsonProperty]
            [DataMember(Name = "Password")]
            public string Password { get; set; }

            [JsonProperty]
            [DataMember(Name = "DeviceId")]
            public string DeviceId { get; set; }

            [JsonProperty]
            [DataMember(Name = "OS")]
            public string OS { get; set; }

            [JsonProperty]
            [DataMember(Name = "IsNotificationActive")]
            public Int32 IsNotificationActive { get; set; }
            #endregion
        }

        public eParameters GetParameters(string strJson)
        {
            eParameters obj = new eParameters();
            try
            {
                JObject o = new JObject();
                o = JObject.Parse(strJson);

                obj = JsonConvert.DeserializeObject<eParameters>(o.ToString());
            }
            catch (Exception ex)
            {
                ErrorLog("GetParameters", ex.Message + " ->> " + ex.StackTrace + " Detail : " + strJson);
            }
            return obj;
        }

        #endregion

        public void Update_TryCount(Int32 UDDRID)
        {
            SqlCommand _sqlCommand = new SqlCommand();

            try
            {
                SqlConnection _sqlConnection = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ToString());

                _sqlCommand.Connection = _sqlConnection;
                _sqlCommand.Connection.Open();
                _sqlCommand.CommandText = "USP_API_SentryV2_DataRequest_Update_TryCount";
                _sqlCommand.CommandType = CommandType.StoredProcedure;
                _sqlCommand.Parameters.AddWithValue("@UDDRID", UDDRID);
                Convert.ToInt32(_sqlCommand.ExecuteNonQuery());
            }
            catch (Exception ex)
            {
                ErrorLog("Update_UserRequest_DataDownload", ex.Message + " ->> " + ex.StackTrace);
            }
            finally
            {
                _sqlCommand.Connection.Close();
                _sqlCommand.Connection.Dispose();
            }

        }
    }
}
