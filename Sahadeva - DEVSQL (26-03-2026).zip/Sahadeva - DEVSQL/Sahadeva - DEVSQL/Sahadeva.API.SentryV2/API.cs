﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ServiceModel;
using System.ServiceModel.Activation;
using System.ServiceModel.Web;
using System.Data.SqlClient;
using System.Data;
using System.Xml;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System.Web.Script.Serialization;
using System.Runtime.Serialization.Json;
using System.IO;
using System.Text;
using System.Configuration;
using System.Net;
using System.Runtime.Serialization;
using System.Net.Mail;

namespace Sahadeva.API.SentryV2
{
    [ServiceContract]

    [AspNetCompatibilityRequirements(RequirementsMode = AspNetCompatibilityRequirementsMode.Allowed)]

    public class API
    {

        #region Parameters deserialization

        [JsonObject(MemberSerialization.OptIn)]
        [DataContract]
        public class eParameters
        {
            [JsonProperty]
            [DataMember(Name = "search_text")]
            public string SearchText { get; set; }

            [JsonProperty]
            [DataMember(Name = "UserID")]
            public string UserID { get; set; }

            [JsonProperty]
            [DataMember(Name = "platform")]
            public string Platform { get; set; }

            [JsonProperty]
            [DataMember(Name = "article_id")]
            public string ArticleID { get; set; }

            [JsonProperty]
            [DataMember(Name = "twitter_id")]
            public string TwitterID { get; set; }

            [JsonProperty]
            [DataMember(Name = "from_date")]
            public string FromDate { get; set; }

            [JsonProperty]
            [DataMember(Name = "to_date")]
            public string ToDate { get; set; }

            [JsonProperty]
            [DataMember(Name = "base_date")]
            public string BaseDate { get; set; }

            #region Incident

            [JsonProperty]
            [DataMember(Name = "incident_id")]
            public string TopicID { get; set; }

            [JsonProperty]
            [DataMember(Name = "client_id")]
            public string EntityID { get; set; }

            [JsonProperty]
            [DataMember(Name = "incident_title")]
            public string Topic_Title { get; set; }

            [JsonProperty]
            [DataMember(Name = "incident_description")]
            public string Topic_Description { get; set; }

            [JsonProperty]
            [DataMember(Name = "incident_keywords")]
            public string Topic_Keywords { get; set; }

            [JsonProperty]
            [DataMember(Name = "incident_platforms")]
            public string Topic_Platforms { get; set; }

            [JsonProperty]
            [DataMember(Name = "incident_reflinks")]
            public string Topic_RefLinks { get; set; }

            [JsonProperty]
            [DataMember(Name = "incident_query")]
            public string Topic_Query { get; set; }

            [JsonProperty]
            [DataMember(Name = "incident_start_date")]
            public string Topic_StartDate { get; set; }

            [JsonProperty]
            [DataMember(Name = "incident_end_date")]
            public string Topic_EndDate { get; set; }

            [JsonProperty]
            [DataMember(Name = "incident_reactivate_date")]
            public string Topic_ReactivateDate { get; set; }

            #endregion

            [JsonProperty]
            [DataMember(Name = "sentiment")]
            public string Sentiment { get; set; }

            [JsonProperty]
            [DataMember(Name = "tonality")]
            public string Tonality { get; set; }

            [JsonProperty]
            [DataMember(Name = "publication_domain")]
            public string Publication_Domain { get; set; }

            [JsonProperty]
            [DataMember(Name = "publication_type")]
            public string Publication_Type { get; set; }

            [JsonProperty]
            [DataMember(Name = "publication_da")]
            public string Publication_DA { get; set; }

            [JsonProperty]
            [DataMember(Name = "publication_traffic")]
            public string Publication_Traffic { get; set; }

            [JsonProperty]
            [DataMember(Name = "publication_impactscore")]
            public string Publication_ImpactScore { get; set; }

            [JsonProperty]
            [DataMember(Name = "publication_edition")]
            public string Publication_Edition { get; set; }

            [JsonProperty]
            [DataMember(Name = "publication_circulation")]
            public string Publication_Circulation { get; set; }

            [JsonProperty]
            [DataMember(Name = "publication_name")]
            public string Publication_Name { get; set; }

            [JsonProperty]
            [DataMember(Name = "sort_by")]
            public string Sort_By { get; set; }

            [JsonProperty]
            [DataMember(Name = "sort_order")]
            public string Sort_Order { get; set; }

            [JsonProperty]
            [DataMember(Name = "media_type")]
            public string Media_Type { get; set; }

            [JsonProperty]
            [DataMember(Name = "profile_category")]
            public string Profile_Category { get; set; }

            [JsonProperty]
            [DataMember(Name = "mentioned_hashtag")]
            public string Mentioned_Hashtag { get; set; }

            [JsonProperty]
            [DataMember(Name = "mentioned_handle")]
            public string Mentioned_Handle { get; set; }

            [JsonProperty]
            [DataMember(Name = "mention_type")]
            public string Mention_Type { get; set; }

            [JsonProperty]
            [DataMember(Name = "client_mention")]
            public string client_mention { get; set; }

            [JsonProperty]
            [DataMember(Name = "headline_sentiment")]
            public string headline_sentiment { get; set; }

            [JsonProperty]
            [DataMember(Name = "profile_name")]
            public string Profile_Name { get; set; }

            [JsonProperty]
            [DataMember(Name = "profile_handle")]
            public string Profile_Handle { get; set; }

            [JsonProperty]
            [DataMember(Name = "participant_type")]
            public string Participant_Type { get; set; }

            [JsonProperty]
            [DataMember(Name = "profile_followerscount")]
            public string Profile_Followerscount { get; set; }

            [JsonProperty]
            [DataMember(Name = "profile_verifiedType")]
            public string Profile_VerifiedType { get; set; }


            #region User
            [JsonProperty]
            [DataMember(Name = "AppName")]
            public string AppName { get; set; }

            [JsonProperty]
            [DataMember(Name = "UserName")]
            public string UserName { get; set; }

            [JsonProperty]
            [DataMember(Name = "Password")]
            public string Password { get; set; }

            [JsonProperty]
            [DataMember(Name = "DeviceId")]
            public string DeviceId { get; set; }

            [JsonProperty]
            [DataMember(Name = "OS")]
            public string OS { get; set; }

            [JsonProperty]
            [DataMember(Name = "App_Version")]
            public string App_Version { get; set; }

            [JsonProperty]
            [DataMember(Name = "IsNotificationActive")]
            public Int32 IsNotificationActive { get; set; }
            #endregion

            [JsonProperty]
            [DataMember(Name = "is_read")]
            public string IsRead { get; set; }

            [JsonProperty]
            [DataMember(Name = "show_percentage")]
            public Int32 show_percentage { get; set; }

            [JsonProperty]
            [DataMember(Name = "hide_denominator")]
            public string hide_denominator { get; set; }

            #region YouTube

            #region PK & Ref Ids
            [JsonProperty]
            [DataMember(Name = "ly_id")]
            public string LYID { get; set; }

            //[JsonProperty]
            //[DataMember(Name = "service_id")]
            //public string ServiceID { get; set; }

            #endregion

            #region Video Details
            [JsonProperty]
            [DataMember(Name = "video_id")]
            public string Video_ID { get; set; }

            [JsonProperty]
            [DataMember(Name = "video_url")]
            public string Video_URL { get; set; }

            [JsonProperty]
            [DataMember(Name = "video_title")]
            public string Video_Title { get; set; }

            [JsonProperty]
            [DataMember(Name = "video_date")]
            public string Video_Date { get; set; }

            [JsonProperty]
            [DataMember(Name = "video_text")]
            public string Video_Text { get; set; }

            [JsonProperty]
            [DataMember(Name = "video_transcript")]
            public string Video_Transcript { get; set; }

            [JsonProperty]
            [DataMember(Name = "video_tags")]
            public string Video_Tags { get; set; }

            [JsonProperty]
            [DataMember(Name = "duration_in_sec")]
            public string DurationInSec { get; set; }

            [JsonProperty]
            [DataMember(Name = "duration_in_min")]
            public string DurationInMin { get; set; }

            [JsonProperty]
            [DataMember(Name = "video_type")]
            public string Video_Type { get; set; }

            [JsonProperty]
            [DataMember(Name = "discourse_category")]
            public string Discourse_Category { get; set; }

            [JsonProperty]
            [DataMember(Name = "mentioned_topics")]
            public string Mentioned_Topics { get; set; }

            [JsonProperty]
            [DataMember(Name = "mentioned_locations")]
            public string Mentioned_Locations { get; set; }


            #endregion

            #region Channel Details

            [JsonProperty]
            [DataMember(Name = "channel_id")]
            public string Channel_ID { get; set; }

            [JsonProperty]
            [DataMember(Name = "channel_handle")]
            public string Channel_Handle { get; set; }

            [JsonProperty]
            [DataMember(Name = "channel_name")]
            public string Channel_Name { get; set; }

            [JsonProperty]
            [DataMember(Name = "channel_url")]
            public string Channel_URL { get; set; }

            [JsonProperty]
            [DataMember(Name = "channel_joined_date")]
            public string Channel_JoinedDate { get; set; }

            [JsonProperty]
            [DataMember(Name = "channel_description")]
            public string Channel_Description { get; set; }

            [JsonProperty]
            [DataMember(Name = "channel_profile_image_link")]
            public string Channel_ProfileImageLink { get; set; }

            [JsonProperty]
            [DataMember(Name = "channel_subscriber_count")]
            public string Channel_SubscriberCount { get; set; }

            [JsonProperty]
            [DataMember(Name = "channel_videos_count")]
            public string Channel_VideosCount { get; set; }

            [JsonProperty]
            [DataMember(Name = "channel_views_count")]
            public string Channel_ViewsCount { get; set; }

            [JsonProperty]
            [DataMember(Name = "channel_country")]
            public string Channel_Country { get; set; }

            [JsonProperty]
            [DataMember(Name = "channel_category")]
            public string Channel_Category { get; set; }
            #endregion

            #region Engagement Details
            [JsonProperty]
            [DataMember(Name = "engagement_view_count")]
            public string Engagement_ViewCount { get; set; }

            [JsonProperty]
            [DataMember(Name = "engagement_like_count")]
            public string Engagement_LikeCount { get; set; }

            [JsonProperty]
            [DataMember(Name = "engagement_dislike_count")]
            public string Engagement_DisLikeCount { get; set; }

            [JsonProperty]
            [DataMember(Name = "engagement_comment_count")]
            public string Engagement_CommentCount { get; set; }

            [JsonProperty]
            [DataMember(Name = "people_brand_mentions")]
            public string People_Brand_Mentions { get; set; }

            #endregion


            #endregion

            [JsonProperty]
            [DataMember(Name = "article_type")]
            public string Article_Type { get; set; }

            [JsonProperty]
            [DataMember(Name = "eng_type")]
            public string Eng_Type { get; set; }

            [JsonProperty]
            [DataMember(Name = "language")]
            public string Language { get; set; }

            [JsonProperty]
            [DataMember(Name = "author")]
            public string Author { get; set; }

            #region FeedMonitor

            [JsonProperty]
            [DataMember(Name = "google_tab")]
            public string GoogleTab { get; set; }

            [JsonProperty]
            [DataMember(Name = "comment")]
            public string Comment { get; set; }

            [JsonProperty]
            [DataMember(Name = "url")]
            public string Url { get; set; }

            [JsonProperty]
            [DataMember(Name = "source")]
            public string Source { get; set; }

            [JsonProperty]
            [DataMember(Name = "incident_ids")]
            public string TopicIDs { get; set; }



            #endregion

            //twitter landing page optimization related
            [JsonProperty]
            [DataMember(Name = "data_parameter")]
            public string data_parameter { get; set; }

            [JsonProperty]
            [DataMember(Name = "exclude_by_text")]
            public string exclude_by_text { get; set; }

            [JsonProperty]
            [DataMember(Name = "last_seen_id")]
            public string last_seen_id { get; set; }

            [JsonProperty]
            [DataMember(Name = "page_size")]
            public string page_size { get; set; }

            //[JsonProperty]
            //[DataMember(Name = "data_tag")]
            //public string data_tag { get; set; }

            [JsonProperty]
            [DataMember(Name = "login_source")]
            public string login_source { get; set; }

            [JsonProperty]
            [DataMember(Name = "show_ids")]
            public string show_ids { get; set; }

            [JsonProperty]
            [DataMember(Name = "data_tag")]
            public string data_tag { get; set; }

            [JsonProperty]
            [DataMember(Name = "tml_publication_domain")]
            public string tml_publication_domain { get; set; }

            [JsonProperty]
            [DataMember(Name = "tml_publication_name")]
            public string tml_publication_name { get; set; }

            [JsonProperty]
            [DataMember(Name = "tml_author")]
            public string tml_author { get; set; }

            [JsonProperty]
            [DataMember(Name = "tml_channel")]
            public string tml_channel { get; set; }

            [JsonProperty]
            [DataMember(Name = "tml_handle")]
            public string tml_handle { get; set; }

            [JsonProperty]
            [DataMember(Name = "tag_id")]
            public string tag_id { get; set; }

            [JsonProperty]
            [DataMember(Name = "platform_id")]
            public string platform_id { get; set; }
        }

        public eParameters GetParameters(Stream postData, string strFunctionName, string strJson = "")
        {
            eParameters obj = new eParameters();
            try
            {
                JObject o = new JObject();
                if (strFunctionName == "CreateIncident")
                {
                    o = JObject.Parse(strJson);
                }
                else
                {
                    o = JObject.Parse(new StreamReader(postData).ReadToEnd().ToString());
                }


                Log(strFunctionName + " Body Is ", o.ToString());

                if (strFunctionName == "CreateIncident" || strFunctionName == "ModifyIncident" || strFunctionName == "DeactivateIncident" || strFunctionName == "ReactivateIncident" || strFunctionName == "ShareFeedback")
                {
                    SendMail(ConfigurationManager.AppSettings["Incident_MailIds"].ToString(), strFunctionName + " Body Is " + o.ToString(), "SENTRY V2 API LOG - " + strFunctionName, null, "mayuresh.joshi86@gmail.com", "mayuresh.joshi86@gmail.com");
                }

                obj = JsonConvert.DeserializeObject<eParameters>(o.ToString());
            }
            catch (Exception ex)
            {
                Log("GetParameters", ex.Message + " ->> " + ex.StackTrace + " Detail : " + new StreamReader(postData).ReadToEnd().ToString());
            }
            return obj;
        }

        #endregion

        [OperationContract]
        [WebInvoke(Method = "POST", UriTemplate = "FetchClients", ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Bare)]
        public Stream FetchClients(Stream postData)
        {
            string result = string.Empty;

            var setting = new JsonSerializerSettings
            {
                MaxDepth = int.MaxValue,
                Formatting = Newtonsoft.Json.Formatting.None
            };

            try
            {

                if (HttpContext.Current.Request.Headers["token"] != null && !String.IsNullOrEmpty(HttpContext.Current.Request.Headers["token"]))
                {
                    bool IsValid = ValidateRequest(Convert.ToString(HttpContext.Current.Request.Headers["token"]));
                    if (IsValid == false)
                    {
                        result = "401 Unauthorized";
                        return new MemoryStream(Encoding.UTF8.GetBytes(result));
                    }
                }

                WebOperationContext.Current.OutgoingResponse.ContentType = "application/json; charset=utf-8";

                eParameters parameters_obj = GetParameters(postData, "FetchClients");



                DataTable dt = new Sahadeva.API.DAL.API_V2().Client_FetchClientsByUserID(Convert.ToInt32(parameters_obj.UserID));
                dynamic json = new JObject();
                json.status = "200";
                json.message = "Success";
                json.data = new JArray();
                json.data = JArray.FromObject(dt);

                //result = File.ReadAllText(ConfigurationManager.AppSettings["FetchIncidents"]);

                result = JsonConvert.SerializeObject(json, setting);
            }
            catch (Exception ex)
            {
                Log("FetchClients", ex.Message + " ->> " + ex.StackTrace + " Detail : " + new StreamReader(postData).ReadToEnd().ToString());

                dynamic json = new JObject();
                json.status = "Error";
                json.message = "Error Occured";
                result = JsonConvert.SerializeObject(json, setting);

            }

            return new MemoryStream(Encoding.UTF8.GetBytes(result));

        }

        #region Incident

        [OperationContract]
        [WebInvoke(Method = "POST", UriTemplate = "Fetch_EventTypes", ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Bare)]
        public Stream Fetch_EventTypes(Stream postData)
        {
            string result = string.Empty;

            var setting = new JsonSerializerSettings
            {
                MaxDepth = int.MaxValue,
                Formatting = Newtonsoft.Json.Formatting.None
            };

            try
            {

                if (HttpContext.Current.Request.Headers["token"] != null && !String.IsNullOrEmpty(HttpContext.Current.Request.Headers["token"]))
                {
                    bool IsValid = ValidateRequest(Convert.ToString(HttpContext.Current.Request.Headers["token"]));
                    if (IsValid == false)
                    {
                        result = "401 Unauthorized";
                        return new MemoryStream(Encoding.UTF8.GetBytes(result));
                    }
                }

                WebOperationContext.Current.OutgoingResponse.ContentType = "application/json; charset=utf-8";

                dynamic json = new JObject();
                json.status = "200";
                json.message = "Success";
                json.data = new JArray();

                dynamic o = new JObject();
                o.Add("event_type_id", "General Listening");
                o.Add("event_type", "General Listening");
                json.data.Add(o);

                o = new JObject();
                o.Add("event_type_id", "Crisis");
                o.Add("event_type", "Crisis");
                json.data.Add(o);

                o = new JObject();
                o.Add("event_type_id", "Announcements");
                o.Add("event_type", "Announcements");
                json.data.Add(o);


                result = JsonConvert.SerializeObject(json, setting);
            }
            catch (Exception ex)
            {
                Log("Fetch_FeedbackTypes", ex.Message + " ->> " + ex.StackTrace + " Detail : " + new StreamReader(postData).ReadToEnd().ToString());

                dynamic json = new JObject();
                json.status = "Error";
                json.message = "Error Occured";
                result = JsonConvert.SerializeObject(json, setting);

            }

            return new MemoryStream(Encoding.UTF8.GetBytes(result));

        }

        [OperationContract]
        [WebInvoke(Method = "POST", UriTemplate = "FetchIncidents", ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Bare)]
        public Stream FetchIncidents(Stream postData)
        {
            string result = string.Empty;
            var setting = new JsonSerializerSettings
            {
                MaxDepth = int.MaxValue,
                Formatting = Newtonsoft.Json.Formatting.None
            };
            try
            {

                if (HttpContext.Current.Request.Headers["token"] != null && !String.IsNullOrEmpty(HttpContext.Current.Request.Headers["token"]))
                {
                    bool IsValid = ValidateRequest(Convert.ToString(HttpContext.Current.Request.Headers["token"]));
                    if (IsValid == false)
                    {
                        result = "401 Unauthorized";
                        return new MemoryStream(Encoding.UTF8.GetBytes(result));
                    }
                }

                WebOperationContext.Current.OutgoingResponse.ContentType = "application/json; charset=utf-8";

                eParameters parameters_obj = GetParameters(postData, "FetchIncidents");

                if (!String.IsNullOrEmpty(parameters_obj.UserID) && Convert.ToInt32(parameters_obj.UserID) > 0)
                {
                    new Sahadeva.API.DAL.API_V2().UserLog_Insert(Convert.ToInt32(parameters_obj.UserID), "FetchIncidents", 0);
                }

                Log("Start Incident_FetchList", "");
                DataSet ds = new Sahadeva.API.DAL.API_V2().Incident_FetchList(Convert.ToInt32(parameters_obj.UserID), Convert.ToInt32(parameters_obj.EntityID));

                DataTable EventData = new DataTable();
                DataTable FocusUserData = new DataTable();
                if (ds!=null && ds.Tables.Count>0)
                {
                    EventData = ds.Tables[0];
                    if (ds.Tables.Count > 1)
                    {
                        FocusUserData = ds.Tables[1];
                    }
                }

                Log("End Incident_FetchList", "");
                dynamic json = new JObject();
                json.status = "200";
                json.message = "Success";
                
                List<string> focusUsers = FocusUserData.AsEnumerable().Select(row => row.Field<int>("UserID").ToString()).ToList();

                json.focus_user_list = new JArray(focusUsers);
                json.data = new JArray();
                json.data = JArray.FromObject(EventData);

                //result = File.ReadAllText(ConfigurationManager.AppSettings["FetchIncidents"]);

                result = JsonConvert.SerializeObject(json, setting);
                //Log("End Incident_FetchList", "");
                //Log("Result is " , result);
            }
            catch (Exception ex)
            {
                Log("FetchIncidents", ex.Message + " ->> " + ex.StackTrace + " Detail : " + new StreamReader(postData).ReadToEnd().ToString());
                dynamic json = new JObject();
                json.status = "Error";
                json.message = "Error Occured";
                result = JsonConvert.SerializeObject(json, setting);
            }

            return new MemoryStream(Encoding.UTF8.GetBytes(result));

        }

        [OperationContract]
        [WebInvoke(Method = "POST", UriTemplate = "FetchIncidentInfo", ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Bare)]
        public Stream FetchIncidentInfo(Stream postData)
        {
            string result = string.Empty;
            var setting = new JsonSerializerSettings
            {
                MaxDepth = int.MaxValue,
                Formatting = Newtonsoft.Json.Formatting.None
            };
            try
            {

                if (HttpContext.Current.Request.Headers["token"] != null && !String.IsNullOrEmpty(HttpContext.Current.Request.Headers["token"]))
                {
                    bool IsValid = ValidateRequest(Convert.ToString(HttpContext.Current.Request.Headers["token"]));
                    if (IsValid == false)
                    {
                        result = "401 Unauthorized";
                        return new MemoryStream(Encoding.UTF8.GetBytes(result));
                    }
                }

                WebOperationContext.Current.OutgoingResponse.ContentType = "application/json; charset=utf-8";

                eParameters parameters_obj = GetParameters(postData, "FetchIncidentInfo");

                if (!String.IsNullOrEmpty(parameters_obj.UserID) && Convert.ToInt32(parameters_obj.UserID) > 0)
                {
                    new Sahadeva.API.DAL.API_V2().UserLog_Insert(Convert.ToInt32(parameters_obj.UserID), "FetchIncidentInfo", Convert.ToInt32(parameters_obj.TopicID));
                }

                DataTable dt = new Sahadeva.API.DAL.API_V2().Incident_FetchDetail(Convert.ToInt32(parameters_obj.TopicID));
                dynamic json = new JObject();
                json.status = "200";
                json.message = "Success";
                json.data = new JArray();
                json.data = JArray.FromObject(dt);

                //result = File.ReadAllText(ConfigurationManager.AppSettings["FetchIncidents"]);

                result = JsonConvert.SerializeObject(json, setting);
            }
            catch (Exception ex)
            {
                Log("FetchIncidentInfo", ex.Message + " ->> " + ex.StackTrace + " Detail : " + new StreamReader(postData).ReadToEnd().ToString());
                dynamic json = new JObject();
                json.status = "Error";
                json.message = "Error Occured";
                result = JsonConvert.SerializeObject(json, setting);
            }

            return new MemoryStream(Encoding.UTF8.GetBytes(result));

        }

        [OperationContract]
        [WebInvoke(Method = "POST", UriTemplate = "CreateIncident", ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Bare)]
        public Stream CreateIncident(Stream postData)
        {
            string result = string.Empty;

            try
            {

                if (HttpContext.Current.Request.Headers["token"] != null && !String.IsNullOrEmpty(HttpContext.Current.Request.Headers["token"]))
                {
                    bool IsValid = ValidateRequest(Convert.ToString(HttpContext.Current.Request.Headers["token"]));
                    if (IsValid == false)
                    {
                        result = "401 Unauthorized";
                        return new MemoryStream(Encoding.UTF8.GetBytes(result));
                    }
                }

                WebOperationContext.Current.OutgoingResponse.ContentType = "application/json; charset=utf-8";

                //eParameters parameters_obj = GetParameters(postData, "CreateIncident");

                var setting = new JsonSerializerSettings
                {
                    MaxDepth = int.MaxValue,
                    Formatting = Newtonsoft.Json.Formatting.None
                };

                string InputBody = new StreamReader(postData).ReadToEnd().ToString();

                Int32 URTID = 0;
                dynamic stuff = JObject.Parse(InputBody);

                Log("CreateIncident", InputBody);

                eParameters parameters_obj = GetParameters(new MemoryStream(Encoding.UTF8.GetBytes("CreateIncident")), "CreateIncident", InputBody);

                if (!String.IsNullOrEmpty(parameters_obj.UserID) && Convert.ToInt32(parameters_obj.UserID) > 0)
                {
                    new Sahadeva.API.DAL.API_V2().UserLog_Insert(Convert.ToInt32(parameters_obj.UserID), "CreateIncident", 0);
                }

                Int32 UserID = Convert.ToInt32(Convert.ToString(stuff.UserID));

                Int32 client_id = Convert.ToInt32(Convert.ToString(stuff.client_id));
                string incident_title = Convert.ToString(stuff.incident_title);
                string incident_description = Convert.ToString(stuff.incident_description);
                string incident_keywords = Convert.ToString(stuff.incident_keywords);
                string incident_platforms = Convert.ToString(stuff.incident_platforms);
                string incident_reflinks = Convert.ToString(stuff.incident_reflinks);
                string incident_query = Convert.ToString(stuff.incident_query);
                string incident_event_type = Convert.ToString(stuff.event_type);
                DateTime incident_start_date = Convert.ToDateTime(Convert.ToString(stuff.incident_start_date));
                DateTime incident_end_date = Convert.ToDateTime(Convert.ToString(stuff.incident_end_date));
                Int32 ns_is_active = Convert.ToInt32(Convert.ToString(stuff.notification_settings.is_active));

                URTID = new Sahadeva.API.DAL.API_V2().Incident_UserRequestTopic_Insert(UserID, client_id, incident_title, incident_description
                    , incident_keywords, incident_platforms, incident_reflinks, incident_query, incident_start_date, incident_end_date, incident_event_type);

                dynamic json = new JObject();
                json.status = "Successful";
                json.message = "Request has been sent.";


                result = JsonConvert.SerializeObject(json, setting);
            }
            catch (Exception ex)
            {
                Log("CreateIncident", ex.Message + " ->> " + ex.StackTrace + " Detail : " + new StreamReader(postData).ReadToEnd().ToString());
                dynamic json = new JObject();
                json.status = "Error";
                json.message = "Error Occured";

                var setting = new JsonSerializerSettings
                {
                    MaxDepth = int.MaxValue,
                    Formatting = Newtonsoft.Json.Formatting.None
                };
                result = JsonConvert.SerializeObject(json, setting);
            }

            return new MemoryStream(Encoding.UTF8.GetBytes(result));

        }

        [OperationContract]
        [WebInvoke(Method = "POST", UriTemplate = "ModifyIncident", ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Bare)]
        public Stream ModifyIncident(Stream postData)
        {
            string result = string.Empty;

            try
            {

                if (HttpContext.Current.Request.Headers["token"] != null && !String.IsNullOrEmpty(HttpContext.Current.Request.Headers["token"]))
                {
                    bool IsValid = ValidateRequest(Convert.ToString(HttpContext.Current.Request.Headers["token"]));
                    if (IsValid == false)
                    {
                        result = "401 Unauthorized";
                        return new MemoryStream(Encoding.UTF8.GetBytes(result));
                    }
                }

                WebOperationContext.Current.OutgoingResponse.ContentType = "application/json; charset=utf-8";

                eParameters parameters_obj = GetParameters(postData, "ModifyIncident");

                if (!String.IsNullOrEmpty(parameters_obj.UserID) && Convert.ToInt32(parameters_obj.UserID) > 0)
                {
                    new Sahadeva.API.DAL.API_V2().UserLog_Insert(Convert.ToInt32(parameters_obj.UserID), "ModifyIncident", Convert.ToInt32(parameters_obj.TopicID));
                }

                dynamic json = new JObject();
                json.status = "Successful";
                json.message = "Request has been sent.";

                var setting = new JsonSerializerSettings
                {
                    MaxDepth = int.MaxValue,
                    Formatting = Newtonsoft.Json.Formatting.None
                };
                result = JsonConvert.SerializeObject(json, setting);

                //result = JsonConvert.SerializeObject(ReadFile, setting);
            }
            catch (Exception ex)
            {
                Log("ModifyIncident", ex.Message + " ->> " + ex.StackTrace + " Detail : " + new StreamReader(postData).ReadToEnd().ToString());
                dynamic json = new JObject();
                json.status = "Error";
                json.message = "Error Occured";

                var setting = new JsonSerializerSettings
                {
                    MaxDepth = int.MaxValue,
                    Formatting = Newtonsoft.Json.Formatting.None
                };
                result = JsonConvert.SerializeObject(json, setting);
            }

            return new MemoryStream(Encoding.UTF8.GetBytes(result));

        }

        [OperationContract]
        [WebInvoke(Method = "POST", UriTemplate = "DeactivateIncident", ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Bare)]
        public Stream DeactivateIncident(Stream postData)
        {
            string result = string.Empty;

            try
            {

                if (HttpContext.Current.Request.Headers["token"] != null && !String.IsNullOrEmpty(HttpContext.Current.Request.Headers["token"]))
                {
                    bool IsValid = ValidateRequest(Convert.ToString(HttpContext.Current.Request.Headers["token"]));
                    if (IsValid == false)
                    {
                        result = "401 Unauthorized";
                        return new MemoryStream(Encoding.UTF8.GetBytes(result));
                    }
                }

                WebOperationContext.Current.OutgoingResponse.ContentType = "application/json; charset=utf-8";

                eParameters parameters_obj = GetParameters(postData, "DeactivateIncident");

                if (!String.IsNullOrEmpty(parameters_obj.UserID) && Convert.ToInt32(parameters_obj.UserID) > 0)
                {
                    new Sahadeva.API.DAL.API_V2().UserLog_Insert(Convert.ToInt32(parameters_obj.UserID), "DeactivateIncident", Convert.ToInt32(parameters_obj.TopicID));
                }

                dynamic json = new JObject();
                json.status = "Successful";
                json.message = "Request has been sent.";

                var setting = new JsonSerializerSettings
                {
                    MaxDepth = int.MaxValue,
                    Formatting = Newtonsoft.Json.Formatting.None
                };
                result = JsonConvert.SerializeObject(json, setting);

                //result = JsonConvert.SerializeObject(ReadFile, setting);
            }
            catch (Exception ex)
            {
                Log("DeactivateIncident", ex.Message + " ->> " + ex.StackTrace + " Detail : " + new StreamReader(postData).ReadToEnd().ToString());
                dynamic json = new JObject();
                json.status = "Error";
                json.message = "Error Occured";

                var setting = new JsonSerializerSettings
                {
                    MaxDepth = int.MaxValue,
                    Formatting = Newtonsoft.Json.Formatting.None
                };
                result = JsonConvert.SerializeObject(json, setting);
            }

            return new MemoryStream(Encoding.UTF8.GetBytes(result));

        }

        [OperationContract]
        [WebInvoke(Method = "POST", UriTemplate = "ReactivateIncident", ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Bare)]
        public Stream ReactivateIncident(Stream postData)
        {
            string result = string.Empty;

            try
            {

                if (HttpContext.Current.Request.Headers["token"] != null && !String.IsNullOrEmpty(HttpContext.Current.Request.Headers["token"]))
                {
                    bool IsValid = ValidateRequest(Convert.ToString(HttpContext.Current.Request.Headers["token"]));
                    if (IsValid == false)
                    {
                        result = "401 Unauthorized";
                        return new MemoryStream(Encoding.UTF8.GetBytes(result));
                    }
                }

                WebOperationContext.Current.OutgoingResponse.ContentType = "application/json; charset=utf-8";

                eParameters parameters_obj = GetParameters(postData, "ReactivateIncident");

                if (!String.IsNullOrEmpty(parameters_obj.UserID) && Convert.ToInt32(parameters_obj.UserID) > 0)
                {
                    new Sahadeva.API.DAL.API_V2().UserLog_Insert(Convert.ToInt32(parameters_obj.UserID), "ReactivateIncident", Convert.ToInt32(parameters_obj.TopicID));
                }

                dynamic json = new JObject();
                json.status = "Successful";
                json.message = "Request has been sent.";

                var setting = new JsonSerializerSettings
                {
                    MaxDepth = int.MaxValue,
                    Formatting = Newtonsoft.Json.Formatting.None
                };
                result = JsonConvert.SerializeObject(json, setting);

                //result = JsonConvert.SerializeObject(ReadFile, setting);
            }
            catch (Exception ex)
            {
                Log("ReactivateIncident", ex.Message + " ->> " + ex.StackTrace + " Detail : " + new StreamReader(postData).ReadToEnd().ToString());
                dynamic json = new JObject();
                json.status = "Error";
                json.message = "Error Occured";

                var setting = new JsonSerializerSettings
                {
                    MaxDepth = int.MaxValue,
                    Formatting = Newtonsoft.Json.Formatting.None
                };
                result = JsonConvert.SerializeObject(json, setting);
            }

            return new MemoryStream(Encoding.UTF8.GetBytes(result));

        }

        [OperationContract]
        [WebInvoke(Method = "POST", UriTemplate = "FetchIncidentDetail", ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Bare)]
        public Stream FetchIncidentDetail(Stream postData)
        {
            string result = string.Empty;
            var setting = new JsonSerializerSettings
            {
                MaxDepth = int.MaxValue,
                Formatting = Newtonsoft.Json.Formatting.None
            };
            try
            {

                if (HttpContext.Current.Request.Headers["token"] != null && !String.IsNullOrEmpty(HttpContext.Current.Request.Headers["token"]))
                {
                    bool IsValid = ValidateRequest(Convert.ToString(HttpContext.Current.Request.Headers["token"]));
                    if (IsValid == false)
                    {
                        result = "401 Unauthorized";
                        return new MemoryStream(Encoding.UTF8.GetBytes(result));
                    }
                }

                string strDevice = "web";
                if (HttpContext.Current.Request.Headers["APPType"] != null && !String.IsNullOrEmpty(HttpContext.Current.Request.Headers["APPType"]))
                {
                    strDevice = Convert.ToString(HttpContext.Current.Request.Headers["APPType"]);
                }

                WebOperationContext.Current.OutgoingResponse.ContentType = "application/json; charset=utf-8";

                eParameters parameters_obj = GetParameters(postData, "FetchIncidentDetail");

                if (!String.IsNullOrEmpty(parameters_obj.UserID) && Convert.ToInt32(parameters_obj.UserID) > 0)
                {
                    new Sahadeva.API.DAL.API_V2().UserLog_Insert(Convert.ToInt32(parameters_obj.UserID), "FetchIncidentDetail", Convert.ToInt32(parameters_obj.TopicID));
                }

                Log("FetchIncidentDetail DS start", "");
                DataSet ds = new Sahadeva.API.DAL.API_V2().Incident_FetchLanding(Convert.ToInt32(parameters_obj.TopicID), Convert.ToDateTime(parameters_obj.FromDate), Convert.ToDateTime(parameters_obj.ToDate), Convert.ToDateTime(parameters_obj.BaseDate), parameters_obj.hide_denominator, Convert.ToString(parameters_obj.show_percentage), strDevice);
                Log("FetchIncidentDetail DS end", "");


                dynamic json = new JObject();
                if (ds.Tables.Count > 0)
                {
                    json.status = "200";
                    json.message = "Success";
                    json.data = new JObject();

                    dynamic o = new JObject();
                    o.incident_id = Convert.ToInt32(parameters_obj.TopicID);
                    o.twitter_stats = JArray.FromObject(ds.Tables[0]);
                    o.online_article_stats = JArray.FromObject(ds.Tables[1]);
                    o.print_media_stats = JArray.FromObject(ds.Tables[2]);
                    o.volume_growth = JArray.FromObject(ds.Tables[3]);
                    o.velocity = JArray.FromObject(ds.Tables[4]);
                    o.key_highlights_data = JArray.FromObject(ds.Tables[5]);
                    o.traffic_drivers_data = JArray.FromObject(ds.Tables[6]);

                    json.data = o;
                }

                //result = File.ReadAllText(ConfigurationManager.AppSettings["FetchLanding_OnlineArticle"]);

                result = JsonConvert.SerializeObject(json, setting);
            }
            catch (Exception ex)
            {
                Log("FetchIncidentDetail", ex.Message + " ->> " + ex.StackTrace + " Detail : " + new StreamReader(postData).ReadToEnd().ToString());
                dynamic json = new JObject();
                json.status = "Error";
                json.message = "Error Occured";
                result = JsonConvert.SerializeObject(json, setting);
            }

            return new MemoryStream(Encoding.UTF8.GetBytes(result));

        }

        #endregion

        #region List
        [OperationContract]
        [WebInvoke(Method = "POST", UriTemplate = "FetchList_OnlineArticle", ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Bare)]
        public Stream FetchList_OnlineArticle(Stream postData)
        {
            string result = string.Empty;

            try
            {

                if (HttpContext.Current.Request.Headers["token"] != null && !String.IsNullOrEmpty(HttpContext.Current.Request.Headers["token"]))
                {
                    bool IsValid = ValidateRequest(Convert.ToString(HttpContext.Current.Request.Headers["token"]));
                    if (IsValid == false)
                    {
                        result = "401 Unauthorized";
                        return new MemoryStream(Encoding.UTF8.GetBytes(result));
                    }
                }

                WebOperationContext.Current.OutgoingResponse.ContentType = "application/json; charset=utf-8";

                eParameters parameters_obj = GetParameters(postData, "FetchList_OnlineArticle");

                if (!String.IsNullOrEmpty(parameters_obj.UserID) && Convert.ToInt32(parameters_obj.UserID) > 0)
                {
                    new Sahadeva.API.DAL.API_V2().UserLog_Insert(Convert.ToInt32(parameters_obj.UserID), "FetchList_OnlineArticle", Convert.ToInt32(parameters_obj.TopicID));
                }

                var setting = new JsonSerializerSettings
                {
                    MaxDepth = int.MaxValue,
                    Formatting = Newtonsoft.Json.Formatting.None
                };


                DataTable dt = new Sahadeva.API.DAL.API_V2().ArticleOnline_FetchList(Convert.ToInt32(parameters_obj.TopicID), Convert.ToDateTime(parameters_obj.FromDate), Convert.ToDateTime(parameters_obj.ToDate), parameters_obj.Sentiment, parameters_obj.Publication_Domain, parameters_obj.Publication_Type, parameters_obj.Publication_DA, parameters_obj.Publication_Traffic, parameters_obj.Publication_ImpactScore, parameters_obj.Sort_By, parameters_obj.Sort_Order, parameters_obj.SearchText, parameters_obj.Mention_Type, parameters_obj.client_mention, Convert.ToInt32(parameters_obj.UserID), parameters_obj.headline_sentiment, parameters_obj.Article_Type, parameters_obj.exclude_by_text);
                dynamic json = new JObject();
                json.status = "200";
                json.message = "Success";
                json.data = new JArray();
                json.data = JArray.FromObject(dt);

                //result = File.ReadAllText(ConfigurationManager.AppSettings["FetchList_OnlineArticle"]);

                result = JsonConvert.SerializeObject(json, setting);
            }
            catch (Exception ex)
            {
                Log("FetchList_OnlineArticle", ex.Message + " ->> " + ex.StackTrace + " Detail : " + new StreamReader(postData).ReadToEnd().ToString());
                dynamic json = new JObject();
                json.status = "Error";
                json.message = "Error Occured";

                var setting = new JsonSerializerSettings
                {
                    MaxDepth = int.MaxValue,
                    Formatting = Newtonsoft.Json.Formatting.None
                };
                result = JsonConvert.SerializeObject(json, setting);
            }

            return new MemoryStream(Encoding.UTF8.GetBytes(result));

        }

        [OperationContract]
        [WebInvoke(Method = "POST", UriTemplate = "FetchList_PrintArticle", ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Bare)]
        public Stream FetchList_PrintArticle(Stream postData)
        {
            string result = string.Empty;

            try
            {

                if (HttpContext.Current.Request.Headers["token"] != null && !String.IsNullOrEmpty(HttpContext.Current.Request.Headers["token"]))
                {
                    bool IsValid = ValidateRequest(Convert.ToString(HttpContext.Current.Request.Headers["token"]));
                    if (IsValid == false)
                    {
                        result = "401 Unauthorized";
                        return new MemoryStream(Encoding.UTF8.GetBytes(result));
                    }
                }

                WebOperationContext.Current.OutgoingResponse.ContentType = "application/json; charset=utf-8";

                eParameters parameters_obj = GetParameters(postData, "FetchList_PrintArticle");

                if (!String.IsNullOrEmpty(parameters_obj.UserID) && Convert.ToInt32(parameters_obj.UserID) > 0)
                {
                    new Sahadeva.API.DAL.API_V2().UserLog_Insert(Convert.ToInt32(parameters_obj.UserID), "FetchList_PrintArticle", Convert.ToInt32(parameters_obj.TopicID));
                }

                var setting = new JsonSerializerSettings
                {
                    MaxDepth = int.MaxValue,
                    Formatting = Newtonsoft.Json.Formatting.None
                };


                DataTable dt = new Sahadeva.API.DAL.API_V2().ArticlePrint_FetchList(Convert.ToInt32(parameters_obj.TopicID), Convert.ToDateTime(parameters_obj.FromDate), Convert.ToDateTime(parameters_obj.ToDate), parameters_obj.Sentiment, parameters_obj.Publication_Name, parameters_obj.Publication_Edition, parameters_obj.Publication_Type, parameters_obj.Publication_Circulation, parameters_obj.Publication_ImpactScore, parameters_obj.Sort_By, parameters_obj.Sort_Order, parameters_obj.SearchText, parameters_obj.Mention_Type, parameters_obj.client_mention, Convert.ToInt32(parameters_obj.UserID), parameters_obj.headline_sentiment, parameters_obj.Article_Type, parameters_obj.Author, parameters_obj.exclude_by_text, parameters_obj.Language);

                dynamic json = new JObject();
                json.status = "200";
                json.message = "Success";
                json.data = new JArray();
                json.data = JArray.FromObject(dt);

                //result = File.ReadAllText(ConfigurationManager.AppSettings["FetchList_PrintArticle"]);

                result = JsonConvert.SerializeObject(json, setting);
            }
            catch (Exception ex)
            {
                Log("FetchList_PrintArticle", ex.Message + " ->> " + ex.StackTrace + " Detail : " + new StreamReader(postData).ReadToEnd().ToString());
                dynamic json = new JObject();
                json.status = "Error";
                json.message = "Error Occured";

                var setting = new JsonSerializerSettings
                {
                    MaxDepth = int.MaxValue,
                    Formatting = Newtonsoft.Json.Formatting.None
                };
                result = JsonConvert.SerializeObject(json, setting);
            }

            return new MemoryStream(Encoding.UTF8.GetBytes(result));

        }

        [OperationContract]
        [WebInvoke(Method = "POST", UriTemplate = "FetchList_Twitter", ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Bare)]
        public Stream FetchList_Twitter(Stream postData)
        {
            string result = string.Empty;

            try
            {

                if (HttpContext.Current.Request.Headers["token"] != null && !String.IsNullOrEmpty(HttpContext.Current.Request.Headers["token"]))
                {
                    bool IsValid = ValidateRequest(Convert.ToString(HttpContext.Current.Request.Headers["token"]));
                    if (IsValid == false)
                    {
                        result = "401 Unauthorized";
                        return new MemoryStream(Encoding.UTF8.GetBytes(result));
                    }
                }

                WebOperationContext.Current.OutgoingResponse.ContentType = "application/json; charset=utf-8";

                eParameters parameters_obj = GetParameters(postData, "FetchList_Twitter");

                if (!String.IsNullOrEmpty(parameters_obj.UserID) && Convert.ToInt32(parameters_obj.UserID) > 0)
                {
                    new Sahadeva.API.DAL.API_V2().UserLog_Insert(Convert.ToInt32(parameters_obj.UserID), "FetchList_Twitter", Convert.ToInt32(parameters_obj.TopicID));
                }

                var setting = new JsonSerializerSettings
                {
                    MaxDepth = int.MaxValue,
                    Formatting = Newtonsoft.Json.Formatting.None
                };


                DataTable dt = new Sahadeva.API.DAL.API_V2().Twitter_FetchList(Convert.ToInt32(parameters_obj.TopicID), Convert.ToDateTime(parameters_obj.BaseDate), Convert.ToDateTime(parameters_obj.FromDate), Convert.ToDateTime(parameters_obj.ToDate), parameters_obj.Sentiment, parameters_obj.Mentioned_Hashtag, parameters_obj.Mentioned_Handle, parameters_obj.Media_Type, parameters_obj.Profile_Category, parameters_obj.Sort_By, parameters_obj.Sort_Order, parameters_obj.Mention_Type, parameters_obj.Profile_Name, parameters_obj.Profile_Handle, parameters_obj.Profile_Followerscount, parameters_obj.Participant_Type, parameters_obj.Profile_VerifiedType, Convert.ToInt32(parameters_obj.UserID), parameters_obj.Tonality, parameters_obj.Eng_Type, parameters_obj.SearchText, parameters_obj.exclude_by_text);
                Log("Twitter_FetchLanding JSON Creation start", "");
                dynamic json = new JObject();
                json.status = "200";
                json.message = "Success";
                json.data = new JArray();
                json.data = JArray.FromObject(dt);
                Log("Twitter_FetchLanding JSON Creation end", "");

                //result = File.ReadAllText(ConfigurationManager.AppSettings["FetchList_OnlineArticle"]);

                result = JsonConvert.SerializeObject(json, setting);
            }
            catch (Exception ex)
            {
                Log("FetchList_Twitter", ex.Message + " ->> " + ex.StackTrace + " Detail : " + new StreamReader(postData).ReadToEnd().ToString());
                dynamic json = new JObject();
                json.status = "Error";
                json.message = "Error Occured";

                var setting = new JsonSerializerSettings
                {
                    MaxDepth = int.MaxValue,
                    Formatting = Newtonsoft.Json.Formatting.None
                };
                result = JsonConvert.SerializeObject(json, setting);
            }

            return new MemoryStream(Encoding.UTF8.GetBytes(result));

        }

        [OperationContract]
        [WebInvoke(Method = "POST", UriTemplate = "FetchList_YouTube", ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Bare)]
        public Stream FetchList_YouTube(Stream postData)
        {
            string result = string.Empty;

            try
            {

                if (HttpContext.Current.Request.Headers["token"] != null && !String.IsNullOrEmpty(HttpContext.Current.Request.Headers["token"]))
                {
                    bool IsValid = ValidateRequest(Convert.ToString(HttpContext.Current.Request.Headers["token"]));
                    if (IsValid == false)
                    {
                        result = "401 Unauthorized";
                        return new MemoryStream(Encoding.UTF8.GetBytes(result));
                    }
                }

                WebOperationContext.Current.OutgoingResponse.ContentType = "application/json; charset=utf-8";

                eParameters parameters_obj = GetParameters(postData, "FetchList_YouTube");

                if (!String.IsNullOrEmpty(parameters_obj.UserID) && Convert.ToInt32(parameters_obj.UserID) > 0)
                {
                    new Sahadeva.API.DAL.API_V2().UserLog_Insert(Convert.ToInt32(parameters_obj.UserID), "FetchList_YouTube", Convert.ToInt32(parameters_obj.TopicID));
                }

                var setting = new JsonSerializerSettings
                {
                    MaxDepth = int.MaxValue,
                    Formatting = Newtonsoft.Json.Formatting.None
                };


                DataTable dt = new Sahadeva.API.DAL.API_V2().YouTube_FetchList(Convert.ToInt32(parameters_obj.TopicID), Convert.ToDateTime(parameters_obj.BaseDate), Convert.ToDateTime(parameters_obj.FromDate), Convert.ToDateTime(parameters_obj.ToDate),
                    parameters_obj.Video_Tags, parameters_obj.Channel_Handle, parameters_obj.Channel_Name, parameters_obj.Sentiment, parameters_obj.Tonality, parameters_obj.Channel_Category,
                    parameters_obj.Mention_Type, parameters_obj.Profile_VerifiedType, parameters_obj.Participant_Type, parameters_obj.Channel_SubscriberCount, parameters_obj.DurationInMin, parameters_obj.Video_Type,
                    parameters_obj.Discourse_Category, parameters_obj.Mentioned_Topics, parameters_obj.Publication_ImpactScore, parameters_obj.Mentioned_Locations,
                    parameters_obj.Sort_By, parameters_obj.Sort_Order, Convert.ToInt32(parameters_obj.UserID), parameters_obj.People_Brand_Mentions, parameters_obj.Language, parameters_obj.SearchText, parameters_obj.exclude_by_text);

                dynamic json = new JObject();
                json.status = "200";
                json.message = "Success";
                json.data = new JArray();
                json.data = JArray.FromObject(dt);


                result = JsonConvert.SerializeObject(json, setting);

                //result = File.ReadAllText(ConfigurationManager.AppSettings["FetchList_Youtube"]);
            }
            catch (Exception ex)
            {
                Log("FetchList_YouTube", ex.Message + " ->> " + ex.StackTrace + " Detail : " + new StreamReader(postData).ReadToEnd().ToString());
                dynamic json = new JObject();
                json.status = "Error";
                json.message = "Error Occured";

                var setting = new JsonSerializerSettings
                {
                    MaxDepth = int.MaxValue,
                    Formatting = Newtonsoft.Json.Formatting.None
                };
                result = JsonConvert.SerializeObject(json, setting);
            }

            return new MemoryStream(Encoding.UTF8.GetBytes(result));

        }
        #endregion

        #region Detail
        [OperationContract]
        [WebInvoke(Method = "POST", UriTemplate = "FetchOnlineArticle", ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Bare)]
        public Stream FetchOnlineArticle(Stream postData)
        {
            string result = string.Empty;

            try
            {

                if (HttpContext.Current.Request.Headers["token"] != null && !String.IsNullOrEmpty(HttpContext.Current.Request.Headers["token"]))
                {
                    bool IsValid = ValidateRequest(Convert.ToString(HttpContext.Current.Request.Headers["token"]));
                    if (IsValid == false)
                    {
                        result = "401 Unauthorized";
                        return new MemoryStream(Encoding.UTF8.GetBytes(result));
                    }
                }

                WebOperationContext.Current.OutgoingResponse.ContentType = "application/json; charset=utf-8";

                eParameters parameters_obj = GetParameters(postData, "FetchOnlineArticle");

                if (!String.IsNullOrEmpty(parameters_obj.UserID) && Convert.ToInt32(parameters_obj.UserID) > 0)
                {
                    new Sahadeva.API.DAL.API_V2().UserLog_Insert(Convert.ToInt32(parameters_obj.UserID), "FetchOnlineArticle", Convert.ToInt32(parameters_obj.ArticleID));
                }

                var setting = new JsonSerializerSettings
                {
                    MaxDepth = int.MaxValue,
                    Formatting = Newtonsoft.Json.Formatting.None
                };

                DataSet ds = new Sahadeva.API.DAL.API_V2().ArticleOnline_FetchById(Convert.ToInt32(parameters_obj.ArticleID), Convert.ToInt32(parameters_obj.UserID));
                dynamic json = new JObject();
                if (ds.Tables.Count > 0)
                {
                    json.status = "200";
                    json.message = "Success";
                    json.data = new JArray();

                    dynamic o = new JObject();
                    o = (JObject)JArray.FromObject(ds.Tables[0])[0];
                    o.publication = (JObject)JArray.FromObject(ds.Tables[1])[0];
                    o.tags = JArray.FromObject(ds.Tables[2]);
                    o.datatags = JArray.FromObject(ds.Tables[3]);

                    json.data.Add(o);
                }

                //result = File.ReadAllText(ConfigurationManager.AppSettings["FetchOnlineArticle"]);

                result = JsonConvert.SerializeObject(json, setting);
            }
            catch (Exception ex)
            {
                Log("FetchOnlineArticle", ex.Message + " ->> " + ex.StackTrace + " Detail : " + new StreamReader(postData).ReadToEnd().ToString());
                dynamic json = new JObject();
                json.status = "Error";
                json.message = "Error Occured";

                var setting = new JsonSerializerSettings
                {
                    MaxDepth = int.MaxValue,
                    Formatting = Newtonsoft.Json.Formatting.None
                };
                result = JsonConvert.SerializeObject(json, setting);
            }

            return new MemoryStream(Encoding.UTF8.GetBytes(result));

        }

        [OperationContract]
        [WebInvoke(Method = "POST", UriTemplate = "FetchTweet", ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Bare)]
        public Stream FetchTweet(Stream postData)
        {
            string result = string.Empty;

            try
            {

                if (HttpContext.Current.Request.Headers["token"] != null && !String.IsNullOrEmpty(HttpContext.Current.Request.Headers["token"]))
                {
                    bool IsValid = ValidateRequest(Convert.ToString(HttpContext.Current.Request.Headers["token"]));
                    if (IsValid == false)
                    {
                        result = "401 Unauthorized";
                        return new MemoryStream(Encoding.UTF8.GetBytes(result));
                    }
                }

                WebOperationContext.Current.OutgoingResponse.ContentType = "application/json; charset=utf-8";

                eParameters parameters_obj = GetParameters(postData, "FetchTweet");

                if (!String.IsNullOrEmpty(parameters_obj.UserID) && Convert.ToInt32(parameters_obj.UserID) > 0)
                {
                    new Sahadeva.API.DAL.API_V2().UserLog_Insert(Convert.ToInt32(parameters_obj.UserID), "FetchTweet", Convert.ToInt32(parameters_obj.TwitterID));
                }

                var setting = new JsonSerializerSettings
                {
                    MaxDepth = int.MaxValue,
                    Formatting = Newtonsoft.Json.Formatting.None
                };

                DataSet ds = new Sahadeva.API.DAL.API_V2().Twitter_FetchById(Convert.ToInt32(parameters_obj.TwitterID), Convert.ToInt32(parameters_obj.UserID));
                dynamic json = new JObject();
                if (ds.Tables.Count > 0)
                {
                    json.status = "200";
                    json.message = "Success";
                    json.data = new JArray();

                    dynamic o = new JObject();
                    o = (JObject)JArray.FromObject(ds.Tables[0])[0];
                    o.profile = (JObject)JArray.FromObject(ds.Tables[1])[0];
                    o.engagement = (JObject)JArray.FromObject(ds.Tables[2])[0];
                    o.mentioned_attributes = JArray.FromObject(ds.Tables[3]);
                    o.tags = JArray.FromObject(ds.Tables[4]);
                    o.datatags = JArray.FromObject(ds.Tables[5]);

                    json.data.Add(o);
                }

                //result = File.ReadAllText(ConfigurationManager.AppSettings["FetchOnlineArticle"]);

                result = JsonConvert.SerializeObject(json, setting);
            }
            catch (Exception ex)
            {
                Log("FetchTweet", ex.Message + " ->> " + ex.StackTrace + " Detail : " + new StreamReader(postData).ReadToEnd().ToString());
                dynamic json = new JObject();
                json.status = "Error";
                json.message = "Error Occured";

                var setting = new JsonSerializerSettings
                {
                    MaxDepth = int.MaxValue,
                    Formatting = Newtonsoft.Json.Formatting.None
                };
                result = JsonConvert.SerializeObject(json, setting);
            }

            return new MemoryStream(Encoding.UTF8.GetBytes(result));

        }

        [OperationContract]
        [WebInvoke(Method = "POST", UriTemplate = "FetchPrintArticle", ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Bare)]
        public Stream FetchPrintArticle(Stream postData)
        {
            string result = string.Empty;

            try
            {

                if (HttpContext.Current.Request.Headers["token"] != null && !String.IsNullOrEmpty(HttpContext.Current.Request.Headers["token"]))
                {
                    bool IsValid = ValidateRequest(Convert.ToString(HttpContext.Current.Request.Headers["token"]));
                    if (IsValid == false)
                    {
                        result = "401 Unauthorized";
                        return new MemoryStream(Encoding.UTF8.GetBytes(result));
                    }
                }

                WebOperationContext.Current.OutgoingResponse.ContentType = "application/json; charset=utf-8";

                eParameters parameters_obj = GetParameters(postData, "FetchPrintArticle");

                if (!String.IsNullOrEmpty(parameters_obj.UserID) && Convert.ToInt32(parameters_obj.UserID) > 0)
                {
                    new Sahadeva.API.DAL.API_V2().UserLog_Insert(Convert.ToInt32(parameters_obj.UserID), "FetchPrintArticle", Convert.ToInt32(parameters_obj.ArticleID));
                }

                var setting = new JsonSerializerSettings
                {
                    MaxDepth = int.MaxValue,
                    Formatting = Newtonsoft.Json.Formatting.None
                };

                DataSet ds = new Sahadeva.API.DAL.API_V2().ArticlePrint_FetchById(Convert.ToInt32(parameters_obj.ArticleID), Convert.ToInt32(parameters_obj.UserID));

                dynamic json = new JObject();
                if (ds.Tables.Count > 0)
                {
                    json.status = "200";
                    json.message = "Success";
                    json.data = new JArray();

                    dynamic o = new JObject();
                    o = (JObject)JArray.FromObject(ds.Tables[0])[0];
                    o.publication = (JObject)JArray.FromObject(ds.Tables[1])[0];
                    o.tags = JArray.FromObject(ds.Tables[2]);
                    o.datatags = JArray.FromObject(ds.Tables[3]);

                    json.data.Add(o);
                }

                //result = File.ReadAllText(ConfigurationManager.AppSettings["FetchPrintArticle"]);

                result = JsonConvert.SerializeObject(json, setting);
            }
            catch (Exception ex)
            {
                Log("FetchPrintArticle", ex.Message + " ->> " + ex.StackTrace + " Detail : " + new StreamReader(postData).ReadToEnd().ToString());
                dynamic json = new JObject();
                json.status = "Error";
                json.message = "Error Occured";

                var setting = new JsonSerializerSettings
                {
                    MaxDepth = int.MaxValue,
                    Formatting = Newtonsoft.Json.Formatting.None
                };
                result = JsonConvert.SerializeObject(json, setting);
            }

            return new MemoryStream(Encoding.UTF8.GetBytes(result));

        }

        [OperationContract]
        [WebInvoke(Method = "POST", UriTemplate = "FetchDetail_YouTube", ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Bare)]
        public Stream FetchDetail_YouTube(Stream postData)
        {
            string result = string.Empty;

            try
            {

                if (HttpContext.Current.Request.Headers["token"] != null && !String.IsNullOrEmpty(HttpContext.Current.Request.Headers["token"]))
                {
                    bool IsValid = ValidateRequest(Convert.ToString(HttpContext.Current.Request.Headers["token"]));
                    if (IsValid == false)
                    {
                        result = "401 Unauthorized";
                        return new MemoryStream(Encoding.UTF8.GetBytes(result));
                    }
                }

                WebOperationContext.Current.OutgoingResponse.ContentType = "application/json; charset=utf-8";

                eParameters parameters_obj = GetParameters(postData, "FetchDetail_YouTube");

                if (!String.IsNullOrEmpty(parameters_obj.UserID) && Convert.ToInt32(parameters_obj.UserID) > 0)
                {
                    new Sahadeva.API.DAL.API_V2().UserLog_Insert(Convert.ToInt32(parameters_obj.UserID), "FetchDetail_YouTube", Convert.ToInt32(parameters_obj.ArticleID));
                }

                var setting = new JsonSerializerSettings
                {
                    MaxDepth = int.MaxValue,
                    Formatting = Newtonsoft.Json.Formatting.None
                };

                DataSet ds = new Sahadeva.API.DAL.API_V2().YouTube_FetchById(Convert.ToInt32(parameters_obj.Video_ID), Convert.ToInt32(parameters_obj.UserID));

                dynamic json = new JObject();
                if (ds.Tables.Count > 0)
                {
                    json.status = "200";
                    json.message = "Success";
                    json.data = new JArray();

                    dynamic o = new JObject();
                    o = (JObject)JArray.FromObject(ds.Tables[0])[0];
                    o.channel = (JObject)JArray.FromObject(ds.Tables[1])[0];
                    o.engagement = (JObject)JArray.FromObject(ds.Tables[2])[0];
                    o.tags = JArray.FromObject(ds.Tables[3]);
                    o.comments = JArray.FromObject(ds.Tables[4]);
                    o.datatags = JArray.FromObject(ds.Tables[5]);

                    json.data.Add(o);
                }

                //result = File.ReadAllText(ConfigurationManager.AppSettings["FetchDetail_Youtube"]);

                result = JsonConvert.SerializeObject(json, setting);
            }
            catch (Exception ex)
            {
                Log("FetchDetail_YouTube", ex.Message + " ->> " + ex.StackTrace + " Detail : " + new StreamReader(postData).ReadToEnd().ToString());
                dynamic json = new JObject();
                json.status = "Error";
                json.message = "Error Occured";

                var setting = new JsonSerializerSettings
                {
                    MaxDepth = int.MaxValue,
                    Formatting = Newtonsoft.Json.Formatting.None
                };
                result = JsonConvert.SerializeObject(json, setting);
            }

            return new MemoryStream(Encoding.UTF8.GetBytes(result));

        }

        #endregion

        #region Notifications
        [OperationContract]
        [WebInvoke(Method = "POST", UriTemplate = "FetchNotificationSettings", ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Bare)]
        public Stream FetchNotificationSettings(Stream postData)
        {
            string result = string.Empty;

            try
            {

                if (HttpContext.Current.Request.Headers["token"] != null && !String.IsNullOrEmpty(HttpContext.Current.Request.Headers["token"]))
                {
                    bool IsValid = ValidateRequest(Convert.ToString(HttpContext.Current.Request.Headers["token"]));
                    if (IsValid == false)
                    {
                        result = "401 Unauthorized";
                        return new MemoryStream(Encoding.UTF8.GetBytes(result));
                    }
                }

                WebOperationContext.Current.OutgoingResponse.ContentType = "application/json; charset=utf-8";

                eParameters parameters_obj = GetParameters(postData, "FetchNotificationSettings");

                if (!String.IsNullOrEmpty(parameters_obj.UserID) && Convert.ToInt32(parameters_obj.UserID) > 0)
                {
                    new Sahadeva.API.DAL.API_V2().UserLog_Insert(Convert.ToInt32(parameters_obj.UserID), "FetchNotificationSettings", Convert.ToInt32(parameters_obj.TopicID));
                }

                var setting = new JsonSerializerSettings
                {
                    MaxDepth = int.MaxValue,
                    Formatting = Newtonsoft.Json.Formatting.None
                };
                Log("parameters_obj.UserID", parameters_obj.UserID.ToString());
                Log("parameters_obj.TopicID", parameters_obj.TopicID.ToString());

                DataSet ds = new Sahadeva.API.DAL.API_V2().Incident_FetchNotificationSettings(Convert.ToInt32(parameters_obj.UserID), Convert.ToInt32(parameters_obj.TopicID));
                dynamic json = new JObject();
                if (ds.Tables.Count > 0)
                {
                    json.status = "200";
                    json.message = "Success";
                    json.data = new JObject();

                    Log("Tables Count ", ds.Tables.Count.ToString());
                    dynamic o = new JObject();
                    o.user_id = Convert.ToInt32(parameters_obj.UserID);

                    o.incident_id = Convert.ToInt32(parameters_obj.TopicID);
                    o.is_active = Convert.ToInt32(Convert.ToString(ds.Tables[0].Rows[0]["is_active"]));
                    o.online_article = (JObject)JArray.FromObject(ds.Tables[1])[0];
                    Log("online_article", "1");
                    o.print_article = (JObject)JArray.FromObject(ds.Tables[2])[0];
                    Log("print_article", "2");
                    o.twitter = (JObject)JArray.FromObject(ds.Tables[3])[0];
                    Log("twitter", "3");
                    o.youtube = (JObject)JArray.FromObject(ds.Tables[4])[0];
                    Log("youtube", "4");
                    json.data = o;
                }

                result = JsonConvert.SerializeObject(json, setting);
            }
            catch (Exception ex)
            {
                Log("FetchNotificationSettings", ex.Message + " ->> " + ex.StackTrace + " Detail : " + new StreamReader(postData).ReadToEnd().ToString());
                dynamic json = new JObject();
                json.status = "Error";
                json.message = "Error Occured";

                var setting = new JsonSerializerSettings
                {
                    MaxDepth = int.MaxValue,
                    Formatting = Newtonsoft.Json.Formatting.None
                };
                result = JsonConvert.SerializeObject(json, setting);
            }

            return new MemoryStream(Encoding.UTF8.GetBytes(result));

        }

        [OperationContract]
        [WebInvoke(Method = "POST", UriTemplate = "UpdateNotificationSettings", ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Bare)]
        public Stream UpdateNotificationSettings(Stream postData)
        {
            string result = string.Empty;

            try
            {

                if (HttpContext.Current.Request.Headers["token"] != null && !String.IsNullOrEmpty(HttpContext.Current.Request.Headers["token"]))
                {
                    bool IsValid = ValidateRequest(Convert.ToString(HttpContext.Current.Request.Headers["token"]));
                    if (IsValid == false)
                    {
                        result = "401 Unauthorized";
                        return new MemoryStream(Encoding.UTF8.GetBytes(result));
                    }
                }

                WebOperationContext.Current.OutgoingResponse.ContentType = "application/json; charset=utf-8";

                var setting = new JsonSerializerSettings
                {
                    MaxDepth = int.MaxValue,
                    Formatting = Newtonsoft.Json.Formatting.None
                };



                dynamic stuff = JObject.Parse(new StreamReader(postData).ReadToEnd().ToString());
                string strTopicID = stuff.data.incident_id;

                Log("strTopicID Data Is ", strTopicID + "-> " + JsonConvert.SerializeObject(stuff, setting));

                Int32 TopicID = Convert.ToInt32(Convert.ToString(stuff.data.incident_id));
                Int32 UserID = Convert.ToInt32(Convert.ToString(stuff.data.UserID));
                Int32 IsActive = Convert.ToInt32(Convert.ToString(stuff.data.is_active));

                if (Convert.ToInt32(UserID) > 0)
                {
                    new Sahadeva.API.DAL.API_V2().UserLog_Insert(Convert.ToInt32(UserID), "UpdateNotificationSettings", Convert.ToInt32(TopicID));
                }

                Int32 PlatformID = Convert.ToInt32(3);
                Int32 Platform_IsActive = Convert.ToInt32(Convert.ToString(stuff.data.twitter.is_active));
                Int32 Platform_AsItHappens = Convert.ToInt32(Convert.ToString(stuff.data.twitter.as_it_happens));
                Int32 Platform_Summarised = Convert.ToInt32(Convert.ToString(stuff.data.twitter.summarised));
                Int32 Platform_SummarisedInterval = Convert.ToInt32(Convert.ToString(stuff.data.twitter.summarised_interval));
                Int32 Platform_Conditional = Convert.ToInt32(Convert.ToString(stuff.data.twitter.conditional));
                Int32 Result = new Sahadeva.API.DAL.API_V2().Incident_UpdateNotificationSettings(TopicID, UserID, IsActive, PlatformID, Platform_IsActive, Platform_AsItHappens, Platform_Summarised, Platform_SummarisedInterval, Platform_Conditional);

                PlatformID = Convert.ToInt32(1);
                Platform_IsActive = Convert.ToInt32(Convert.ToString(stuff.data.online_article.is_active));
                Platform_AsItHappens = Convert.ToInt32(Convert.ToString(stuff.data.online_article.as_it_happens));
                Platform_Summarised = Convert.ToInt32(Convert.ToString(stuff.data.online_article.summarised));
                Platform_SummarisedInterval = Convert.ToInt32(Convert.ToString(stuff.data.online_article.summarised_interval));
                Platform_Conditional = Convert.ToInt32(Convert.ToString(stuff.data.online_article.conditional));
                Result = new Sahadeva.API.DAL.API_V2().Incident_UpdateNotificationSettings(TopicID, UserID, IsActive, PlatformID, Platform_IsActive, Platform_AsItHappens, Platform_Summarised, Platform_SummarisedInterval, Platform_Conditional);

                PlatformID = Convert.ToInt32(2);
                Platform_IsActive = Convert.ToInt32(Convert.ToString(stuff.data.print_article.is_active));
                Platform_AsItHappens = Convert.ToInt32(Convert.ToString(stuff.data.print_article.as_it_happens));
                Platform_Summarised = Convert.ToInt32(Convert.ToString(stuff.data.print_article.summarised));
                Platform_SummarisedInterval = Convert.ToInt32(Convert.ToString(stuff.data.print_article.summarised_interval));
                Platform_Conditional = Convert.ToInt32(Convert.ToString(stuff.data.print_article.conditional));
                Result = new Sahadeva.API.DAL.API_V2().Incident_UpdateNotificationSettings(TopicID, UserID, IsActive, PlatformID, Platform_IsActive, Platform_AsItHappens, Platform_Summarised, Platform_SummarisedInterval, Platform_Conditional);

                PlatformID = Convert.ToInt32(4);
                Platform_IsActive = Convert.ToInt32(Convert.ToString(stuff.data.youtube.is_active));
                Platform_AsItHappens = Convert.ToInt32(Convert.ToString(stuff.data.youtube.as_it_happens));
                Platform_Summarised = Convert.ToInt32(Convert.ToString(stuff.data.youtube.summarised));
                Platform_SummarisedInterval = Convert.ToInt32(Convert.ToString(stuff.data.youtube.summarised_interval));
                Platform_Conditional = Convert.ToInt32(Convert.ToString(stuff.data.youtube.conditional));
                Result = new Sahadeva.API.DAL.API_V2().Incident_UpdateNotificationSettings(TopicID, UserID, IsActive, PlatformID, Platform_IsActive, Platform_AsItHappens, Platform_Summarised, Platform_SummarisedInterval, Platform_Conditional);


                result = "{\"status\": \"Successful\",\"message\": \"Notification settings has updated.\"}";
            }
            catch (Exception ex)
            {
                Log("UpdateNotificationSettings", ex.Message + " ->> " + ex.StackTrace + " Detail : " + new StreamReader(postData).ReadToEnd().ToString());
                dynamic json = new JObject();
                json.status = "Error";
                json.message = "Error Occured";

                var setting = new JsonSerializerSettings
                {
                    MaxDepth = int.MaxValue,
                    Formatting = Newtonsoft.Json.Formatting.None
                };
                result = JsonConvert.SerializeObject(json, setting);
            }

            return new MemoryStream(Encoding.UTF8.GetBytes(result));

        }

        [OperationContract]
        [WebInvoke(Method = "POST", UriTemplate = "FetchNotificationSettings_New", ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Bare)]
        public Stream FetchNotificationSettings_New(Stream postData)
        {
            string result = string.Empty;

            try
            {

                if (HttpContext.Current.Request.Headers["token"] != null && !String.IsNullOrEmpty(HttpContext.Current.Request.Headers["token"]))
                {
                    bool IsValid = ValidateRequest(Convert.ToString(HttpContext.Current.Request.Headers["token"]));
                    if (IsValid == false)
                    {
                        result = "401 Unauthorized";
                        return new MemoryStream(Encoding.UTF8.GetBytes(result));
                    }
                }

                WebOperationContext.Current.OutgoingResponse.ContentType = "application/json; charset=utf-8";

                eParameters parameters_obj = GetParameters(postData, "FetchNotificationSettings_New");

                if (!String.IsNullOrEmpty(parameters_obj.UserID) && Convert.ToInt32(parameters_obj.UserID) > 0)
                {
                    new Sahadeva.API.DAL.API_V2().UserLog_Insert(Convert.ToInt32(parameters_obj.UserID), "FetchNotificationSettings_New", Convert.ToInt32(parameters_obj.TopicID));
                }

                var setting = new JsonSerializerSettings
                {
                    MaxDepth = int.MaxValue,
                    Formatting = Newtonsoft.Json.Formatting.None
                };
                Log("parameters_obj.UserID", parameters_obj.UserID.ToString());
                Log("parameters_obj.TopicID", parameters_obj.TopicID.ToString());

                DataSet ds = new Sahadeva.API.DAL.API_V2().Incident_FetchNotificationSettings_New(Convert.ToInt32(parameters_obj.UserID), Convert.ToInt32(parameters_obj.TopicID));
                dynamic json = new JObject();
                if (ds.Tables.Count > 0)
                {
                    json.status = "200";
                    json.message = "Success";
                    json.data = new JObject();

                    Log("Tables Count ", ds.Tables.Count.ToString());
                    dynamic o = new JObject();
                    o.user_id = Convert.ToInt32(parameters_obj.UserID);

                    o.incident_id = Convert.ToInt32(parameters_obj.TopicID);
                    o.is_active = Convert.ToInt32(Convert.ToString(ds.Tables[0].Rows[0]["is_active"]));
                    o.online_article = (JObject)JArray.FromObject(ds.Tables[1])[0];
                    Log("online_article", "1");
                    o.print_article = (JObject)JArray.FromObject(ds.Tables[2])[0];
                    Log("print_article", "2");
                    o.twitter = (JObject)JArray.FromObject(ds.Tables[3])[0];
                    Log("twitter", "3");
                    o.youtube = (JObject)JArray.FromObject(ds.Tables[4])[0];
                    Log("youtube", "4");

                    o.online_article["conditional_settings"] = BuildConditional(ds.Tables[5]);
                    o.print_article["conditional_settings"] = BuildConditional(ds.Tables[6]);
                    o.twitter["conditional_settings"] = BuildConditional(ds.Tables[7]);
                    o.youtube["conditional_settings"] = BuildConditional(ds.Tables[8]);

                    json.data = o;
                }

                result = JsonConvert.SerializeObject(json, setting);
            }
            catch (Exception ex)
            {
                Log("FetchNotificationSettings_New", ex.Message + " ->> " + ex.StackTrace + " Detail : " + new StreamReader(postData).ReadToEnd().ToString());
                dynamic json = new JObject();
                json.status = "Error";
                json.message = "Error Occured";

                var setting = new JsonSerializerSettings
                {
                    MaxDepth = int.MaxValue,
                    Formatting = Newtonsoft.Json.Formatting.None
                };
                result = JsonConvert.SerializeObject(json, setting);
            }

            return new MemoryStream(Encoding.UTF8.GetBytes(result));

        }

        [OperationContract]
        [WebInvoke(Method = "POST", UriTemplate = "UpdateNotificationSettings_New", ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Bare)]
        public Stream UpdateNotificationSettings_New(Stream postData)
        {
            string result = string.Empty;

            try
            {

                if (HttpContext.Current.Request.Headers["token"] != null && !String.IsNullOrEmpty(HttpContext.Current.Request.Headers["token"]))
                {
                    bool IsValid = ValidateRequest(Convert.ToString(HttpContext.Current.Request.Headers["token"]));
                    if (IsValid == false)
                    {
                        result = "401 Unauthorized";
                        return new MemoryStream(Encoding.UTF8.GetBytes(result));
                    }
                }

                WebOperationContext.Current.OutgoingResponse.ContentType = "application/json; charset=utf-8";

                var setting = new JsonSerializerSettings
                {
                    MaxDepth = int.MaxValue,
                    Formatting = Newtonsoft.Json.Formatting.None
                };



                dynamic stuff = JObject.Parse(new StreamReader(postData).ReadToEnd().ToString());
                string strTopicID = stuff.data.incident_id;

                Log("strTopicID Data Is ", strTopicID + "-> " + JsonConvert.SerializeObject(stuff, setting));

                Int32 TopicID = Convert.ToInt32(Convert.ToString(stuff.data.incident_id));
                Int32 UserID = Convert.ToInt32(Convert.ToString(stuff.data.user_id));
                Int32 IsActive = Convert.ToInt32(Convert.ToString(stuff.data.is_active));

                if (Convert.ToInt32(UserID) > 0)
                {
                    new Sahadeva.API.DAL.API_V2().UserLog_Insert(Convert.ToInt32(UserID), "UpdateNotificationSettings_New", Convert.ToInt32(TopicID));
                }

                Int32 PlatformID = Convert.ToInt32(3);
                Int32 Platform_IsActive = Convert.ToInt32(Convert.ToString(stuff.data.twitter.is_active));
                Int32 Platform_AsItHappens = Convert.ToInt32(Convert.ToString(stuff.data.twitter.as_it_happens));
                Int32 Platform_Summarised = Convert.ToInt32(Convert.ToString(stuff.data.twitter.summarised));
                Int32 Platform_SummarisedInterval = Convert.ToInt32(Convert.ToString(stuff.data.twitter.summarised_interval));
                Int32 Platform_Conditional = Convert.ToInt32(Convert.ToString(stuff.data.twitter.conditional));

                Int32 Result = new Sahadeva.API.DAL.API_V2().Incident_UpdateNotificationSettings_New(TopicID, UserID, IsActive, PlatformID, Platform_IsActive, Platform_AsItHappens, Platform_Summarised, Platform_SummarisedInterval, Platform_Conditional);

                if (Platform_Conditional == 1)
                {
                    string Con_obj = Convert.ToString(stuff.data.twitter.conditional_settings);

                    foreach (var condition in stuff.data.twitter.conditional_settings)
                    {
                        string conditionName = Convert.ToString(condition["condition_name"]);
                        int conditionId = Convert.ToInt32(Convert.ToString(condition["condition_id"]));
                        int is_active = Convert.ToInt32(Convert.ToString(condition["is_active"]));

                        int Is_Deleted = Convert.ToInt32(Convert.ToString(condition["is_deleted"]));

                        string criteriaJson = condition["criteria"].ToString();

                        Log("Criteria JSON String: ", criteriaJson);

                        new Sahadeva.API.DAL.API_V2().Incident_ConditionalDetail_Insert(TopicID, UserID, PlatformID, conditionId, Is_Deleted, criteriaJson, conditionName, is_active);

                    }

                }

                PlatformID = Convert.ToInt32(1);
                Platform_IsActive = Convert.ToInt32(Convert.ToString(stuff.data.online_article.is_active));
                Platform_AsItHappens = Convert.ToInt32(Convert.ToString(stuff.data.online_article.as_it_happens));
                Platform_Summarised = Convert.ToInt32(Convert.ToString(stuff.data.online_article.summarised));
                Platform_SummarisedInterval = Convert.ToInt32(Convert.ToString(stuff.data.online_article.summarised_interval));
                Platform_Conditional = Convert.ToInt32(Convert.ToString(stuff.data.online_article.conditional));
                Result = new Sahadeva.API.DAL.API_V2().Incident_UpdateNotificationSettings_New(TopicID, UserID, IsActive, PlatformID, Platform_IsActive, Platform_AsItHappens, Platform_Summarised, Platform_SummarisedInterval, Platform_Conditional);

                if (Platform_Conditional == 1)
                {
                    string Con_obj = Convert.ToString(stuff.data.online_article.conditional_settings);

                    foreach (var condition in stuff.data.online_article.conditional_settings)
                    {
                        string conditionName = Convert.ToString(condition["condition_name"]);
                        int conditionId = Convert.ToInt32(Convert.ToString(condition["condition_id"]));
                        int Is_Deleted = Convert.ToInt32(Convert.ToString(condition["is_deleted"]));
                        int is_active = Convert.ToInt32(Convert.ToString(condition["is_active"]));

                        string criteriaJson = condition["criteria"].ToString();

                        Log("Criteria JSON String: ", criteriaJson);

                        new Sahadeva.API.DAL.API_V2().Incident_ConditionalDetail_Insert(TopicID, UserID, PlatformID, conditionId, Is_Deleted, criteriaJson, conditionName, is_active);

                    }

                }

                PlatformID = Convert.ToInt32(2);
                Platform_IsActive = Convert.ToInt32(Convert.ToString(stuff.data.print_article.is_active));
                Platform_AsItHappens = Convert.ToInt32(Convert.ToString(stuff.data.print_article.as_it_happens));
                Platform_Summarised = Convert.ToInt32(Convert.ToString(stuff.data.print_article.summarised));
                Platform_SummarisedInterval = Convert.ToInt32(Convert.ToString(stuff.data.print_article.summarised_interval));
                Platform_Conditional = Convert.ToInt32(Convert.ToString(stuff.data.print_article.conditional));
                Result = new Sahadeva.API.DAL.API_V2().Incident_UpdateNotificationSettings_New(TopicID, UserID, IsActive, PlatformID, Platform_IsActive, Platform_AsItHappens, Platform_Summarised, Platform_SummarisedInterval, Platform_Conditional);

                if (Platform_Conditional == 1)
                {
                    string Con_obj = Convert.ToString(stuff.data.print_article.conditional_settings);

                    foreach (var condition in stuff.data.print_article.conditional_settings)
                    {
                        string conditionName = Convert.ToString(condition["condition_name"]);
                        int conditionId = Convert.ToInt32(Convert.ToString(condition["condition_id"]));
                        int Is_Deleted = Convert.ToInt32(Convert.ToString(condition["is_deleted"]));
                        int is_active = Convert.ToInt32(Convert.ToString(condition["is_active"]));

                        string criteriaJson = condition["criteria"].ToString();

                        Log("Criteria JSON String: ", criteriaJson);

                        new Sahadeva.API.DAL.API_V2().Incident_ConditionalDetail_Insert(TopicID, UserID, PlatformID, conditionId, Is_Deleted, criteriaJson, conditionName, is_active);

                    }

                }

                PlatformID = Convert.ToInt32(4);
                Platform_IsActive = Convert.ToInt32(Convert.ToString(stuff.data.youtube.is_active));
                Platform_AsItHappens = Convert.ToInt32(Convert.ToString(stuff.data.youtube.as_it_happens));
                Platform_Summarised = Convert.ToInt32(Convert.ToString(stuff.data.youtube.summarised));
                Platform_SummarisedInterval = Convert.ToInt32(Convert.ToString(stuff.data.youtube.summarised_interval));
                Platform_Conditional = Convert.ToInt32(Convert.ToString(stuff.data.youtube.conditional));
                Result = new Sahadeva.API.DAL.API_V2().Incident_UpdateNotificationSettings_New(TopicID, UserID, IsActive, PlatformID, Platform_IsActive, Platform_AsItHappens, Platform_Summarised, Platform_SummarisedInterval, Platform_Conditional);

                if (Platform_Conditional == 1)
                {
                    string Con_obj = Convert.ToString(stuff.data.youtube.conditional_settings);

                    foreach (var condition in stuff.data.youtube.conditional_settings)
                    {
                        string conditionName = Convert.ToString(condition["condition_name"]);
                        int conditionId = Convert.ToInt32(Convert.ToString(condition["condition_id"]));
                        int is_active = Convert.ToInt32(Convert.ToString(condition["is_active"]));
                        int Is_Deleted = Convert.ToInt32(Convert.ToString(condition["is_deleted"]));

                        string criteriaJson = condition["criteria"].ToString();

                        Log("Criteria JSON String: ", criteriaJson);

                        new Sahadeva.API.DAL.API_V2().Incident_ConditionalDetail_Insert(TopicID, UserID, PlatformID, conditionId, Is_Deleted, criteriaJson, conditionName, is_active);

                    }

                }


                result = "{\"status\": \"Successful\",\"message\": \"Notification settings has updated.\"}";
            }
            catch (Exception ex)
            {
                Log("UpdateNotificationSettings_New", ex.Message + " ->> " + ex.StackTrace + " Detail : " + new StreamReader(postData).ReadToEnd().ToString());
                dynamic json = new JObject();
                json.status = "Error";
                json.message = "Error Occured";

                var setting = new JsonSerializerSettings
                {
                    MaxDepth = int.MaxValue,
                    Formatting = Newtonsoft.Json.Formatting.None
                };
                result = JsonConvert.SerializeObject(json, setting);
            }

            return new MemoryStream(Encoding.UTF8.GetBytes(result));

        }

        [OperationContract]
        [WebInvoke(Method = "POST", UriTemplate = "FetchSummaryDetail_OnlineArticle", ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Bare)]
        public Stream FetchSummaryDetail_OnlineArticle(Stream postData)
        {
            string result = string.Empty;

            try
            {

                if (HttpContext.Current.Request.Headers["token"] != null && !String.IsNullOrEmpty(HttpContext.Current.Request.Headers["token"]))
                {
                    bool IsValid = ValidateRequest(Convert.ToString(HttpContext.Current.Request.Headers["token"]));
                    if (IsValid == false)
                    {
                        result = "401 Unauthorized";
                        return new MemoryStream(Encoding.UTF8.GetBytes(result));
                    }
                }

                WebOperationContext.Current.OutgoingResponse.ContentType = "application/json; charset=utf-8";

                var setting = new JsonSerializerSettings
                {
                    MaxDepth = int.MaxValue,
                    Formatting = Newtonsoft.Json.Formatting.None
                };


                dynamic stuff = JObject.Parse(new StreamReader(postData).ReadToEnd().ToString());

                Int32 PrimaryKey = Convert.ToInt32(Convert.ToString(stuff.primary_key));
                string NotificationType = Convert.ToString(stuff.notification_type);

                string json = new Sahadeva.API.DAL.API_V2().Fetch_NotificationDetail_ByNLID(NotificationType, PrimaryKey);

                Log("strTopicID Data Is ", PrimaryKey + " -> " + JsonConvert.SerializeObject(json, setting));


                //result = File.ReadAllText(ConfigurationManager.AppSettings["FetchSummaryDetail_OnlineArticle"]);
                if (!string.IsNullOrEmpty(json))
                {
                    //result = JsonConvert.SerializeObject(json, setting);
                    result = json;
                }
                else
                {
                    result = "{\"status\": \"Error\",\"message\": \"Error Occured\"}";
                }

            }
            catch (Exception ex)
            {
                Log("FetchSummaryDetail_OnlineArticle", ex.Message + " ->> " + ex.StackTrace + " Detail : " + new StreamReader(postData).ReadToEnd().ToString());
                dynamic json = new JObject();
                json.status = "Error";
                json.message = "Error Occured";

                var setting = new JsonSerializerSettings
                {
                    MaxDepth = int.MaxValue,
                    Formatting = Newtonsoft.Json.Formatting.None
                };
                result = JsonConvert.SerializeObject(json, setting);
            }

            return new MemoryStream(Encoding.UTF8.GetBytes(result));

        }

        [OperationContract]
        [WebInvoke(Method = "POST", UriTemplate = "FetchSummaryDetail_PrintArticle", ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Bare)]
        public Stream FetchSummaryDetail_PrintArticle(Stream postData)
        {
            string result = string.Empty;

            try
            {

                if (HttpContext.Current.Request.Headers["token"] != null && !String.IsNullOrEmpty(HttpContext.Current.Request.Headers["token"]))
                {
                    bool IsValid = ValidateRequest(Convert.ToString(HttpContext.Current.Request.Headers["token"]));
                    if (IsValid == false)
                    {
                        result = "401 Unauthorized";
                        return new MemoryStream(Encoding.UTF8.GetBytes(result));
                    }
                }

                WebOperationContext.Current.OutgoingResponse.ContentType = "application/json; charset=utf-8";

                var setting = new JsonSerializerSettings
                {
                    MaxDepth = int.MaxValue,
                    Formatting = Newtonsoft.Json.Formatting.None
                };

                dynamic stuff = JObject.Parse(new StreamReader(postData).ReadToEnd().ToString());

                Int32 PrimaryKey = Convert.ToInt32(Convert.ToString(stuff.primary_key));
                string NotificationType = Convert.ToString(stuff.notification_type);

                string json = new Sahadeva.API.DAL.API_V2().Fetch_NotificationDetail_ByNLID(NotificationType, PrimaryKey);

                Log("strTopicID Data Is ", PrimaryKey + " -> " + JsonConvert.SerializeObject(json, setting));


                //result = File.ReadAllText(ConfigurationManager.AppSettings["FetchSummaryDetail_PrintArticle"]);
                if (!string.IsNullOrEmpty(json))
                {
                    //result = JsonConvert.SerializeObject(json, setting);
                    result = json;
                }
                else
                {
                    result = "{\"status\": \"Error\",\"message\": \"Error Occured\"}";
                }
            }
            catch (Exception ex)
            {
                Log("FetchSummaryDetail_PrintArticle", ex.Message + " ->> " + ex.StackTrace + " Detail : " + new StreamReader(postData).ReadToEnd().ToString());
                dynamic json = new JObject();
                json.status = "Error";
                json.message = "Error Occured";

                var setting = new JsonSerializerSettings
                {
                    MaxDepth = int.MaxValue,
                    Formatting = Newtonsoft.Json.Formatting.None
                };
                result = JsonConvert.SerializeObject(json, setting);
            }

            return new MemoryStream(Encoding.UTF8.GetBytes(result));

        }

        [OperationContract]
        [WebInvoke(Method = "POST", UriTemplate = "FetchSummaryDetail_Twitter", ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Bare)]
        public Stream FetchSummaryDetail_Twitter(Stream postData)
        {
            string result = string.Empty;

            try
            {

                if (HttpContext.Current.Request.Headers["token"] != null && !String.IsNullOrEmpty(HttpContext.Current.Request.Headers["token"]))
                {
                    bool IsValid = ValidateRequest(Convert.ToString(HttpContext.Current.Request.Headers["token"]));
                    if (IsValid == false)
                    {
                        result = "401 Unauthorized";
                        return new MemoryStream(Encoding.UTF8.GetBytes(result));
                    }
                }

                WebOperationContext.Current.OutgoingResponse.ContentType = "application/json; charset=utf-8";

                var setting = new JsonSerializerSettings
                {
                    MaxDepth = int.MaxValue,
                    Formatting = Newtonsoft.Json.Formatting.None
                };


                dynamic stuff = JObject.Parse(new StreamReader(postData).ReadToEnd().ToString());

                Int32 PrimaryKey = Convert.ToInt32(Convert.ToString(stuff.primary_key));
                string NotificationType = Convert.ToString(stuff.notification_type);

                string json = new Sahadeva.API.DAL.API_V2().Fetch_NotificationDetail_ByNLID(NotificationType, PrimaryKey);

                Log("strTopicID Data Is ", PrimaryKey + " -> " + JsonConvert.SerializeObject(json, setting));


                //result = File.ReadAllText(ConfigurationManager.AppSettings["FetchSummaryDetail_Twitter"]);
                if (!string.IsNullOrEmpty(json))
                {
                    //result = JsonConvert.SerializeObject(json, setting);
                    result = json;
                }
                else
                {
                    result = "{\"status\": \"Error\",\"message\": \"Error Occured\"}";
                }
            }
            catch (Exception ex)
            {
                Log("FetchSummaryDetail_Twitter", ex.Message + " ->> " + ex.StackTrace + " Detail : " + new StreamReader(postData).ReadToEnd().ToString());
                dynamic json = new JObject();
                json.status = "Error";
                json.message = "Error Occured";

                var setting = new JsonSerializerSettings
                {
                    MaxDepth = int.MaxValue,
                    Formatting = Newtonsoft.Json.Formatting.None
                };
                result = JsonConvert.SerializeObject(json, setting);
            }

            return new MemoryStream(Encoding.UTF8.GetBytes(result));

        }


        [OperationContract]
        [WebInvoke(Method = "POST", UriTemplate = "FetchSummaryDetail_YouTube", ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Bare)]
        public Stream FetchSummaryDetail_YouTube(Stream postData)
        {
            string result = string.Empty;

            try
            {

                if (HttpContext.Current.Request.Headers["token"] != null && !String.IsNullOrEmpty(HttpContext.Current.Request.Headers["token"]))
                {
                    bool IsValid = ValidateRequest(Convert.ToString(HttpContext.Current.Request.Headers["token"]));
                    if (IsValid == false)
                    {
                        result = "401 Unauthorized";
                        return new MemoryStream(Encoding.UTF8.GetBytes(result));
                    }
                }

                WebOperationContext.Current.OutgoingResponse.ContentType = "application/json; charset=utf-8";

                var setting = new JsonSerializerSettings
                {
                    MaxDepth = int.MaxValue,
                    Formatting = Newtonsoft.Json.Formatting.None
                };


                dynamic stuff = JObject.Parse(new StreamReader(postData).ReadToEnd().ToString());

                Int32 PrimaryKey = Convert.ToInt32(Convert.ToString(stuff.primary_key));
                string NotificationType = Convert.ToString(stuff.notification_type);

                string json = new Sahadeva.API.DAL.API_V2().Fetch_NotificationDetail_ByNLID(NotificationType, PrimaryKey);

                Log("strTopicID Data Is ", PrimaryKey + " -> " + JsonConvert.SerializeObject(json, setting));


                //result = File.ReadAllText(ConfigurationManager.AppSettings["FetchSummaryDetail_Twitter"]);
                if (!string.IsNullOrEmpty(json))
                {
                    //result = JsonConvert.SerializeObject(json, setting);
                    result = json;
                }
                else
                {
                    result = "{\"status\": \"Error\",\"message\": \"Error Occured\"}";
                }
            }
            catch (Exception ex)
            {
                Log("FetchSummaryDetail_YouTube", ex.Message + " ->> " + ex.StackTrace + " Detail : " + new StreamReader(postData).ReadToEnd().ToString());
                dynamic json = new JObject();
                json.status = "Error";
                json.message = "Error Occured";

                var setting = new JsonSerializerSettings
                {
                    MaxDepth = int.MaxValue,
                    Formatting = Newtonsoft.Json.Formatting.None
                };
                result = JsonConvert.SerializeObject(json, setting);
            }

            return new MemoryStream(Encoding.UTF8.GetBytes(result));

        }

        #endregion

        #region Filter
        [OperationContract]
        [WebInvoke(Method = "POST", UriTemplate = "FetchFilter_OnlineArticle", ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Bare)]
        public Stream FetchFilter_OnlineArticle(Stream postData)
        {
            string result = string.Empty;

            try
            {

                if (HttpContext.Current.Request.Headers["token"] != null && !String.IsNullOrEmpty(HttpContext.Current.Request.Headers["token"]))
                {
                    bool IsValid = ValidateRequest(Convert.ToString(HttpContext.Current.Request.Headers["token"]));
                    if (IsValid == false)
                    {
                        result = "401 Unauthorized";
                        return new MemoryStream(Encoding.UTF8.GetBytes(result));
                    }
                }

                WebOperationContext.Current.OutgoingResponse.ContentType = "application/json; charset=utf-8";

                eParameters parameters_obj = GetParameters(postData, "FetchFilter_OnlineArticle");

                if (!String.IsNullOrEmpty(parameters_obj.UserID) && Convert.ToInt32(parameters_obj.UserID) > 0)
                {
                    new Sahadeva.API.DAL.API_V2().UserLog_Insert(Convert.ToInt32(parameters_obj.UserID), "FetchFilter_OnlineArticle", Convert.ToInt32(parameters_obj.TopicID));
                }

                var setting = new JsonSerializerSettings
                {
                    MaxDepth = int.MaxValue,
                    Formatting = Newtonsoft.Json.Formatting.None
                };

                DataSet ds = new Sahadeva.API.DAL.API_V2().ArticleOnline_FetchFilter(Convert.ToInt32(parameters_obj.TopicID), Convert.ToDateTime(parameters_obj.FromDate), Convert.ToDateTime(parameters_obj.ToDate));

                dynamic json = new JObject();
                if (ds.Tables.Count > 0)
                {
                    json.status = "200";
                    json.message = "Success";
                    json.data = new JArray();

                    //dynamic oo = new JObject();
                    //oo.filter = new JObject();
                    //oo.filter.search_text = "";
                    //oo.filter.sentiment = JArray.FromObject(ds.Tables[0]);
                    //oo.filter.publication_domain = JArray.FromObject(ds.Tables[1]);
                    //oo.filter.publication_category = JArray.FromObject(ds.Tables[2]);
                    //oo.filter.publication_type = JArray.FromObject(ds.Tables[3]);
                    //oo.filter.domain_authority = JArray.FromObject(ds.Tables[4]);
                    //oo.filter.domain_traffic = JArray.FromObject(ds.Tables[5]);

                    dynamic oo = new JObject();
                    oo.filter = new JObject();
                    oo.filter.search_text = "";
                    oo.filter.exclude_by_text = "";

                    oo.filter.headline_sentiment = JArray.FromObject(ds.Tables[9]);
                    oo.filter.sentiment = JArray.FromObject(ds.Tables[0]);

                    oo.filter.publication_type = JArray.FromObject(ds.Tables[3]);
                    oo.filter.mention_type = JArray.FromObject(ds.Tables[7]);
                    oo.filter.client_mention_headline = JArray.FromObject(ds.Tables[8]);

                    //oo.filter.publication_domain = JArray.FromObject(ds.Tables[1]);
                    oo.filter.publication_domain = "";
                    oo.filter.publication_category = JArray.FromObject(ds.Tables[2]);

                    oo.filter.domain_authority = (JObject)JArray.FromObject(ds.Tables[4])[0];
                    oo.filter.domain_traffic = JArray.FromObject(ds.Tables[5]);
                    oo.filter.pi_score = (JObject)JArray.FromObject(ds.Tables[6])[0];
                    oo.filter.article_type = JArray.FromObject(ds.Tables[10]);
                    oo.filter.datatags = JArray.FromObject(ds.Tables[11]);
                    oo.filter.tml_publication_domain = JArray.FromObject(ds.Tables[12]);


                    json.data.Add(oo);
                }

                result = JsonConvert.SerializeObject(json, setting);
            }
            catch (Exception ex)
            {
                Log("FetchFilter_OnlineArticle", ex.Message + " ->> " + ex.StackTrace + " Detail : " + new StreamReader(postData).ReadToEnd().ToString());
                dynamic json = new JObject();
                json.status = "Error";
                json.message = "Error Occured";

                var setting = new JsonSerializerSettings
                {
                    MaxDepth = int.MaxValue,
                    Formatting = Newtonsoft.Json.Formatting.None
                };
                result = JsonConvert.SerializeObject(json, setting);
            }

            return new MemoryStream(Encoding.UTF8.GetBytes(result));

        }

        [OperationContract]
        [WebInvoke(Method = "POST", UriTemplate = "FetchFilter_PrintArticle", ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Bare)]
        public Stream FetchFilter_Print(Stream postData)
        {
            string result = string.Empty;

            try
            {

                if (HttpContext.Current.Request.Headers["token"] != null && !String.IsNullOrEmpty(HttpContext.Current.Request.Headers["token"]))
                {
                    bool IsValid = ValidateRequest(Convert.ToString(HttpContext.Current.Request.Headers["token"]));
                    if (IsValid == false)
                    {
                        result = "401 Unauthorized";
                        return new MemoryStream(Encoding.UTF8.GetBytes(result));
                    }
                }

                WebOperationContext.Current.OutgoingResponse.ContentType = "application/json; charset=utf-8";

                eParameters parameters_obj = GetParameters(postData, "FetchFilter_Print");

                if (!String.IsNullOrEmpty(parameters_obj.UserID) && Convert.ToInt32(parameters_obj.UserID) > 0)
                {
                    new Sahadeva.API.DAL.API_V2().UserLog_Insert(Convert.ToInt32(parameters_obj.UserID), "FetchFilter_PrintArticle", Convert.ToInt32(parameters_obj.TopicID));
                }

                var setting = new JsonSerializerSettings
                {
                    MaxDepth = int.MaxValue,
                    Formatting = Newtonsoft.Json.Formatting.None
                };

                DataSet ds = new Sahadeva.API.DAL.API_V2().ArticlePrint_FetchFilter(Convert.ToInt32(parameters_obj.TopicID), Convert.ToDateTime(parameters_obj.FromDate), Convert.ToDateTime(parameters_obj.ToDate));

                dynamic json = new JObject();
                if (ds.Tables.Count > 0)
                {
                    json.status = "200";
                    json.message = "Success";
                    json.data = new JArray();

                    dynamic oo = new JObject();
                    oo.filter = new JObject();
                    oo.filter.search_text = "";
                    oo.filter.exclude_by_text = "";
                    oo.filter.headline_sentiment = JArray.FromObject(ds.Tables[9]);
                    oo.filter.sentiment = JArray.FromObject(ds.Tables[0]);

                    oo.filter.publication_name = JArray.FromObject(ds.Tables[1]);
                    oo.filter.publication_type = JArray.FromObject(ds.Tables[3]);

                    oo.filter.publication_edition = JArray.FromObject(ds.Tables[4]);
                    oo.filter.mention_type = JArray.FromObject(ds.Tables[7]);
                    oo.filter.client_mention_headline = JArray.FromObject(ds.Tables[8]);
                    oo.filter.pi_score = (JObject)JArray.FromObject(ds.Tables[6])[0];

                    oo.filter.publication_category = JArray.FromObject(ds.Tables[2]);
                    oo.filter.publication_circulation = JArray.FromObject(ds.Tables[5]);
                    oo.filter.article_type = JArray.FromObject(ds.Tables[10]);
                    oo.filter.source = JArray.FromObject(ds.Tables[11]);
                    oo.filter.language = JArray.FromObject(ds.Tables[12]);
                    oo.filter.datatags = JArray.FromObject(ds.Tables[13]);
                    oo.filter.tml_publication_name = JArray.FromObject(ds.Tables[14]);
                    oo.filter.tml_author = JArray.FromObject(ds.Tables[15]);

                    json.data.Add(oo);


                }

                result = JsonConvert.SerializeObject(json, setting);
            }
            catch (Exception ex)
            {
                Log("FetchFilter_Print", ex.Message + " ->> " + ex.StackTrace + " Detail : " + new StreamReader(postData).ReadToEnd().ToString());
                dynamic json = new JObject();
                json.status = "Error";
                json.message = "Error Occured";

                var setting = new JsonSerializerSettings
                {
                    MaxDepth = int.MaxValue,
                    Formatting = Newtonsoft.Json.Formatting.None
                };
                result = JsonConvert.SerializeObject(json, setting);
            }

            return new MemoryStream(Encoding.UTF8.GetBytes(result));

        }

        [OperationContract]
        [WebInvoke(Method = "POST", UriTemplate = "FetchFilter_Twitter", ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Bare)]
        public Stream FetchFilter_Twitter(Stream postData)
        {
            string result = string.Empty;

            try
            {

                if (HttpContext.Current.Request.Headers["token"] != null && !String.IsNullOrEmpty(HttpContext.Current.Request.Headers["token"]))
                {
                    bool IsValid = ValidateRequest(Convert.ToString(HttpContext.Current.Request.Headers["token"]));
                    if (IsValid == false)
                    {
                        result = "401 Unauthorized";
                        return new MemoryStream(Encoding.UTF8.GetBytes(result));
                    }
                }

                WebOperationContext.Current.OutgoingResponse.ContentType = "application/json; charset=utf-8";

                eParameters parameters_obj = GetParameters(postData, "FetchFilter_Twitter");

                if (!String.IsNullOrEmpty(parameters_obj.UserID) && Convert.ToInt32(parameters_obj.UserID) > 0)
                {
                    new Sahadeva.API.DAL.API_V2().UserLog_Insert(Convert.ToInt32(parameters_obj.UserID), "FetchFilter_Twitter", Convert.ToInt32(parameters_obj.TopicID));
                }

                var setting = new JsonSerializerSettings
                {
                    MaxDepth = int.MaxValue,
                    Formatting = Newtonsoft.Json.Formatting.None
                };

                DataSet ds = new Sahadeva.API.DAL.API_V2().Twitter_FetchFilter(Convert.ToInt32(parameters_obj.TopicID), Convert.ToDateTime(parameters_obj.BaseDate), Convert.ToDateTime(parameters_obj.FromDate), Convert.ToDateTime(parameters_obj.ToDate));

                dynamic json = new JObject();
                if (ds.Tables.Count > 0)
                {
                    json.status = "200";
                    json.message = "Success";
                    json.data = new JArray();

                    dynamic oo = new JObject();
                    oo.filter = new JObject();
                    oo.filter.mentioned_hashtag = "";
                    oo.filter.mentioned_handle = "";
                    oo.filter.profile_name = "";
                    oo.filter.profile_handle = "";
                    oo.filter.search_text = "";
                    oo.filter.exclude_by_text = "";
                    oo.filter.sentiment = JArray.FromObject(ds.Tables[0]);
                    oo.filter.media_type = JArray.FromObject(ds.Tables[1]);
                    oo.filter.profile_category = JArray.FromObject(ds.Tables[2]);
                    oo.filter.mention_type = JArray.FromObject(ds.Tables[3]);
                    oo.filter.followers = JArray.FromObject(ds.Tables[4]);
                    oo.filter.participant_type = JArray.FromObject(ds.Tables[5]);
                    oo.filter.verified_type = JArray.FromObject(ds.Tables[6]);
                    oo.filter.tonality = JArray.FromObject(ds.Tables[7]);
                    oo.filter.eng_type = JArray.FromObject(ds.Tables[8]);
                    oo.filter.hashtags = JArray.FromObject(ds.Tables[9]);
                    oo.filter.datatags = JArray.FromObject(ds.Tables[10]);
                    oo.filter.tml_handle = JArray.FromObject(ds.Tables[11]);
                    json.data.Add(oo);
                }

                result = JsonConvert.SerializeObject(json, setting);
            }
            catch (Exception ex)
            {
                Log("FetchFilter_Twitter", ex.Message + " ->> " + ex.StackTrace + " Detail : " + new StreamReader(postData).ReadToEnd().ToString());
                dynamic json = new JObject();
                json.status = "Error";
                json.message = "Error Occured";

                var setting = new JsonSerializerSettings
                {
                    MaxDepth = int.MaxValue,
                    Formatting = Newtonsoft.Json.Formatting.None
                };
                result = JsonConvert.SerializeObject(json, setting);
            }

            return new MemoryStream(Encoding.UTF8.GetBytes(result));

        }

        [OperationContract]
        [WebInvoke(Method = "POST", UriTemplate = "FetchFilter_YouTube", ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Bare)]
        public Stream FetchFilter_YouTube(Stream postData)
        {
            string result = string.Empty;

            try
            {

                if (HttpContext.Current.Request.Headers["token"] != null && !String.IsNullOrEmpty(HttpContext.Current.Request.Headers["token"]))
                {
                    bool IsValid = ValidateRequest(Convert.ToString(HttpContext.Current.Request.Headers["token"]));
                    if (IsValid == false)
                    {
                        result = "401 Unauthorized";
                        return new MemoryStream(Encoding.UTF8.GetBytes(result));
                    }
                }

                WebOperationContext.Current.OutgoingResponse.ContentType = "application/json; charset=utf-8";

                eParameters parameters_obj = GetParameters(postData, "FetchFilter_YouTube");

                if (!String.IsNullOrEmpty(parameters_obj.UserID) && Convert.ToInt32(parameters_obj.UserID) > 0)
                {
                    new Sahadeva.API.DAL.API_V2().UserLog_Insert(Convert.ToInt32(parameters_obj.UserID), "FetchFilter_YouTube", Convert.ToInt32(parameters_obj.TopicID));
                }

                var setting = new JsonSerializerSettings
                {
                    MaxDepth = int.MaxValue,
                    Formatting = Newtonsoft.Json.Formatting.None
                };

                DataSet ds = new Sahadeva.API.DAL.API_V2().YouTube_FetchFilter(Convert.ToInt32(parameters_obj.TopicID), Convert.ToDateTime(parameters_obj.BaseDate), Convert.ToDateTime(parameters_obj.FromDate), Convert.ToDateTime(parameters_obj.ToDate));

                dynamic json = new JObject();
                if (ds.Tables.Count > 0)
                {
                    json.status = "200";
                    json.message = "Success";
                    json.data = new JArray();

                    dynamic oo = new JObject();
                    oo.filter = new JObject();
                    oo.filter.mentioned_hashtag = "";
                    oo.filter.mentioned_handle = "";
                    oo.filter.channel_name = "";
                    oo.filter.channel_handle = "";
                    oo.filter.search_text = "";
                    oo.filter.exclude_by_text = "";
                    oo.filter.sentiment = JArray.FromObject(ds.Tables[0]);
                    oo.filter.tonality = JArray.FromObject(ds.Tables[1]);
                    oo.filter.channel_category = JArray.FromObject(ds.Tables[2]);
                    oo.filter.mention_type = JArray.FromObject(ds.Tables[3]);
                    oo.filter.verified_type = JArray.FromObject(ds.Tables[4]);
                    oo.filter.participant_type = JArray.FromObject(ds.Tables[5]);
                    oo.filter.subscribers_range = JArray.FromObject(ds.Tables[6]);
                    oo.filter.length_range = JArray.FromObject(ds.Tables[7]);
                    oo.filter.types_of_video = JArray.FromObject(ds.Tables[8]);
                    oo.filter.discource_category = JArray.FromObject(ds.Tables[9]);
                    oo.filter.people_brand_mentions = JArray.FromObject(ds.Tables[10]);
                    oo.filter.topics_discussed_in_video = JArray.FromObject(ds.Tables[11]);
                    oo.filter.impact_score_range = JArray.FromObject(ds.Tables[12]);
                    oo.filter.location = JArray.FromObject(ds.Tables[13]);
                    oo.filter.language = JArray.FromObject(ds.Tables[14]);
                    oo.filter.datatags = JArray.FromObject(ds.Tables[15]);
                    oo.filter.tml_channel = JArray.FromObject(ds.Tables[16]);
                    json.data.Add(oo);
                }

                result = JsonConvert.SerializeObject(json, setting);

                //result = File.ReadAllText(ConfigurationManager.AppSettings["FetchFilter_YouTube"]);
            }
            catch (Exception ex)
            {
                Log("FetchFilter_YouTube", ex.Message + " ->> " + ex.StackTrace + " Detail : " + new StreamReader(postData).ReadToEnd().ToString());
                dynamic json = new JObject();
                json.status = "Error";
                json.message = "Error Occured";

                var setting = new JsonSerializerSettings
                {
                    MaxDepth = int.MaxValue,
                    Formatting = Newtonsoft.Json.Formatting.None
                };
                result = JsonConvert.SerializeObject(json, setting);
            }

            return new MemoryStream(Encoding.UTF8.GetBytes(result));

        }

        #endregion

        #region Landing
        [OperationContract]
        [WebInvoke(Method = "POST", UriTemplate = "FetchLanding_OnlineArticle", ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Bare)]
        public Stream FetchLanding_OnlineArticle(Stream postData)
        {
            string result = string.Empty;

            try
            {

                if (HttpContext.Current.Request.Headers["token"] != null && !String.IsNullOrEmpty(HttpContext.Current.Request.Headers["token"]))
                {
                    bool IsValid = ValidateRequest(Convert.ToString(HttpContext.Current.Request.Headers["token"]));
                    if (IsValid == false)
                    {
                        result = "401 Unauthorized";
                        return new MemoryStream(Encoding.UTF8.GetBytes(result));
                    }
                }

                string strDevice = "web";
                if (HttpContext.Current.Request.Headers["APPType"] != null && !String.IsNullOrEmpty(HttpContext.Current.Request.Headers["APPType"]))
                {
                    strDevice = Convert.ToString(HttpContext.Current.Request.Headers["APPType"]);
                }

                WebOperationContext.Current.OutgoingResponse.ContentType = "application/json; charset=utf-8";

                //Converting to stringa and back to Stream, caz Stream losses its memory
                string InputBody = new StreamReader(postData).ReadToEnd().ToString();
                byte[] byteArray = Encoding.UTF8.GetBytes(InputBody);
                MemoryStream stream = new MemoryStream(byteArray);
                postData = stream;

                eParameters parameters_obj = GetParameters(postData, "FetchLanding_OnlineArticle");

                if (!String.IsNullOrEmpty(parameters_obj.UserID) && Convert.ToInt32(parameters_obj.UserID) > 0)
                {
                    new Sahadeva.API.DAL.API_V2().UserLog_Insert(Convert.ToInt32(parameters_obj.UserID), "FetchLanding_OnlineArticle", Convert.ToInt32(parameters_obj.TopicID));
                }

                var setting = new JsonSerializerSettings
                {
                    MaxDepth = int.MaxValue,
                    Formatting = Newtonsoft.Json.Formatting.None
                };


                DataSet ds = new DataSet();

                Log("ArticleOnline_FetchLanding DS start", "");
                ds = new Sahadeva.API.DAL.API_V2().ArticleOnline_FetchLanding(Convert.ToInt32(parameters_obj.TopicID), Convert.ToDateTime(parameters_obj.FromDate), Convert.ToDateTime(parameters_obj.ToDate), Convert.ToDateTime(parameters_obj.BaseDate), parameters_obj.hide_denominator, Convert.ToString(parameters_obj.show_percentage), strDevice);
                Log("ArticleOnline_FetchLanding DS end", "");


                dynamic json = new JObject();
                if (ds.Tables.Count > 0)
                {
                    json.status = "200";
                    json.message = "Success";
                    json.data = new JObject();

                    dynamic o = new JObject();
                    o.incident_id = Convert.ToInt32(parameters_obj.TopicID);
                    o.stats = JArray.FromObject(ds.Tables[0]);
                    o.publication_type = JArray.FromObject(ds.Tables[1]);
                    o.top_stories_by_traffic = JArray.FromObject(ds.Tables[2]);
                    o.sentiment = JArray.FromObject(ds.Tables[3]);
                    o.article_type = JArray.FromObject(ds.Tables[4]);
                    o.distribution_across_da_range = JArray.FromObject(ds.Tables[5]);
                    o.key_highlights_data = JArray.FromObject(ds.Tables[6]);

                    dynamic o_counts = new JObject();
                    o.counts = new JObject();
                    o.counts.twitter = (JObject)JArray.FromObject(ds.Tables[7])[0];
                    o.counts.online = (JObject)JArray.FromObject(ds.Tables[8])[0];
                    o.counts.print = (JObject)JArray.FromObject(ds.Tables[9])[0];

                    Int32 NoOfRecords = Convert.ToInt32(Convert.ToString(o.counts.online.current_value_in_number));

                    if (NoOfRecords > Convert.ToInt32(ConfigurationManager.AppSettings["event_report"].ToString()))
                    {
                        json.message = "event_report";
                    }

                    //o_counts.Add();
                    //o_counts.Add((JObject)JArray.FromObject(ds.Tables[8])[0]);
                    //o_counts.Add((JObject)JArray.FromObject(ds.Tables[9])[0]);
                    //o.counts = o_counts;

                    o.headline_sentiment = JArray.FromObject(ds.Tables[10]);
                    o.client_name_in_headline = JArray.FromObject(ds.Tables[11]);


                    if (strDevice != "web" && ds.Tables.Count > 11 && ds.Tables[12] != null)
                    {
                        o.counts.youtube = (JObject)JArray.FromObject(ds.Tables[12])[0];
                    }

                    json.data = o;
                }

                //result = File.ReadAllText(ConfigurationManager.AppSettings["FetchLanding_OnlineArticle"]);

                result = JsonConvert.SerializeObject(json, setting);
            }
            catch (Exception ex)
            {
                Log("FetchLanding_OnlineArticle", ex.Message + " ->> " + ex.StackTrace + " Detail : " + new StreamReader(postData).ReadToEnd().ToString());
                dynamic json = new JObject();
                json.status = "Error";
                json.message = "Error Occured";

                var setting = new JsonSerializerSettings
                {
                    MaxDepth = int.MaxValue,
                    Formatting = Newtonsoft.Json.Formatting.None
                };
                result = JsonConvert.SerializeObject(json, setting);
            }

            return new MemoryStream(Encoding.UTF8.GetBytes(result));

        }

        [OperationContract]
        [WebInvoke(Method = "POST", UriTemplate = "FetchLanding_PrintArticle", ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Bare)]
        public Stream FetchLanding_PrintArticle(Stream postData)
        {
            string result = string.Empty;

            try
            {

                if (HttpContext.Current.Request.Headers["token"] != null && !String.IsNullOrEmpty(HttpContext.Current.Request.Headers["token"]))
                {
                    bool IsValid = ValidateRequest(Convert.ToString(HttpContext.Current.Request.Headers["token"]));
                    if (IsValid == false)
                    {
                        result = "401 Unauthorized";
                        return new MemoryStream(Encoding.UTF8.GetBytes(result));
                    }
                }

                string strDevice = "web";
                if (HttpContext.Current.Request.Headers["APPType"] != null && !String.IsNullOrEmpty(HttpContext.Current.Request.Headers["APPType"]))
                {
                    strDevice = Convert.ToString(HttpContext.Current.Request.Headers["APPType"]);
                }

                WebOperationContext.Current.OutgoingResponse.ContentType = "application/json; charset=utf-8";

                //Converting to stringa and back to Stream, caz Stream losses its memory
                string InputBody = new StreamReader(postData).ReadToEnd().ToString();
                byte[] byteArray = Encoding.UTF8.GetBytes(InputBody);
                MemoryStream stream = new MemoryStream(byteArray);
                postData = stream;

                eParameters parameters_obj = GetParameters(postData, "FetchLanding_PrintArticle");

                if (!String.IsNullOrEmpty(parameters_obj.UserID) && Convert.ToInt32(parameters_obj.UserID) > 0)
                {
                    new Sahadeva.API.DAL.API_V2().UserLog_Insert(Convert.ToInt32(parameters_obj.UserID), "FetchLanding_PrintArticle", Convert.ToInt32(parameters_obj.TopicID));
                }

                var setting = new JsonSerializerSettings
                {
                    MaxDepth = int.MaxValue,
                    Formatting = Newtonsoft.Json.Formatting.None
                };

                //DataSet ds = new Sahadeva.API.DAL.API_V2().ArticlePrint_FetchLanding(Convert.ToInt32(parameters_obj.TopicID), Convert.ToDateTime(parameters_obj.FromDate), Convert.ToDateTime(parameters_obj.ToDate), Convert.ToDateTime(parameters_obj.BaseDate));

                DataSet ds = new DataSet();


                Log("ArticlePrint_FetchLanding DS start", "");
                ds = new Sahadeva.API.DAL.API_V2().ArticlePrint_FetchLanding(Convert.ToInt32(parameters_obj.TopicID), Convert.ToDateTime(parameters_obj.FromDate), Convert.ToDateTime(parameters_obj.ToDate), Convert.ToDateTime(parameters_obj.BaseDate), parameters_obj.hide_denominator, Convert.ToString(parameters_obj.show_percentage), strDevice);
                Log("ArticlePrint_FetchLanding DS end", "");

                dynamic json = new JObject();
                if (ds.Tables.Count > 0)
                {
                    json.status = "200";
                    json.message = "Success";
                    json.data = new JObject();

                    dynamic o = new JObject();
                    o.incident_id = Convert.ToInt32(parameters_obj.TopicID);
                    o.stats = JArray.FromObject(ds.Tables[0]);
                    o.publication_type = JArray.FromObject(ds.Tables[1]);
                    o.edition_distribution = JArray.FromObject(ds.Tables[2]);
                    o.top_stories_by_traffic = JArray.FromObject(ds.Tables[3]);
                    o.percentage_of_source = JArray.FromObject(ds.Tables[4]);
                    o.sentiment = JArray.FromObject(ds.Tables[5]);
                    o.article_type = JArray.FromObject(ds.Tables[6]);
                    o.top_10_contributors_list_of_publications = JArray.FromObject(ds.Tables[7]);
                    o.key_highlights_data = JArray.FromObject(ds.Tables[8]);

                    //dynamic o_counts = new JArray();
                    //o.counts = new JArray();
                    //o_counts.Add((JObject)JArray.FromObject(ds.Tables[9])[0]);
                    //o_counts.Add((JObject)JArray.FromObject(ds.Tables[10])[0]);
                    //o_counts.Add((JObject)JArray.FromObject(ds.Tables[11])[0]);
                    //o.counts = o_counts;

                    dynamic o_counts = new JObject();
                    o.counts = new JObject();
                    o.counts.twitter = (JObject)JArray.FromObject(ds.Tables[9])[0];
                    o.counts.online = (JObject)JArray.FromObject(ds.Tables[10])[0];
                    o.counts.print = (JObject)JArray.FromObject(ds.Tables[11])[0];

                    Int32 NoOfRecords = Convert.ToInt32(Convert.ToString(o.counts.print.current_value_in_number));

                    if (NoOfRecords > Convert.ToInt32(ConfigurationManager.AppSettings["event_report"].ToString()))
                    {
                        json.message = "event_report";
                    }

                    o.headline_sentiment = JArray.FromObject(ds.Tables[12]);
                    o.client_name_in_headline = JArray.FromObject(ds.Tables[13]);
                    if (strDevice != "web" && ds.Tables.Count > 11 && ds.Tables[14] != null)
                    {
                        o.counts.youtube = (JObject)JArray.FromObject(ds.Tables[14])[0];
                    }


                    json.data = o;
                }

                //result = File.ReadAllText(ConfigurationManager.AppSettings["FetchLanding_PrintArticle"]);

                result = JsonConvert.SerializeObject(json, setting);
            }
            catch (Exception ex)
            {
                Log("FetchLanding_PrintArticle", ex.Message + " ->> " + ex.StackTrace + " Detail : " + new StreamReader(postData).ReadToEnd().ToString());
                dynamic json = new JObject();
                json.status = "Error";
                json.message = "Error Occured";

                var setting = new JsonSerializerSettings
                {
                    MaxDepth = int.MaxValue,
                    Formatting = Newtonsoft.Json.Formatting.None
                };
                result = JsonConvert.SerializeObject(json, setting);
            }

            return new MemoryStream(Encoding.UTF8.GetBytes(result));

        }

        [OperationContract]
        [WebInvoke(Method = "POST", UriTemplate = "FetchLanding_Twitter", ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Bare)]
        public Stream FetchLanding_Twitter(Stream postData)
        {
            string result = string.Empty;

            try
            {

                if (HttpContext.Current.Request.Headers["token"] != null && !String.IsNullOrEmpty(HttpContext.Current.Request.Headers["token"]))
                {
                    bool IsValid = ValidateRequest(Convert.ToString(HttpContext.Current.Request.Headers["token"]));
                    if (IsValid == false)
                    {
                        result = "401 Unauthorized";
                        return new MemoryStream(Encoding.UTF8.GetBytes(result));
                    }
                }

                string strDevice = "web";
                if (HttpContext.Current.Request.Headers["APPType"] != null && !String.IsNullOrEmpty(HttpContext.Current.Request.Headers["APPType"]))
                {
                    strDevice = Convert.ToString(HttpContext.Current.Request.Headers["APPType"]);
                }


                WebOperationContext.Current.OutgoingResponse.ContentType = "application/json; charset=utf-8";

                //Converting to stringa and back to Stream, caz Stream losses its memory
                string InputBody = new StreamReader(postData).ReadToEnd().ToString();
                byte[] byteArray = Encoding.UTF8.GetBytes(InputBody);
                MemoryStream stream = new MemoryStream(byteArray);
                postData = stream;

                eParameters parameters_obj = GetParameters(postData, "FetchLanding_Twitter");

                if (!String.IsNullOrEmpty(parameters_obj.UserID) && Convert.ToInt32(parameters_obj.UserID) > 0)
                {
                    new Sahadeva.API.DAL.API_V2().UserLog_Insert(Convert.ToInt32(parameters_obj.UserID), "FetchLanding_Twitter", Convert.ToInt32(parameters_obj.TopicID));
                }

                var setting = new JsonSerializerSettings
                {
                    MaxDepth = int.MaxValue,
                    Formatting = Newtonsoft.Json.Formatting.None
                };

                DataSet ds = new DataSet();

                Log("Twitter_FetchLanding DS start", "");
                ds = new Sahadeva.API.DAL.API_V2().Twitter_FetchLanding(Convert.ToInt32(parameters_obj.TopicID), Convert.ToDateTime(parameters_obj.FromDate), Convert.ToDateTime(parameters_obj.ToDate), Convert.ToDateTime(parameters_obj.BaseDate), parameters_obj.hide_denominator, Convert.ToString(parameters_obj.show_percentage), strDevice);
                Log("Twitter_FetchLanding DS end", "");

                Log("Twitter_FetchLanding JSON Creation start", "");
                dynamic json = new JObject();
                if (ds.Tables.Count > 0)
                {
                    json.status = "200";
                    json.message = "Success";
                    json.data = new JObject();

                    dynamic o = new JObject();
                    o.incident_id = Convert.ToInt32(parameters_obj.TopicID);
                    //o.tweetsTimeline = JArray.FromObject(ds.Tables[0]);
                    o.stats = JArray.FromObject(ds.Tables[1]);
                    o.conversion_themes = JArray.FromObject(ds.Tables[2]);
                    o.sentimentBreakup = JArray.FromObject(ds.Tables[3]);
                    o.engagementBreakup = JArray.FromObject(ds.Tables[4]);
                    o.top_mentioned_hashtags = JArray.FromObject(ds.Tables[5]);
                    o.active_participants = JArray.FromObject(ds.Tables[6]);
                    o.media_influencers = JArray.FromObject(ds.Tables[7]);
                    o.topTenContributors = JArray.FromObject(ds.Tables[8]);
                    o.topTenContributorsByEngagement = JArray.FromObject(ds.Tables[9]);
                    o.tonality = JArray.FromObject(ds.Tables[10]);

                    o.tweetsTimeline = new JObject();
                    o.tweetsTimeline.x_axis_values = JArray.FromObject(ds.Tables[11]);
                    o.tweetsTimeline.bar_chart_y_values = JArray.FromObject(ds.Tables[12]);
                    o.tweetsTimeline.area_chart_y_values = JArray.FromObject(ds.Tables[13]);

                    o.key_highlights_data = JArray.FromObject(ds.Tables[14]);

                    //dynamic o_counts = new JArray();
                    //o.counts = new JArray();
                    //o_counts.Add((JObject)JArray.FromObject(ds.Tables[15])[0]);
                    //o_counts.Add((JObject)JArray.FromObject(ds.Tables[16])[0]);
                    //o_counts.Add((JObject)JArray.FromObject(ds.Tables[17])[0]);
                    //o.counts = o_counts;

                    o.counts = new JObject();
                    o.counts.twitter = (JObject)JArray.FromObject(ds.Tables[15])[0];
                    o.counts.online = (JObject)JArray.FromObject(ds.Tables[16])[0];
                    o.counts.print = (JObject)JArray.FromObject(ds.Tables[17])[0];

                    Int32 NoOfRecords = Convert.ToInt32(Convert.ToString(o.counts.twitter.current_value_in_number));

                    if (NoOfRecords > Convert.ToInt32(ConfigurationManager.AppSettings["event_report"].ToString()))
                    {
                        json.message = "event_report";
                    }

                    if (strDevice != "web" && ds.Tables.Count > 17 && ds.Tables[18] != null)
                    {
                        o.counts.youtube = (JObject)JArray.FromObject(ds.Tables[18])[0];
                    }

                    json.data = o;
                }
                Log("Twitter_FetchLanding JSON Creation End", "");


                //result = File.ReadAllText(ConfigurationManager.AppSettings["FetchLanding_OnlineArticle"]);

                Log("Twitter_FetchLanding SerializeObject Creation Start", "");
                result = JsonConvert.SerializeObject(json, setting);
                Log("Twitter_FetchLanding SerializeObject Creation End", "");
            }
            catch (Exception ex)
            {
                Log("FetchLanding_Twitter", ex.Message + " ->> " + ex.StackTrace + " Detail : " + new StreamReader(postData).ReadToEnd().ToString());
                dynamic json = new JObject();
                json.status = "Error";
                json.message = "Error Occured";

                var setting = new JsonSerializerSettings
                {
                    MaxDepth = int.MaxValue,
                    Formatting = Newtonsoft.Json.Formatting.None
                };
                result = JsonConvert.SerializeObject(json, setting);
            }

            return new MemoryStream(Encoding.UTF8.GetBytes(result));

        }

        [OperationContract]
        [WebInvoke(Method = "POST", UriTemplate = "FetchLanding_Overview", ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Bare)]
        public Stream FetchLanding_Overview(Stream postData)
        {
            string result = string.Empty;
            var setting = new JsonSerializerSettings
            {
                MaxDepth = int.MaxValue,
                Formatting = Newtonsoft.Json.Formatting.None
            };
            try
            {

                if (HttpContext.Current.Request.Headers["token"] != null && !String.IsNullOrEmpty(HttpContext.Current.Request.Headers["token"]))
                {
                    bool IsValid = ValidateRequest(Convert.ToString(HttpContext.Current.Request.Headers["token"]));
                    if (IsValid == false)
                    {
                        result = "401 Unauthorized";
                        return new MemoryStream(Encoding.UTF8.GetBytes(result));
                    }
                }

                string strDevice = "web";
                if (HttpContext.Current.Request.Headers["APPType"] != null && !String.IsNullOrEmpty(HttpContext.Current.Request.Headers["APPType"]))
                {
                    strDevice = Convert.ToString(HttpContext.Current.Request.Headers["APPType"]);
                }

                WebOperationContext.Current.OutgoingResponse.ContentType = "application/json; charset=utf-8";

                //Converting to stringa and back to Stream, caz Stream losses its memory
                string InputBody = new StreamReader(postData).ReadToEnd().ToString();
                byte[] byteArray = Encoding.UTF8.GetBytes(InputBody);
                MemoryStream stream = new MemoryStream(byteArray);
                postData = stream;

                eParameters parameters_obj = GetParameters(postData, "FetchLanding_Overview");

                if (!String.IsNullOrEmpty(parameters_obj.UserID) && Convert.ToInt32(parameters_obj.UserID) > 0)
                {
                    new Sahadeva.API.DAL.API_V2().UserLog_Insert(Convert.ToInt32(parameters_obj.UserID), "FetchLanding_Overview", Convert.ToInt32(parameters_obj.TopicID));
                }

                DataSet ds = new DataSet();

                Log("Incident_FetchLanding DS start", "");
                ds = new Sahadeva.API.DAL.API_V2().Incident_FetchLanding(Convert.ToInt32(parameters_obj.TopicID), Convert.ToDateTime(parameters_obj.FromDate), Convert.ToDateTime(parameters_obj.ToDate), Convert.ToDateTime(parameters_obj.BaseDate), parameters_obj.hide_denominator, Convert.ToString(parameters_obj.show_percentage), strDevice);
                Log("Incident_FetchLanding DS end", "");

                Log("Incident_FetchLanding JSON start", "");
                dynamic json = new JObject();
                if (ds.Tables.Count > 0)
                {
                    json.status = "200";
                    json.message = "Success";
                    json.data = new JObject();

                    dynamic o = new JObject();
                    o.incident_id = Convert.ToInt32(parameters_obj.TopicID);
                    o.twitter_stats = JArray.FromObject(ds.Tables[0]);
                    o.online_article_stats = JArray.FromObject(ds.Tables[1]);
                    o.print_media_stats = JArray.FromObject(ds.Tables[2]);
                    o.youtube_stats = JArray.FromObject(ds.Tables[12]);
                    o.volume_growth = JArray.FromObject(ds.Tables[3]);
                    //o.velocity = JArray.FromObject(ds.Tables[4]);
                    o.key_highlights_data = JArray.FromObject(ds.Tables[5]);
                    o.traffic_drivers_data = JArray.FromObject(ds.Tables[6]);

                    o.velocity = new JObject();
                    o.velocity.twitter = JArray.FromObject(ds.Tables[7]);
                    o.velocity.online = JArray.FromObject(ds.Tables[8]);
                    o.velocity.print = JArray.FromObject(ds.Tables[9]);
                    o.velocity.youtube = JArray.FromObject(ds.Tables[10]);

                    o.platforms = (JObject)JArray.FromObject(ds.Tables[11])[0];

                    Int32 NoOfRecordsTwitter = Convert.ToInt32(Convert.ToString(o.twitter_stats[0].current_value_in_number));
                    Int32 NoOfRecordsOnline = Convert.ToInt32(Convert.ToString(o.online_article_stats[0].current_value_in_number));
                    Int32 NoOfRecordsPrint = Convert.ToInt32(Convert.ToString(o.print_media_stats[0].current_value_in_number));
                    Int32 NoOfRecordsYoutube = Convert.ToInt32(Convert.ToString(o.youtube_stats[0].current_value_in_number));

                    if ((NoOfRecordsTwitter + NoOfRecordsOnline + NoOfRecordsPrint + NoOfRecordsYoutube) > Convert.ToInt32(ConfigurationManager.AppSettings["event_report"].ToString()))
                    {
                        json.message = "event_report";
                    }

                    json.data = o;
                }

                Log("Incident_FetchLanding JSON End", "");

                //result = File.ReadAllText(ConfigurationManager.AppSettings["FetchLanding_OnlineArticle"]);
                Log("Incident_FetchLanding SerializeObject start", "");
                result = JsonConvert.SerializeObject(json, setting);
                Log("Incident_FetchLanding SerializeObject End", "");
            }
            catch (Exception ex)
            {
                Log("FetchIncidentDetail", ex.Message + " ->> " + ex.StackTrace + " Detail : " + new StreamReader(postData).ReadToEnd().ToString());
                dynamic json = new JObject();
                json.status = "Error";
                json.message = "Error Occured";
                result = JsonConvert.SerializeObject(json, setting);
            }

            return new MemoryStream(Encoding.UTF8.GetBytes(result));

        }

        [OperationContract]
        [WebInvoke(Method = "POST", UriTemplate = "FetchLanding_YouTube", ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Bare)]
        public Stream FetchLanding_YouTube(Stream postData)
        {
            string result = string.Empty;

            try
            {

                if (HttpContext.Current.Request.Headers["token"] != null && !String.IsNullOrEmpty(HttpContext.Current.Request.Headers["token"]))
                {
                    bool IsValid = ValidateRequest(Convert.ToString(HttpContext.Current.Request.Headers["token"]));
                    if (IsValid == false)
                    {
                        result = "401 Unauthorized";
                        return new MemoryStream(Encoding.UTF8.GetBytes(result));
                    }
                }

                string strDevice = "web";
                if (HttpContext.Current.Request.Headers["APPType"] != null && !String.IsNullOrEmpty(HttpContext.Current.Request.Headers["APPType"]))
                {
                    strDevice = Convert.ToString(HttpContext.Current.Request.Headers["APPType"]);
                }

                WebOperationContext.Current.OutgoingResponse.ContentType = "application/json; charset=utf-8";

                //Converting to stringa and back to Stream, caz Stream losses its memory
                string InputBody = new StreamReader(postData).ReadToEnd().ToString();
                byte[] byteArray = Encoding.UTF8.GetBytes(InputBody);
                MemoryStream stream = new MemoryStream(byteArray);
                postData = stream;

                eParameters parameters_obj = GetParameters(postData, "FetchLanding_YouTube");

                if (!String.IsNullOrEmpty(parameters_obj.UserID) && Convert.ToInt32(parameters_obj.UserID) > 0)
                {
                    new Sahadeva.API.DAL.API_V2().UserLog_Insert(Convert.ToInt32(parameters_obj.UserID), "FetchLanding_YouTube", Convert.ToInt32(parameters_obj.TopicID));
                }

                var setting = new JsonSerializerSettings
                {
                    MaxDepth = int.MaxValue,
                    Formatting = Newtonsoft.Json.Formatting.None
                };


                DataSet ds = new DataSet();


                Log("FetchLanding_YouTube DS start", "");
                ds = new Sahadeva.API.DAL.API_V2().FetchLanding_YouTube(Convert.ToInt32(parameters_obj.TopicID), Convert.ToDateTime(parameters_obj.FromDate), Convert.ToDateTime(parameters_obj.ToDate), Convert.ToDateTime(parameters_obj.BaseDate), parameters_obj.hide_denominator, Convert.ToString(parameters_obj.show_percentage), strDevice);
                Log("FetchLanding_YouTube DS end", "");


                Log("FetchLanding_YouTube JSON Creation start", "");
                dynamic json = new JObject();
                if (ds.Tables.Count > 0)
                {
                    json.status = "200";
                    json.message = "Success";
                    json.data = new JObject();

                    dynamic o = new JObject();
                    o.incident_id = Convert.ToInt32(parameters_obj.TopicID);

                    o.stats = JArray.FromObject(ds.Tables[0]);
                    o.sentimentBreakup = JArray.FromObject(ds.Tables[1]);
                    o.tonality = JArray.FromObject(ds.Tables[2]);
                    o.distribution_by_type_of_video = JArray.FromObject(ds.Tables[3]);
                    o.mention_type = JArray.FromObject(ds.Tables[4]);
                    o.discourse_category = JArray.FromObject(ds.Tables[5]);
                    o.people_brand_mentioned = JArray.FromObject(ds.Tables[6]);
                    o.client_mentions_in_the_video = JArray.FromObject(ds.Tables[7]);
                    o.topics_discussed_in_video = JArray.FromObject(ds.Tables[8]);
                    o.impact_score = JArray.FromObject(ds.Tables[9]);
                    o.location = JArray.FromObject(ds.Tables[10]);
                    o.language = JArray.FromObject(ds.Tables[11]);
                    o.top_videos_by_views = JArray.FromObject(ds.Tables[12]);
                    o.top_videos_by_engagement = JArray.FromObject(ds.Tables[13]);
                    o.top_channels_by_subscribers = JArray.FromObject(ds.Tables[14]);

                    o.key_highlights_data = JArray.FromObject(ds.Tables[15]);

                    o.counts = new JObject();
                    o.counts.twitter = (JObject)JArray.FromObject(ds.Tables[16])[0];
                    o.counts.online = (JObject)JArray.FromObject(ds.Tables[17])[0];
                    o.counts.print = (JObject)JArray.FromObject(ds.Tables[18])[0];
                    o.counts.youtube = (JObject)JArray.FromObject(ds.Tables[19])[0];

                    Int32 NoOfRecords = Convert.ToInt32(Convert.ToString(o.counts.youtube.current_value_in_number));

                    if (NoOfRecords > Convert.ToInt32(ConfigurationManager.AppSettings["event_report"].ToString()))
                    {
                        json.message = "event_report";
                    }


                    json.data = o;
                }
                Log("FetchLanding_YouTube JSON Creation End", "");




                Log("FetchLanding_YouTube SerializeObject Creation Start", "");
                result = JsonConvert.SerializeObject(json, setting);
                Log("FetchLanding_YouTube SerializeObject Creation End", "");

                //result = File.ReadAllText(ConfigurationManager.AppSettings["FetchLanding_YouTube"]);
            }
            catch (Exception ex)
            {
                Log("FetchLanding_YouTube", ex.Message + " ->> " + ex.StackTrace + " Detail : " + new StreamReader(postData).ReadToEnd().ToString());
                dynamic json = new JObject();
                json.status = "Error";
                json.message = "Error Occured";

                var setting = new JsonSerializerSettings
                {
                    MaxDepth = int.MaxValue,
                    Formatting = Newtonsoft.Json.Formatting.None
                };
                result = JsonConvert.SerializeObject(json, setting);
            }

            return new MemoryStream(Encoding.UTF8.GetBytes(result));

        }

        #endregion

        #region Participant
        [OperationContract]
        [WebInvoke(Method = "POST", UriTemplate = "FetchList_Participant_Twitter", ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Bare)]
        public Stream FetchList_Participant_Twitter(Stream postData)
        {
            string result = string.Empty;

            try
            {

                if (HttpContext.Current.Request.Headers["token"] != null && !String.IsNullOrEmpty(HttpContext.Current.Request.Headers["token"]))
                {
                    bool IsValid = ValidateRequest(Convert.ToString(HttpContext.Current.Request.Headers["token"]));
                    if (IsValid == false)
                    {
                        result = "401 Unauthorized";
                        return new MemoryStream(Encoding.UTF8.GetBytes(result));
                    }
                }

                WebOperationContext.Current.OutgoingResponse.ContentType = "application/json; charset=utf-8";

                eParameters parameters_obj = GetParameters(postData, "FetchList_Participant_Twitter");

                if (!String.IsNullOrEmpty(parameters_obj.UserID) && Convert.ToInt32(parameters_obj.UserID) > 0)
                {
                    new Sahadeva.API.DAL.API_V2().UserLog_Insert(Convert.ToInt32(parameters_obj.UserID), "FetchList_Participant_Twitter", Convert.ToInt32(parameters_obj.TopicID));
                }

                var setting = new JsonSerializerSettings
                {
                    MaxDepth = int.MaxValue,
                    Formatting = Newtonsoft.Json.Formatting.None
                };


                DataTable dt = new Sahadeva.API.DAL.API_V2().Twitter_FetchParticipant_FetchList(Convert.ToInt32(parameters_obj.TopicID), Convert.ToDateTime(parameters_obj.BaseDate), Convert.ToDateTime(parameters_obj.FromDate), Convert.ToDateTime(parameters_obj.ToDate), parameters_obj.Sentiment, parameters_obj.Mentioned_Hashtag, parameters_obj.Mentioned_Handle, parameters_obj.Media_Type, parameters_obj.Profile_Category, parameters_obj.Sort_By, parameters_obj.Sort_Order, parameters_obj.Mention_Type, parameters_obj.Profile_Name, parameters_obj.Profile_Handle, parameters_obj.Profile_Followerscount, parameters_obj.Participant_Type, parameters_obj.Profile_VerifiedType, parameters_obj.Tonality, parameters_obj.Eng_Type, parameters_obj.SearchText, parameters_obj.exclude_by_text);
                dynamic json = new JObject();
                json.status = "200";
                json.message = "Success";
                json.data = new JArray();

                if (dt.Rows.Count > 0)
                {
                    for (int i = 0; i < dt.Rows.Count; i++)
                    {
                        dynamic o = new JObject();

                        o.Add("incident_id", Convert.ToInt32(parameters_obj.TopicID));
                        o.profile = new JObject();
                        o.activity = new JObject();
                        for (int c = 0; c < 13; c++)
                        {
                            o.profile.Add(dt.Columns[c].ColumnName.ToString(), dt.Rows[i][c].ToString());
                        }
                        for (int c = 13; c < dt.Columns.Count; c++)
                        {
                            o.activity.Add(dt.Columns[c].ColumnName.ToString(), dt.Rows[i][c].ToString());
                        }

                        json.data.Add(o);
                    }
                }

                //result = File.ReadAllText(ConfigurationManager.AppSettings["FetchList_OnlineArticle"]);

                result = JsonConvert.SerializeObject(json, setting);
            }
            catch (Exception ex)
            {
                Log("FetchList_Participant_Twitter", ex.Message + " ->> " + ex.StackTrace + " Detail : " + new StreamReader(postData).ReadToEnd().ToString());
                dynamic json = new JObject();
                json.status = "Error";
                json.message = "Error Occured";

                var setting = new JsonSerializerSettings
                {
                    MaxDepth = int.MaxValue,
                    Formatting = Newtonsoft.Json.Formatting.None
                };
                result = JsonConvert.SerializeObject(json, setting);
            }

            return new MemoryStream(Encoding.UTF8.GetBytes(result));

        }

        [OperationContract]
        [WebInvoke(Method = "POST", UriTemplate = "Fetch_Participant_Twitter", ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Bare)]
        public Stream Fetch_Participant_Twitter(Stream postData)
        {
            string result = string.Empty;

            try
            {

                if (HttpContext.Current.Request.Headers["token"] != null && !String.IsNullOrEmpty(HttpContext.Current.Request.Headers["token"]))
                {
                    bool IsValid = ValidateRequest(Convert.ToString(HttpContext.Current.Request.Headers["token"]));
                    if (IsValid == false)
                    {
                        result = "401 Unauthorized";
                        return new MemoryStream(Encoding.UTF8.GetBytes(result));
                    }
                }

                WebOperationContext.Current.OutgoingResponse.ContentType = "application/json; charset=utf-8";

                eParameters parameters_obj = GetParameters(postData, "Fetch_Participant_Twitter");

                if (!String.IsNullOrEmpty(parameters_obj.UserID) && Convert.ToInt32(parameters_obj.UserID) > 0)
                {
                    new Sahadeva.API.DAL.API_V2().UserLog_Insert(Convert.ToInt32(parameters_obj.UserID), "Fetch_Participant_Twitter", Convert.ToInt32(parameters_obj.TopicID));
                }

                var setting = new JsonSerializerSettings
                {
                    MaxDepth = int.MaxValue,
                    Formatting = Newtonsoft.Json.Formatting.None
                };

                DataSet ds = new Sahadeva.API.DAL.API_V2().Twitter_FetchParticipant_FetchById(Convert.ToInt32(parameters_obj.TopicID), Convert.ToDateTime(parameters_obj.FromDate), Convert.ToDateTime(parameters_obj.ToDate), parameters_obj.Profile_Handle);

                dynamic json = new JObject();
                if (ds.Tables.Count > 0)
                {
                    json.status = "200";
                    json.message = "Success";
                    json.data = new JArray();

                    dynamic o = new JObject();
                    o.Add("incident_id", Convert.ToInt32(parameters_obj.TopicID));
                    o.profile = (JObject)JArray.FromObject(ds.Tables[0])[0];
                    o.activity = (JObject)JArray.FromObject(ds.Tables[1])[0];
                    o.engagement = (JObject)JArray.FromObject(ds.Tables[2])[0];
                    o.tweets = JArray.FromObject(ds.Tables[3]);

                    json.data.Add(o);
                }

                //result = File.ReadAllText(ConfigurationManager.AppSettings["FetchOnlineArticle"]);

                result = JsonConvert.SerializeObject(json, setting);
            }
            catch (Exception ex)
            {
                Log("Fetch_Participant_Twitter", ex.Message + " ->> " + ex.StackTrace + " Detail : " + new StreamReader(postData).ReadToEnd().ToString());
                dynamic json = new JObject();
                json.status = "Error";
                json.message = "Error Occured";

                var setting = new JsonSerializerSettings
                {
                    MaxDepth = int.MaxValue,
                    Formatting = Newtonsoft.Json.Formatting.None
                };
                result = JsonConvert.SerializeObject(json, setting);
            }

            return new MemoryStream(Encoding.UTF8.GetBytes(result));

        }

        [OperationContract]
        [WebInvoke(Method = "POST", UriTemplate = "FetchFilter_Participant_Twitter", ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Bare)]
        public Stream FetchFilter_Participant_Twitter(Stream postData)
        {
            string result = string.Empty;

            try
            {

                if (HttpContext.Current.Request.Headers["token"] != null && !String.IsNullOrEmpty(HttpContext.Current.Request.Headers["token"]))
                {
                    bool IsValid = ValidateRequest(Convert.ToString(HttpContext.Current.Request.Headers["token"]));
                    if (IsValid == false)
                    {
                        result = "401 Unauthorized";
                        return new MemoryStream(Encoding.UTF8.GetBytes(result));
                    }
                }

                WebOperationContext.Current.OutgoingResponse.ContentType = "application/json; charset=utf-8";

                eParameters parameters_obj = GetParameters(postData, "FetchFilter_Participant_Twitter");

                if (!String.IsNullOrEmpty(parameters_obj.UserID) && Convert.ToInt32(parameters_obj.UserID) > 0)
                {
                    new Sahadeva.API.DAL.API_V2().UserLog_Insert(Convert.ToInt32(parameters_obj.UserID), "FetchFilter_Participant_Twitter", Convert.ToInt32(parameters_obj.TopicID));
                }

                var setting = new JsonSerializerSettings
                {
                    MaxDepth = int.MaxValue,
                    Formatting = Newtonsoft.Json.Formatting.None
                };

                DataSet ds = new Sahadeva.API.DAL.API_V2().Twitter_FetchParticipant_FetchFilter(Convert.ToInt32(parameters_obj.TopicID), Convert.ToDateTime(parameters_obj.BaseDate), Convert.ToDateTime(parameters_obj.FromDate), Convert.ToDateTime(parameters_obj.ToDate));

                dynamic json = new JObject();
                if (ds.Tables.Count > 0)
                {
                    json.status = "200";
                    json.message = "Success";
                    json.data = new JArray();

                    dynamic oo = new JObject();
                    oo.filter = new JObject();
                    oo.filter.profile_name = "";
                    oo.filter.profile_handle = "";
                    oo.filter.sentiment = JArray.FromObject(ds.Tables[0]);
                    oo.filter.profile_category = JArray.FromObject(ds.Tables[1]);
                    oo.filter.followers = JArray.FromObject(ds.Tables[2]);
                    oo.filter.participant_type = JArray.FromObject(ds.Tables[3]);

                    json.data.Add(oo);
                }

                result = JsonConvert.SerializeObject(json, setting);
            }
            catch (Exception ex)
            {
                Log("FetchFilter_Participant_Twitter", ex.Message + " ->> " + ex.StackTrace + " Detail : " + new StreamReader(postData).ReadToEnd().ToString());
                dynamic json = new JObject();
                json.status = "Error";
                json.message = "Error Occured";

                var setting = new JsonSerializerSettings
                {
                    MaxDepth = int.MaxValue,
                    Formatting = Newtonsoft.Json.Formatting.None
                };
                result = JsonConvert.SerializeObject(json, setting);
            }

            return new MemoryStream(Encoding.UTF8.GetBytes(result));

        }



        [OperationContract]
        [WebInvoke(Method = "POST", UriTemplate = "FetchList_Participant_OnlineArticle", ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Bare)]
        public Stream FetchList_Participant_OnlineArticle(Stream postData)
        {
            string result = string.Empty;

            try
            {

                if (HttpContext.Current.Request.Headers["token"] != null && !String.IsNullOrEmpty(HttpContext.Current.Request.Headers["token"]))
                {
                    bool IsValid = ValidateRequest(Convert.ToString(HttpContext.Current.Request.Headers["token"]));
                    if (IsValid == false)
                    {
                        result = "401 Unauthorized";
                        return new MemoryStream(Encoding.UTF8.GetBytes(result));
                    }
                }

                WebOperationContext.Current.OutgoingResponse.ContentType = "application/json; charset=utf-8";

                eParameters parameters_obj = GetParameters(postData, "FetchList_Participant_OnlineArticle");

                if (!String.IsNullOrEmpty(parameters_obj.UserID) && Convert.ToInt32(parameters_obj.UserID) > 0)
                {
                    new Sahadeva.API.DAL.API_V2().UserLog_Insert(Convert.ToInt32(parameters_obj.UserID), "FetchList_Participant_OnlineArticle", Convert.ToInt32(parameters_obj.TopicID));
                }

                var setting = new JsonSerializerSettings
                {
                    MaxDepth = int.MaxValue,
                    Formatting = Newtonsoft.Json.Formatting.None
                };


                DataTable dt = new Sahadeva.API.DAL.API_V2().ArticleOnline_FetchParticipant_FetchList(Convert.ToInt32(parameters_obj.TopicID), Convert.ToDateTime(parameters_obj.FromDate), Convert.ToDateTime(parameters_obj.ToDate), parameters_obj.Sentiment, parameters_obj.Publication_Domain, parameters_obj.Publication_Type, parameters_obj.Publication_DA, parameters_obj.Publication_Traffic, parameters_obj.Publication_ImpactScore, parameters_obj.Sort_By, parameters_obj.Sort_Order, parameters_obj.SearchText, parameters_obj.Mention_Type, parameters_obj.client_mention, parameters_obj.headline_sentiment, parameters_obj.Article_Type, parameters_obj.exclude_by_text);
                dynamic json = new JObject();
                json.status = "200";
                json.message = "Success";
                json.data = new JArray();

                if (dt.Rows.Count > 0)
                {
                    for (int i = 0; i < dt.Rows.Count; i++)
                    {
                        dynamic o = new JObject();

                        o.Add("incident_id", Convert.ToInt32(parameters_obj.TopicID));
                        o.profile = new JObject();
                        o.activity = new JObject();
                        for (int c = 0; c < 7; c++)
                        {
                            o.profile.Add(dt.Columns[c].ColumnName.ToString(), dt.Rows[i][c].ToString());
                        }
                        for (int c = 7; c < dt.Columns.Count; c++)
                        {
                            o.activity.Add(dt.Columns[c].ColumnName.ToString(), dt.Rows[i][c].ToString());
                        }

                        json.data.Add(o);
                    }
                }

                //result = File.ReadAllText(ConfigurationManager.AppSettings["FetchList_OnlineArticle"]);

                result = JsonConvert.SerializeObject(json, setting);
            }
            catch (Exception ex)
            {
                Log("FetchList_Participant_OnlineArticle", ex.Message + " ->> " + ex.StackTrace + " Detail : " + new StreamReader(postData).ReadToEnd().ToString());
                dynamic json = new JObject();
                json.status = "Error";
                json.message = "Error Occured";

                var setting = new JsonSerializerSettings
                {
                    MaxDepth = int.MaxValue,
                    Formatting = Newtonsoft.Json.Formatting.None
                };
                result = JsonConvert.SerializeObject(json, setting);
            }

            return new MemoryStream(Encoding.UTF8.GetBytes(result));

        }

        [OperationContract]
        [WebInvoke(Method = "POST", UriTemplate = "Fetch_Participant_OnlineArticle", ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Bare)]
        public Stream Fetch_Participant_OnlineArticle(Stream postData)
        {
            string result = string.Empty;

            try
            {

                if (HttpContext.Current.Request.Headers["token"] != null && !String.IsNullOrEmpty(HttpContext.Current.Request.Headers["token"]))
                {
                    bool IsValid = ValidateRequest(Convert.ToString(HttpContext.Current.Request.Headers["token"]));
                    if (IsValid == false)
                    {
                        result = "401 Unauthorized";
                        return new MemoryStream(Encoding.UTF8.GetBytes(result));
                    }
                }

                WebOperationContext.Current.OutgoingResponse.ContentType = "application/json; charset=utf-8";

                eParameters parameters_obj = GetParameters(postData, "Fetch_Participant_OnlineArticle");

                if (!String.IsNullOrEmpty(parameters_obj.UserID) && Convert.ToInt32(parameters_obj.UserID) > 0)
                {
                    new Sahadeva.API.DAL.API_V2().UserLog_Insert(Convert.ToInt32(parameters_obj.UserID), "Fetch_Participant_OnlineArticle", Convert.ToInt32(parameters_obj.TopicID));
                }

                var setting = new JsonSerializerSettings
                {
                    MaxDepth = int.MaxValue,
                    Formatting = Newtonsoft.Json.Formatting.None
                };

                DataSet ds = new Sahadeva.API.DAL.API_V2().ArticleOnline_FetchParticipant_FetchById(Convert.ToInt32(parameters_obj.TopicID), Convert.ToDateTime(parameters_obj.FromDate), Convert.ToDateTime(parameters_obj.ToDate), parameters_obj.Publication_Domain);

                dynamic json = new JObject();
                if (ds.Tables.Count > 0)
                {
                    json.status = "200";
                    json.message = "Success";
                    json.data = new JArray();

                    dynamic o = new JObject();
                    o.Add("incident_id", Convert.ToInt32(parameters_obj.TopicID));
                    o.profile = (JObject)JArray.FromObject(ds.Tables[0])[0];
                    o.activity = (JObject)JArray.FromObject(ds.Tables[1])[0];
                    o.articles = JArray.FromObject(ds.Tables[2]);

                    json.data.Add(o);
                }

                //result = File.ReadAllText(ConfigurationManager.AppSettings["FetchOnlineArticle"]);

                result = JsonConvert.SerializeObject(json, setting);
            }
            catch (Exception ex)
            {
                Log("Fetch_Participant_OnlineArticle", ex.Message + " ->> " + ex.StackTrace + " Detail : " + new StreamReader(postData).ReadToEnd().ToString());
                dynamic json = new JObject();
                json.status = "Error";
                json.message = "Error Occured";

                var setting = new JsonSerializerSettings
                {
                    MaxDepth = int.MaxValue,
                    Formatting = Newtonsoft.Json.Formatting.None
                };
                result = JsonConvert.SerializeObject(json, setting);
            }

            return new MemoryStream(Encoding.UTF8.GetBytes(result));

        }

        [OperationContract]
        [WebInvoke(Method = "POST", UriTemplate = "FetchFilter_Participant_OnlineArticle", ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Bare)]
        public Stream FetchFilter_Participant_OnlineArticle(Stream postData)
        {
            string result = string.Empty;

            try
            {

                if (HttpContext.Current.Request.Headers["token"] != null && !String.IsNullOrEmpty(HttpContext.Current.Request.Headers["token"]))
                {
                    bool IsValid = ValidateRequest(Convert.ToString(HttpContext.Current.Request.Headers["token"]));
                    if (IsValid == false)
                    {
                        result = "401 Unauthorized";
                        return new MemoryStream(Encoding.UTF8.GetBytes(result));
                    }
                }

                WebOperationContext.Current.OutgoingResponse.ContentType = "application/json; charset=utf-8";

                eParameters parameters_obj = GetParameters(postData, "FetchFilter_Participant_OnlineArticle");

                if (!String.IsNullOrEmpty(parameters_obj.UserID) && Convert.ToInt32(parameters_obj.UserID) > 0)
                {
                    new Sahadeva.API.DAL.API_V2().UserLog_Insert(Convert.ToInt32(parameters_obj.UserID), "FetchFilter_Participant_OnlineArticle", Convert.ToInt32(parameters_obj.TopicID));
                }

                var setting = new JsonSerializerSettings
                {
                    MaxDepth = int.MaxValue,
                    Formatting = Newtonsoft.Json.Formatting.None
                };

                DataSet ds = new Sahadeva.API.DAL.API_V2().ArticleOnline_FetchParticipant_FetchFilter(Convert.ToInt32(parameters_obj.TopicID), Convert.ToDateTime(parameters_obj.FromDate), Convert.ToDateTime(parameters_obj.ToDate));

                dynamic json = new JObject();
                if (ds.Tables.Count > 0)
                {
                    json.status = "200";
                    json.message = "Success";
                    json.data = new JArray();

                    dynamic oo = new JObject();
                    oo.filter = new JObject();
                    oo.filter.publication_name = "";
                    oo.filter.publication_type = JArray.FromObject(ds.Tables[0]);
                    oo.filter.Sentiment = JArray.FromObject(ds.Tables[1]);
                    oo.filter.domain_authority = (JObject)JArray.FromObject(ds.Tables[2])[0];
                    oo.filter.pi_score = (JObject)JArray.FromObject(ds.Tables[3])[0];

                    json.data.Add(oo);
                }

                result = JsonConvert.SerializeObject(json, setting);
            }
            catch (Exception ex)
            {
                Log("FetchFilter_Participant_OnlineArticle", ex.Message + " ->> " + ex.StackTrace + " Detail : " + new StreamReader(postData).ReadToEnd().ToString());
                dynamic json = new JObject();
                json.status = "Error";
                json.message = "Error Occured";

                var setting = new JsonSerializerSettings
                {
                    MaxDepth = int.MaxValue,
                    Formatting = Newtonsoft.Json.Formatting.None
                };
                result = JsonConvert.SerializeObject(json, setting);
            }

            return new MemoryStream(Encoding.UTF8.GetBytes(result));

        }




        [OperationContract]
        [WebInvoke(Method = "POST", UriTemplate = "FetchList_Participant_PrintArticle", ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Bare)]
        public Stream FetchList_Participant_PrintArticle(Stream postData)
        {
            string result = string.Empty;

            try
            {

                if (HttpContext.Current.Request.Headers["token"] != null && !String.IsNullOrEmpty(HttpContext.Current.Request.Headers["token"]))
                {
                    bool IsValid = ValidateRequest(Convert.ToString(HttpContext.Current.Request.Headers["token"]));
                    if (IsValid == false)
                    {
                        result = "401 Unauthorized";
                        return new MemoryStream(Encoding.UTF8.GetBytes(result));
                    }
                }

                WebOperationContext.Current.OutgoingResponse.ContentType = "application/json; charset=utf-8";

                eParameters parameters_obj = GetParameters(postData, "FetchList_Participant_PrintArticle");

                if (!String.IsNullOrEmpty(parameters_obj.UserID) && Convert.ToInt32(parameters_obj.UserID) > 0)
                {
                    new Sahadeva.API.DAL.API_V2().UserLog_Insert(Convert.ToInt32(parameters_obj.UserID), "FetchList_Participant_PrintArticle", Convert.ToInt32(parameters_obj.TopicID));
                }

                var setting = new JsonSerializerSettings
                {
                    MaxDepth = int.MaxValue,
                    Formatting = Newtonsoft.Json.Formatting.None
                };


                DataTable dt = new Sahadeva.API.DAL.API_V2().ArticlePrint_FetchParticipant_FetchList(Convert.ToInt32(parameters_obj.TopicID), Convert.ToDateTime(parameters_obj.FromDate), Convert.ToDateTime(parameters_obj.ToDate), parameters_obj.Sentiment, parameters_obj.Publication_Name, parameters_obj.Publication_Edition, parameters_obj.Publication_Type, parameters_obj.Publication_Circulation, parameters_obj.Publication_ImpactScore, parameters_obj.Sort_By, parameters_obj.Sort_Order, parameters_obj.SearchText, parameters_obj.Mention_Type, parameters_obj.client_mention, parameters_obj.headline_sentiment, parameters_obj.Article_Type, parameters_obj.Author, parameters_obj.exclude_by_text, parameters_obj.Language);
                dynamic json = new JObject();
                json.status = "200";
                json.message = "Success";
                json.data = new JArray();

                if (dt.Rows.Count > 0)
                {
                    for (int i = 0; i < dt.Rows.Count; i++)
                    {
                        dynamic o = new JObject();

                        o.Add("incident_id", Convert.ToInt32(parameters_obj.TopicID));
                        o.profile = new JObject();
                        o.activity = new JObject();
                        for (int c = 0; c < 6; c++)
                        {
                            o.profile.Add(dt.Columns[c].ColumnName.ToString(), dt.Rows[i][c].ToString());
                        }
                        for (int c = 6; c < dt.Columns.Count; c++)
                        {
                            o.activity.Add(dt.Columns[c].ColumnName.ToString(), dt.Rows[i][c].ToString());
                        }

                        json.data.Add(o);
                    }
                }

                //result = File.ReadAllText(ConfigurationManager.AppSettings["FetchList_OnlineArticle"]);

                result = JsonConvert.SerializeObject(json, setting);
            }
            catch (Exception ex)
            {
                Log("FetchList_Participant_PrintArticle", ex.Message + " ->> " + ex.StackTrace + " Detail : " + new StreamReader(postData).ReadToEnd().ToString());
                dynamic json = new JObject();
                json.status = "Error";
                json.message = "Error Occured";

                var setting = new JsonSerializerSettings
                {
                    MaxDepth = int.MaxValue,
                    Formatting = Newtonsoft.Json.Formatting.None
                };
                result = JsonConvert.SerializeObject(json, setting);
            }

            return new MemoryStream(Encoding.UTF8.GetBytes(result));

        }

        [OperationContract]
        [WebInvoke(Method = "POST", UriTemplate = "Fetch_Participant_PrintArticle", ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Bare)]
        public Stream Fetch_Participant_PrintArticle(Stream postData)
        {
            string result = string.Empty;

            try
            {

                if (HttpContext.Current.Request.Headers["token"] != null && !String.IsNullOrEmpty(HttpContext.Current.Request.Headers["token"]))
                {
                    bool IsValid = ValidateRequest(Convert.ToString(HttpContext.Current.Request.Headers["token"]));
                    if (IsValid == false)
                    {
                        result = "401 Unauthorized";
                        return new MemoryStream(Encoding.UTF8.GetBytes(result));
                    }
                }

                WebOperationContext.Current.OutgoingResponse.ContentType = "application/json; charset=utf-8";

                eParameters parameters_obj = GetParameters(postData, "Fetch_Participant_PrintArticle");

                if (!String.IsNullOrEmpty(parameters_obj.UserID) && Convert.ToInt32(parameters_obj.UserID) > 0)
                {
                    new Sahadeva.API.DAL.API_V2().UserLog_Insert(Convert.ToInt32(parameters_obj.UserID), "Fetch_Participant_PrintArticle", Convert.ToInt32(parameters_obj.TopicID));
                }

                var setting = new JsonSerializerSettings
                {
                    MaxDepth = int.MaxValue,
                    Formatting = Newtonsoft.Json.Formatting.None
                };

                DataSet ds = new Sahadeva.API.DAL.API_V2().ArticlePrint_FetchParticipant_FetchById(Convert.ToInt32(parameters_obj.TopicID), Convert.ToDateTime(parameters_obj.FromDate), Convert.ToDateTime(parameters_obj.ToDate), parameters_obj.Publication_Name);

                dynamic json = new JObject();
                if (ds.Tables.Count > 0)
                {
                    json.status = "200";
                    json.message = "Success";
                    json.data = new JArray();

                    dynamic o = new JObject();
                    o.Add("incident_id", Convert.ToInt32(parameters_obj.TopicID));
                    o.profile = (JObject)JArray.FromObject(ds.Tables[0])[0];
                    o.activity = (JObject)JArray.FromObject(ds.Tables[1])[0];
                    o.articles = JArray.FromObject(ds.Tables[2]);

                    json.data.Add(o);
                }

                //result = File.ReadAllText(ConfigurationManager.AppSettings["FetchOnlineArticle"]);

                result = JsonConvert.SerializeObject(json, setting);
            }
            catch (Exception ex)
            {
                Log("Fetch_Participant_PrintArticle", ex.Message + " ->> " + ex.StackTrace + " Detail : " + new StreamReader(postData).ReadToEnd().ToString());
                dynamic json = new JObject();
                json.status = "Error";
                json.message = "Error Occured";

                var setting = new JsonSerializerSettings
                {
                    MaxDepth = int.MaxValue,
                    Formatting = Newtonsoft.Json.Formatting.None
                };
                result = JsonConvert.SerializeObject(json, setting);
            }

            return new MemoryStream(Encoding.UTF8.GetBytes(result));

        }

        [OperationContract]
        [WebInvoke(Method = "POST", UriTemplate = "FetchFilter_Participant_PrintArticle", ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Bare)]
        public Stream FetchFilter_Participant_PrintArticle(Stream postData)
        {
            string result = string.Empty;

            try
            {

                if (HttpContext.Current.Request.Headers["token"] != null && !String.IsNullOrEmpty(HttpContext.Current.Request.Headers["token"]))
                {
                    bool IsValid = ValidateRequest(Convert.ToString(HttpContext.Current.Request.Headers["token"]));
                    if (IsValid == false)
                    {
                        result = "401 Unauthorized";
                        return new MemoryStream(Encoding.UTF8.GetBytes(result));
                    }
                }

                WebOperationContext.Current.OutgoingResponse.ContentType = "application/json; charset=utf-8";

                eParameters parameters_obj = GetParameters(postData, "FetchFilter_Participant_PrintArticle");

                if (!String.IsNullOrEmpty(parameters_obj.UserID) && Convert.ToInt32(parameters_obj.UserID) > 0)
                {
                    new Sahadeva.API.DAL.API_V2().UserLog_Insert(Convert.ToInt32(parameters_obj.UserID), "FetchFilter_Participant_PrintArticle", Convert.ToInt32(parameters_obj.TopicID));
                }

                var setting = new JsonSerializerSettings
                {
                    MaxDepth = int.MaxValue,
                    Formatting = Newtonsoft.Json.Formatting.None
                };

                DataSet ds = new Sahadeva.API.DAL.API_V2().ArticlePrint_FetchParticipant_FetchFilter(Convert.ToInt32(parameters_obj.TopicID), Convert.ToDateTime(parameters_obj.FromDate), Convert.ToDateTime(parameters_obj.ToDate));

                dynamic json = new JObject();
                if (ds.Tables.Count > 0)
                {
                    json.status = "200";
                    json.message = "Success";
                    json.data = new JArray();

                    dynamic oo = new JObject();
                    oo.filter = new JObject();
                    oo.filter.publication_name = "";
                    oo.filter.publication_type = JArray.FromObject(ds.Tables[0]);
                    oo.filter.Sentiment = JArray.FromObject(ds.Tables[1]);
                    oo.filter.publication_edition = JArray.FromObject(ds.Tables[2]);
                    oo.filter.pi_score = (JObject)JArray.FromObject(ds.Tables[3])[0];

                    json.data.Add(oo);
                }

                result = JsonConvert.SerializeObject(json, setting);
            }
            catch (Exception ex)
            {
                Log("FetchFilter_Participant_PrintArticle", ex.Message + " ->> " + ex.StackTrace + " Detail : " + new StreamReader(postData).ReadToEnd().ToString());
                dynamic json = new JObject();
                json.status = "Error";
                json.message = "Error Occured";

                var setting = new JsonSerializerSettings
                {
                    MaxDepth = int.MaxValue,
                    Formatting = Newtonsoft.Json.Formatting.None
                };
                result = JsonConvert.SerializeObject(json, setting);
            }

            return new MemoryStream(Encoding.UTF8.GetBytes(result));

        }


        [OperationContract]
        [WebInvoke(Method = "POST", UriTemplate = "FetchList_Participant_YouTube", ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Bare)]
        public Stream FetchList_Participant_YouTube(Stream postData)
        {
            string result = string.Empty;

            try
            {

                if (HttpContext.Current.Request.Headers["token"] != null && !String.IsNullOrEmpty(HttpContext.Current.Request.Headers["token"]))
                {
                    bool IsValid = ValidateRequest(Convert.ToString(HttpContext.Current.Request.Headers["token"]));
                    if (IsValid == false)
                    {
                        result = "401 Unauthorized";
                        return new MemoryStream(Encoding.UTF8.GetBytes(result));
                    }
                }

                WebOperationContext.Current.OutgoingResponse.ContentType = "application/json; charset=utf-8";

                eParameters parameters_obj = GetParameters(postData, "FetchList_Participant_YouTube");

                if (!String.IsNullOrEmpty(parameters_obj.UserID) && Convert.ToInt32(parameters_obj.UserID) > 0)
                {
                    new Sahadeva.API.DAL.API_V2().UserLog_Insert(Convert.ToInt32(parameters_obj.UserID), "FetchList_Participant_YouTube", Convert.ToInt32(parameters_obj.TopicID));
                }

                var setting = new JsonSerializerSettings
                {
                    MaxDepth = int.MaxValue,
                    Formatting = Newtonsoft.Json.Formatting.None
                };


                DataTable dt = new Sahadeva.API.DAL.API_V2().YouTube_FetchParticipant_FetchList(Convert.ToInt32(parameters_obj.TopicID), Convert.ToDateTime(parameters_obj.BaseDate), Convert.ToDateTime(parameters_obj.FromDate), Convert.ToDateTime(parameters_obj.ToDate),
                    parameters_obj.Video_Tags, parameters_obj.Channel_Handle, parameters_obj.Channel_Name, parameters_obj.Sentiment, parameters_obj.Tonality, parameters_obj.Channel_Category,
                    parameters_obj.Mention_Type, parameters_obj.Profile_VerifiedType, parameters_obj.Participant_Type, parameters_obj.Channel_SubscriberCount, parameters_obj.DurationInMin, parameters_obj.Video_Type,
                    parameters_obj.Discourse_Category, parameters_obj.Mentioned_Topics, parameters_obj.Publication_ImpactScore, parameters_obj.Mentioned_Locations,
                    parameters_obj.Sort_By, parameters_obj.Sort_Order, Convert.ToInt32(parameters_obj.UserID), parameters_obj.People_Brand_Mentions, parameters_obj.Language, parameters_obj.SearchText, parameters_obj.exclude_by_text);
                dynamic json = new JObject();
                json.status = "200";
                json.message = "Success";
                json.data = new JArray();

                if (dt.Rows.Count > 0)
                {
                    for (int i = 0; i < dt.Rows.Count; i++)
                    {
                        dynamic o = new JObject();

                        o.Add("incident_id", Convert.ToInt32(parameters_obj.TopicID));
                        o.channel = new JObject();
                        o.activity = new JObject();
                        for (int c = 0; c < 17; c++)
                        {
                            o.channel.Add(dt.Columns[c].ColumnName.ToString(), dt.Rows[i][c].ToString());
                        }
                        for (int c = 17; c < dt.Columns.Count; c++)
                        {
                            o.activity.Add(dt.Columns[c].ColumnName.ToString(), dt.Rows[i][c].ToString());
                        }

                        json.data.Add(o);
                    }
                }

                //result = File.ReadAllText(ConfigurationManager.AppSettings["FetchList_Participant_YouTube"]);

                result = JsonConvert.SerializeObject(json, setting);
            }
            catch (Exception ex)
            {
                Log("FetchList_Participant_YouTube", ex.Message + " ->> " + ex.StackTrace + " Detail : " + new StreamReader(postData).ReadToEnd().ToString());
                dynamic json = new JObject();
                json.status = "Error";
                json.message = "Error Occured";

                var setting = new JsonSerializerSettings
                {
                    MaxDepth = int.MaxValue,
                    Formatting = Newtonsoft.Json.Formatting.None
                };
                result = JsonConvert.SerializeObject(json, setting);
            }

            return new MemoryStream(Encoding.UTF8.GetBytes(result));

        }

        [OperationContract]
        [WebInvoke(Method = "POST", UriTemplate = "Fetch_Participant_YouTube", ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Bare)]
        public Stream Fetch_Participant_YouTube(Stream postData)
        {
            string result = string.Empty;

            try
            {

                if (HttpContext.Current.Request.Headers["token"] != null && !String.IsNullOrEmpty(HttpContext.Current.Request.Headers["token"]))
                {
                    bool IsValid = ValidateRequest(Convert.ToString(HttpContext.Current.Request.Headers["token"]));
                    if (IsValid == false)
                    {
                        result = "401 Unauthorized";
                        return new MemoryStream(Encoding.UTF8.GetBytes(result));
                    }
                }

                WebOperationContext.Current.OutgoingResponse.ContentType = "application/json; charset=utf-8";

                eParameters parameters_obj = GetParameters(postData, "Fetch_Participant_YouTube");

                if (!String.IsNullOrEmpty(parameters_obj.UserID) && Convert.ToInt32(parameters_obj.UserID) > 0)
                {
                    new Sahadeva.API.DAL.API_V2().UserLog_Insert(Convert.ToInt32(parameters_obj.UserID), "Fetch_Participant_YouTube", Convert.ToInt32(parameters_obj.TopicID));
                }

                var setting = new JsonSerializerSettings
                {
                    MaxDepth = int.MaxValue,
                    Formatting = Newtonsoft.Json.Formatting.None
                };

                DataSet ds = new Sahadeva.API.DAL.API_V2().YouTube_FetchParticipant_FetchById(Convert.ToInt32(parameters_obj.TopicID), Convert.ToDateTime(parameters_obj.FromDate), Convert.ToDateTime(parameters_obj.ToDate), parameters_obj.Channel_Handle);

                dynamic json = new JObject();
                if (ds.Tables.Count > 0)
                {
                    json.status = "200";
                    json.message = "Success";
                    json.data = new JArray();

                    dynamic o = new JObject();
                    o.Add("incident_id", Convert.ToInt32(parameters_obj.TopicID));
                    o.channel = (JObject)JArray.FromObject(ds.Tables[0])[0];
                    o.engagement = (JObject)JArray.FromObject(ds.Tables[1])[0];
                    o.videos = JArray.FromObject(ds.Tables[2]);

                    json.data.Add(o);
                }

                //result = File.ReadAllText(ConfigurationManager.AppSettings["Fetch_Participant_YouTube"]);

                result = JsonConvert.SerializeObject(json, setting);
            }
            catch (Exception ex)
            {
                Log("Fetch_Participant_YouTube", ex.Message + " ->> " + ex.StackTrace + " Detail : " + new StreamReader(postData).ReadToEnd().ToString());
                dynamic json = new JObject();
                json.status = "Error";
                json.message = "Error Occured";

                var setting = new JsonSerializerSettings
                {
                    MaxDepth = int.MaxValue,
                    Formatting = Newtonsoft.Json.Formatting.None
                };
                result = JsonConvert.SerializeObject(json, setting);
            }

            return new MemoryStream(Encoding.UTF8.GetBytes(result));

        }

        [OperationContract]
        [WebInvoke(Method = "POST", UriTemplate = "FetchFilter_Participant_YouTube", ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Bare)]
        public Stream FetchFilter_Participant_YouTube(Stream postData)
        {
            string result = string.Empty;

            try
            {

                //if (HttpContext.Current.Request.Headers["token"] != null && !String.IsNullOrEmpty(HttpContext.Current.Request.Headers["token"]))
                //{
                //    bool IsValid = ValidateRequest(Convert.ToString(HttpContext.Current.Request.Headers["token"]));
                //    if (IsValid == false)
                //    {
                //        result = "401 Unauthorized";
                //        return new MemoryStream(Encoding.UTF8.GetBytes(result));
                //    }
                //}

                //WebOperationContext.Current.OutgoingResponse.ContentType = "application/json; charset=utf-8";

                //eParameters parameters_obj = GetParameters(postData, "FetchFilter_Participant_YouTube");

                //if (!String.IsNullOrEmpty(parameters_obj.UserID) && Convert.ToInt32(parameters_obj.UserID) > 0)
                //{
                //    new Sahadeva.API.DAL.API_V2().UserLog_Insert(Convert.ToInt32(parameters_obj.UserID), "FetchFilter_Participant_YouTube", Convert.ToInt32(parameters_obj.TopicID));
                //}

                //var setting = new JsonSerializerSettings
                //{
                //    MaxDepth = int.MaxValue
                //};

                //DataSet ds = new Sahadeva.API.DAL.API_V2().YouTube_FetchParticipant_FetchFilter(Convert.ToInt32(parameters_obj.TopicID), Convert.ToDateTime(parameters_obj.BaseDate), Convert.ToDateTime(parameters_obj.FromDate), Convert.ToDateTime(parameters_obj.ToDate));

                //dynamic json = new JObject();
                //if (ds.Tables.Count > 0)
                //{
                //    json.status = "200";
                //    json.message = "Success";
                //    json.data = new JArray();

                //    dynamic oo = new JObject();
                //    oo.filter = new JObject();
                //    oo.filter.channel_name = "";
                //    oo.filter.channel_handle = "";
                //    oo.filter.sentiment = JArray.FromObject(ds.Tables[0]);
                //    oo.filter.tonality = JArray.FromObject(ds.Tables[1]);
                //    oo.filter.channel_category = JArray.FromObject(ds.Tables[2]);
                //    oo.filter.mention_type = JArray.FromObject(ds.Tables[3]);
                //    oo.filter.verified_type = JArray.FromObject(ds.Tables[4]);
                //    oo.filter.participant_type = JArray.FromObject(ds.Tables[5]);
                //    oo.filter.subscribers_range = JArray.FromObject(ds.Tables[6]);
                //    oo.filter.length_range = JArray.FromObject(ds.Tables[7]);
                //    oo.filter.types_of_video = JArray.FromObject(ds.Tables[8]);
                //    oo.filter.discource_category = JArray.FromObject(ds.Tables[9]);
                //    oo.filter.people_brand_mentions = JArray.FromObject(ds.Tables[10]);
                //    oo.filter.topics_discussed_in_video = JArray.FromObject(ds.Tables[11]);
                //    oo.filter.impact_score_range = JArray.FromObject(ds.Tables[12]);
                //    oo.filter.location = JArray.FromObject(ds.Tables[13]);

                //    json.data.Add(oo);
                //}

                //result = JsonConvert.SerializeObject(json, setting);

                result = File.ReadAllText(ConfigurationManager.AppSettings["FetchFilter_Participant_YouTube"]);

            }
            catch (Exception ex)
            {
                Log("FetchFilter_Participant_YouTube", ex.Message + " ->> " + ex.StackTrace + " Detail : " + new StreamReader(postData).ReadToEnd().ToString());
                dynamic json = new JObject();
                json.status = "Error";
                json.message = "Error Occured";

                var setting = new JsonSerializerSettings
                {
                    MaxDepth = int.MaxValue,
                    Formatting = Newtonsoft.Json.Formatting.None
                };
                result = JsonConvert.SerializeObject(json, setting);
            }

            return new MemoryStream(Encoding.UTF8.GetBytes(result));

        }

        #endregion

        #region Actions
        [OperationContract]
        [WebInvoke(Method = "POST", UriTemplate = "DownloadData", ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Bare)]
        public Stream DownloadData(Stream postData)
        {
            string result = string.Empty;

            var setting = new JsonSerializerSettings
            {
                MaxDepth = int.MaxValue,
                Formatting = Newtonsoft.Json.Formatting.None
            };

            try
            {

                if (HttpContext.Current.Request.Headers["token"] != null && !String.IsNullOrEmpty(HttpContext.Current.Request.Headers["token"]))
                {
                    bool IsValid = ValidateRequest(Convert.ToString(HttpContext.Current.Request.Headers["token"]));
                    if (IsValid == false)
                    {
                        result = "401 Unauthorized";
                        return new MemoryStream(Encoding.UTF8.GetBytes(result));
                    }
                }

                WebOperationContext.Current.OutgoingResponse.ContentType = "application/json; charset=utf-8";

                Int32 UDDRID = 0;
                string InputBody = new StreamReader(postData).ReadToEnd().ToString();
                dynamic stuff = JObject.Parse(InputBody);

                Log("DownloadData", InputBody);

                Int32 UserID = Convert.ToInt32(Convert.ToString(stuff.UserID));
                Int32 TopicID = Convert.ToInt32(Convert.ToString(stuff.incident_id));

                if (Convert.ToInt32(UserID) > 0)
                {
                    new Sahadeva.API.DAL.API_V2().UserLog_Insert(Convert.ToInt32(UserID), "DownloadData", Convert.ToInt32(TopicID));
                }

                UDDRID = new Sahadeva.API.DAL.API_V2().API_UserRequest_DataDownload_Insert(UserID, TopicID, InputBody);

                dynamic json = new JObject();
                json.status = "Successful";
                if (InputBody.Contains("event_report"))
                {
                    json.message = "Your request to generate a report for this event has been submitted.You will be notified when it’s ready on your registered email.";
                }
                else
                {
                    json.message = "Request has been sent.You will receive an e-mail of required data.";
                }


                result = JsonConvert.SerializeObject(json, setting);
            }
            catch (Exception ex)
            {
                Log("DownloadData", ex.Message + " ->> " + ex.StackTrace + " Detail : " + new StreamReader(postData).ReadToEnd().ToString());

                dynamic json = new JObject();
                json.status = "Error";
                json.message = "Error Occured";
                result = JsonConvert.SerializeObject(json, setting);

            }

            return new MemoryStream(Encoding.UTF8.GetBytes(result));

        }

        [OperationContract]
        [WebInvoke(Method = "POST", UriTemplate = "Fetch_FeedbackTypes", ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Bare)]
        public Stream Fetch_FeedbackTypes(Stream postData)
        {
            string result = string.Empty;

            var setting = new JsonSerializerSettings
            {
                MaxDepth = int.MaxValue,
                Formatting = Newtonsoft.Json.Formatting.None
            };

            try
            {

                if (HttpContext.Current.Request.Headers["token"] != null && !String.IsNullOrEmpty(HttpContext.Current.Request.Headers["token"]))
                {
                    bool IsValid = ValidateRequest(Convert.ToString(HttpContext.Current.Request.Headers["token"]));
                    if (IsValid == false)
                    {
                        result = "401 Unauthorized";
                        return new MemoryStream(Encoding.UTF8.GetBytes(result));
                    }
                }

                WebOperationContext.Current.OutgoingResponse.ContentType = "application/json; charset=utf-8";

                dynamic json = new JObject();
                json.status = "200";
                json.message = "Success";
                json.data = new JArray();

                dynamic o = new JObject();
                o.Add("feedback_typeid", "1");
                o.Add("feedback_type", "Suggestion");
                json.data.Add(o);

                o = new JObject();
                o.Add("feedback_typeid", "2");
                o.Add("feedback_type", "Service related");
                json.data.Add(o);

                o = new JObject();
                o.Add("feedback_typeid", "3");
                o.Add("feedback_type", "Report Bug");
                json.data.Add(o);

                o = new JObject();
                o.Add("feedback_typeid", "4");
                o.Add("feedback_type", "Report Incorrect information");
                json.data.Add(o);


                result = JsonConvert.SerializeObject(json, setting);
            }
            catch (Exception ex)
            {
                Log("Fetch_FeedbackTypes", ex.Message + " ->> " + ex.StackTrace + " Detail : " + new StreamReader(postData).ReadToEnd().ToString());

                dynamic json = new JObject();
                json.status = "Error";
                json.message = "Error Occured";
                result = JsonConvert.SerializeObject(json, setting);

            }

            return new MemoryStream(Encoding.UTF8.GetBytes(result));

        }

        [OperationContract]
        [WebInvoke(Method = "POST", UriTemplate = "ShareFeedback", ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Bare)]
        public Stream ShareFeedback(Stream postData)
        {
            string result = string.Empty;

            var setting = new JsonSerializerSettings
            {
                MaxDepth = int.MaxValue,
                Formatting = Newtonsoft.Json.Formatting.None
            };

            try
            {

                if (HttpContext.Current.Request.Headers["token"] != null && !String.IsNullOrEmpty(HttpContext.Current.Request.Headers["token"]))
                {
                    bool IsValid = ValidateRequest(Convert.ToString(HttpContext.Current.Request.Headers["token"]));
                    if (IsValid == false)
                    {
                        result = "401 Unauthorized";
                        return new MemoryStream(Encoding.UTF8.GetBytes(result));
                    }
                }

                WebOperationContext.Current.OutgoingResponse.ContentType = "application/json; charset=utf-8";

                eParameters parameters_obj = GetParameters(postData, "ShareFeedback");


                //if (!String.IsNullOrEmpty(parameters_obj.UserID) && Convert.ToInt32(parameters_obj.UserID) > 0)
                //{
                //    //new Sahadeva.API.DAL.API_V2().UserLog_Insert(Convert.ToInt32(parameters_obj.UserID), "ShareFeedback", Convert.ToInt32(parameters_obj.TopicID));
                //}

                dynamic json = new JObject();
                json.status = "Successful";
                json.message = "Thank you for your feedback.";

                result = JsonConvert.SerializeObject(json, setting);
            }
            catch (Exception ex)
            {
                Log("ShareFeedback", ex.Message + " ->> " + ex.StackTrace + " Detail : " + new StreamReader(postData).ReadToEnd().ToString());

                dynamic json = new JObject();
                json.status = "Error";
                json.message = "Error Occured";
                result = JsonConvert.SerializeObject(json, setting);

            }

            return new MemoryStream(Encoding.UTF8.GetBytes(result));

        }

        [OperationContract]
        [WebInvoke(Method = "POST", UriTemplate = "UserBookmark_Update", ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Bare)]
        public Stream UserBookmark_Update(Stream postData)
        {
            string result = string.Empty;

            try
            {

                if (HttpContext.Current.Request.Headers["token"] != null && !String.IsNullOrEmpty(HttpContext.Current.Request.Headers["token"]))
                {
                    bool IsValid = ValidateRequest(Convert.ToString(HttpContext.Current.Request.Headers["token"]));
                    if (IsValid == false)
                    {
                        result = "401 Unauthorized";
                        return new MemoryStream(Encoding.UTF8.GetBytes(result));
                    }
                }

                WebOperationContext.Current.OutgoingResponse.ContentType = "application/json; charset=utf-8";

                //eParameters parameters_obj = GetParameters(postData, "CreateIncident");

                var setting = new JsonSerializerSettings
                {
                    MaxDepth = int.MaxValue,
                    Formatting = Newtonsoft.Json.Formatting.None
                };

                string InputBody = new StreamReader(postData).ReadToEnd().ToString();

                Int32 RecordID_Output = 0;
                dynamic stuff = JObject.Parse(InputBody);

                Log("UserBookmark_Update", InputBody);
                //eParameters parameters_obj = GetParameters(null, "UserBookmark", InputBody);


                Int32 UserID = Convert.ToInt32(Convert.ToString(stuff.UserID));
                Int32 TopicID = Convert.ToInt32(Convert.ToString(stuff.incident_id));
                string platform = Convert.ToString(Convert.ToString(stuff.platform));
                Int32 RecordID = Convert.ToInt32(Convert.ToString(stuff.record_id));
                string Title = Convert.ToString(stuff.title);
                string Type = Convert.ToString(stuff.type);
                Int32 PlatformID = 0;

                if (Convert.ToInt32(UserID) > 0)
                {
                    new Sahadeva.API.DAL.API_V2().UserLog_Insert(Convert.ToInt32(UserID), "UserBookmark_Update", Convert.ToInt32(RecordID));
                }

                if (platform == "online") { PlatformID = 1; }
                if (platform == "print") { PlatformID = 2; }
                if (platform == "twitter") { PlatformID = 3; }
                if (platform == "youtube") { PlatformID = 4; }


                RecordID_Output = new Sahadeva.API.DAL.API_V2().UserBookmark_Update(UserID, PlatformID, RecordID, Type, Title, TopicID);

                dynamic json = new JObject();
                json.status = "Successful";
                json.message = "Request has been sent.";


                result = JsonConvert.SerializeObject(json, setting);
            }
            catch (Exception ex)
            {
                Log("UserBookmark_Update", ex.Message + " ->> " + ex.StackTrace + " Detail : " + new StreamReader(postData).ReadToEnd().ToString());
                dynamic json = new JObject();
                json.status = "Error";
                json.message = "Error Occured";

                var setting = new JsonSerializerSettings
                {
                    MaxDepth = int.MaxValue,
                    Formatting = Newtonsoft.Json.Formatting.None
                };
                result = JsonConvert.SerializeObject(json, setting);
            }

            return new MemoryStream(Encoding.UTF8.GetBytes(result));

        }

        #endregion

        #region Landing_Summaries
        //[OperationContract]
        //[WebInvoke(Method = "POST", UriTemplate = "FetchLanding_OnlineArticle_Summary", ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Bare)]
        //public Stream FetchLanding_OnlineArticle_Summary(Stream postData)
        //{
        //    string result = string.Empty;

        //    try
        //    {

        //        if (HttpContext.Current.Request.Headers["token"] != null && !String.IsNullOrEmpty(HttpContext.Current.Request.Headers["token"]))
        //        {
        //            bool IsValid = ValidateRequest(Convert.ToString(HttpContext.Current.Request.Headers["token"]));
        //            if (IsValid == false)
        //            {
        //                result = "401 Unauthorized";
        //                return new MemoryStream(Encoding.UTF8.GetBytes(result));
        //            }
        //        }

        //        WebOperationContext.Current.OutgoingResponse.ContentType = "application/json; charset=utf-8";

        //        eParameters parameters_obj = GetParameters(postData, "FetchLanding_OnlineArticle_Summary");

        //        var setting = new JsonSerializerSettings
        //        {
        //            MaxDepth = int.MaxValue
        //        };



        //        DataSet ds = new Sahadeva.API.DAL.API_V2().ArticleOnline_FetchLanding(Convert.ToInt32(parameters_obj.TopicID), Convert.ToDateTime(parameters_obj.FromDate), Convert.ToDateTime(parameters_obj.ToDate), Convert.ToDateTime(parameters_obj.BaseDate));


        //        dynamic json = new JObject();
        //        if (ds.Tables.Count > 0)
        //        {

        //            json.status = "200";
        //            json.message = "Success";
        //            json.data = new JObject();

        //            System.Threading.Thread.Sleep(25000);
        //            dynamic o = new JObject();
        //            o.incident_id = Convert.ToInt32(parameters_obj.TopicID);
        //            o.key_highlights_data = JArray.FromObject(ds.Tables[6]);
        //            json.data = o;
        //        }

        //        //result = File.ReadAllText(ConfigurationManager.AppSettings["FetchLanding_OnlineArticle"]);

        //        result = JsonConvert.SerializeObject(json, setting);
        //    }
        //    catch (Exception ex)
        //    {
        //        Log("FetchLanding_OnlineArticle_Summary", ex.Message + " ->> " + ex.StackTrace + " Detail : " + new StreamReader(postData).ReadToEnd().ToString());
        //        dynamic json = new JObject();
        //        json.status = "Error";
        //        json.message = "Error Occured";

        //        var setting = new JsonSerializerSettings
        //        {
        //            MaxDepth = int.MaxValue
        //        };
        //        result = JsonConvert.SerializeObject(json, setting);
        //    }

        //    return new MemoryStream(Encoding.UTF8.GetBytes(result));

        //}

        //[OperationContract]
        //[WebInvoke(Method = "POST", UriTemplate = "FetchLanding_PrintArticle_Summary", ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Bare)]
        //public Stream FetchLanding_PrintArticle_Summary(Stream postData)
        //{
        //    string result = string.Empty;

        //    try
        //    {

        //        if (HttpContext.Current.Request.Headers["token"] != null && !String.IsNullOrEmpty(HttpContext.Current.Request.Headers["token"]))
        //        {
        //            bool IsValid = ValidateRequest(Convert.ToString(HttpContext.Current.Request.Headers["token"]));
        //            if (IsValid == false)
        //            {
        //                result = "401 Unauthorized";
        //                return new MemoryStream(Encoding.UTF8.GetBytes(result));
        //            }
        //        }

        //        WebOperationContext.Current.OutgoingResponse.ContentType = "application/json; charset=utf-8";

        //        eParameters parameters_obj = GetParameters(postData, "FetchLanding_PrintArticle_Summary");

        //        var setting = new JsonSerializerSettings
        //        {
        //            MaxDepth = int.MaxValue
        //        };

        //        DataSet ds = new Sahadeva.API.DAL.API_V2().ArticlePrint_FetchLanding(Convert.ToInt32(parameters_obj.TopicID), Convert.ToDateTime(parameters_obj.FromDate), Convert.ToDateTime(parameters_obj.ToDate), Convert.ToDateTime(parameters_obj.BaseDate));



        //        dynamic json = new JObject();
        //        if (ds.Tables.Count > 0)
        //        {
        //            json.status = "200";
        //            json.message = "Success";
        //            json.data = new JObject();

        //            System.Threading.Thread.Sleep(25000);
        //            dynamic o = new JObject();
        //            o.incident_id = Convert.ToInt32(parameters_obj.TopicID);
        //            o.key_highlights_data = JArray.FromObject(ds.Tables[8]);
        //            json.data = o;
        //        }

        //        //result = File.ReadAllText(ConfigurationManager.AppSettings["FetchLanding_PrintArticle"]);

        //        result = JsonConvert.SerializeObject(json, setting);
        //    }
        //    catch (Exception ex)
        //    {
        //        Log("FetchLanding_PrintArticle_Summary", ex.Message + " ->> " + ex.StackTrace + " Detail : " + new StreamReader(postData).ReadToEnd().ToString());
        //        dynamic json = new JObject();
        //        json.status = "Error";
        //        json.message = "Error Occured";

        //        var setting = new JsonSerializerSettings
        //        {
        //            MaxDepth = int.MaxValue
        //        };
        //        result = JsonConvert.SerializeObject(json, setting);
        //    }

        //    return new MemoryStream(Encoding.UTF8.GetBytes(result));

        //}

        //[OperationContract]
        //[WebInvoke(Method = "POST", UriTemplate = "FetchLanding_Twitter_Summary", ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Bare)]
        //public Stream FetchLanding_Twitter_Summary(Stream postData)
        //{
        //    string result = string.Empty;

        //    try
        //    {

        //        if (HttpContext.Current.Request.Headers["token"] != null && !String.IsNullOrEmpty(HttpContext.Current.Request.Headers["token"]))
        //        {
        //            bool IsValid = ValidateRequest(Convert.ToString(HttpContext.Current.Request.Headers["token"]));
        //            if (IsValid == false)
        //            {
        //                result = "401 Unauthorized";
        //                return new MemoryStream(Encoding.UTF8.GetBytes(result));
        //            }
        //        }

        //        WebOperationContext.Current.OutgoingResponse.ContentType = "application/json; charset=utf-8";

        //        eParameters parameters_obj = GetParameters(postData, "FetchLanding_Twitter_Summary");

        //        var setting = new JsonSerializerSettings
        //        {
        //            MaxDepth = int.MaxValue
        //        };


        //        Log("Twitter_FetchLanding start", "");
        //        DataSet ds = new Sahadeva.API.DAL.API_V2().Twitter_FetchLanding(Convert.ToInt32(parameters_obj.TopicID), Convert.ToDateTime(parameters_obj.FromDate), Convert.ToDateTime(parameters_obj.ToDate), Convert.ToDateTime(parameters_obj.BaseDate));
        //        Log("Twitter_FetchLanding end", "");

        //        Log("Twitter_FetchLanding JSON Creation start", "");
        //        dynamic json = new JObject();
        //        if (ds.Tables.Count > 0)
        //        {
        //            json.status = "200";
        //            json.message = "Success";
        //            json.data = new JObject();

        //            System.Threading.Thread.Sleep(25000);
        //            dynamic o = new JObject();
        //            o.incident_id = Convert.ToInt32(parameters_obj.TopicID);
        //            o.key_highlights_data = JArray.FromObject(ds.Tables[14]);
        //            json.data = o;
        //        }
        //        Log("Twitter_FetchLanding JSON Creation End", "");


        //        //result = File.ReadAllText(ConfigurationManager.AppSettings["FetchLanding_OnlineArticle"]);

        //        Log("Twitter_FetchLanding SerializeObject Creation Start", "");
        //        result = JsonConvert.SerializeObject(json, setting);
        //        Log("Twitter_FetchLanding SerializeObject Creation End", "");
        //    }
        //    catch (Exception ex)
        //    {
        //        Log("FetchLanding_Twitter_Summary", ex.Message + " ->> " + ex.StackTrace + " Detail : " + new StreamReader(postData).ReadToEnd().ToString());
        //        dynamic json = new JObject();
        //        json.status = "Error";
        //        json.message = "Error Occured";

        //        var setting = new JsonSerializerSettings
        //        {
        //            MaxDepth = int.MaxValue
        //        };
        //        result = JsonConvert.SerializeObject(json, setting);
        //    }

        //    return new MemoryStream(Encoding.UTF8.GetBytes(result));

        //}

        //[OperationContract]
        //[WebInvoke(Method = "POST", UriTemplate = "FetchLanding_Overview_Summary", ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Bare)]
        //public Stream FetchLanding_Overview_Summary(Stream postData)
        //{
        //    string result = string.Empty;
        //    var setting = new JsonSerializerSettings
        //    {
        //        MaxDepth = int.MaxValue
        //    };
        //    try
        //    {

        //        if (HttpContext.Current.Request.Headers["token"] != null && !String.IsNullOrEmpty(HttpContext.Current.Request.Headers["token"]))
        //        {
        //            bool IsValid = ValidateRequest(Convert.ToString(HttpContext.Current.Request.Headers["token"]));
        //            if (IsValid == false)
        //            {
        //                result = "401 Unauthorized";
        //                return new MemoryStream(Encoding.UTF8.GetBytes(result));
        //            }
        //        }

        //        WebOperationContext.Current.OutgoingResponse.ContentType = "application/json; charset=utf-8";

        //        eParameters parameters_obj = GetParameters(postData, "FetchLanding_Overview_Summary");

        //        Log("Incident_FetchLanding DS start", "");
        //        DataSet ds = new Sahadeva.API.DAL.API_V2().Incident_FetchLanding(Convert.ToInt32(parameters_obj.TopicID), Convert.ToDateTime(parameters_obj.FromDate), Convert.ToDateTime(parameters_obj.ToDate), Convert.ToDateTime(parameters_obj.BaseDate));
        //        Log("Incident_FetchLanding DS end", "");

        //        Log("Incident_FetchLanding JSON start", "");
        //        dynamic json = new JObject();
        //        if (ds.Tables.Count > 0)
        //        {
        //            json.status = "200";
        //            json.message = "Success";
        //            json.data = new JObject();

        //            System.Threading.Thread.Sleep(15000);
        //            dynamic o = new JObject();
        //            o.incident_id = Convert.ToInt32(parameters_obj.TopicID);
        //            o.key_highlights_data = JArray.FromObject(ds.Tables[5]);
        //            json.data = o;
        //        }

        //        Log("Incident_FetchLanding JSON End", "");

        //        //result = File.ReadAllText(ConfigurationManager.AppSettings["FetchLanding_OnlineArticle"]);
        //        Log("Incident_FetchLanding SerializeObject start", "");
        //        result = JsonConvert.SerializeObject(json, setting);
        //        Log("Incident_FetchLanding SerializeObject End", "");
        //    }
        //    catch (Exception ex)
        //    {
        //        Log("FetchLanding_Overview_Summary", ex.Message + " ->> " + ex.StackTrace + " Detail : " + new StreamReader(postData).ReadToEnd().ToString());
        //        dynamic json = new JObject();
        //        json.status = "Error";
        //        json.message = "Error Occured";
        //        result = JsonConvert.SerializeObject(json, setting);
        //    }

        //    return new MemoryStream(Encoding.UTF8.GetBytes(result));

        //}
        #endregion

        [OperationContract]
        [WebInvoke(Method = "POST", UriTemplate = "FetchAsyncData", ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Bare)]
        public Stream FetchAsyncData(Stream postData)
        {
            string result = string.Empty;

            var setting = new JsonSerializerSettings
            {
                MaxDepth = int.MaxValue,
                Formatting = Newtonsoft.Json.Formatting.None
            };

            try
            {

                if (HttpContext.Current.Request.Headers["token"] != null && !String.IsNullOrEmpty(HttpContext.Current.Request.Headers["token"]))
                {
                    bool IsValid = ValidateRequest(Convert.ToString(HttpContext.Current.Request.Headers["token"]));
                    if (IsValid == false)
                    {
                        result = "401 Unauthorized";
                        return new MemoryStream(Encoding.UTF8.GetBytes(result));
                    }
                }

                WebOperationContext.Current.OutgoingResponse.ContentType = "application/json; charset=utf-8";

                eParameters parameters_obj = GetParameters(postData, "DownloadData");

                if (!String.IsNullOrEmpty(parameters_obj.UserID) && Convert.ToInt32(parameters_obj.UserID) > 0)
                {
                    new Sahadeva.API.DAL.API_V2().UserLog_Insert(Convert.ToInt32(parameters_obj.UserID), "DownloadData", Convert.ToInt32(parameters_obj.TopicID));
                }

                // Create 2 DataTable instances.
                DataTable table1 = new DataTable("Employees");
                table1.Columns.Add("ID");
                table1.Columns.Add("Name");

                for (int i = 1; i < 501; i++)
                {
                    table1.Rows.Add("Employee " + i.ToString(), i);

                }
                System.Threading.Thread.Sleep(28000);
                dynamic json = new JObject();
                json.status = "200";
                json.message = "Success";
                json.data = new JObject();

                dynamic o = new JObject();
                o.employees = JArray.FromObject(table1);
                json.data = o;

                result = JsonConvert.SerializeObject(json, setting);
            }
            catch (Exception ex)
            {
                Log("DownloadData", ex.Message + " ->> " + ex.StackTrace + " Detail : " + new StreamReader(postData).ReadToEnd().ToString());

                dynamic json = new JObject();
                json.status = "Error";
                json.message = "Error Occured";
                result = JsonConvert.SerializeObject(json, setting);

            }

            return new MemoryStream(Encoding.UTF8.GetBytes(result));

        }

        #region New Landing Summaries
        [OperationContract]
        [WebInvoke(Method = "POST", UriTemplate = "FetchLanding_OnlineArticle_Summary", ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Bare)]
        public Stream FetchLanding_OnlineArticle_Summary(Stream postData)
        {
            string result = string.Empty;

            try
            {

                if (HttpContext.Current.Request.Headers["token"] != null && !String.IsNullOrEmpty(HttpContext.Current.Request.Headers["token"]))
                {
                    bool IsValid = ValidateRequest(Convert.ToString(HttpContext.Current.Request.Headers["token"]));
                    if (IsValid == false)
                    {
                        result = "401 Unauthorized";
                        return new MemoryStream(Encoding.UTF8.GetBytes(result));
                    }
                }

                WebOperationContext.Current.OutgoingResponse.ContentType = "application/json; charset=utf-8";

                eParameters parameters_obj = GetParameters(postData, "FetchLanding_OnlineArticle_Summary");

                if (!String.IsNullOrEmpty(parameters_obj.UserID) && Convert.ToInt32(parameters_obj.UserID) > 0)
                {
                    new Sahadeva.API.DAL.API_V2().UserLog_Insert(Convert.ToInt32(parameters_obj.UserID), "FetchLanding_OnlineArticle_Summary", Convert.ToInt32(parameters_obj.TopicID));
                }

                var setting = new JsonSerializerSettings
                {
                    MaxDepth = int.MaxValue,
                    Formatting = Newtonsoft.Json.Formatting.None
                };


                dynamic json = new JObject();
                string strOutput = string.Empty;

                DataTable dt = new DataTable();

                if (ConfigurationManager.AppSettings["IsIntent"].ToString() == "0")
                {

                    if (ConfigurationManager.AppSettings["Summary_IsPeak"].ToString() == "0")
                    {
                        dt = new MDB.DAL.DAL().Incident_ArticleOnlineSummary_Insert(Convert.ToInt32(parameters_obj.TopicID), 0, Convert.ToDateTime(parameters_obj.FromDate), Convert.ToDateTime(parameters_obj.ToDate), "", "Landing", 0);

                        if (dt.Rows.Count > 0)
                        {
                            json = (JObject)JArray.FromObject(dt)[0];
                            Summary objSummary = new Summary();
                            strOutput = objSummary.FetchData_OnlineArticle(Convert.ToString(json), "", false);
                        }
                    }
                    else
                    {
                        dt = new MDB.DAL.DAL().Summary_FetchPeakSummaries(Convert.ToInt32(parameters_obj.TopicID), 0, Convert.ToDateTime(parameters_obj.FromDate), Convert.ToDateTime(parameters_obj.ToDate), "online", "ID");
                        Summary objSummary = new Summary();
                        string strPeakSummaryOutput = string.Empty;
                        if (dt.Rows.Count > 0)
                        {
                            /*------------------------------------------------------*/
                            string strIDs = Convert.ToString(dt.Rows[0][0]);
                            Log("strIDs ", strIDs);
                            dynamic strInputJson = new JObject();
                            strInputJson.IDs = strIDs;
                            strInputJson.Platform = "online";
                            strInputJson.TopicID = Convert.ToString(Convert.ToInt32(parameters_obj.TopicID));

                            strPeakSummaryOutput = objSummary.FetchData_PeakSummarization(Convert.ToString(strInputJson));

                            Log("strPeakSummaryOutput", strPeakSummaryOutput);
                            /*------------------------------------------------------*/
                        }

                        /*------------------------------------------------------*/
                        //DateTime LastPeakDate = Convert.ToDateTime(Convert.ToString(dt.Rows[0][1]));
                        dt = new MDB.DAL.DAL().Incident_ArticleOnlineSummary_Insert(Convert.ToInt32(parameters_obj.TopicID), 0, Convert.ToDateTime(parameters_obj.FromDate), Convert.ToDateTime(parameters_obj.ToDate), "", "Landing", 0);

                        if (dt.Rows.Count > 0)
                        {
                            json = (JObject)JArray.FromObject(dt)[0];
                            objSummary = new Summary();
                            //strOutput = objSummary.FetchData_OnlineArticle(Convert.ToString(json),"PEAK SUMMARY - >"+ strPeakSummaryOutput);
                            strOutput = objSummary.FetchData_OnlineArticle(Convert.ToString(json), strPeakSummaryOutput, false);
                        }
                        /*------------------------------------------------------*/

                    }

                }
                else if (ConfigurationManager.AppSettings["IsIntent"].ToString() == "1")
                {
                    dt = new MDB.DAL.DAL().Incident_ArticleOnlineSummary_Insert(Convert.ToInt32(parameters_obj.TopicID), 0, Convert.ToDateTime(parameters_obj.FromDate), Convert.ToDateTime(parameters_obj.ToDate), "", "Landing", 0);

                    if (dt.Rows.Count > 0)
                    {
                        json = (JObject)JArray.FromObject(dt)[0];
                        Summary objSummary = new Summary();
                        strOutput = objSummary.FetchData_OnlineArticle(Convert.ToString(json), "", true);
                    }
                }

                result = strOutput;

            }
            catch (Exception ex)
            {
                Log("FetchLanding_OnlineArticle_Summary", ex.Message + " ->> " + ex.StackTrace + " Detail : " + new StreamReader(postData).ReadToEnd().ToString());
                dynamic json = new JObject();
                json.status = "Error";
                json.message = "Error Occured";

                var setting = new JsonSerializerSettings
                {
                    MaxDepth = int.MaxValue,
                    Formatting = Newtonsoft.Json.Formatting.None
                };
                result = JsonConvert.SerializeObject(json, setting);
            }

            return new MemoryStream(Encoding.UTF8.GetBytes(result));

        }

        [OperationContract]
        [WebInvoke(Method = "POST", UriTemplate = "FetchLanding_PrintArticle_Summary", ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Bare)]
        public Stream FetchLanding_PrintArticle_Summary(Stream postData)
        {
            string result = string.Empty;

            try
            {

                if (HttpContext.Current.Request.Headers["token"] != null && !String.IsNullOrEmpty(HttpContext.Current.Request.Headers["token"]))
                {
                    bool IsValid = ValidateRequest(Convert.ToString(HttpContext.Current.Request.Headers["token"]));
                    if (IsValid == false)
                    {
                        result = "401 Unauthorized";
                        return new MemoryStream(Encoding.UTF8.GetBytes(result));
                    }
                }

                WebOperationContext.Current.OutgoingResponse.ContentType = "application/json; charset=utf-8";

                eParameters parameters_obj = GetParameters(postData, "FetchLanding_PrintArticle_Summary_New");

                if (!String.IsNullOrEmpty(parameters_obj.UserID) && Convert.ToInt32(parameters_obj.UserID) > 0)
                {
                    new Sahadeva.API.DAL.API_V2().UserLog_Insert(Convert.ToInt32(parameters_obj.UserID), "FetchLanding_PrintArticle_Summary_New", Convert.ToInt32(parameters_obj.TopicID));
                }

                var setting = new JsonSerializerSettings
                {
                    MaxDepth = int.MaxValue,
                    Formatting = Newtonsoft.Json.Formatting.None
                };



                //DataSet ds = new Sahadeva.API.DAL.API_V2().ArticleOnline_FetchLanding(Convert.ToInt32(parameters_obj.TopicID), Convert.ToDateTime(parameters_obj.FromDate), Convert.ToDateTime(parameters_obj.ToDate), Convert.ToDateTime(parameters_obj.BaseDate));
                dynamic json = new JObject();
                string strOutput = string.Empty;

                DataTable dt = new DataTable();

                if (ConfigurationManager.AppSettings["IsIntent"].ToString() == "0")
                {
                    if (ConfigurationManager.AppSettings["Summary_IsPeak"].ToString() == "0")
                    {
                        dt = new MDB.DAL.DAL().Incident_ArticlePrintSummary_Insert(Convert.ToInt32(parameters_obj.TopicID), 0, Convert.ToDateTime(parameters_obj.FromDate), Convert.ToDateTime(parameters_obj.ToDate), "", "Landing", 0);

                        if (dt.Rows.Count > 0)
                        {
                            json = (JObject)JArray.FromObject(dt)[0];
                            Summary objSummary = new Summary();
                            strOutput = objSummary.FetchData_PrintArticle(Convert.ToString(json), "", false);
                        }
                    }
                    else
                    {
                        dt = new MDB.DAL.DAL().Summary_FetchPeakSummaries(Convert.ToInt32(parameters_obj.TopicID), 0, Convert.ToDateTime(parameters_obj.FromDate), Convert.ToDateTime(parameters_obj.ToDate), "print", "ID");
                        string strPeakSummaryOutput = string.Empty;
                        Summary objSummary = new Summary();
                        if (dt.Rows.Count > 0)
                        {
                            /*------------------------------------------------------*/
                            string strIDs = Convert.ToString(dt.Rows[0][0]);

                            dynamic strInputJson = new JObject();
                            strInputJson.IDs = strIDs;
                            strInputJson.Platform = "print";
                            strInputJson.TopicID = Convert.ToString(Convert.ToInt32(parameters_obj.TopicID));

                            strPeakSummaryOutput = objSummary.FetchData_PeakSummarization(Convert.ToString(strInputJson));
                            /*------------------------------------------------------*/
                        }

                        /*------------------------------------------------------*/
                        //DateTime LastPeakDate = Convert.ToDateTime(Convert.ToString(dt.Rows[0][1]));
                        dt = new MDB.DAL.DAL().Incident_ArticlePrintSummary_Insert(Convert.ToInt32(parameters_obj.TopicID), 0, Convert.ToDateTime(parameters_obj.FromDate), Convert.ToDateTime(parameters_obj.ToDate), "", "Landing", 0);

                        if (dt.Rows.Count > 0)
                        {
                            json = (JObject)JArray.FromObject(dt)[0];
                            objSummary = new Summary();
                            //strOutput = objSummary.FetchData_PrintArticle(Convert.ToString(json), "PEAK SUMMARY - >" + strPeakSummaryOutput);
                            strOutput = objSummary.FetchData_PrintArticle(Convert.ToString(json), strPeakSummaryOutput, false);
                        }
                        /*------------------------------------------------------*/


                    }
                }
                else
                {
                    dt = new MDB.DAL.DAL().Incident_ArticlePrintSummary_Insert(Convert.ToInt32(parameters_obj.TopicID), 0, Convert.ToDateTime(parameters_obj.FromDate), Convert.ToDateTime(parameters_obj.ToDate), "", "Landing", 0);

                    if (dt.Rows.Count > 0)
                    {
                        json = (JObject)JArray.FromObject(dt)[0];
                        Summary objSummary = new Summary();
                        strOutput = objSummary.FetchData_PrintArticle(Convert.ToString(json), "", true);
                    }

                }

                result = strOutput;

            }
            catch (Exception ex)
            {
                Log("FetchLanding_PrintArticle_Summary", ex.Message + " ->> " + ex.StackTrace + " Detail : " + new StreamReader(postData).ReadToEnd().ToString());
                dynamic json = new JObject();
                json.status = "Error";
                json.message = "Error Occured";

                var setting = new JsonSerializerSettings
                {
                    MaxDepth = int.MaxValue,
                    Formatting = Newtonsoft.Json.Formatting.None
                };
                result = JsonConvert.SerializeObject(json, setting);
            }

            return new MemoryStream(Encoding.UTF8.GetBytes(result));

        }

        [OperationContract]
        [WebInvoke(Method = "POST", UriTemplate = "FetchLanding_Twitter_Summary", ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Bare)]
        public Stream FetchLanding_Twitter_Summary(Stream postData)
        {
            string result = string.Empty;

            try
            {

                if (HttpContext.Current.Request.Headers["token"] != null && !String.IsNullOrEmpty(HttpContext.Current.Request.Headers["token"]))
                {
                    bool IsValid = ValidateRequest(Convert.ToString(HttpContext.Current.Request.Headers["token"]));
                    if (IsValid == false)
                    {
                        result = "401 Unauthorized";
                        return new MemoryStream(Encoding.UTF8.GetBytes(result));
                    }
                }

                WebOperationContext.Current.OutgoingResponse.ContentType = "application/json; charset=utf-8";

                eParameters parameters_obj = GetParameters(postData, "FetchLanding_Twitter_Summary_New");

                if (!String.IsNullOrEmpty(parameters_obj.UserID) && Convert.ToInt32(parameters_obj.UserID) > 0)
                {
                    new Sahadeva.API.DAL.API_V2().UserLog_Insert(Convert.ToInt32(parameters_obj.UserID), "FetchLanding_Twitter_Summary_New", Convert.ToInt32(parameters_obj.TopicID));
                }

                var setting = new JsonSerializerSettings
                {
                    MaxDepth = int.MaxValue,
                    Formatting = Newtonsoft.Json.Formatting.None
                };

                dynamic json = new JObject();
                string strOutput = string.Empty;
                Summary objSummary = new Summary();
                DataTable dt = new DataTable();

                if (ConfigurationManager.AppSettings["IsIntent"].ToString() == "0")
                {

                    if (ConfigurationManager.AppSettings["Summary_IsPeak"].ToString() == "0")
                    {

                        string JSONToInsert = objSummary.CreateJSON(Convert.ToInt32(parameters_obj.TopicID), Convert.ToDateTime(parameters_obj.FromDate), Convert.ToDateTime(parameters_obj.ToDate));
                        Int32 ts_id = new MDB.DAL.DAL().Incident_TwitterSummary_Insert(Convert.ToInt32(parameters_obj.TopicID), 0, Convert.ToDateTime(parameters_obj.FromDate), Convert.ToDateTime(parameters_obj.ToDate), JSONToInsert, "Landing", 0);

                        if (ts_id > 0)
                        {
                            strOutput = objSummary.FetchData_Twitter(Convert.ToString(ts_id), "");
                        }
                    }
                    else
                    {
                        dt = new MDB.DAL.DAL().Summary_FetchPeakSummaries(Convert.ToInt32(parameters_obj.TopicID), 0, Convert.ToDateTime(parameters_obj.FromDate), Convert.ToDateTime(parameters_obj.ToDate), "twitter", "ID");

                        if (dt.Rows.Count > 0)
                        {
                            /*------------------------------------------------------*/
                            string strIDs = Convert.ToString(dt.Rows[0][0]);

                            dynamic strInputJson = new JObject();
                            strInputJson.IDs = strIDs;
                            strInputJson.Platform = "twitter";
                            strInputJson.TopicID = Convert.ToString(Convert.ToInt32(parameters_obj.TopicID));

                            string strPeakSummaryOutput = objSummary.FetchData_PeakSummarization(Convert.ToString(strInputJson));
                            /*------------------------------------------------------*/


                            /*------------------------------------------------------*/
                            //DateTime LastPeakDate = Convert.ToDateTime(Convert.ToString(dt.Rows[0][1]));
                            string JSONToInsert = objSummary.CreateJSON(Convert.ToInt32(parameters_obj.TopicID), Convert.ToDateTime(parameters_obj.FromDate), Convert.ToDateTime(parameters_obj.ToDate));
                            Int32 ts_id = new MDB.DAL.DAL().Incident_TwitterSummary_Insert(Convert.ToInt32(parameters_obj.TopicID), 0, Convert.ToDateTime(parameters_obj.FromDate), Convert.ToDateTime(parameters_obj.ToDate), JSONToInsert, "Landing", 0);

                            if (ts_id > 0)
                            {
                                //strOutput = objSummary.FetchData_Twitter(Convert.ToString(ts_id), "PEAK SUMMARY - >" + strPeakSummaryOutput);
                                strOutput = objSummary.FetchData_Twitter(Convert.ToString(ts_id), strPeakSummaryOutput);
                            }

                            /*------------------------------------------------------*/

                        }
                    }
                }
                else if (ConfigurationManager.AppSettings["IsIntent"].ToString() == "1")
                {
                    dt = new MDB.DAL.DAL().Incident_TwitterSummary_Insert_Intent(Convert.ToInt32(parameters_obj.TopicID), 0, Convert.ToDateTime(parameters_obj.FromDate), Convert.ToDateTime(parameters_obj.ToDate), "", "Landing", 0);

                    if (dt.Rows.Count > 0)
                    {
                        json = (JObject)JArray.FromObject(dt)[0];
                        Log("FetchLanding_Twitter_Summary", Convert.ToString(json));
                        strOutput = objSummary.FetchData_Twitter_Intent(Convert.ToString(json), "");
                    }
                }

                result = strOutput;

            }
            catch (Exception ex)
            {
                Log("FetchLanding_Twitter_Summary", ex.Message + " ->> " + ex.StackTrace + " Detail : " + new StreamReader(postData).ReadToEnd().ToString());
                dynamic json = new JObject();
                json.status = "Error";
                json.message = "Error Occured";

                var setting = new JsonSerializerSettings
                {
                    MaxDepth = int.MaxValue,
                    Formatting = Newtonsoft.Json.Formatting.None
                };
                result = JsonConvert.SerializeObject(json, setting);
            }

            return new MemoryStream(Encoding.UTF8.GetBytes(result));

        }

        [OperationContract]
        [WebInvoke(Method = "POST", UriTemplate = "FetchLanding_Overview_Summary", ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Bare)]
        public Stream FetchLanding_Overview_Summary(Stream postData)
        {
            string result = string.Empty;

            try
            {

                if (HttpContext.Current.Request.Headers["token"] != null && !String.IsNullOrEmpty(HttpContext.Current.Request.Headers["token"]))
                {
                    bool IsValid = ValidateRequest(Convert.ToString(HttpContext.Current.Request.Headers["token"]));
                    if (IsValid == false)
                    {
                        result = "401 Unauthorized";
                        return new MemoryStream(Encoding.UTF8.GetBytes(result));
                    }
                }

                WebOperationContext.Current.OutgoingResponse.ContentType = "application/json; charset=utf-8";

                eParameters parameters_obj = GetParameters(postData, "FetchLanding_Overall_Summary_New");

                if (!String.IsNullOrEmpty(parameters_obj.UserID) && Convert.ToInt32(parameters_obj.UserID) > 0)
                {
                    new Sahadeva.API.DAL.API_V2().UserLog_Insert(Convert.ToInt32(parameters_obj.UserID), "FetchLanding_Overall_Summary_New", Convert.ToInt32(parameters_obj.TopicID));
                }

                var setting = new JsonSerializerSettings
                {
                    MaxDepth = int.MaxValue,
                    Formatting = Newtonsoft.Json.Formatting.None
                };

                dynamic json = new JObject();
                string strOutput = string.Empty;
                Summary objSummary = new Summary();
                if (ConfigurationManager.AppSettings["Summary_IsPeak"].ToString() == "0")
                {
                    DataTable dt = new MDB.DAL.DAL().Incident_ArticleOnlineSummary_Insert(Convert.ToInt32(parameters_obj.TopicID), 0, Convert.ToDateTime(parameters_obj.FromDate), Convert.ToDateTime(parameters_obj.ToDate), "", "Landing", 0);


                    if (dt.Rows.Count > 0)
                    {
                        json = (JObject)JArray.FromObject(dt)[0];
                        strOutput = objSummary.FetchData_OnlineArticle(Convert.ToString(json), "");
                    }

                    dt = new MDB.DAL.DAL().Incident_ArticlePrintSummary_Insert(Convert.ToInt32(parameters_obj.TopicID), 0, Convert.ToDateTime(parameters_obj.FromDate), Convert.ToDateTime(parameters_obj.ToDate), "", "Landing", 0);

                    json = new JObject();
                    strOutput = string.Empty;
                    if (dt.Rows.Count > 0)
                    {
                        json = (JObject)JArray.FromObject(dt)[0];

                        strOutput = objSummary.FetchData_PrintArticle(Convert.ToString(json), "");
                    }


                    string JSONToInsert = objSummary.CreateJSON(Convert.ToInt32(parameters_obj.TopicID), Convert.ToDateTime(parameters_obj.FromDate), Convert.ToDateTime(parameters_obj.ToDate));
                    Int32 ts_id = new MDB.DAL.DAL().Incident_TwitterSummary_Insert(Convert.ToInt32(parameters_obj.TopicID), 0, Convert.ToDateTime(parameters_obj.FromDate), Convert.ToDateTime(parameters_obj.ToDate), JSONToInsert, "Landing", 0);
                    strOutput = string.Empty;

                    json = new JObject();
                    if (ts_id > 0)
                    {
                        strOutput = objSummary.FetchData_Twitter(Convert.ToString(ts_id), "");
                    }


                    dt = new MDB.DAL.DAL().Incident_OverallSummary_Insert(Convert.ToInt32(parameters_obj.TopicID), 0, Convert.ToDateTime(parameters_obj.FromDate), Convert.ToDateTime(parameters_obj.ToDate), "", "Landing");

                    json = new JObject();
                    strOutput = string.Empty;
                    if (dt.Rows.Count > 0)
                    {
                        json = (JObject)JArray.FromObject(dt)[0];

                        strOutput = objSummary.FetchData_Overall(Convert.ToString(json));
                    }
                }
                else
                {
                    DataTable dt = new MDB.DAL.DAL().Incident_ArticleOnlineSummary_Insert(Convert.ToInt32(parameters_obj.TopicID), 0, Convert.ToDateTime(parameters_obj.FromDate), Convert.ToDateTime(parameters_obj.ToDate), "", "Landing", 0);


                    if (dt.Rows.Count > 0)
                    {
                        json = (JObject)JArray.FromObject(dt)[0];
                        strOutput = objSummary.FetchData_OnlineArticle(Convert.ToString(json), "");
                    }

                    dt = new MDB.DAL.DAL().Incident_ArticlePrintSummary_Insert(Convert.ToInt32(parameters_obj.TopicID), 0, Convert.ToDateTime(parameters_obj.FromDate), Convert.ToDateTime(parameters_obj.ToDate), "", "Landing", 0);

                    json = new JObject();
                    strOutput = string.Empty;
                    if (dt.Rows.Count > 0)
                    {
                        json = (JObject)JArray.FromObject(dt)[0];

                        strOutput = objSummary.FetchData_PrintArticle(Convert.ToString(json), "");
                    }


                    string JSONToInsert = objSummary.CreateJSON(Convert.ToInt32(parameters_obj.TopicID), Convert.ToDateTime(parameters_obj.FromDate), Convert.ToDateTime(parameters_obj.ToDate));
                    Int32 ts_id = new MDB.DAL.DAL().Incident_TwitterSummary_Insert(Convert.ToInt32(parameters_obj.TopicID), 0, Convert.ToDateTime(parameters_obj.FromDate), Convert.ToDateTime(parameters_obj.ToDate), JSONToInsert, "Landing", 0);
                    strOutput = string.Empty;

                    json = new JObject();
                    if (ts_id > 0)
                    {
                        strOutput = objSummary.FetchData_Twitter(Convert.ToString(ts_id), "");
                    }


                    dt = new MDB.DAL.DAL().Incident_OverallSummary_Insert(Convert.ToInt32(parameters_obj.TopicID), 0, Convert.ToDateTime(parameters_obj.FromDate), Convert.ToDateTime(parameters_obj.ToDate), "", "Landing");

                    json = new JObject();
                    strOutput = string.Empty;
                    if (dt.Rows.Count > 0)
                    {
                        json = (JObject)JArray.FromObject(dt)[0];

                        strOutput = objSummary.FetchData_Overall(Convert.ToString(json));
                    }
                }

                result = strOutput;

            }
            catch (Exception ex)
            {
                Log("FetchLanding_Overall_Summary_New", ex.Message + " ->> " + ex.StackTrace + " Detail : " + new StreamReader(postData).ReadToEnd().ToString());
                dynamic json = new JObject();
                json.status = "Error";
                json.message = "Error Occured";

                var setting = new JsonSerializerSettings
                {
                    MaxDepth = int.MaxValue,
                    Formatting = Newtonsoft.Json.Formatting.None
                };
                result = JsonConvert.SerializeObject(json, setting);
            }

            return new MemoryStream(Encoding.UTF8.GetBytes(result));

        }


        [OperationContract]
        [WebInvoke(Method = "POST", UriTemplate = "FetchLanding_YouTube_Summary", ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Bare)]
        public Stream FetchLanding_YouTube_Summary(Stream postData)
        {
            string result = string.Empty;

            try
            {

                if (HttpContext.Current.Request.Headers["token"] != null && !String.IsNullOrEmpty(HttpContext.Current.Request.Headers["token"]))
                {
                    bool IsValid = ValidateRequest(Convert.ToString(HttpContext.Current.Request.Headers["token"]));
                    if (IsValid == false)
                    {
                        result = "401 Unauthorized";
                        return new MemoryStream(Encoding.UTF8.GetBytes(result));
                    }
                }

                WebOperationContext.Current.OutgoingResponse.ContentType = "application/json; charset=utf-8";

                eParameters parameters_obj = GetParameters(postData, "FetchLanding_YouTube_Summary");

                if (!String.IsNullOrEmpty(parameters_obj.UserID) && Convert.ToInt32(parameters_obj.UserID) > 0)
                {
                    new Sahadeva.API.DAL.API_V2().UserLog_Insert(Convert.ToInt32(parameters_obj.UserID), "FetchLanding_YouTube_Summary", Convert.ToInt32(parameters_obj.TopicID));
                }

                var setting = new JsonSerializerSettings
                {
                    MaxDepth = int.MaxValue,
                    Formatting = Newtonsoft.Json.Formatting.None
                };

                dynamic json = new JObject();
                string strOutput = string.Empty;
                Summary objSummary = new Summary();
                DataTable dt = new DataTable();

                if (ConfigurationManager.AppSettings["IsIntent"].ToString() == "0")
                {

                    if (ConfigurationManager.AppSettings["Summary_IsPeak"].ToString() == "0")
                    {

                        string JSONToInsert = objSummary.CreateJSON(Convert.ToInt32(parameters_obj.TopicID), Convert.ToDateTime(parameters_obj.FromDate), Convert.ToDateTime(parameters_obj.ToDate));
                        dt = new MDB.DAL.DAL().Incident_YouTubeSummary_Insert(Convert.ToInt32(parameters_obj.TopicID), 0, Convert.ToDateTime(parameters_obj.FromDate), Convert.ToDateTime(parameters_obj.ToDate), JSONToInsert, "Landing", 0);

                        if (dt.Rows.Count > 0)
                        {
                            json = (JObject)JArray.FromObject(dt)[0];
                            strOutput = objSummary.FetchData_YouTube(Convert.ToString(json), "", false);
                        }

                    }
                    else
                    {
                        dt = new MDB.DAL.DAL().Summary_FetchPeakSummaries(Convert.ToInt32(parameters_obj.TopicID), 0, Convert.ToDateTime(parameters_obj.FromDate), Convert.ToDateTime(parameters_obj.ToDate), "youtube", "ID");

                        if (dt.Rows.Count > 0)
                        {
                            /*------------------------------------------------------*/
                            string strIDs = Convert.ToString(dt.Rows[0][0]);

                            dynamic strInputJson = new JObject();
                            strInputJson.IDs = strIDs;
                            strInputJson.Platform = "youtube";
                            strInputJson.TopicID = Convert.ToString(Convert.ToInt32(parameters_obj.TopicID));

                            string strPeakSummaryOutput = objSummary.FetchData_PeakSummarization(Convert.ToString(strInputJson));
                            /*------------------------------------------------------*/


                            /*------------------------------------------------------*/
                            //DateTime LastPeakDate = Convert.ToDateTime(Convert.ToString(dt.Rows[0][1]));
                            string JSONToInsert = objSummary.CreateJSON(Convert.ToInt32(parameters_obj.TopicID), Convert.ToDateTime(parameters_obj.FromDate), Convert.ToDateTime(parameters_obj.ToDate));
                            dt = new MDB.DAL.DAL().Incident_YouTubeSummary_Insert(Convert.ToInt32(parameters_obj.TopicID), 0, Convert.ToDateTime(parameters_obj.FromDate), Convert.ToDateTime(parameters_obj.ToDate), JSONToInsert, "Landing", 0);

                            if (dt.Rows.Count > 0)
                            {
                                json = (JObject)JArray.FromObject(dt)[0];
                                objSummary = new Summary();

                                strOutput = objSummary.FetchData_YouTube(Convert.ToString(json), strPeakSummaryOutput, false);
                            }
                            /*------------------------------------------------------*/

                        }
                    }
                }
                else if (ConfigurationManager.AppSettings["IsIntent"].ToString() == "1")
                {
                    dt = new MDB.DAL.DAL().Incident_YouTubeSummary_Insert(Convert.ToInt32(parameters_obj.TopicID), 0, Convert.ToDateTime(parameters_obj.FromDate), Convert.ToDateTime(parameters_obj.ToDate), "", "Landing", 0);

                    if (dt.Rows.Count > 0)
                    {
                        json = (JObject)JArray.FromObject(dt)[0];
                        Log("FetchLanding_YouTube_Summary", Convert.ToString(json));
                        strOutput = objSummary.FetchData_YouTube(Convert.ToString(json), "", true);
                    }
                }

                result = strOutput;

            }
            catch (Exception ex)
            {
                Log("FetchLanding_YouTube_Summary", ex.Message + " ->> " + ex.StackTrace + " Detail : " + new StreamReader(postData).ReadToEnd().ToString());
                dynamic json = new JObject();
                json.status = "Error";
                json.message = "Error Occured";

                var setting = new JsonSerializerSettings
                {
                    MaxDepth = int.MaxValue,
                    Formatting = Newtonsoft.Json.Formatting.None
                };
                result = JsonConvert.SerializeObject(json, setting);
            }

            return new MemoryStream(Encoding.UTF8.GetBytes(result));

        }

        #endregion

        #region ValidateRequest & Log & Email
        public bool ValidateRequest(string token)
        {
            try
            {
                if (token == ConfigurationManager.AppSettings["token"].ToString())
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            catch (Exception)
            {

                throw;
            }
        }

        private void Log(string functionName, string error)
        {
            try
            {
                if (ConfigurationManager.AppSettings["IsLogActive"].ToString() == "1")
                {
                    string LogPath = ConfigurationManager.AppSettings["LogPath"].ToString();
                    using (TextWriter myWriter = File.AppendText(LogPath))
                    {

                        TextWriter.Synchronized(myWriter).WriteLine("<--> :{0}", string.Empty);
                        TextWriter.Synchronized(myWriter).WriteLine("Function Name :{0}", functionName);
                        TextWriter.Synchronized(myWriter).WriteLine("Error :{0}", error);
                        TextWriter.Synchronized(myWriter).WriteLine("Date :{0}", DateTime.Now.ToString());
                        TextWriter.Synchronized(myWriter).WriteLine("<--> :{0}", string.Empty);
                        TextWriter.Synchronized(myWriter).Flush();
                        TextWriter.Synchronized(myWriter).Close();
                    }
                }
            }
            catch (Exception ex)
            {
            }
        }

        private bool SendMail(string ToMailID, string Body, string Subject, string FilePath, string CCMailID, string BCCMailID)
        {

            bool IsSent = false;
            try
            {
                //Get From App Config From MailID
                string FromMailID = ConfigurationManager.AppSettings["FromMailAddress"].ToString();
                //Set From Mail ID To MailAddress Properties
                MailAddress ObjFrom = new MailAddress(FromMailID, ConfigurationManager.AppSettings["FromDisplayName"].ToString());
                //Call the refrence of ddll system.net.mail.MailMessage which help to send you mail
                System.Net.Mail.MailMessage mails = new System.Net.Mail.MailMessage();
                //Define all proprties related mail configration
                //Set from mail ID here
                mails.From = ObjFrom;
                //Multiple TO Mailid which available comma sepreated the split bu (,)
                string[] SplitTOMailID = ToMailID.Split(',');
                //if array is available the using foreach loop get one by one id 
                foreach (string ToMailIDValues in SplitTOMailID)
                {
                    //Check here if id is not null or blank
                    if (!string.IsNullOrEmpty(ToMailIDValues))
                    {
                        //Here add in To MailID Properites
                        mails.To.Add(ToMailIDValues);
                    }
                }
                //Multiple CC Mailid which available comma sepreated the split bu (,)
                string[] SplitCCMailID = CCMailID.Split(',');
                foreach (string CCMailIDValues in SplitCCMailID)
                {
                    //Check here if id is not null or blank
                    if (!string.IsNullOrEmpty(CCMailIDValues))
                    {
                        //Here add in CC MailID Properites
                        mails.CC.Add(CCMailIDValues);
                    }
                }
                //Multiple BCC Mailid which available comma sepreated the split bu (,)
                string[] SplitBCCMailID = BCCMailID.Split(',');
                foreach (string CCMailIDValues in SplitBCCMailID)
                {
                    //Check here if id is not null or blank
                    if (!string.IsNullOrEmpty(CCMailIDValues))
                    {
                        //Here add in BCC MailID Properites
                        mails.Bcc.Add(CCMailIDValues);
                    }
                }
                // Set Subject
                mails.Subject = Subject.Replace('\r', ' ').Replace('\n', ' ');
                mails.Subject = HttpUtility.HtmlDecode(mails.Subject);
                //if Set html body then always set true
                mails.IsBodyHtml = true;
                //set Message Body
                mails.Body = Body;

                #region Attachment
                //attachment file is exist or not check
                if (File.Exists(FilePath))
                {
                    //if yes the attach the excel sheet
                    Attachment attach = new Attachment(FilePath);
                    //add in mail
                    mails.Attachments.Add(attach);
                }
                #endregion


                //Call SMTP as alias objSMTP
                SmtpClient objSMTP = new SmtpClient();

                //SET SMTP Host from mail Config
                objSMTP.Host = ConfigurationManager.AppSettings["MailServer"].ToString();
                //SET SMTP Port From Mail Config
                objSMTP.Port = Convert.ToInt32(ConfigurationManager.AppSettings["MailPort"]);
                //SET SMTP Userdefault credentails
                objSMTP.UseDefaultCredentials = true;


                if (ConfigurationManager.AppSettings["MailServer"].ToString() == "smtp1.projectstoday.com")
                {
                    objSMTP = new SmtpClient();
                    objSMTP.Host = ConfigurationManager.AppSettings["Host"].ToString();
                    objSMTP.Port = Convert.ToInt32(ConfigurationManager.AppSettings["Port"]);
                    objSMTP.EnableSsl = true;
                    objSMTP.DeliveryMethod = SmtpDeliveryMethod.Network;
                    var fromAddress = new MailAddress(ConfigurationManager.AppSettings["FromMailAddress"].ToString(), ConfigurationManager.AppSettings["FromDisplayName"].ToString());
                    objSMTP.Credentials = new NetworkCredential(fromAddress.Address, ConfigurationManager.AppSettings["Password"].ToString());
                }




                // and finally send mail
                objSMTP.Send(mails);
                IsSent = true;
            }
            //catch (SmtpException ex)
            //{
            //    ErrorLog("SendMail ", ex.ToString() + " ->> " + ex.Message + " ->> " + ex.StackTrace);
            //    //SendMail(ConfigurationManager.AppSettings["MailErrorID"].ToString(), ex.ToString(), "Error In SendMail Function", "", "", "");
            //}
            catch (Exception ex)
            {
                Log("SendMail ", ex.ToString() + " ->> " + ex.Message + " ->> " + ex.StackTrace);

                //throw err;
            }

            return IsSent;
        }

        #endregion

        #region FetchUser FOR AUTHENTICATION


        //[OperationContract]
        //[WebInvoke(Method = "POST", UriTemplate = "FetchUser", ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Bare)]
        //public Stream FetchUser(Stream postData)
        //{
        //    string result = string.Empty;
        //    dynamic json = new JObject();
        //    Log("In FetchUser", "1");
        //    try
        //    {

        //        if (HttpContext.Current.Request.Headers["token"] != null && !String.IsNullOrEmpty(HttpContext.Current.Request.Headers["token"]))
        //        {
        //            bool IsValid = ValidateRequest(Convert.ToString(HttpContext.Current.Request.Headers["token"]));
        //            if (IsValid == false)
        //            {
        //                result = "401 Unauthorized";
        //                return new MemoryStream(Encoding.UTF8.GetBytes(result));
        //            }
        //        }

        //        WebOperationContext.Current.OutgoingResponse.ContentType = "application/json; charset=utf-8";
        //        eParameters obj = GetParameters(postData, "FetchUser");



        //        var setting = new JsonSerializerSettings
        //        {
        //            MaxDepth = int.MaxValue
        //        };
        //        Log("In FetchUser", "2");
        //        if (obj != null)
        //        {
        //            //Log("App_Version" + obj.App_Version.ToString(), "");
        //            bool IsValid = FetchUser_AD(obj.UserName, obj.Password);
        //            Log("AD Login is" + IsValid.ToString(), "");
        //            Log("In FetchUser", "3");
        //            if (IsValid == true)
        //            {
        //                DataSet ds = new Sahadeva.API.DAL.API_V2().User_FetchDetails(obj.UserName, obj.Password, obj.AppName);
        //                Log("In FetchUser", "4");

        //                json.Status = "Yes";
        //                json.Status_Code = "200";
        //                json.message = "Success";
        //                json.clients = new JArray();

        //                Int32 UserID = 0;
        //                if (ds != null && ds.Tables.Count > 0)
        //                {
        //                    DataTable dt = ds.Tables[0];
        //                    Log("In FetchUser", "5");
        //                    for (int i = 0; i < dt.Rows.Count; i++)
        //                    {
        //                        for (int c = 0; c < 5; c++)
        //                        {

        //                            Log("In FetchUser ForLoop", "");

        //                            if (dt.Columns[c].ColumnName.ToString().Contains("UserID"))
        //                            {
        //                                UserID = Convert.ToInt32(dt.Rows[i][c].ToString());
        //                            }


        //                            json.Add(dt.Columns[c].ColumnName.ToString(), dt.Rows[i][c].ToString());
        //                        }
        //                    }

        //                    Log("In FetchUser", "6");
        //                }

        //                UpdateDeviceId(UserID, obj.DeviceId, obj.OS, obj.App_Version);

        //                if (Convert.ToInt32(UserID) > 0)
        //                {
        //                    new Sahadeva.API.DAL.API_V2().UserLog_Insert(Convert.ToInt32(UserID), "FetchUser", 0);
        //                }
        //            }
        //            else
        //            {
        //                json.RoleID = Convert.ToString("");
        //                json.Status = "Authentication Failed";
        //                json.UserID = Convert.ToString("");
        //                json.Status_Code = "401";
        //                json.clients = new JArray();
        //            }
        //        }

        //        Log("In FetchUser", "7");

        //        result = JsonConvert.SerializeObject(json, setting);

        //        Log(result, "");


        //    }
        //    catch (Exception ex)
        //    {
        //        Log("FetchUser", ex.Message + " ->> " + ex.StackTrace + " Detail : " + new StreamReader(postData).ReadToEnd().ToString());
        //        json = new JObject();
        //        json.RoleID = Convert.ToString("");
        //        json.Status = "Authentication Failed";
        //        json.UserID = Convert.ToString("");
        //        json.Status_Code = "401";

        //        var setting = new JsonSerializerSettings
        //        {
        //            MaxDepth = int.MaxValue
        //        };
        //        result = JsonConvert.SerializeObject(json, setting);
        //    }

        //    return new MemoryStream(Encoding.UTF8.GetBytes(result));

        //}

        [OperationContract]
        [WebInvoke(Method = "POST", UriTemplate = "FetchUser", ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Bare)]
        public Stream FetchUser(Stream postData)
        {
            string result = string.Empty;
            dynamic json = new JObject();
            Log("In FetchUser", "1");
            try
            {

                if (HttpContext.Current.Request.Headers["token"] != null && !String.IsNullOrEmpty(HttpContext.Current.Request.Headers["token"]))
                {
                    bool IsValid = ValidateRequest(Convert.ToString(HttpContext.Current.Request.Headers["token"]));
                    if (IsValid == false)
                    {
                        result = "401 Unauthorized";
                        return new MemoryStream(Encoding.UTF8.GetBytes(result));
                    }
                }

                string strDevice = "web";
                if (HttpContext.Current.Request.Headers["APPType"] != null && !String.IsNullOrEmpty(HttpContext.Current.Request.Headers["APPType"]))
                {
                    strDevice = Convert.ToString(HttpContext.Current.Request.Headers["APPType"]);
                }

                WebOperationContext.Current.OutgoingResponse.ContentType = "application/json; charset=utf-8";
                eParameters obj = GetParameters(postData, "FetchUser");



                var setting = new JsonSerializerSettings
                {
                    MaxDepth = int.MaxValue,
                    Formatting = Newtonsoft.Json.Formatting.None
                };
                Log("In FetchUser", "2");
                if (obj != null)
                {
                    bool IsValid = FetchUser_AD(obj.UserName, obj.Password);
                    Log("AD Login is" + IsValid.ToString(), "");
                    Log("In FetchUser", "3");
                    if (IsValid == true)
                    {
                        DataSet ds = new Sahadeva.API.DAL.API_V2().User_FetchDetails_New(obj.UserName);
                        Log("In FetchUser", "4");

                        json.Status = "Yes";
                        json.Status_Code = "200";
                        json.message = "Success";
                        json.clients = new JArray();

                        Int32 UserID = 0;
                        if (ds != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
                        {
                            DataTable dt = ds.Tables[0];
                            Log("In FetchUser", "5");
                            for (int i = 0; i < dt.Rows.Count; i++)
                            {
                                for (int c = 0; c < dt.Columns.Count; c++)
                                {

                                    Log("In FetchUser ForLoop", "");

                                    if (dt.Columns[c].ColumnName.ToString().Contains("UserID"))
                                    {
                                        UserID = Convert.ToInt32(dt.Rows[i][c].ToString());
                                    }


                                    json.Add(dt.Columns[c].ColumnName.ToString(), dt.Rows[i][c].ToString());
                                }
                            }

                            //if (obj.UserName.ToLower().Contains("mayuresh.joshi"))
                            //{
                            //    json.UI_RoleName = Convert.ToString("User");
                            //}
                            //else if (obj.UserName.ToLower().Contains("sameer.kamble"))
                            //{
                            //    json.UI_RoleName = Convert.ToString("Support");
                            //}

                            Log("In FetchUser", "6");

                            if (Convert.ToInt32(UserID) > 0)
                            {
                                new Sahadeva.API.DAL.API_V2().UserLog_Insert(Convert.ToInt32(UserID), "FetchUser", 0);
                            }

                            Log("strDevice", strDevice);

                            if (strDevice != "web")
                            {
                                Log("UserID", UserID.ToString());
                                Log("obj.DeviceId", obj.DeviceId.ToString());
                                Log("obj.OS", obj.OS.ToString());
                                Log("obj.AppName", obj.AppName.ToString());
                                UpdateDeviceId(UserID, obj.DeviceId, obj.OS, obj.AppName);
                            }

                        }
                        else
                        {
                            json.RoleID = Convert.ToString("");
                            json.Status = "Please contact Admin";
                            json.UserID = Convert.ToString("");
                            json.Status_Code = "401";
                            json.UI_RoleName = Convert.ToString("");
                            json.clients = new JArray();
                        }
                    }
                    else
                    {
                        json.RoleID = Convert.ToString("");
                        json.Status = "Authentication Failed";
                        json.UserID = Convert.ToString("");
                        json.Status_Code = "401";
                        json.UI_RoleName = Convert.ToString("");
                        json.clients = new JArray();
                    }
                }

                Log("In FetchUser", "7");

                result = JsonConvert.SerializeObject(json, setting);

                Log(result, "");
            }
            catch (Exception ex)
            {
                Log("FetchUser", ex.Message + " ->> " + ex.StackTrace + " Detail : " + new StreamReader(postData).ReadToEnd().ToString());
                json = new JObject();
                json.RoleID = Convert.ToString("");
                json.Status = "Authentication Failed";
                json.UserID = Convert.ToString("");
                json.Status_Code = "401";

                var setting = new JsonSerializerSettings
                {
                    MaxDepth = int.MaxValue,
                    Formatting = Newtonsoft.Json.Formatting.None
                };
                result = JsonConvert.SerializeObject(json, setting);
            }

            return new MemoryStream(Encoding.UTF8.GetBytes(result));

        }

        public bool FetchUser_AD(string UserName, string Password)
        {
            bool flag = true;
            //bool flag = false;
            //try
            //{

            //    // Allowed combinations
            //    if (
                      
            //            (UserName == "mayuresh.joshi" && Password == "Infinix@2027") 
            //            || (UserName == "sameer.kamble" && Password == "Infinix2026")
            //            || (UserName == "kalki_support" && Password == "Infinix@2025")
            //            || (UserName == "karan.dange" && Password == "Infinix30")
            //            || (UserName == "yash.karmancherry" && Password == "Infinix@07")
            //       )
            //    {
            //        flag = true;
            //    }
            //    else
            //    {
            //        flag = false;
            //    }

            //    //AuthServiceClient ADServiceClient = new AuthServiceClient("AdFactorsAuthEndpoint");
            //    //flag = ADServiceClient.IsAuthenticated(UserName, Password);
            //    //ADServiceClient.Close();
            //}
            //catch (Exception ex)
            //{
            //    Log("FetchUser_AD", ex.Message + " ->> " + ex.StackTrace);
            //    flag = FetchUser_AD_Python(UserName, Password);
            //}

            return flag;
        }

        public bool FetchUser_AD_Python(string UserName, string Password)
        {
            bool flag = false;
            try
            {
                if (ConfigurationManager.AppSettings["IsADPython"].ToString() == "1")
                {
                    string url = ConfigurationManager.AppSettings["ADPython_URL"].ToString();// "http://110.173.181.218:9615/auth";
                    string jsonPayload = "{\"username\":\"" + UserName + "\", \"password\":\"" + Password + "\"}";
                    Log("FetchUser_AD_Python", jsonPayload);

                    try
                    {
                        // Create the request
                        HttpWebRequest request = (HttpWebRequest)WebRequest.Create(url);
                        request.Method = "POST";
                        request.ContentType = "application/json";

                        // Add payload to request
                        byte[] byteData = Encoding.UTF8.GetBytes(jsonPayload);
                        request.ContentLength = byteData.Length;
                        using (Stream requestStream = request.GetRequestStream())
                        {
                            requestStream.Write(byteData, 0, byteData.Length);
                        }

                        // Get response
                        using (HttpWebResponse response = (HttpWebResponse)request.GetResponse())
                        {
                            using (StreamReader reader = new StreamReader(response.GetResponseStream()))
                            {
                                string responseText = reader.ReadToEnd();
                                Log("FetchUser_AD_Python responseText", responseText);
                                //Console.WriteLine("Status Code: " + (int)response.StatusCode);
                                //Console.WriteLine("Response Body: " + responseText);

                                // Basic check for "status":"success"
                                if (responseText.Contains("success"))
                                {
                                    //Console.WriteLine("✅ Login successful!");
                                    flag = true;
                                }
                                else
                                {
                                    //Console.WriteLine("❌ Login failed.");
                                    flag = false;
                                }
                            }
                        }
                    }
                    catch (WebException ex)
                    {
                        //Console.WriteLine("An error occurred: " + ex.Message);
                        Log("FetchUser_AD_Python", ex.Message + " ->> " + ex.StackTrace);
                        if (ex.Response != null)
                        {
                            using (StreamReader reader = new StreamReader(ex.Response.GetResponseStream()))
                            {
                                string errorResponse = reader.ReadToEnd();
                                //Console.WriteLine("Error Response: " + errorResponse);
                                Log("FetchUser_AD_Python", errorResponse);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Log("FetchUser_AD_Python", ex.Message + " ->> " + ex.StackTrace);
            }

            return flag;
        }

        public bool FetchUser_AD_Azure(string UserName, string Password)
        {
            bool flag = false;
            try
            {
                if (ConfigurationManager.AppSettings["IsAD_Azure"].ToString() == "1")
                {
                    string url = ConfigurationManager.AppSettings["AD_Azure_URL"].ToString();// "http://110.173.181.218:9615/auth";
                    string jsonPayload = "{\"username\":\"" + UserName + "\", \"password\":\"" + Password + "\"}";
                    Log("FetchUser_AD_Azure", jsonPayload);

                    try
                    {
                        // Create the request
                        ServicePointManager.Expect100Continue = true;
                        ServicePointManager.SecurityProtocol = (SecurityProtocolType)3072;
                        ServicePointManager.ServerCertificateValidationCallback += (sender, cert, chain, sslPolicyErrors) => true;
                        HttpWebRequest request = (HttpWebRequest)WebRequest.Create(url);
                        request.Method = "POST";
                        request.ContentType = "text/plain";


                        // Authorization Header
                        request.Headers.Add(
                            HttpRequestHeader.Authorization,
                            "Bearer " + Password
                        );

                        // Empty body
                        byte[] data = Encoding.UTF8.GetBytes("");
                        request.ContentLength = data.Length;

                        using (Stream stream = request.GetRequestStream())
                        {
                            stream.Write(data, 0, data.Length);
                        }

                        // Get response
                        using (HttpWebResponse response = (HttpWebResponse)request.GetResponse())
                        {
                            using (StreamReader reader = new StreamReader(response.GetResponseStream()))
                            {
                                string responseText = reader.ReadToEnd();
                                Log("FetchUser_AD_Azure responseText", responseText);

                                // Basic check for "status":"success"
                                if (responseText.Contains("\"message\":\"Token is valid\""))
                                {
                                    //Console.WriteLine("✅ Login successful!");
                                    flag = true;
                                }
                                else
                                {
                                    //Console.WriteLine("❌ Login failed.");
                                    flag = false;
                                }
                            }
                        }
                    }
                    catch (WebException ex)
                    {
                        //Console.WriteLine("An error occurred: " + ex.Message);
                        Log("FetchUser_AD_Azure", ex.Message + " ->> " + ex.StackTrace);
                        if (ex.Response != null)
                        {
                            using (StreamReader reader = new StreamReader(ex.Response.GetResponseStream()))
                            {
                                string errorResponse = reader.ReadToEnd();
                                //Console.WriteLine("Error Response: " + errorResponse);
                                Log("FetchUser_AD_Azure", errorResponse);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Log("FetchUser_AD_Azure", ex.Message + " ->> " + ex.StackTrace);
            }

            return flag;
        }

        [OperationContract]
        [WebInvoke(Method = "POST", UriTemplate = "FetchUser_SSO", ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Bare)]
        public Stream FetchUser_SSO(Stream postData)
        {
            string result = string.Empty;
            dynamic json = new JObject();
            Log("In FetchUser_Azure", "1");
            try
            {

                if (HttpContext.Current.Request.Headers["token"] != null && !String.IsNullOrEmpty(HttpContext.Current.Request.Headers["token"]))
                {
                    bool IsValid = ValidateRequest(Convert.ToString(HttpContext.Current.Request.Headers["token"]));
                    if (IsValid == false)
                    {
                        result = "401 Unauthorized";
                        return new MemoryStream(Encoding.UTF8.GetBytes(result));
                    }
                }

                string strDevice = "web";
                if (HttpContext.Current.Request.Headers["APPType"] != null && !String.IsNullOrEmpty(HttpContext.Current.Request.Headers["APPType"]))
                {
                    strDevice = Convert.ToString(HttpContext.Current.Request.Headers["APPType"]);
                }

                WebOperationContext.Current.OutgoingResponse.ContentType = "application/json; charset=utf-8";
                eParameters obj = GetParameters(postData, "FetchUser");



                var setting = new JsonSerializerSettings
                {
                    MaxDepth = int.MaxValue,
                    Formatting = Newtonsoft.Json.Formatting.None
                };
                Log("In FetchUser_Azure", "2");
                if (obj != null)
                {
                    bool IsValid = FetchUser_AD_Azure(obj.UserName, obj.Password);
                    Log("AD Login is" + IsValid.ToString(), "");
                    Log("In FetchUser_Azure", "3");
                    if (IsValid == true)
                    {
                        DataSet ds = new Sahadeva.API.DAL.API_V2().User_FetchDetails_New(obj.UserName);
                        Log("In FetchUser_Azure", "4");

                        json.Status = "Yes";
                        json.Status_Code = "200";
                        json.message = "Success";
                        json.clients = new JArray();

                        Int32 UserID = 0;
                        if (ds != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
                        {
                            DataTable dt = ds.Tables[0];
                            Log("In FetchUser_Azure", "5");
                            for (int i = 0; i < dt.Rows.Count; i++)
                            {
                                for (int c = 0; c < dt.Columns.Count; c++)
                                {

                                    Log("In FetchUser_Azure ForLoop", "");

                                    if (dt.Columns[c].ColumnName.ToString().Contains("UserID"))
                                    {
                                        UserID = Convert.ToInt32(dt.Rows[i][c].ToString());
                                    }


                                    json.Add(dt.Columns[c].ColumnName.ToString(), dt.Rows[i][c].ToString());
                                }
                            }

                            //if (obj.UserName.ToLower().Contains("mayuresh.joshi"))
                            //{
                            //    json.UI_RoleName = Convert.ToString("User");
                            //}
                            //else if (obj.UserName.ToLower().Contains("sameer.kamble"))
                            //{
                            //    json.UI_RoleName = Convert.ToString("Support");
                            //}

                            Log("In FetchUser_Azure", "6");

                            if (Convert.ToInt32(UserID) > 0)
                            {
                                new Sahadeva.API.DAL.API_V2().UserLog_Insert(Convert.ToInt32(UserID), "FetchUser", 0);
                            }

                            Log("strDevice", strDevice);

                            if (strDevice != "web")
                            {
                                Log("UserID", UserID.ToString());
                                Log("obj.DeviceId", obj.DeviceId.ToString());
                                Log("obj.OS", obj.OS.ToString());
                                Log("obj.AppName", obj.AppName.ToString());
                                UpdateDeviceId(UserID, obj.DeviceId, obj.OS, obj.AppName);
                            }

                        }
                        else
                        {
                            json.RoleID = Convert.ToString("");
                            json.Status = "Please contact Admin";
                            json.UserID = Convert.ToString("");
                            json.Status_Code = "401";
                            json.UI_RoleName = Convert.ToString("");
                            json.clients = new JArray();
                        }
                    }
                    else
                    {
                        json.RoleID = Convert.ToString("");
                        json.Status = "Authentication Failed";
                        json.UserID = Convert.ToString("");
                        json.Status_Code = "401";
                        json.UI_RoleName = Convert.ToString("");
                        json.clients = new JArray();
                    }
                }

                Log("In FetchUser_Azure", "7");

                result = JsonConvert.SerializeObject(json, setting);

                Log(result, "");
            }
            catch (Exception ex)
            {
                Log("FetchUser_Azure", ex.Message + " ->> " + ex.StackTrace + " Detail : " + new StreamReader(postData).ReadToEnd().ToString());
                json = new JObject();
                json.RoleID = Convert.ToString("");
                json.Status = "Authentication Failed";
                json.UserID = Convert.ToString("");
                json.Status_Code = "401";

                var setting = new JsonSerializerSettings
                {
                    MaxDepth = int.MaxValue,
                    Formatting = Newtonsoft.Json.Formatting.None
                };
                result = JsonConvert.SerializeObject(json, setting);
            }

            return new MemoryStream(Encoding.UTF8.GetBytes(result));

        }

        public bool UpdateDeviceId(Int32 UserID, string DeviceID, string OS, string AppName)
        {
            bool IsResult = false;

            try
            {
                new Sahadeva.API.DAL.API_V2().User_UpdateDeviceId(UserID, DeviceID, OS, AppName);
                IsResult = true;
            }
            catch (Exception ex)
            {
                Log("UpdateDeviceId", ex.Message + " ->> " + ex.StackTrace);
            }

            return IsResult;
        }

        [OperationContract]
        [WebInvoke(Method = "POST", UriTemplate = "FetchUser_New", ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Bare)]
        public Stream FetchUser_New(Stream postData)
        {
            string result = string.Empty;
            dynamic json = new JObject();
            Log("In FetchUser_New", "1");
            try
            {

                if (HttpContext.Current.Request.Headers["token"] != null && !String.IsNullOrEmpty(HttpContext.Current.Request.Headers["token"]))
                {
                    bool IsValid = ValidateRequest(Convert.ToString(HttpContext.Current.Request.Headers["token"]));
                    if (IsValid == false)
                    {
                        result = "401 Unauthorized";
                        return new MemoryStream(Encoding.UTF8.GetBytes(result));
                    }
                }

                string strDevice = "web";
                if (HttpContext.Current.Request.Headers["APPType"] != null && !String.IsNullOrEmpty(HttpContext.Current.Request.Headers["APPType"]))
                {
                    strDevice = Convert.ToString(HttpContext.Current.Request.Headers["APPType"]);
                }

                WebOperationContext.Current.OutgoingResponse.ContentType = "application/json; charset=utf-8";
                eParameters obj = GetParameters(postData, "FetchUser");

                if (!String.IsNullOrEmpty(obj.UserID) && Convert.ToInt32(obj.UserID) > 0)
                {
                    new Sahadeva.API.DAL.API_V2().UserLog_Insert(Convert.ToInt32(obj.UserID), "FetchUser", 0);
                }

                var setting = new JsonSerializerSettings
                {
                    MaxDepth = int.MaxValue,
                    Formatting = Newtonsoft.Json.Formatting.None
                };

                Log("In FetchUser_New", "2");
                if (obj != null)
                {
                    bool IsValid = false;
                    if (obj.login_source == "SSO" && !string.IsNullOrEmpty(obj.UserName))
                    {
                        IsValid = true;
                    }
                    else
                    {
                        IsValid = FetchUser_AD(obj.UserName, obj.Password);
                    }

                    Log("AD Login is" + IsValid.ToString(), "");
                    Log("In FetchUser_New", "3");
                    if (IsValid == true)
                    {
                        DataSet ds = new Sahadeva.API.DAL.API_V2().User_FetchDetails_New(obj.UserName);
                        Log("In FetchUser_New", "4");

                        json.Status = "Yes";
                        json.Status_Code = "200";
                        json.message = "Success";
                        json.clients = new JArray();

                        string focusUsersConfig = ConfigurationManager.AppSettings["focusUsers"];

                        List<string> focusUsers = focusUsersConfig
                            .Split(',')
                            .Select(x => x.Trim())
                            .ToList();

                        json.focus_user_list = new JArray(focusUsers);

                        Int32 UserID = 0;
                        if (ds != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
                        {
                            DataTable dt = ds.Tables[0];
                            Log("In FetchUser_New", "5");
                            for (int i = 0; i < dt.Rows.Count; i++)
                            {
                                for (int c = 0; c < dt.Columns.Count; c++)
                                {

                                    Log("In FetchUser_New ForLoop", "");

                                    if (dt.Columns[c].ColumnName.ToString().Contains("UserID"))
                                    {
                                        UserID = Convert.ToInt32(dt.Rows[i][c].ToString());
                                    }


                                    json.Add(dt.Columns[c].ColumnName.ToString(), dt.Rows[i][c].ToString());
                                }
                            }

                            //if (obj.UserName.ToLower().Contains("mayuresh.joshi"))
                            //{
                            //    json.UI_RoleName = Convert.ToString("User");
                            //}
                            //else if (obj.UserName.ToLower().Contains("sameer.kamble"))
                            //{
                            //    json.UI_RoleName = Convert.ToString("Support");
                            //}

                            Log("In FetchUser_New", "6");
                        }
                        else
                        {
                            json.RoleID = Convert.ToString("");
                            //json.Status = "Authentication Failed";
                            json.Status = ConfigurationManager.AppSettings["Accessdenied"];
                            json.UserID = Convert.ToString("");
                            json.Status_Code = "401";
                            json.UI_RoleName = Convert.ToString("");
                            json.clients = new JArray();
                        }

                        Log("strDevice", strDevice);

                        if (strDevice != "web")
                        {
                            Log("UserID", UserID.ToString());
                            Log("obj.DeviceId", obj.DeviceId.ToString());
                            Log("obj.OS", obj.OS.ToString());
                            Log("obj.AppName", obj.AppName.ToString());
                            UpdateDeviceId(UserID, obj.DeviceId, obj.OS, obj.AppName);
                        }
                        if (!String.IsNullOrEmpty(obj.OS))
                        {
                            Log("IsNullOrEmpty", obj.OS.ToString());
                            Log("obj.DeviceId", obj.DeviceId.ToString());
                            Log("obj.OS", obj.OS.ToString());
                            Log("obj.AppName", obj.AppName.ToString());
                            Log("UserID", UserID.ToString());
                            Log("obj.DeviceId", obj.DeviceId.ToString());
                            Log("obj.OS", obj.OS.ToString());
                            Log("obj.AppName", obj.AppName.ToString());
                            UpdateDeviceId(UserID, obj.DeviceId, obj.OS, obj.AppName);
                        }
                    }
                    else
                    {
                        json.RoleID = Convert.ToString("");
                        json.Status = "Authentication Failed";
                        json.UserID = Convert.ToString("");
                        json.Status_Code = "401";
                        json.UI_RoleName = Convert.ToString("");
                        json.clients = new JArray();
                    }
                }

                Log("In FetchUser_New", "7");

                result = JsonConvert.SerializeObject(json, setting);

                Log(result, "");
            }
            catch (Exception ex)
            {
                Log("FetchUser_New", ex.Message + " ->> " + ex.StackTrace + " Detail : " + new StreamReader(postData).ReadToEnd().ToString());
                json = new JObject();
                json.RoleID = Convert.ToString("");
                json.Status = "Authentication Failed";
                json.UserID = Convert.ToString("");
                json.Status_Code = "401";

                var setting = new JsonSerializerSettings
                {
                    MaxDepth = int.MaxValue,
                    Formatting = Newtonsoft.Json.Formatting.None
                };
                result = JsonConvert.SerializeObject(json, setting);
            }

            return new MemoryStream(Encoding.UTF8.GetBytes(result));

        }


        [OperationContract]
        [WebInvoke(Method = "POST", UriTemplate = "Fetch_Focus_UserList", ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Bare)]
        public Stream Fetch_Focus_UserList(Stream postData)
        {
            string result = string.Empty;

            try
            {

                if (HttpContext.Current.Request.Headers["token"] != null && !String.IsNullOrEmpty(HttpContext.Current.Request.Headers["token"]))
                {
                    bool IsValid = ValidateRequest(Convert.ToString(HttpContext.Current.Request.Headers["token"]));
                    if (IsValid == false)
                    {
                        result = "401 Unauthorized";
                        return new MemoryStream(Encoding.UTF8.GetBytes(result));
                    }
                }

                WebOperationContext.Current.OutgoingResponse.ContentType = "application/json; charset=utf-8";

                //eParameters parameters_obj = GetParameters(postData, "CreateIncident");

                var setting = new JsonSerializerSettings
                {
                    MaxDepth = int.MaxValue,
                    Formatting = Newtonsoft.Json.Formatting.None
                };

                string InputBody = new StreamReader(postData).ReadToEnd().ToString();

                Log("Fetch_Focus_UserList", InputBody);

                string focusUsersConfig = ConfigurationManager.AppSettings["focusUsers"];

                List<string> focusUsers = focusUsersConfig
                    .Split(',')
                    .Select(x => x.Trim())
                    .ToList();

                dynamic json = new JObject();
                json.status = "Successful";
                json.message = "Successful";
                json.focus_user_list = new JArray(focusUsers);


                result = JsonConvert.SerializeObject(json, setting);
            }
            catch (Exception ex)
            {
                Log("Fetch_Focus_UserList", ex.Message + " ->> " + ex.StackTrace + " Detail : " + new StreamReader(postData).ReadToEnd().ToString());
                dynamic json = new JObject();
                json.status = "Error";
                json.message = "Error Occured";

                var setting = new JsonSerializerSettings
                {
                    MaxDepth = int.MaxValue,
                    Formatting = Newtonsoft.Json.Formatting.None
                };
                result = JsonConvert.SerializeObject(json, setting);
            }

            return new MemoryStream(Encoding.UTF8.GetBytes(result));

        }

        #endregion


        [OperationContract]
        [WebInvoke(Method = "POST", UriTemplate = "FetchAlert_Parameterized", ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Bare)]
        public Stream FetchAlert_Parameterized(Stream postData)
        {
            Log("FetchAlert_Parameterized", "");
            string result = string.Empty;

            try
            {

                if (HttpContext.Current.Request.Headers["token"] != null && !String.IsNullOrEmpty(HttpContext.Current.Request.Headers["token"]))
                {
                    bool IsValid = ValidateRequest(Convert.ToString(HttpContext.Current.Request.Headers["token"]));
                    if (IsValid == false)
                    {
                        result = "401 Unauthorized";
                        return new MemoryStream(Encoding.UTF8.GetBytes(result));
                    }
                }

                HttpWebRequest request = (HttpWebRequest)WebRequest.Create("http://sentryv2aws.adfactorspr.com/SentryV1_Live/EMAILAPI/FetchAlert_Parameterized");

                //Create bytes array to send Input as parameter
                byte[] bytes = System.Text.Encoding.GetEncoding("ISO-8859-1").GetBytes(new StreamReader(postData).ReadToEnd().ToString());

                //Set request options
                request.ContentType = "application/json; charset=utf-8";
                request.ContentLength = bytes.Length;
                request.Method = "POST";
                request.Timeout = 900000;
                request.Headers["token"] = "045793b8fae14ebfbb5a32cc55d11fcd";

                //Upload bytes array to request
                using (Stream os = request.GetRequestStream())
                {
                    os.Write(bytes, 0, bytes.Length);
                }

                //Get response from Request
                using (System.Net.WebResponse resp = request.GetResponse())
                {
                    using (StreamReader sr = new StreamReader(resp.GetResponseStream()))
                    {
                        result = sr.ReadToEnd().Trim();
                    }
                }

                var setting = new JsonSerializerSettings
                {
                    MaxDepth = int.MaxValue,
                    Formatting = Newtonsoft.Json.Formatting.None
                };

                //result = JsonConvert.SerializeObject(result, setting);
                Log(result, "");
            }
            catch (Exception ex)
            {
                Log("FetchAlert_Parameterized", ex.Message + " ->> " + ex.StackTrace + " Detail : " + new StreamReader(postData).ReadToEnd().ToString());
            }

            return new MemoryStream(Encoding.UTF8.GetBytes(result));

        }

        [OperationContract]
        [WebInvoke(Method = "POST", UriTemplate = "FetchAlert", ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Bare)]
        public Stream FetchAlert(Stream postData)
        {
            string result = string.Empty;

            try
            {

                if (HttpContext.Current.Request.Headers["token"] != null && !String.IsNullOrEmpty(HttpContext.Current.Request.Headers["token"]))
                {
                    bool IsValid = ValidateRequest(Convert.ToString(HttpContext.Current.Request.Headers["token"]));
                    if (IsValid == false)
                    {
                        result = "401 Unauthorized";
                        return new MemoryStream(Encoding.UTF8.GetBytes(result));
                    }
                }

                WebOperationContext.Current.OutgoingResponse.ContentType = "application/json; charset=utf-8";

                HttpWebRequest request = (HttpWebRequest)WebRequest.Create("http://sentryv2aws.adfactorspr.com/SentryV1_Live/EMAILAPI/FetchAlert");

                //Create bytes array to send Input as parameter
                byte[] bytes = System.Text.Encoding.GetEncoding("ISO-8859-1").GetBytes(new StreamReader(postData).ReadToEnd().ToString());

                //Set request options
                request.ContentType = "application/json; charset=utf-8";
                request.ContentLength = bytes.Length;
                request.Method = "POST";
                request.Timeout = 900000;
                request.Headers["token"] = "045793b8fae14ebfbb5a32cc55d11fcd";

                //Upload bytes array to request
                using (Stream os = request.GetRequestStream())
                {
                    os.Write(bytes, 0, bytes.Length);
                }

                //Get response from Request
                using (System.Net.WebResponse resp = request.GetResponse())
                {
                    using (StreamReader sr = new StreamReader(resp.GetResponseStream()))
                    {
                        result = sr.ReadToEnd().Trim();
                    }
                }

                var setting = new JsonSerializerSettings
                {
                    MaxDepth = int.MaxValue,
                    Formatting = Newtonsoft.Json.Formatting.None
                };

                //result = JsonConvert.SerializeObject(result, setting);
                Log(result, "");
            }
            catch (Exception ex)
            {
                Log("FetchAlert", ex.Message + " ->> " + ex.StackTrace + " Detail : " + new StreamReader(postData).ReadToEnd().ToString());
            }

            return new MemoryStream(Encoding.UTF8.GetBytes(result));

        }

        [OperationContract]
        [WebInvoke(Method = "POST", UriTemplate = "FetchClientsByUserIDWithTopic", ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Bare)]
        public Stream FetchClientsByUserIDWithTopic(Stream postData)
        {
            Log("FetchClientsByUserIDWithTopic", "");
            string result = string.Empty;

            try
            {

                if (HttpContext.Current.Request.Headers["token"] != null && !String.IsNullOrEmpty(HttpContext.Current.Request.Headers["token"]))
                {
                    bool IsValid = ValidateRequest(Convert.ToString(HttpContext.Current.Request.Headers["token"]));
                    if (IsValid == false)
                    {
                        result = "401 Unauthorized";
                        return new MemoryStream(Encoding.UTF8.GetBytes(result));
                    }
                }

                //HttpWebRequest request = (HttpWebRequest)WebRequest.Create("http://sentryv2aws.adfactorspr.com/SentryV1_Live/EMAILAPI/FetchClientsByUserIDWithTopic");

                ////Create bytes array to send Input as parameter
                //byte[] bytes = System.Text.Encoding.GetEncoding("ISO-8859-1").GetBytes(new StreamReader(postData).ReadToEnd().ToString());

                ////Set request options
                //request.ContentType = "application/json; charset=utf-8";
                //request.ContentLength = bytes.Length;
                //request.Method = "POST";
                //request.Timeout = 900000;
                //request.Headers["token"] = "045793b8fae14ebfbb5a32cc55d11fcd";

                ////Upload bytes array to request
                //using (Stream os = request.GetRequestStream())
                //{
                //    os.Write(bytes, 0, bytes.Length);
                //}

                ////Get response from Request
                //using (System.Net.WebResponse resp = request.GetResponse())
                //{
                //    using (StreamReader sr = new StreamReader(resp.GetResponseStream()))
                //    {
                //        result = sr.ReadToEnd().Trim();
                //    }
                //}

                var setting = new JsonSerializerSettings
                {
                    MaxDepth = int.MaxValue,
                    Formatting = Newtonsoft.Json.Formatting.None
                };

                //result = "{\"clients\":[{\"Queries\":[],\"Topics\":[],\"EntityID\":\"0\",\"EntityName\":\"--Select--\"},{\"Queries\":[],\"Topics\":[{\"Queries\":[{\"EQID\":\"1\",\"QueryName\":\"Query1\",\"Query\":\"\\\"AdaniCements\\\"\"}],\"TopicID\":\"1\",\"TopicName\":\"Default\"}],\"EntityID\":\"1\",\"EntityName\":\"AdaniCement\"}],\"Status_Code\":\"200\",\"UserID\":\"634\",\"UserRoleID\":\"3\",\"RoleID\":\"24\",\"Role\":\"SC-User\",\"Access\":\"\",\"Device_Id\":\"\",\"OS\":\"\",\"app_version\":\"\",\"Status\":\"Yes\",\"IsNotificationActive\":\"1\"}";
                result = File.ReadAllText(ConfigurationManager.AppSettings["FetchClientsByUserIDWithTopic"]);
                //result = JsonConvert.SerializeObject(result, setting);
                Log(result, "");
            }
            catch (Exception ex)
            {
                Log("FetchClientsByUserIDWithTopic", ex.Message + " ->> " + ex.StackTrace + " Detail : " + new StreamReader(postData).ReadToEnd().ToString());
            }

            return new MemoryStream(Encoding.UTF8.GetBytes(result));

        }


        #region User Bookmark

        [OperationContract]
        [WebInvoke(Method = "POST", UriTemplate = "UserBookmark_FetchList", ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Bare)]
        public Stream UserBookmark_FetchList(Stream postData)
        {
            string result = string.Empty;

            try
            {

                if (HttpContext.Current.Request.Headers["token"] != null && !String.IsNullOrEmpty(HttpContext.Current.Request.Headers["token"]))
                {
                    bool IsValid = ValidateRequest(Convert.ToString(HttpContext.Current.Request.Headers["token"]));
                    if (IsValid == false)
                    {
                        result = "401 Unauthorized";
                        return new MemoryStream(Encoding.UTF8.GetBytes(result));
                    }
                }

                WebOperationContext.Current.OutgoingResponse.ContentType = "application/json; charset=utf-8";

                eParameters parameters_obj = GetParameters(postData, "UserBookmark_FetchList");

                if (!String.IsNullOrEmpty(parameters_obj.UserID) && Convert.ToInt32(parameters_obj.UserID) > 0)
                {
                    new Sahadeva.API.DAL.API_V2().UserLog_Insert(Convert.ToInt32(parameters_obj.UserID), "UserBookmark_FetchList", Convert.ToInt32(parameters_obj.TopicID));
                }

                var setting = new JsonSerializerSettings
                {
                    MaxDepth = int.MaxValue,
                    Formatting = Newtonsoft.Json.Formatting.None
                };


                DataTable dt = new Sahadeva.API.DAL.API_V2().UserBookmark_FetchList(Convert.ToInt32(parameters_obj.UserID), parameters_obj.Platform, Convert.ToInt32(parameters_obj.TopicID));
                dynamic json = new JObject();
                json.status = "200";
                json.message = "Success";
                json.data = new JArray();
                json.data = JArray.FromObject(dt);

                //result = File.ReadAllText(ConfigurationManager.AppSettings["FetchList_OnlineArticle"]);

                result = JsonConvert.SerializeObject(json, setting);
            }
            catch (Exception ex)
            {
                Log("UserBookmark_FetchList", ex.Message + " ->> " + ex.StackTrace + " Detail : " + new StreamReader(postData).ReadToEnd().ToString());
                dynamic json = new JObject();
                json.status = "Error";
                json.message = "Error Occured";

                var setting = new JsonSerializerSettings
                {
                    MaxDepth = int.MaxValue,
                    Formatting = Newtonsoft.Json.Formatting.None
                };
                result = JsonConvert.SerializeObject(json, setting);
            }

            return new MemoryStream(Encoding.UTF8.GetBytes(result));

        }
        #endregion

        #region Notifications

        [OperationContract]
        [WebInvoke(Method = "POST", UriTemplate = "Notifications_FetchList", ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Bare)]
        public Stream Notifications_FetchList(Stream postData)
        {
            string result = string.Empty;

            try
            {

                if (HttpContext.Current.Request.Headers["token"] != null && !String.IsNullOrEmpty(HttpContext.Current.Request.Headers["token"]))
                {
                    bool IsValid = ValidateRequest(Convert.ToString(HttpContext.Current.Request.Headers["token"]));
                    if (IsValid == false)
                    {
                        result = "401 Unauthorized";
                        return new MemoryStream(Encoding.UTF8.GetBytes(result));
                    }
                }

                WebOperationContext.Current.OutgoingResponse.ContentType = "application/json; charset=utf-8";

                eParameters parameters_obj = GetParameters(postData, "Notifications_FetchList");

                if (!String.IsNullOrEmpty(parameters_obj.UserID) && Convert.ToInt32(parameters_obj.UserID) > 0)
                {
                    new Sahadeva.API.DAL.API_V2().UserLog_Insert(Convert.ToInt32(parameters_obj.UserID), "Notifications_FetchList", Convert.ToInt32(parameters_obj.TopicID));
                }

                var setting = new JsonSerializerSettings
                {
                    MaxDepth = int.MaxValue,
                    Formatting = Newtonsoft.Json.Formatting.None
                };


                DataSet ds = new Sahadeva.API.DAL.API_V2().Notifications_FetchList(Convert.ToInt32(parameters_obj.UserID), parameters_obj.Platform, Convert.ToInt32(parameters_obj.IsRead));

                DataTable dt = new DataTable();
                DataTable dt2 = new DataTable();
                if (ds != null)
                {
                    if (ds.Tables.Count > 0)
                    {
                        dt = ds.Tables[0];
                        dt2 = ds.Tables[1];
                    }
                }

                dynamic json = new JObject();
                json.status = "200";
                json.message = "Success";
                if (dt != null)
                {
                    if (dt.Rows.Count > 0)
                    {
                        json.UserID = dt.Rows[0]["UserID"];
                        json.total = dt.Rows[0]["total"];
                        json.online_count = dt.Rows[0]["online_count"];
                        json.print_count = dt.Rows[0]["print_count"];
                        json.twitter_count = dt.Rows[0]["twitter_count"];
                        json.youtube_count = dt.Rows[0]["youtube_count"];
                    }
                }
                json.data = new JArray();
                json.data = JArray.FromObject(dt2);

                //result = File.ReadAllText(ConfigurationManager.AppSettings["FetchList_OnlineArticle"]);

                result = JsonConvert.SerializeObject(json, setting);
            }
            catch (Exception ex)
            {
                Log("Notifications_FetchList", ex.Message + " ->> " + ex.StackTrace + " Detail : " + new StreamReader(postData).ReadToEnd().ToString());
                dynamic json = new JObject();
                json.status = "Error";
                json.message = "Error Occured";

                var setting = new JsonSerializerSettings
                {
                    MaxDepth = int.MaxValue,
                    Formatting = Newtonsoft.Json.Formatting.None
                };
                result = JsonConvert.SerializeObject(json, setting);
            }

            return new MemoryStream(Encoding.UTF8.GetBytes(result));

        }

        [OperationContract]
        [WebInvoke(Method = "POST", UriTemplate = "Notifications_Update_IsRead", ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Bare)]
        public Stream Notifications_Update_IsRead(Stream postData)
        {
            string result = string.Empty;

            try
            {

                if (HttpContext.Current.Request.Headers["token"] != null && !String.IsNullOrEmpty(HttpContext.Current.Request.Headers["token"]))
                {
                    bool IsValid = ValidateRequest(Convert.ToString(HttpContext.Current.Request.Headers["token"]));
                    if (IsValid == false)
                    {
                        result = "401 Unauthorized";
                        return new MemoryStream(Encoding.UTF8.GetBytes(result));
                    }
                }

                WebOperationContext.Current.OutgoingResponse.ContentType = "application/json; charset=utf-8";

                var setting = new JsonSerializerSettings
                {
                    MaxDepth = int.MaxValue,
                    Formatting = Newtonsoft.Json.Formatting.None
                };


                Int32 Result = 0;
                dynamic stuff = JObject.Parse(new StreamReader(postData).ReadToEnd().ToString());
                Int32 UserID = Convert.ToInt32(Convert.ToString(stuff.UserID));
                //string PrimaryKey = Convert.ToString(Convert.ToString(stuff.primary_key));
                //string NotificationType = Convert.ToString(stuff.notification_type);

                //Result = new Sahadeva.API.DAL.API_V2().Notifications_Update_IsRead(UserID, PrimaryKey, NotificationType);

                //Log("strTopicID Data Is ", PrimaryKey + "-> " + JsonConvert.SerializeObject(stuff, setting));



                foreach (var item in stuff.Data)
                {
                    string PrimaryKey = Convert.ToString(item.primary_key);
                    string NotificationType = Convert.ToString(item.notification_type);

                    if (Convert.ToInt32(UserID) > 0)
                    {
                        new Sahadeva.API.DAL.API_V2().UserLog_Insert(Convert.ToInt32(UserID), "Notifications_Update_IsRead", 0);
                    }

                    Result = new Sahadeva.API.DAL.API_V2().Notifications_Update_IsRead(UserID, PrimaryKey, NotificationType);

                    System.Threading.Thread.Sleep(3000);

                    Log("strTopicID Data Is ", PrimaryKey + " -> " + JsonConvert.SerializeObject(item, setting));
                }

                result = "{\"status\": \"Successful\",\"message\": \"Updated successfully.\"}";
            }
            catch (Exception ex)
            {
                Log("Notifications_Update_IsRead", ex.Message + " ->> " + ex.StackTrace + " Detail : " + new StreamReader(postData).ReadToEnd().ToString());
                dynamic json = new JObject();
                json.status = "Error";
                json.message = "Error Occured";

                var setting = new JsonSerializerSettings
                {
                    MaxDepth = int.MaxValue,
                    Formatting = Newtonsoft.Json.Formatting.None
                };
                result = JsonConvert.SerializeObject(json, setting);
            }

            return new MemoryStream(Encoding.UTF8.GetBytes(result));

        }

        [OperationContract]
        [WebInvoke(Method = "POST", UriTemplate = "UpdateNotificationSettings_Bulk", ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Bare)]

        public Stream UpdateNotificationSettings_Bulk(Stream postData)
        {
            string result = string.Empty;

            try
            {
                if (HttpContext.Current.Request.Headers["token"] != null && !String.IsNullOrEmpty(HttpContext.Current.Request.Headers["token"]))
                {
                    bool IsValid = ValidateRequest(Convert.ToString(HttpContext.Current.Request.Headers["token"]));
                    if (IsValid == false)
                    {
                        result = "401 Unauthorized";
                        return new MemoryStream(Encoding.UTF8.GetBytes(result));
                    }
                }

                WebOperationContext.Current.OutgoingResponse.ContentType = "application/json; charset=utf-8";

                var serializerSettings = new JsonSerializerSettings
                {
                    MaxDepth = int.MaxValue,
                    Formatting = Newtonsoft.Json.Formatting.None
                };

                string jsonData = new StreamReader(postData).ReadToEnd();
                dynamic root = JObject.Parse(jsonData);

                Log("UpdateNotificationSettings Bulk Input", JsonConvert.SerializeObject(root, serializerSettings));

                DataTable dtUpdates = new DataTable();
                dtUpdates.Columns.AddRange(new DataColumn[]
            {
                new DataColumn("TopicID", typeof(int)),
                new DataColumn("UserID", typeof(int)),
                new DataColumn("IsActive", typeof(int)),
                new DataColumn("PlatformID", typeof(int)),
                new DataColumn("Platform_IsActive", typeof(int)),
                new DataColumn("Platform_AsItHappens", typeof(int)),
                new DataColumn("Platform_Summarised", typeof(int)),
                new DataColumn("Platform_SummarisedInterval", typeof(int)),
                new DataColumn("Platform_Conditional", typeof(int))
            });

                var platformMap = new Dictionary<string, int>
            {
                { "online_article", 1 },
                { "print_article", 2 },
                { "twitter", 3 },
                { "youtube", 4 }
            };

                // 4. Process Data
                foreach (var item in root.data)
                {

                    JObject jItem = (JObject)item;

                    JToken incidentIdToken = jItem["incident_id"];
                    int topicID = (incidentIdToken != null && incidentIdToken.Type != JTokenType.Null) ? incidentIdToken.Value<int>() : 0;

                    JToken userIdToken = jItem["user_id"];
                    int userID = (userIdToken != null && userIdToken.Type != JTokenType.Null) ? userIdToken.Value<int>() : 0;

                    JToken isActiveToken = jItem["is_active"];
                    int isActive = (isActiveToken != null && isActiveToken.Type != JTokenType.Null) ? isActiveToken.Value<int>() : 0;

                    if (userID > 0)
                    {
                        new Sahadeva.API.DAL.API_V2().UserLog_Insert(userID, "UpdateNotificationSettings", topicID);
                    }

                    foreach (var kvp in platformMap)
                    {
                        string platformKey = kvp.Key;
                        int platformID = kvp.Value;

                        if (jItem[platformKey] != null && jItem[platformKey].Type != JTokenType.Null)
                        {
                            JToken p = jItem[platformKey]; // Use jItem for stable JToken access


                            dtUpdates.Rows.Add(
                                topicID,
                                userID,
                                isActive,
                                platformID,
                                (p["is_active"] != null && p["is_active"].Type != JTokenType.Null) ? p["is_active"].Value<int>() : 0,
                                (p["as_it_happens"] != null && p["as_it_happens"].Type != JTokenType.Null) ? p["as_it_happens"].Value<int>() : 0,
                                (p["summarised"] != null && p["summarised"].Type != JTokenType.Null) ? p["summarised"].Value<int>() : 0,
                                (p["summarised_interval"] != null && p["summarised_interval"].Type != JTokenType.Null) ? p["summarised_interval"].Value<int>() : 0,
                                (p["conditional"] != null && p["conditional"].Type != JTokenType.Null) ? p["conditional"].Value<int>() : 0
                            );
                        }
                    }
                }

                int resultCode = new Sahadeva.API.DAL.API_V2().Incident_UpdateNotificationSettings_Bulk(dtUpdates);

                result = "{\"status\": \"Successful\", \"message\": \"Notification settings updated successfully.\"}";
            }
            catch (Exception ex)
            {
                Log("UpdateNotificationSettings", ex.ToString());

                dynamic json = new JObject();
                json.status = "Error";
                json.message = "Error occurred while updating notification settings.";

                var serializerSettings = new JsonSerializerSettings
                {
                    MaxDepth = int.MaxValue,
                    Formatting = Newtonsoft.Json.Formatting.None
                };

                result = JsonConvert.SerializeObject(json, serializerSettings);
            }

            return new MemoryStream(Encoding.UTF8.GetBytes(result));
        }

        [OperationContract]
        [WebInvoke(Method = "POST", UriTemplate = "FetchNotificationSettings_By_IncidentID", ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Bare)]
        public Stream FetchNotificationSettings_By_IncidentID(Stream postData)
        {
            string result = string.Empty;

            try
            {

                if (HttpContext.Current.Request.Headers["token"] != null && !String.IsNullOrEmpty(HttpContext.Current.Request.Headers["token"]))
                {
                    bool IsValid = ValidateRequest(Convert.ToString(HttpContext.Current.Request.Headers["token"]));
                    if (IsValid == false)
                    {
                        result = "401 Unauthorized";
                        return new MemoryStream(Encoding.UTF8.GetBytes(result));
                    }
                }

                WebOperationContext.Current.OutgoingResponse.ContentType = "application/json; charset=utf-8";

                eParameters parameters_obj = GetParameters(postData, "FetchNotificationSettings_By_IncidentID");

                if (!String.IsNullOrEmpty(parameters_obj.TopicID) && Convert.ToInt32(parameters_obj.TopicID) > 0)
                {
                    new Sahadeva.API.DAL.API_V2().UserLog_Insert(Convert.ToInt32(parameters_obj.TopicID), "FetchNotificationSettings_By_IncidentID", Convert.ToInt32(parameters_obj.TopicID));
                }

                var setting = new JsonSerializerSettings
                {
                    MaxDepth = int.MaxValue,
                    Formatting = Newtonsoft.Json.Formatting.None
                };

                Log("parameters_obj.TopicID", parameters_obj.TopicID.ToString());

                DataSet ds = new Sahadeva.API.DAL.API_V2().Incident_FetchNotificationSettings_BY_IncidentID(Convert.ToInt32(parameters_obj.TopicID));
                dynamic json = new JObject();
                if (ds != null && ds.Tables.Count > 0)
                {
                    json.status = "200";
                    json.message = "Success";
                    json.data = new JObject();

                    Log("Tables Count", ds.Tables.Count.ToString());

                    dynamic o = new JObject();

                    // Convert each table to JArray safely
                    if (ds.Tables.Count > 0)
                    {
                        var onlineArr = JArray.FromObject(ds.Tables[0]);
                        o.online_article = onlineArr;
                        Log("online_article", "1");
                    }

                    if (ds.Tables.Count > 1)
                    {
                        var printArr = JArray.FromObject(ds.Tables[1]);
                        o.print_article = printArr;
                        Log("print_article", "2");
                    }

                    if (ds.Tables.Count > 2)
                    {
                        var twitterArr = JArray.FromObject(ds.Tables[2]);
                        o.twitter = twitterArr;
                        Log("twitter", "3");
                    }

                    if (ds.Tables.Count > 3)
                    {
                        var youtubeArr = JArray.FromObject(ds.Tables[3]);
                        o.youtube = youtubeArr;
                        Log("youtube", "4");
                    }

                    json.data = o;
                }


                result = JsonConvert.SerializeObject(json, setting);
            }
            catch (Exception ex)
            {
                Log("FetchNotificationSettings_By_IncidentID", ex.Message + " ->> " + ex.StackTrace + " Detail : " + new StreamReader(postData).ReadToEnd().ToString());
                dynamic json = new JObject();
                json.status = "Error";
                json.message = "Error Occured";

                var setting = new JsonSerializerSettings
                {
                    MaxDepth = int.MaxValue,
                    Formatting = Newtonsoft.Json.Formatting.None
                };
                result = JsonConvert.SerializeObject(json, setting);
            }

            return new MemoryStream(Encoding.UTF8.GetBytes(result));

        }

        #endregion

        #region Notifications_New

        [OperationContract]
        [WebInvoke(Method = "POST", UriTemplate = "Notifications_FetchList_New", ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Bare)]
        public Stream Notifications_FetchList_New(Stream postData)
        {
            string result = string.Empty;

            try
            {

                if (HttpContext.Current.Request.Headers["token"] != null && !String.IsNullOrEmpty(HttpContext.Current.Request.Headers["token"]))
                {
                    bool IsValid = ValidateRequest(Convert.ToString(HttpContext.Current.Request.Headers["token"]));
                    if (IsValid == false)
                    {
                        result = "401 Unauthorized";
                        return new MemoryStream(Encoding.UTF8.GetBytes(result));
                    }
                }

                WebOperationContext.Current.OutgoingResponse.ContentType = "application/json; charset=utf-8";

                eParameters parameters_obj = GetParameters(postData, "Notifications_FetchList_New");

                if (!String.IsNullOrEmpty(parameters_obj.UserID) && Convert.ToInt32(parameters_obj.UserID) > 0)
                {
                    new Sahadeva.API.DAL.API_V2().UserLog_Insert(Convert.ToInt32(parameters_obj.UserID), "Notifications_FetchList_New", Convert.ToInt32(parameters_obj.TopicID));
                }

                var setting = new JsonSerializerSettings
                {
                    MaxDepth = int.MaxValue,
                    Formatting = Newtonsoft.Json.Formatting.None
                };


                DataSet ds = new Sahadeva.API.DAL.API_V2().Notifications_FetchList_New(Convert.ToInt32(parameters_obj.UserID), parameters_obj.Platform, Convert.ToInt32(parameters_obj.IsRead));

                DataTable dt = new DataTable();
                DataTable dt2 = new DataTable();
                if (ds != null)
                {
                    if (ds.Tables.Count > 0)
                    {
                        dt = ds.Tables[0];
                        dt2 = ds.Tables[1];
                    }
                }

                dynamic json = new JObject();
                json.status = "200";
                json.message = "Success";
                if (dt != null)
                {
                    if (dt.Rows.Count > 0)
                    {
                        json.UserID = dt.Rows[0]["UserID"];
                        json.total = dt.Rows[0]["total"];
                        json.online_count = dt.Rows[0]["online_count"];
                        json.print_count = dt.Rows[0]["print_count"];
                        json.twitter_count = dt.Rows[0]["twitter_count"];
                        json.youtube_count = dt.Rows[0]["youtube_count"];
                    }
                }
                json.data = new JArray();
                json.data = JArray.FromObject(dt2);

                //result = File.ReadAllText(ConfigurationManager.AppSettings["FetchList_OnlineArticle"]);

                result = JsonConvert.SerializeObject(json, setting);
            }
            catch (Exception ex)
            {
                Log("Notifications_FetchList_New", ex.Message + " ->> " + ex.StackTrace + " Detail : " + new StreamReader(postData).ReadToEnd().ToString());
                dynamic json = new JObject();
                json.status = "Error";
                json.message = "Error Occured";

                var setting = new JsonSerializerSettings
                {
                    MaxDepth = int.MaxValue,
                    Formatting = Newtonsoft.Json.Formatting.None
                };
                result = JsonConvert.SerializeObject(json, setting);
            }

            return new MemoryStream(Encoding.UTF8.GetBytes(result));

        }

        //[OperationContract]
        //[WebInvoke(Method = "POST", UriTemplate = "UpdateNotificationSettings_Bulk", ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Bare)]
        //public Stream UpdateNotificationSettings_Bulk(Stream postData)
        //{
        //    string result = string.Empty;

        //    try
        //    {
        //        if (HttpContext.Current.Request.Headers["token"] != null && !String.IsNullOrEmpty(HttpContext.Current.Request.Headers["token"]))
        //        {
        //            bool IsValid = ValidateRequest(Convert.ToString(HttpContext.Current.Request.Headers["token"]));
        //            if (IsValid == false)
        //            {
        //                result = "401 Unauthorized";
        //                return new MemoryStream(Encoding.UTF8.GetBytes(result));
        //            }
        //        }

        //        WebOperationContext.Current.OutgoingResponse.ContentType = "application/json; charset=utf-8";

        //        var serializerSettings = new JsonSerializerSettings
        //        {
        //            MaxDepth = int.MaxValue,
        //            Formatting = Newtonsoft.Json.Formatting.None
        //        };

        //        string jsonData = new StreamReader(postData).ReadToEnd();
        //        dynamic root = JObject.Parse(jsonData);

        //        Log("UpdateNotificationSettings Bulk Input", JsonConvert.SerializeObject(root, serializerSettings));

        //        DataTable dtUpdates = new DataTable();
        //        dtUpdates.Columns.AddRange(new DataColumn[]
        //    {
        //        new DataColumn("TopicID", typeof(int)),
        //        new DataColumn("UserID", typeof(int)),
        //        new DataColumn("IsActive", typeof(int)),
        //        new DataColumn("PlatformID", typeof(int)),
        //        new DataColumn("Platform_IsActive", typeof(int)),
        //        new DataColumn("Platform_AsItHappens", typeof(int)),
        //        new DataColumn("Platform_Summarised", typeof(int)),
        //        new DataColumn("Platform_SummarisedInterval", typeof(int)),
        //        new DataColumn("Platform_Conditional", typeof(int))
        //    });

        //        var platformMap = new Dictionary<string, int>
        //    {
        //        { "online_article", 1 },
        //        { "print_article", 2 },
        //        { "twitter", 3 },
        //        { "youtube", 4 }
        //    };

        //        // 4. Process Data
        //        foreach (var item in root.data)
        //        {

        //            JObject jItem = (JObject)item;

        //            JToken incidentIdToken = jItem["incident_id"];
        //            int topicID = (incidentIdToken != null && incidentIdToken.Type != JTokenType.Null) ? incidentIdToken.Value<int>() : 0;

        //            JToken userIdToken = jItem["user_id"];
        //            int userID = (userIdToken != null && userIdToken.Type != JTokenType.Null) ? userIdToken.Value<int>() : 0;

        //            JToken isActiveToken = jItem["is_active"];
        //            int isActive = (isActiveToken != null && isActiveToken.Type != JTokenType.Null) ? isActiveToken.Value<int>() : 0;

        //            if (userID > 0)
        //            {
        //                new Sahadeva.API.DAL.API_V2().UserLog_Insert(userID, "UpdateNotificationSettings", topicID);
        //            }

        //            foreach (var kvp in platformMap)
        //            {
        //                string platformKey = kvp.Key;
        //                int platformID = kvp.Value;

        //                if (jItem[platformKey] != null && jItem[platformKey].Type != JTokenType.Null)
        //                {
        //                    JToken p = jItem[platformKey]; // Use jItem for stable JToken access


        //                    dtUpdates.Rows.Add(
        //                        topicID,
        //                        userID,
        //                        isActive,
        //                        platformID,
        //                        (p["is_active"] != null && p["is_active"].Type != JTokenType.Null) ? p["is_active"].Value<int>() : 0,
        //                        (p["as_it_happens"] != null && p["as_it_happens"].Type != JTokenType.Null) ? p["as_it_happens"].Value<int>() : 0,
        //                        (p["summarised"] != null && p["summarised"].Type != JTokenType.Null) ? p["summarised"].Value<int>() : 0,
        //                        (p["summarised_interval"] != null && p["summarised_interval"].Type != JTokenType.Null) ? p["summarised_interval"].Value<int>() : 0,
        //                        (p["conditional"] != null && p["conditional"].Type != JTokenType.Null) ? p["conditional"].Value<int>() : 0
        //                    );
        //                }
        //            }
        //        }

        //        int resultCode = new Sahadeva.API.DAL.API_V2().Incident_UpdateNotificationSettings_Bulk(dtUpdates);

        //        result = "{\"status\": \"Successful\", \"message\": \"Notification settings updated successfully.\"}";
        //    }
        //    catch (Exception ex)
        //    {
        //        Log("UpdateNotificationSettings", ex.ToString());

        //        dynamic json = new JObject();
        //        json.status = "Error";
        //        json.message = "Error occurred while updating notification settings.";

        //        var serializerSettings = new JsonSerializerSettings
        //        {
        //            MaxDepth = int.MaxValue,
        //            Formatting = Newtonsoft.Json.Formatting.None
        //        };

        //        result = JsonConvert.SerializeObject(json, serializerSettings);
        //    }

        //    return new MemoryStream(Encoding.UTF8.GetBytes(result));
        //}

        //[OperationContract]
        //[WebInvoke(Method = "POST", UriTemplate = "FetchNotificationSettings_By_IncidentID", ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Bare)]
        //public Stream FetchNotificationSettings_By_IncidentID(Stream postData)
        //{
        //    string result = string.Empty;

        //    try
        //    {

        //        if (HttpContext.Current.Request.Headers["token"] != null && !String.IsNullOrEmpty(HttpContext.Current.Request.Headers["token"]))
        //        {
        //            bool IsValid = ValidateRequest(Convert.ToString(HttpContext.Current.Request.Headers["token"]));
        //            if (IsValid == false)
        //            {
        //                result = "401 Unauthorized";
        //                return new MemoryStream(Encoding.UTF8.GetBytes(result));
        //            }
        //        }

        //        WebOperationContext.Current.OutgoingResponse.ContentType = "application/json; charset=utf-8";

        //        eParameters parameters_obj = GetParameters(postData, "FetchNotificationSettings_By_IncidentID");

        //        if (!String.IsNullOrEmpty(parameters_obj.TopicID) && Convert.ToInt32(parameters_obj.TopicID) > 0)
        //        {
        //            new Sahadeva.API.DAL.API_V2().UserLog_Insert(Convert.ToInt32(parameters_obj.TopicID), "FetchNotificationSettings_By_IncidentID", Convert.ToInt32(parameters_obj.TopicID));
        //        }

        //        var setting = new JsonSerializerSettings
        //        {
        //            MaxDepth = int.MaxValue,
        //            Formatting = Newtonsoft.Json.Formatting.None
        //        };

        //        Log("parameters_obj.TopicID", parameters_obj.TopicID.ToString());

        //        DataSet ds = new Sahadeva.API.DAL.API_V2().Incident_FetchNotificationSettings_BY_IncidentID(Convert.ToInt32(parameters_obj.TopicID));
        //        dynamic json = new JObject();
        //        if (ds != null && ds.Tables.Count > 0)
        //        {
        //            json.status = "200";
        //            json.message = "Success";
        //            json.data = new JObject();

        //            Log("Tables Count", ds.Tables.Count.ToString());

        //            dynamic o = new JObject();

        //            // Convert each table to JArray safely
        //            if (ds.Tables.Count > 0)
        //            {
        //                var onlineArr = JArray.FromObject(ds.Tables[0]);
        //                o.online_article = onlineArr;
        //                Log("online_article", "1");
        //            }

        //            if (ds.Tables.Count > 1)
        //            {
        //                var printArr = JArray.FromObject(ds.Tables[1]);
        //                o.print_article = printArr;
        //                Log("print_article", "2");
        //            }

        //            if (ds.Tables.Count > 2)
        //            {
        //                var twitterArr = JArray.FromObject(ds.Tables[2]);
        //                o.twitter = twitterArr;
        //                Log("twitter", "3");
        //            }

        //            if (ds.Tables.Count > 3)
        //            {
        //                var youtubeArr = JArray.FromObject(ds.Tables[3]);
        //                o.youtube = youtubeArr;
        //                Log("youtube", "4");
        //            }

        //            json.data = o;
        //        }


        //        result = JsonConvert.SerializeObject(json, setting);
        //    }
        //    catch (Exception ex)
        //    {
        //        Log("FetchNotificationSettings_By_IncidentID", ex.Message + " ->> " + ex.StackTrace + " Detail : " + new StreamReader(postData).ReadToEnd().ToString());
        //        dynamic json = new JObject();
        //        json.status = "Error";
        //        json.message = "Error Occured";

        //        var setting = new JsonSerializerSettings
        //        {
        //            MaxDepth = int.MaxValue,
        //            Formatting = Newtonsoft.Json.Formatting.None
        //        };
        //        result = JsonConvert.SerializeObject(json, setting);
        //    }

        //    return new MemoryStream(Encoding.UTF8.GetBytes(result));

        //}

        [OperationContract]
        [WebInvoke(Method = "POST", UriTemplate = "UpdateNotificationSettings_Bulk_New", ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Bare)]
        public Stream UpdateNotificationSettings_Bulk_New(Stream postData)
        {
            string result = string.Empty;

            try
            {
                if (HttpContext.Current.Request.Headers["token"] != null &&
                    !String.IsNullOrEmpty(HttpContext.Current.Request.Headers["token"]))
                {
                    bool IsValid = ValidateRequest(Convert.ToString(HttpContext.Current.Request.Headers["token"]));
                    if (IsValid == false)
                    {
                        result = "401 Unauthorized";
                        return new MemoryStream(Encoding.UTF8.GetBytes(result));
                    }
                }

                WebOperationContext.Current.OutgoingResponse.ContentType = "application/json; charset=utf-8";

                var serializerSettings = new JsonSerializerSettings
                {
                    MaxDepth = int.MaxValue,
                    Formatting = Newtonsoft.Json.Formatting.None
                };

                string jsonData = new StreamReader(postData).ReadToEnd();
                dynamic root = JObject.Parse(jsonData);

                Log("UpdateNotificationSettings Bulk Input", JsonConvert.SerializeObject(root, serializerSettings));

                DataTable dtUpdates = new DataTable();
                dtUpdates.Columns.AddRange(new DataColumn[]
                {
                    new DataColumn("TopicID", typeof(int)),
                    new DataColumn("UserID", typeof(int)),
                    new DataColumn("IsActive", typeof(int)),
                    new DataColumn("PlatformID", typeof(int)),
                    new DataColumn("Platform_IsActive", typeof(int)),
                    new DataColumn("Platform_AsItHappens", typeof(int)),
                    new DataColumn("Platform_Summarised", typeof(int)),
                    new DataColumn("Platform_SummarisedInterval", typeof(int)),
                    new DataColumn("Platform_Conditional", typeof(int))
                });

                var platformMap = new Dictionary<string, int>
                {
                    { "online_article", 1 },
                    { "print_article", 2 },
                    { "twitter", 3 },
                    { "youtube", 4 }
                };
                foreach (JObject jItem in root["data"].Children<JObject>())
                {
                    int topicID = Convert.ToInt32(Convert.ToString(jItem["incident_id"]));
                    int userID = Convert.ToInt32(Convert.ToString(jItem["user_id"]));
                    int isActive = Convert.ToInt32(Convert.ToString(jItem["is_active"]));

                    if (userID > 0)
                        new Sahadeva.API.DAL.API_V2().UserLog_Insert(userID, "UpdateNotificationSettings_New", topicID);

                    foreach (var kvp in platformMap)
                    {
                        string platformKey = kvp.Key;
                        int platformID = kvp.Value;

                        if (jItem[platformKey] != null && jItem[platformKey].Type != JTokenType.Null)
                        {
                            JToken p = jItem[platformKey];

                            int Platform_Conditional =
                                (p["conditional"] != null && p["conditional"].Type != JTokenType.Null)
                                ? p["conditional"].Value<int>() : 0;

                            dtUpdates.Rows.Add(
                                topicID,
                                userID,
                                isActive,
                                platformID,
                                (p["platform_is_active"] != null && p["platform_is_active"].Type != JTokenType.Null) ? p["platform_is_active"].Value<int>() : 0,
                                (p["as_it_happens"] != null && p["as_it_happens"].Type != JTokenType.Null) ? p["as_it_happens"].Value<int>() : 0,
                                (p["summarised"] != null && p["summarised"].Type != JTokenType.Null) ? p["summarised"].Value<int>() : 0,
                                (p["summarised_interval"] != null && p["summarised_interval"].Type != JTokenType.Null) ? p["summarised_interval"].Value<int>() : 0,
                                (p["conditional"] != null && p["conditional"].Type != JTokenType.Null) ? p["conditional"].Value<int>() : 0
                            );

                            if (Platform_Conditional == 1 && p["conditional_settings"] != null && p["conditional_settings"].Type == JTokenType.Array)
                            {
                                foreach (var condition in p["conditional_settings"])
                                {
                                    int conditionId = Convert.ToInt32(Convert.ToString(condition["condition_id"]));
                                    int isDeleted = Convert.ToInt32(Convert.ToString(condition["is_deleted"]));
                                    int is_active = Convert.ToInt32(Convert.ToString(condition["is_active"]));
                                    string criteriaJson = Convert.ToString(condition["criteria"]);
                                    string conditionName = Convert.ToString(condition["condition_name"]);

                                    Log("Criteria JSON: ", criteriaJson);

                                    new Sahadeva.API.DAL.API_V2().Incident_ConditionalDetail_Insert(
                                        topicID,
                                        userID,
                                        platformID,
                                        conditionId,
                                        isDeleted,
                                        criteriaJson,
                                        conditionName,
                                        is_active
                                    );
                                }
                            }
                        }
                    }
                }

                int resultCode = new Sahadeva.API.DAL.API_V2().Incident_UpdateNotificationSettings_Bulk_New(dtUpdates);

                result = "{\"status\": \"Successful\", \"message\": \"Notification settings updated successfully.\"}";
            }
            catch (Exception ex)
            {
                Log("UpdateNotificationSettings_New", ex.ToString());

                dynamic json = new JObject();
                json.status = "Error";
                json.message = "Error occurred while updating notification settings.";

                result = JsonConvert.SerializeObject(json, new JsonSerializerSettings
                {
                    MaxDepth = int.MaxValue,
                    Formatting = Newtonsoft.Json.Formatting.None
                });
            }

            return new MemoryStream(Encoding.UTF8.GetBytes(result));
        }


        [OperationContract]
        [WebInvoke(Method = "POST", UriTemplate = "FetchNotificationSettings_By_IncidentID_New", ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Bare)]
        public Stream FetchNotificationSettings_By_IncidentID_New(Stream postData)
        {
            string result = string.Empty;

            try
            {
                if (HttpContext.Current.Request.Headers["token"] != null &&
                    !String.IsNullOrEmpty(HttpContext.Current.Request.Headers["token"]))
                {
                    bool IsValid = ValidateRequest(Convert.ToString(HttpContext.Current.Request.Headers["token"]));
                    if (!IsValid)
                    {
                        result = "401 Unauthorized";
                        return new MemoryStream(Encoding.UTF8.GetBytes(result));
                    }
                }

                WebOperationContext.Current.OutgoingResponse.ContentType = "application/json; charset=utf-8";

                eParameters p = GetParameters(postData, "FetchNotificationSettings_By_IncidentID_New");

                DataSet ds = new Sahadeva.API.DAL.API_V2().Incident_FetchNotificationSettings_BY_IncidentID_New(Convert.ToInt32(p.TopicID));

                JObject response = new JObject();
                response["status"] = "200";
                response["message"] = "Success";
                JArray dataArr = new JArray();

                if (ds != null && ds.Tables.Count >= 5)
                {
                    DataTable dtOnline = ds.Tables[0];
                    DataTable dtPrint = ds.Tables[1];
                    DataTable dtTwitter = ds.Tables[2];
                    DataTable dtYoutube = ds.Tables[3];
                    DataTable dtCond = ds.Tables[4];

                    var users = dtOnline.AsEnumerable().Select(r => new
                    {
                        UserID = r["user_id"].ToString(),
                        IncidentID = r["incident_id"].ToString(),
                        user_name = r["user_name"].ToString(),
                        email_id = r["email_id"].ToString(),
                        is_active = r["is_active"].ToString()
                    }).Distinct().ToList();

                    foreach (var usr in users)
                    {
                        JObject userObj = new JObject();
                        userObj["user_id"] = usr.UserID;
                        userObj["incident_id"] = usr.IncidentID;
                        userObj["user_name"] = usr.user_name;
                        userObj["email_id"] = usr.email_id;
                        userObj["is_active"] = usr.is_active;
                        //userObj["is_active"] = 0;

                        userObj["online_article"] = BuildPlatform(1, dtOnline, dtCond, usr.UserID, usr.IncidentID);
                        userObj["print_article"] = BuildPlatform(2, dtPrint, dtCond, usr.UserID, usr.IncidentID);
                        userObj["twitter"] = BuildPlatform(3, dtTwitter, dtCond, usr.UserID, usr.IncidentID);
                        userObj["youtube"] = BuildPlatform(4, dtYoutube, dtCond, usr.UserID, usr.IncidentID);

                        dataArr.Add(userObj);
                    }
                }

                response["data"] = dataArr;

                result = response.ToString();
            }
            catch (Exception ex)
            {
                JObject errorJson = new JObject();
                errorJson["status"] = "Error";
                errorJson["message"] = ex.Message;
                result = errorJson.ToString();
            }

            return new MemoryStream(Encoding.UTF8.GetBytes(result));
        }

        private JObject BuildPlatform(int platformId, DataTable dtPlatform, DataTable dtCond, string userId, string incidentId)
        {
            JObject obj = new JObject();

            var row = dtPlatform.AsEnumerable()
                .FirstOrDefault(r => r["user_id"].ToString() == userId);

            if (row == null)
            {
                obj["platform_is_active"] = 0;
                obj["as_it_happens"] = 0;
                obj["summarised"] = 0;
                obj["summarised_interval"] = "0";
                obj["conditional"] = 0;
                obj["conditional_settings"] = new JArray();
                return obj;
            }

            obj["platform_is_active"] = Convert.ToInt32(row["platform_is_active"]);
            obj["is_listening_active"] = Convert.ToInt32(row["is_listening_active"]);
            obj["as_it_happens"] = Convert.ToInt32(row["as_it_happens"]);
            obj["summarised"] = Convert.ToInt32(row["summarised"]);
            obj["summarised_interval"] = row["summarised_interval"].ToString();
            obj["conditional"] = Convert.ToInt32(row["conditional"]);

            JArray condList = new JArray();

            var condRows = dtCond.AsEnumerable()
                .Where(r => r["user_id"].ToString() == userId &&
                            r["platform_id"].ToString() == platformId.ToString());

            foreach (var c in condRows)
            {
                JObject condObj = new JObject();
                condObj["condition_name"] = Convert.ToString(c["condition_name"]);
                condObj["condition_id"] = Convert.ToInt32(c["condition_id"]);
                condObj["is_active"] = Convert.ToInt32(c["is_active"]);
                condObj["is_deleted"] = Convert.ToInt32(c["is_deleted"]);
                condObj["criteria"] = JArray.Parse(c["criteria_json"].ToString());
                condList.Add(condObj);
            }

            obj["conditional_settings"] = condList;
            return obj;
        }

        #endregion

        #region Relevant

        [OperationContract]
        [WebInvoke(Method = "POST", UriTemplate = "MarkAsIrrelevant", ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Bare)]
        public Stream MarkAsIrrelevant(Stream postData)
        {
            string result = string.Empty;

            try
            {

                if (HttpContext.Current.Request.Headers["token"] != null && !String.IsNullOrEmpty(HttpContext.Current.Request.Headers["token"]))
                {
                    bool IsValid = ValidateRequest(Convert.ToString(HttpContext.Current.Request.Headers["token"]));
                    if (IsValid == false)
                    {
                        result = "401 Unauthorized";
                        return new MemoryStream(Encoding.UTF8.GetBytes(result));
                    }
                }

                WebOperationContext.Current.OutgoingResponse.ContentType = "application/json; charset=utf-8";

                //eParameters parameters_obj = GetParameters(postData, "CreateIncident");

                var setting = new JsonSerializerSettings
                {
                    MaxDepth = int.MaxValue,
                    Formatting = Newtonsoft.Json.Formatting.None
                };

                string InputBody = new StreamReader(postData).ReadToEnd().ToString();

                Int32 RecordID_Output = 0;
                dynamic stuff = JObject.Parse(InputBody);

                Log("MarkAsIrrelevant", InputBody);
                //eParameters parameters_obj = GetParameters(null, "UserBookmark", InputBody);


                Int32 UserID = Convert.ToInt32(Convert.ToString(stuff.UserID));
                string platform = Convert.ToString(Convert.ToString(stuff.platform));
                Int32 RecordID = Convert.ToInt32(Convert.ToString(stuff.record_id));
                string Reason = Convert.ToString(stuff.reason);
                Int32 PlatformID = 0;

                if (Convert.ToInt32(UserID) > 0)
                {
                    new Sahadeva.API.DAL.API_V2().UserLog_Insert(Convert.ToInt32(UserID), "MarkAsIrrelevant", Convert.ToInt32(RecordID));
                }

                if (platform == "online") { PlatformID = 1; }
                if (platform == "print") { PlatformID = 2; }
                if (platform == "twitter") { PlatformID = 3; }


                RecordID_Output = new Sahadeva.API.DAL.API_V2().UserRequest_Irrelavant(UserID, PlatformID, RecordID, Reason);

                dynamic json = new JObject();
                json.status = "Successful";
                json.message = "Request has been sent.";


                result = JsonConvert.SerializeObject(json, setting);
            }
            catch (Exception ex)
            {
                Log("MarkAsIrrelevant", ex.Message + " ->> " + ex.StackTrace + " Detail : " + new StreamReader(postData).ReadToEnd().ToString());
                dynamic json = new JObject();
                json.status = "Error";
                json.message = "Error Occured";

                var setting = new JsonSerializerSettings
                {
                    MaxDepth = int.MaxValue,
                    Formatting = Newtonsoft.Json.Formatting.None
                };
                result = JsonConvert.SerializeObject(json, setting);
            }

            return new MemoryStream(Encoding.UTF8.GetBytes(result));

        }

        #endregion

        #region FeedMonitor

        [OperationContract]
        [WebInvoke(Method = "POST", UriTemplate = "FeedMonitor_Funnel", ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Bare)]
        public Stream FeedMonitor_Funnel(Stream postData)
        {
            string result = string.Empty;

            try
            {

                if (HttpContext.Current.Request.Headers["token"] != null && !String.IsNullOrEmpty(HttpContext.Current.Request.Headers["token"]))
                {
                    bool IsValid = ValidateRequest(Convert.ToString(HttpContext.Current.Request.Headers["token"]));
                    if (IsValid == false)
                    {
                        result = "401 Unauthorized";
                        return new MemoryStream(Encoding.UTF8.GetBytes(result));
                    }
                }

                WebOperationContext.Current.OutgoingResponse.ContentType = "application/json; charset=utf-8";

                eParameters parameters_obj = GetParameters(postData, "FeedMonitor_Funnel");

                if (!String.IsNullOrEmpty(parameters_obj.UserID) && Convert.ToInt32(parameters_obj.UserID) > 0)
                {
                    new Sahadeva.API.DAL.API_V2().UserLog_Insert(Convert.ToInt32(parameters_obj.UserID), "FeedMonitor_Funnel", Convert.ToInt32(parameters_obj.TopicID));
                }

                var setting = new JsonSerializerSettings
                {
                    MaxDepth = int.MaxValue
                };


                DataTable dt = new Sahadeva.API.DAL.API_V2().Fetch_FeedMonitor_Funnel(Convert.ToInt32(parameters_obj.TopicID), Convert.ToDateTime(parameters_obj.FromDate), Convert.ToDateTime(parameters_obj.ToDate), parameters_obj.GoogleTab, parameters_obj.Source);
                dynamic json = new JObject();
                json.status = "200";
                json.message = "Success";
                json.data = new JArray();
                json.data = JArray.FromObject(dt);

                //result = File.ReadAllText(ConfigurationManager.AppSettings["FetchList_OnlineArticle"]);

                result = JsonConvert.SerializeObject(json, setting);
            }
            catch (Exception ex)
            {
                Log("FeedMonitor_Funnel", ex.Message + " ->> " + ex.StackTrace + " Detail : " + new StreamReader(postData).ReadToEnd().ToString());
                dynamic json = new JObject();
                json.status = "Error";
                json.message = "Error Occured";

                var setting = new JsonSerializerSettings
                {
                    MaxDepth = int.MaxValue
                };
                result = JsonConvert.SerializeObject(json, setting);
            }

            return new MemoryStream(Encoding.UTF8.GetBytes(result));

        }


        [OperationContract]
        [WebInvoke(Method = "POST", UriTemplate = "FeedMonitor_Funnel_Details", ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Bare)]
        public Stream FeedMonitor_Funnel_Details(Stream postData)
        {
            string result = string.Empty;

            try
            {

                if (HttpContext.Current.Request.Headers["token"] != null && !String.IsNullOrEmpty(HttpContext.Current.Request.Headers["token"]))
                {
                    bool IsValid = ValidateRequest(Convert.ToString(HttpContext.Current.Request.Headers["token"]));
                    if (IsValid == false)
                    {
                        result = "401 Unauthorized";
                        return new MemoryStream(Encoding.UTF8.GetBytes(result));
                    }
                }

                WebOperationContext.Current.OutgoingResponse.ContentType = "application/json; charset=utf-8";

                eParameters parameters_obj = GetParameters(postData, "Fetch_FeedMonitor_Funnel_Details");

                if (!String.IsNullOrEmpty(parameters_obj.UserID) && Convert.ToInt32(parameters_obj.UserID) > 0)
                {
                    new Sahadeva.API.DAL.API_V2().UserLog_Insert(Convert.ToInt32(parameters_obj.UserID), "Fetch_FeedMonitor_Funnel_Details", Convert.ToInt32(parameters_obj.TopicID));
                }

                var setting = new JsonSerializerSettings
                {
                    MaxDepth = int.MaxValue
                };


                DataTable dt = new Sahadeva.API.DAL.API_V2().Fetch_FeedMonitor_Funnel_Details(Convert.ToInt32(parameters_obj.TopicID), Convert.ToDateTime(parameters_obj.FromDate), Convert.ToDateTime(parameters_obj.ToDate), parameters_obj.Comment, parameters_obj.GoogleTab, parameters_obj.Url, parameters_obj.Source);
                dynamic json = new JObject();
                json.status = "200";
                json.message = "Success";
                json.data = new JArray();
                json.data = JArray.FromObject(dt);

                //result = File.ReadAllText(ConfigurationManager.AppSettings["FetchList_OnlineArticle"]);

                result = JsonConvert.SerializeObject(json, setting);
            }
            catch (Exception ex)
            {
                Log("FeedMonitor_Funnel_Details", ex.Message + " ->> " + ex.StackTrace + " Detail : " + new StreamReader(postData).ReadToEnd().ToString());
                dynamic json = new JObject();
                json.status = "Error";
                json.message = "Error Occured";

                var setting = new JsonSerializerSettings
                {
                    MaxDepth = int.MaxValue
                };
                result = JsonConvert.SerializeObject(json, setting);
            }

            return new MemoryStream(Encoding.UTF8.GetBytes(result));

        }

        [OperationContract]
        [WebInvoke(Method = "POST", UriTemplate = "FeedMonitor_FetchIncidents", ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Bare)]
        public Stream FeedMonitor_FetchIncidents(Stream postData)
        {
            string result = string.Empty;
            var setting = new JsonSerializerSettings
            {
                MaxDepth = int.MaxValue
            };
            try
            {

                if (HttpContext.Current.Request.Headers["token"] != null && !String.IsNullOrEmpty(HttpContext.Current.Request.Headers["token"]))
                {
                    bool IsValid = ValidateRequest(Convert.ToString(HttpContext.Current.Request.Headers["token"]));
                    if (IsValid == false)
                    {
                        result = "401 Unauthorized";
                        return new MemoryStream(Encoding.UTF8.GetBytes(result));
                    }
                }

                WebOperationContext.Current.OutgoingResponse.ContentType = "application/json; charset=utf-8";

                eParameters parameters_obj = GetParameters(postData, "FeedMonitor_FetchIncidents");

                if (!String.IsNullOrEmpty(parameters_obj.UserID) && Convert.ToInt32(parameters_obj.UserID) > 0)
                {
                    new Sahadeva.API.DAL.API_V2().UserLog_Insert(Convert.ToInt32(parameters_obj.UserID), "FeedMonitor_FetchIncidents", 0);
                }

                Log("Start FeedMonitor Incident_FetchList", "");
                DataTable dt = new Sahadeva.API.DAL.API_V2().FeedMonitor_Incident_FetchList(Convert.ToInt32(parameters_obj.UserID), Convert.ToInt32(parameters_obj.EntityID), parameters_obj.TopicIDs, parameters_obj.Topic_Title);
                Log("End FeedMonitor Incident_FetchList", "");
                dynamic json = new JObject();
                json.status = "200";
                json.message = "Success";
                json.data = new JArray();
                json.data = JArray.FromObject(dt);

                //result = File.ReadAllText(ConfigurationManager.AppSettings["FetchIncidents"]);

                result = JsonConvert.SerializeObject(json, setting);
                //Log("End Incident_FetchList", "");
                Log("Result is ", result);
            }
            catch (Exception ex)
            {
                Log("FeedMonitor_FetchIncidents", ex.Message + " ->> " + ex.StackTrace + " Detail : " + new StreamReader(postData).ReadToEnd().ToString());
                dynamic json = new JObject();
                json.status = "Error";
                json.message = "Error Occured";
                result = JsonConvert.SerializeObject(json, setting);
            }

            return new MemoryStream(Encoding.UTF8.GetBytes(result));

        }

        [OperationContract]
        [WebInvoke(Method = "POST", UriTemplate = "FeedMonitor_UserEvent_Stats", ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Bare)]
        public Stream FeedMonitor_UserEvent_Stats(Stream postData)
        {
            string result = string.Empty;
            var setting = new JsonSerializerSettings
            {
                MaxDepth = int.MaxValue
            };
            try
            {

                if (HttpContext.Current.Request.Headers["token"] != null && !String.IsNullOrEmpty(HttpContext.Current.Request.Headers["token"]))
                {
                    bool IsValid = ValidateRequest(Convert.ToString(HttpContext.Current.Request.Headers["token"]));
                    if (IsValid == false)
                    {
                        result = "401 Unauthorized";
                        return new MemoryStream(Encoding.UTF8.GetBytes(result));
                    }
                }

                WebOperationContext.Current.OutgoingResponse.ContentType = "application/json; charset=utf-8";

                eParameters parameters_obj = GetParameters(postData, "FeedMonitor_FetchIncidents");

                if (!String.IsNullOrEmpty(parameters_obj.UserID) && Convert.ToInt32(parameters_obj.UserID) > 0)
                {
                    new Sahadeva.API.DAL.API_V2().UserLog_Insert(Convert.ToInt32(parameters_obj.UserID), "FeedMonitor_UserEvent_Stats", 0);
                }

                Log("Start FeedMonitor UserEvent_Stats", "");
                DataSet ds = new Sahadeva.API.DAL.API_V2().Fetch_FeedMonitor_UserEvent_Stats(Convert.ToInt32(parameters_obj.UserID));
                Log("End FeedMonitor UserEvent_Stats", "");


                dynamic json = new JObject();
                if (ds != null)
                {
                    if (ds.Tables != null)
                    {
                        json.status = "200";
                        json.message = "Success";
                        json.data = new JObject();

                        dynamic o = new JObject();
                        o.user_id = Convert.ToInt32(parameters_obj.UserID);
                        o.user_event_stats = JArray.FromObject(ds.Tables[0]);

                        if (ds.Tables.Count > 0)
                        {
                            if (ds.Tables[1] != null)
                            {
                                var negativeEvents = ds.Tables[1].AsEnumerable()
                                                         .Select(row => row[0].ToString())
                                                         .ToArray();
                                o.negative_events = string.Join(",", negativeEvents);
                            }

                            if (ds.Tables[2] != null)
                            {
                                var positiveEvents = ds.Tables[2].AsEnumerable()
                                                        .Select(row => row[0].ToString())
                                                        .ToArray();
                                o.positive_events = string.Join(",", positiveEvents);
                            }
                        }
                        json.data = o;
                    }
                }

                //result = File.ReadAllText(ConfigurationManager.AppSettings["FetchIncidents"]);

                result = JsonConvert.SerializeObject(json, setting);
                //Log("End Incident_FetchList", "");
                Log("Result is ", result);
            }
            catch (Exception ex)
            {
                Log("FeedMonitor_FetchIncidents", ex.Message + " ->> " + ex.StackTrace + " Detail : " + new StreamReader(postData).ReadToEnd().ToString());
                dynamic json = new JObject();
                json.status = "Error";
                json.message = "Error Occured";
                result = JsonConvert.SerializeObject(json, setting);
            }

            return new MemoryStream(Encoding.UTF8.GetBytes(result));

        }

        [OperationContract]
        [WebInvoke(Method = "POST", UriTemplate = "FeedMonitor_Funnel_Twitter", ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Bare)]
        public Stream FeedMonitor_Funnel_Twitter(Stream postData)
        {
            string result = string.Empty;

            try
            {

                if (HttpContext.Current.Request.Headers["token"] != null && !String.IsNullOrEmpty(HttpContext.Current.Request.Headers["token"]))
                {
                    bool IsValid = ValidateRequest(Convert.ToString(HttpContext.Current.Request.Headers["token"]));
                    if (IsValid == false)
                    {
                        result = "401 Unauthorized";
                        return new MemoryStream(Encoding.UTF8.GetBytes(result));
                    }
                }

                WebOperationContext.Current.OutgoingResponse.ContentType = "application/json; charset=utf-8";

                eParameters parameters_obj = GetParameters(postData, "FeedMonitor_Funnel_Twitter");

                if (!String.IsNullOrEmpty(parameters_obj.UserID) && Convert.ToInt32(parameters_obj.UserID) > 0)
                {
                    new Sahadeva.API.DAL.API_V2().UserLog_Insert(Convert.ToInt32(parameters_obj.UserID), "FeedMonitor_Funnel_Twitter", Convert.ToInt32(parameters_obj.TopicID));
                }

                var setting = new JsonSerializerSettings
                {
                    MaxDepth = int.MaxValue
                };


                DataTable dt = new Sahadeva.API.DAL.API_V2().Fetch_FeedMonitor_Funnel_Twitter(Convert.ToInt32(parameters_obj.TopicID), Convert.ToDateTime(parameters_obj.FromDate), Convert.ToDateTime(parameters_obj.ToDate));
                dynamic json = new JObject();
                json.status = "200";
                json.message = "Success";
                json.data = new JArray();
                json.data = JArray.FromObject(dt);

                //result = File.ReadAllText(ConfigurationManager.AppSettings["FetchList_OnlineArticle"]);

                result = JsonConvert.SerializeObject(json, setting);
            }
            catch (Exception ex)
            {
                Log("FeedMonitor_Funnel_Twitter", ex.Message + " ->> " + ex.StackTrace + " Detail : " + new StreamReader(postData).ReadToEnd().ToString());
                dynamic json = new JObject();
                json.status = "Error";
                json.message = "Error Occured";

                var setting = new JsonSerializerSettings
                {
                    MaxDepth = int.MaxValue
                };
                result = JsonConvert.SerializeObject(json, setting);
            }

            return new MemoryStream(Encoding.UTF8.GetBytes(result));

        }

        [OperationContract]
        [WebInvoke(Method = "POST", UriTemplate = "FeedMonitor_Funnel_Twitter_Details", ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Bare)]
        public Stream FeedMonitor_Funnel_Twitter_Details(Stream postData)
        {
            string result = string.Empty;

            try
            {

                if (HttpContext.Current.Request.Headers["token"] != null && !String.IsNullOrEmpty(HttpContext.Current.Request.Headers["token"]))
                {
                    bool IsValid = ValidateRequest(Convert.ToString(HttpContext.Current.Request.Headers["token"]));
                    if (IsValid == false)
                    {
                        result = "401 Unauthorized";
                        return new MemoryStream(Encoding.UTF8.GetBytes(result));
                    }
                }

                WebOperationContext.Current.OutgoingResponse.ContentType = "application/json; charset=utf-8";

                eParameters parameters_obj = GetParameters(postData, "Fetch_FeedMonitor_Funnel_Twitter_Details");

                if (!String.IsNullOrEmpty(parameters_obj.UserID) && Convert.ToInt32(parameters_obj.UserID) > 0)
                {
                    new Sahadeva.API.DAL.API_V2().UserLog_Insert(Convert.ToInt32(parameters_obj.UserID), "Fetch_FeedMonitor_Funnel_Twitter_Details", Convert.ToInt32(parameters_obj.TopicID));
                }

                var setting = new JsonSerializerSettings
                {
                    MaxDepth = int.MaxValue
                };


                DataTable dt = new Sahadeva.API.DAL.API_V2().Fetch_FeedMonitor_Funnel_Twitter_Details(Convert.ToInt32(parameters_obj.TopicID), Convert.ToDateTime(parameters_obj.FromDate), Convert.ToDateTime(parameters_obj.ToDate), parameters_obj.Comment, parameters_obj.Url);
                dynamic json = new JObject();
                json.status = "200";
                json.message = "Success";
                json.data = new JArray();
                json.data = JArray.FromObject(dt);

                //result = File.ReadAllText(ConfigurationManager.AppSettings["FetchList_OnlineArticle"]);

                result = JsonConvert.SerializeObject(json, setting);
            }
            catch (Exception ex)
            {
                Log("FeedMonitor_Funnel_Twitter_Details", ex.Message + " ->> " + ex.StackTrace + " Detail : " + new StreamReader(postData).ReadToEnd().ToString());
                dynamic json = new JObject();
                json.status = "Error";
                json.message = "Error Occured";

                var setting = new JsonSerializerSettings
                {
                    MaxDepth = int.MaxValue
                };
                result = JsonConvert.SerializeObject(json, setting);
            }

            return new MemoryStream(Encoding.UTF8.GetBytes(result));

        }

        [OperationContract]
        [WebInvoke(Method = "POST", UriTemplate = "FeedMonitor_Funnel_YouTube", ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Bare)]
        public Stream FeedMonitor_Funnel_YouTube(Stream postData)
        {
            string result = string.Empty;

            try
            {

                if (HttpContext.Current.Request.Headers["token"] != null && !String.IsNullOrEmpty(HttpContext.Current.Request.Headers["token"]))
                {
                    bool IsValid = ValidateRequest(Convert.ToString(HttpContext.Current.Request.Headers["token"]));
                    if (IsValid == false)
                    {
                        result = "401 Unauthorized";
                        return new MemoryStream(Encoding.UTF8.GetBytes(result));
                    }
                }

                WebOperationContext.Current.OutgoingResponse.ContentType = "application/json; charset=utf-8";

                eParameters parameters_obj = GetParameters(postData, "FeedMonitor_Funnel_YouTube");

                if (!String.IsNullOrEmpty(parameters_obj.UserID) && Convert.ToInt32(parameters_obj.UserID) > 0)
                {
                    new Sahadeva.API.DAL.API_V2().UserLog_Insert(Convert.ToInt32(parameters_obj.UserID), "FeedMonitor_Funnel_YouTube", Convert.ToInt32(parameters_obj.TopicID));
                }

                var setting = new JsonSerializerSettings
                {
                    MaxDepth = int.MaxValue
                };


                DataTable dt = new Sahadeva.API.DAL.API_V2().Fetch_FeedMonitor_Funnel_YouTube(Convert.ToInt32(parameters_obj.TopicID), Convert.ToDateTime(parameters_obj.FromDate), Convert.ToDateTime(parameters_obj.ToDate));
                dynamic json = new JObject();
                json.status = "200";
                json.message = "Success";
                json.data = new JArray();
                json.data = JArray.FromObject(dt);

                //result = File.ReadAllText(ConfigurationManager.AppSettings["FetchList_OnlineArticle"]);

                result = JsonConvert.SerializeObject(json, setting);
            }
            catch (Exception ex)
            {
                Log("FeedMonitor_Funnel_YouTube", ex.Message + " ->> " + ex.StackTrace + " Detail : " + new StreamReader(postData).ReadToEnd().ToString());
                dynamic json = new JObject();
                json.status = "Error";
                json.message = "Error Occured";

                var setting = new JsonSerializerSettings
                {
                    MaxDepth = int.MaxValue
                };
                result = JsonConvert.SerializeObject(json, setting);
            }

            return new MemoryStream(Encoding.UTF8.GetBytes(result));

        }

        [OperationContract]
        [WebInvoke(Method = "POST", UriTemplate = "FeedMonitor_Funnel_YouTube_Details", ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Bare)]
        public Stream FeedMonitor_Funnel_YouTube_Details(Stream postData)
        {
            string result = string.Empty;

            try
            {

                if (HttpContext.Current.Request.Headers["token"] != null && !String.IsNullOrEmpty(HttpContext.Current.Request.Headers["token"]))
                {
                    bool IsValid = ValidateRequest(Convert.ToString(HttpContext.Current.Request.Headers["token"]));
                    if (IsValid == false)
                    {
                        result = "401 Unauthorized";
                        return new MemoryStream(Encoding.UTF8.GetBytes(result));
                    }
                }

                WebOperationContext.Current.OutgoingResponse.ContentType = "application/json; charset=utf-8";

                eParameters parameters_obj = GetParameters(postData, "Fetch_FeedMonitor_Funnel_YouTube_Details");

                if (!String.IsNullOrEmpty(parameters_obj.UserID) && Convert.ToInt32(parameters_obj.UserID) > 0)
                {
                    new Sahadeva.API.DAL.API_V2().UserLog_Insert(Convert.ToInt32(parameters_obj.UserID), "Fetch_FeedMonitor_Funnel_YouTube_Details", Convert.ToInt32(parameters_obj.TopicID));
                }

                var setting = new JsonSerializerSettings
                {
                    MaxDepth = int.MaxValue
                };


                DataTable dt = new Sahadeva.API.DAL.API_V2().Fetch_FeedMonitor_Funnel_YouTube_Details(Convert.ToInt32(parameters_obj.TopicID), Convert.ToDateTime(parameters_obj.FromDate), Convert.ToDateTime(parameters_obj.ToDate), parameters_obj.Comment, parameters_obj.Url);
                dynamic json = new JObject();
                json.status = "200";
                json.message = "Success";
                json.data = new JArray();
                json.data = JArray.FromObject(dt);

                //result = File.ReadAllText(ConfigurationManager.AppSettings["FetchList_OnlineArticle"]);

                result = JsonConvert.SerializeObject(json, setting);
            }
            catch (Exception ex)
            {
                Log("FeedMonitor_Funnel_YouTube_Details", ex.Message + " ->> " + ex.StackTrace + " Detail : " + new StreamReader(postData).ReadToEnd().ToString());
                dynamic json = new JObject();
                json.status = "Error";
                json.message = "Error Occured";

                var setting = new JsonSerializerSettings
                {
                    MaxDepth = int.MaxValue
                };
                result = JsonConvert.SerializeObject(json, setting);
            }

            return new MemoryStream(Encoding.UTF8.GetBytes(result));

        }

        #endregion

        #region New Landing Twitter

        [OperationContract]
        [WebInvoke(Method = "POST", UriTemplate = "FetchLanding_Twitter_Optimized_StatCards", ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Bare)]
        public Stream FetchLanding_Twitter_Optimized_StatCards(Stream postData)
        {
            string result = string.Empty;

            try
            {

                if (HttpContext.Current.Request.Headers["token"] != null && !String.IsNullOrEmpty(HttpContext.Current.Request.Headers["token"]))
                {
                    bool IsValid = ValidateRequest(Convert.ToString(HttpContext.Current.Request.Headers["token"]));
                    if (IsValid == false)
                    {
                        result = "401 Unauthorized";
                        return new MemoryStream(Encoding.UTF8.GetBytes(result));
                    }
                }

                WebOperationContext.Current.OutgoingResponse.ContentType = "application/json; charset=utf-8";

                //Converting to stringa and back to Stream, caz Stream losses its memory
                string InputBody = new StreamReader(postData).ReadToEnd().ToString();
                byte[] byteArray = Encoding.UTF8.GetBytes(InputBody);
                MemoryStream stream = new MemoryStream(byteArray);
                postData = stream;

                eParameters parameters_obj = GetParameters(postData, "FetchLanding_Twitter_Optimized_StatCards");

                if (!String.IsNullOrEmpty(parameters_obj.UserID) && Convert.ToInt32(parameters_obj.UserID) > 0)
                {
                    new Sahadeva.API.DAL.API_V2().UserLog_Insert(Convert.ToInt32(parameters_obj.UserID), "FetchLanding_Twitter_Optimized_StatCards", Convert.ToInt32(parameters_obj.TopicID));
                }

                var setting = new JsonSerializerSettings
                {
                    MaxDepth = int.MaxValue
                };

                string strDevice = "web";
                if (HttpContext.Current.Request.Headers["APPType"] != null && !String.IsNullOrEmpty(HttpContext.Current.Request.Headers["APPType"]))
                {
                    strDevice = Convert.ToString(HttpContext.Current.Request.Headers["APPType"]);
                }

                DataSet ds = new DataSet();


                Log("FetchLanding_Twitter_Optimized_StatCards DS start", "");
                ds = new Sahadeva.API.DAL.API_V2().FetchLanding_Twitter_Optimized_StatCards(Convert.ToInt32(parameters_obj.TopicID), Convert.ToDateTime(parameters_obj.FromDate), Convert.ToDateTime(parameters_obj.ToDate), Convert.ToDateTime(parameters_obj.BaseDate), parameters_obj.hide_denominator, Convert.ToString(parameters_obj.show_percentage), strDevice);
                Log("FetchLanding_Twitter_Optimized_StatCards DS end", "");


                Log("FetchLanding_Twitter_Optimized_StatCards JSON Creation start", "");
                dynamic json = new JObject();
                if (ds.Tables.Count > 0)
                {
                    json.status = "200";
                    json.message = "Success";
                    json.data = new JObject();

                    dynamic o = new JObject();
                    o.incident_id = Convert.ToInt32(parameters_obj.TopicID);
                    o.stats = JArray.FromObject(ds.Tables[1]);
                    json.data = o;
                }
                Log("FetchLanding_Twitter_Optimized_StatCards JSON Creation End", "");

                Log("FetchLanding_Twitter_Optimized_StatCards SerializeObject Creation Start", "");
                result = JsonConvert.SerializeObject(json, setting);
                Log("FetchLanding_Twitter_Optimized_StatCards SerializeObject Creation End", "");
            }
            catch (Exception ex)
            {
                Log("FetchLanding_Twitter_Optimized_StatCards", ex.Message + " ->> " + ex.StackTrace + " Detail : " + new StreamReader(postData).ReadToEnd().ToString());
                dynamic json = new JObject();
                json.status = "Error";
                json.message = "Error Occured";

                var setting = new JsonSerializerSettings
                {
                    MaxDepth = int.MaxValue
                };
                result = JsonConvert.SerializeObject(json, setting);
            }

            return new MemoryStream(Encoding.UTF8.GetBytes(result));

        }

        [OperationContract]
        [WebInvoke(Method = "POST", UriTemplate = "FetchLanding_Twitter_Optimized_Data_By_Parameter", ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Bare)]
        public Stream FetchLanding_Twitter_Optimized_Data_By_Parameter(Stream postData)
        {
            string result = string.Empty;

            try
            {

                if (HttpContext.Current.Request.Headers["token"] != null && !String.IsNullOrEmpty(HttpContext.Current.Request.Headers["token"]))
                {
                    bool IsValid = ValidateRequest(Convert.ToString(HttpContext.Current.Request.Headers["token"]));
                    if (IsValid == false)
                    {
                        result = "401 Unauthorized";
                        return new MemoryStream(Encoding.UTF8.GetBytes(result));
                    }
                }

                WebOperationContext.Current.OutgoingResponse.ContentType = "application/json; charset=utf-8";

                //Converting to stringa and back to Stream, caz Stream losses its memory
                string InputBody = new StreamReader(postData).ReadToEnd().ToString();
                byte[] byteArray = Encoding.UTF8.GetBytes(InputBody);
                MemoryStream stream = new MemoryStream(byteArray);
                postData = stream;

                eParameters parameters_obj = GetParameters(postData, "FetchLanding_Twitter_Optimized_Data_By_Parameter");


                var setting = new JsonSerializerSettings
                {
                    MaxDepth = int.MaxValue
                };


                DataSet ds = new DataSet();

                if (parameters_obj.data_parameter == "Conversion_Themes")
                {
                    Log("FetchLanding_Twitter_Optimized_Conversion_Themes DS start", "");
                    ds = new Sahadeva.API.DAL.API_V2().FetchLanding_Twitter_Optimized_Conversion_Themes(Convert.ToInt32(parameters_obj.TopicID), Convert.ToDateTime(parameters_obj.FromDate), Convert.ToDateTime(parameters_obj.ToDate), Convert.ToDateTime(parameters_obj.BaseDate));
                    Log("FetchLanding_Twitter_Optimized_Conversion_Themes DS end", "");
                }
                else if (parameters_obj.data_parameter == "Active_Participants")
                {
                    Log("FetchLanding_Twitter_Optimized_Conversion_Themes DS start", "");
                    ds = new Sahadeva.API.DAL.API_V2().FetchLanding_Twitter_Optimized_Active_Participants(Convert.ToInt32(parameters_obj.TopicID), Convert.ToDateTime(parameters_obj.FromDate), Convert.ToDateTime(parameters_obj.ToDate), Convert.ToDateTime(parameters_obj.BaseDate));
                    Log("FetchLanding_Twitter_Optimized_Conversion_Themes DS end", "");
                }
                else if (parameters_obj.data_parameter == "Distribution_By_Engagement")
                {
                    Log("FetchLanding_Twitter_Optimized_Distribution_By_Engagement DS start", "");
                    ds = new Sahadeva.API.DAL.API_V2().FetchLanding_Twitter_Optimized_Distribution_By_Engagement(Convert.ToInt32(parameters_obj.TopicID), Convert.ToDateTime(parameters_obj.FromDate), Convert.ToDateTime(parameters_obj.ToDate), Convert.ToDateTime(parameters_obj.BaseDate));
                    Log("FetchLanding_Twitter_Optimized_Distribution_By_Engagement DS end", "");
                }
                else if (parameters_obj.data_parameter == "Distribution_By_Sentiment")
                {
                    Log("FetchLanding_Twitter_Optimized_Distribution_By_Sentiment DS start", "");
                    ds = new Sahadeva.API.DAL.API_V2().FetchLanding_Twitter_Optimized_Distribution_By_Sentiment(Convert.ToInt32(parameters_obj.TopicID), Convert.ToDateTime(parameters_obj.FromDate), Convert.ToDateTime(parameters_obj.ToDate), Convert.ToDateTime(parameters_obj.BaseDate));
                    Log("FetchLanding_Twitter_Optimized_Distribution_By_Sentiment DS end", "");
                }
                else if (parameters_obj.data_parameter == "Distribution_By_Tonaity")
                {
                    Log("FetchLanding_Twitter_Optimized_Distribution_By_Tonaity DS start", "");
                    ds = new Sahadeva.API.DAL.API_V2().FetchLanding_Twitter_Optimized_Distribution_By_Tonaity(Convert.ToInt32(parameters_obj.TopicID), Convert.ToDateTime(parameters_obj.FromDate), Convert.ToDateTime(parameters_obj.ToDate), Convert.ToDateTime(parameters_obj.BaseDate));
                    Log("FetchLanding_Twitter_Optimized_Distribution_By_Tonaity DS end", "");
                }
                else if (parameters_obj.data_parameter == "Heading_stats")
                {
                    Log("FetchLanding_Twitter_Optimized_Heading_stats DS start", "");
                    ds = new Sahadeva.API.DAL.API_V2().FetchLanding_Twitter_Optimized_Heading_stats(Convert.ToInt32(parameters_obj.TopicID), Convert.ToDateTime(parameters_obj.FromDate), Convert.ToDateTime(parameters_obj.ToDate), Convert.ToDateTime(parameters_obj.BaseDate), parameters_obj.hide_denominator, Convert.ToString(parameters_obj.show_percentage));
                    Log("FetchLanding_Twitter_Optimized_Heading_stats DS end", "");
                }
                else if (parameters_obj.data_parameter == "Media_Influencers")
                {
                    Log("FetchLanding_Twitter_Optimized_Media_Influencers DS start", "");
                    ds = new Sahadeva.API.DAL.API_V2().FetchLanding_Twitter_Optimized_Media_Influencers(Convert.ToInt32(parameters_obj.TopicID), Convert.ToDateTime(parameters_obj.FromDate), Convert.ToDateTime(parameters_obj.ToDate), Convert.ToDateTime(parameters_obj.BaseDate));
                    Log("FetchLanding_Twitter_Optimized_Media_Influencers DS end", "");
                }
                else if (parameters_obj.data_parameter == "Top_Mentioned_Hashtags")
                {
                    Log("FetchLanding_Twitter_Optimized_Top_Mentioned_Hashtags DS start", "");
                    ds = new Sahadeva.API.DAL.API_V2().FetchLanding_Twitter_Optimized_Top_Mentioned_Hashtags(Convert.ToInt32(parameters_obj.TopicID), Convert.ToDateTime(parameters_obj.FromDate), Convert.ToDateTime(parameters_obj.ToDate), Convert.ToDateTime(parameters_obj.BaseDate));
                    Log("FetchLanding_Twitter_Optimized_Top_Mentioned_Hashtags DS end", "");
                }
                else if (parameters_obj.data_parameter == "TopTenContributorsByEngagement")
                {
                    Log("FetchLanding_Twitter_Optimized_TopTenContributorsByEngagement DS start", "");
                    ds = new Sahadeva.API.DAL.API_V2().FetchLanding_Twitter_Optimized_TopTenContributorsByEngagement(Convert.ToInt32(parameters_obj.TopicID), Convert.ToDateTime(parameters_obj.FromDate), Convert.ToDateTime(parameters_obj.ToDate), Convert.ToDateTime(parameters_obj.BaseDate));
                    Log("FetchLanding_Twitter_Optimized_TopTenContributorsByEngagement DS end", "");
                }
                else if (parameters_obj.data_parameter == "TopTenContributorsByReach")
                {
                    Log("FetchLanding_Twitter_Optimized_TopTenContributorsByReach DS start", "");
                    ds = new Sahadeva.API.DAL.API_V2().FetchLanding_Twitter_Optimized_TopTenContributorsByReach(Convert.ToInt32(parameters_obj.TopicID), Convert.ToDateTime(parameters_obj.FromDate), Convert.ToDateTime(parameters_obj.ToDate), Convert.ToDateTime(parameters_obj.BaseDate));
                    Log("FetchLanding_Twitter_Optimized_TopTenContributorsByReach DS end", "");
                }
                else if (parameters_obj.data_parameter == "TweetsTimeline")
                {
                    Log("FetchLanding_Twitter_Optimized_TweetsTimeline DS start", "");
                    ds = new Sahadeva.API.DAL.API_V2().FetchLanding_Twitter_Optimized_TweetsTimeline(Convert.ToInt32(parameters_obj.TopicID), Convert.ToDateTime(parameters_obj.FromDate), Convert.ToDateTime(parameters_obj.ToDate), Convert.ToDateTime(parameters_obj.BaseDate));
                    Log("FetchLanding_Twitter_Optimized_TweetsTimeline DS end", "");
                }
                else if (parameters_obj.data_parameter == "Key_Highlights_Data")
                {
                    Log("FetchLanding_Twitter_Optimized_TweetsTimeline DS start", "");
                    ds = new Sahadeva.API.DAL.API_V2().FetchLanding_Twitter_Optimized_Key_Highlights_Data(Convert.ToInt32(parameters_obj.TopicID), Convert.ToDateTime(parameters_obj.FromDate), Convert.ToDateTime(parameters_obj.ToDate), Convert.ToDateTime(parameters_obj.BaseDate));
                    Log("FetchLanding_Twitter_Optimized_TweetsTimeline DS end", "");
                }

                Log("FetchLanding_Twitter_Optimized_Data_By_Parameter JSON Creation start", "");
                dynamic json = new JObject();
                if (ds.Tables.Count > 0)
                {
                    json.status = "200";
                    json.message = "Success";
                    json.data = new JObject();

                    dynamic o = new JObject();
                    o.incident_id = Convert.ToInt32(parameters_obj.TopicID);

                    if (parameters_obj.data_parameter == "Conversion_Themes")
                    {
                        o.conversion_themes = JArray.FromObject(ds.Tables[0]);
                    }
                    else if (parameters_obj.data_parameter == "Active_Participants")
                    {
                        o.active_participants = JArray.FromObject(ds.Tables[0]);
                    }
                    else if (parameters_obj.data_parameter == "Distribution_By_Engagement")
                    {
                        o.engagementBreakup = JArray.FromObject(ds.Tables[0]);
                    }
                    else if (parameters_obj.data_parameter == "Distribution_By_Sentiment")
                    {
                        o.sentimentBreakup = JArray.FromObject(ds.Tables[0]);
                    }
                    else if (parameters_obj.data_parameter == "Distribution_By_Tonaity")
                    {
                        o.tonality = JArray.FromObject(ds.Tables[0]);
                    }
                    else if (parameters_obj.data_parameter == "Heading_stats")
                    {
                        o.counts = new JObject();
                        o.counts.twitter = (JObject)JArray.FromObject(ds.Tables[0])[0];
                        o.counts.online = (JObject)JArray.FromObject(ds.Tables[1])[0];
                        o.counts.print = (JObject)JArray.FromObject(ds.Tables[2])[0];
                        o.counts.youtube = (JObject)JArray.FromObject(ds.Tables[3])[0];
                    }
                    else if (parameters_obj.data_parameter == "Media_Influencers")
                    {
                        o.media_influencers = JArray.FromObject(ds.Tables[0]);
                    }
                    else if (parameters_obj.data_parameter == "Top_Mentioned_Hashtags")
                    {
                        o.top_mentioned_hashtags = JArray.FromObject(ds.Tables[0]);
                    }
                    else if (parameters_obj.data_parameter == "TopTenContributorsByEngagement")
                    {
                        o.topTenContributorsByEngagement = JArray.FromObject(ds.Tables[0]);
                    }
                    else if (parameters_obj.data_parameter == "TopTenContributorsByReach")
                    {
                        o.topTenContributors = JArray.FromObject(ds.Tables[0]);
                    }
                    else if (parameters_obj.data_parameter == "TweetsTimeline")
                    {
                        o.tweetsTimeline = new JObject();
                        o.tweetsTimeline.x_axis_values = JArray.FromObject(ds.Tables[0]);
                        o.tweetsTimeline.bar_chart_y_values = JArray.FromObject(ds.Tables[1]);
                        o.tweetsTimeline.area_chart_y_values = JArray.FromObject(ds.Tables[2]);
                    }
                    else if (parameters_obj.data_parameter == "Key_Highlights_Data")
                    {
                        o.key_highlights_data = JArray.FromObject(ds.Tables[0]);
                    }

                    json.data = o;
                }
                Log("FetchLanding_Twitter_Optimized_Data_By_Parameter JSON Creation End", "");


                //result = File.ReadAllText(ConfigurationManager.AppSettings["FetchLanding_OnlineArticle"]);

                Log("FetchLanding_Twitter_Optimized_Data_By_Parameter SerializeObject Creation Start", "");
                result = JsonConvert.SerializeObject(json, setting);
                Log("FetchLanding_Twitter_Optimized_Data_By_Parameter SerializeObject Creation End", "");
            }
            catch (Exception ex)
            {
                Log("FetchLanding_Twitter_Optimized_Data_By_Parameter", ex.Message + " ->> " + ex.StackTrace + " Detail : " + new StreamReader(postData).ReadToEnd().ToString());
                dynamic json = new JObject();
                json.status = "Error";
                json.message = "Error Occured";

                var setting = new JsonSerializerSettings
                {
                    MaxDepth = int.MaxValue
                };
                result = JsonConvert.SerializeObject(json, setting);
            }

            return new MemoryStream(Encoding.UTF8.GetBytes(result));

        }


        #endregion

        #region New Landing Online

        [OperationContract]
        [WebInvoke(Method = "POST", UriTemplate = "FetchLanding_OnlineArticle_Optimized_StatCards", ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Bare)]
        public Stream FetchLanding_OnlineArticle_Optimized_StatCards(Stream postData)
        {
            string result = string.Empty;

            try
            {

                if (HttpContext.Current.Request.Headers["token"] != null && !String.IsNullOrEmpty(HttpContext.Current.Request.Headers["token"]))
                {
                    bool IsValid = ValidateRequest(Convert.ToString(HttpContext.Current.Request.Headers["token"]));
                    if (IsValid == false)
                    {
                        result = "401 Unauthorized";
                        return new MemoryStream(Encoding.UTF8.GetBytes(result));
                    }
                }

                string strDevice = "web";
                if (HttpContext.Current.Request.Headers["APPType"] != null && !String.IsNullOrEmpty(HttpContext.Current.Request.Headers["APPType"]))
                {
                    strDevice = Convert.ToString(HttpContext.Current.Request.Headers["APPType"]);
                }

                WebOperationContext.Current.OutgoingResponse.ContentType = "application/json; charset=utf-8";

                //Converting to stringa and back to Stream, caz Stream losses its memory
                string InputBody = new StreamReader(postData).ReadToEnd().ToString();
                byte[] byteArray = Encoding.UTF8.GetBytes(InputBody);
                MemoryStream stream = new MemoryStream(byteArray);
                postData = stream;

                eParameters parameters_obj = GetParameters(postData, "FetchLanding_OnlineArticle_Optimized_StatCards");



                var setting = new JsonSerializerSettings
                {
                    MaxDepth = int.MaxValue,
                    Formatting = Newtonsoft.Json.Formatting.None
                };


                DataSet ds = new DataSet();

                Log("ArticleOnline_FetchLanding_Optimized_StatCards DS start", "");
                ds = new Sahadeva.API.DAL.API_V2().ArticleOnline_FetchLanding_Optimized_StatCards(Convert.ToInt32(parameters_obj.TopicID), Convert.ToDateTime(parameters_obj.FromDate), Convert.ToDateTime(parameters_obj.ToDate), Convert.ToDateTime(parameters_obj.BaseDate), parameters_obj.hide_denominator, Convert.ToString(parameters_obj.show_percentage), strDevice);
                Log("ArticleOnline_FetchLanding_Optimized_StatCards DS end", "");


                dynamic json = new JObject();
                if (ds.Tables.Count > 0)
                {
                    json.status = "200";
                    json.message = "Success";
                    json.data = new JObject();

                    dynamic o = new JObject();
                    o.incident_id = Convert.ToInt32(parameters_obj.TopicID);
                    o.stats = JArray.FromObject(ds.Tables[0]);

                    json.data = o;
                }

                //result = File.ReadAllText(ConfigurationManager.AppSettings["FetchLanding_OnlineArticle"]);

                result = JsonConvert.SerializeObject(json, setting);
            }
            catch (Exception ex)
            {
                Log("FetchLanding_OnlineArticle_Optimized_StatCards", ex.Message + " ->> " + ex.StackTrace + " Detail : " + new StreamReader(postData).ReadToEnd().ToString());
                dynamic json = new JObject();
                json.status = "Error";
                json.message = "Error Occured";

                var setting = new JsonSerializerSettings
                {
                    MaxDepth = int.MaxValue,
                    Formatting = Newtonsoft.Json.Formatting.None
                };
                result = JsonConvert.SerializeObject(json, setting);
            }

            return new MemoryStream(Encoding.UTF8.GetBytes(result));

        }

        [OperationContract]
        [WebInvoke(Method = "POST", UriTemplate = "FetchLanding_Online_Optimized_Data_By_Parameter", ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Bare)]
        public Stream FetchLanding_Online_Optimized_Data_By_Parameter(Stream postData)
        {
            string result = string.Empty;

            try
            {

                if (HttpContext.Current.Request.Headers["token"] != null && !String.IsNullOrEmpty(HttpContext.Current.Request.Headers["token"]))
                {
                    bool IsValid = ValidateRequest(Convert.ToString(HttpContext.Current.Request.Headers["token"]));
                    if (IsValid == false)
                    {
                        result = "401 Unauthorized";
                        return new MemoryStream(Encoding.UTF8.GetBytes(result));
                    }
                }

                WebOperationContext.Current.OutgoingResponse.ContentType = "application/json; charset=utf-8";

                //Converting to stringa and back to Stream, caz Stream losses its memory
                string InputBody = new StreamReader(postData).ReadToEnd().ToString();
                byte[] byteArray = Encoding.UTF8.GetBytes(InputBody);
                MemoryStream stream = new MemoryStream(byteArray);
                postData = stream;

                eParameters parameters_obj = GetParameters(postData, "FetchLanding_Online_Optimized_Data_By_Parameter");


                var setting = new JsonSerializerSettings
                {
                    MaxDepth = int.MaxValue
                };

                DataSet ds = new DataSet();


                if (!string.IsNullOrEmpty(parameters_obj.data_parameter))
                {
                    String Parameter = Convert.ToString(parameters_obj.data_parameter);

                    Log("FetchLanding_Online_Optimized_" + Parameter + "DS Start", "");
                    ds = new Sahadeva.API.DAL.API_V2().FetchLanding_Online_Optimized_Data_By_Parameter(Convert.ToInt32(parameters_obj.TopicID), Convert.ToDateTime(parameters_obj.FromDate), Convert.ToDateTime(parameters_obj.ToDate), Convert.ToDateTime(parameters_obj.BaseDate), parameters_obj.data_parameter, parameters_obj.hide_denominator, Convert.ToString(parameters_obj.show_percentage));
                    Log("FetchLanding_Online_Optimized_" + Parameter + "DS End", "");
                }

                Log("FetchLanding_Online_Optimized_Data_By_Parameter JSON Creation start", "");
                dynamic json = new JObject();
                if (ds.Tables.Count > 0)
                {
                    json.status = "200";
                    json.message = "Success";
                    json.data = new JObject();

                    dynamic o = new JObject();
                    o.incident_id = Convert.ToInt32(parameters_obj.TopicID);

                    if (parameters_obj.data_parameter == "Top_Stories_by_Traffic")
                    {
                        o.top_stories_by_traffic = JArray.FromObject(ds.Tables[0]);
                    }
                    else if (parameters_obj.data_parameter == "Distribution_by_Publication_Type")
                    {
                        o.publication_type = JArray.FromObject(ds.Tables[0]);
                    }
                    else if (parameters_obj.data_parameter == "Distribution_by_Headline_Sentiment")
                    {
                        o.headline_sentiment = JArray.FromObject(ds.Tables[0]);
                    }
                    else if (parameters_obj.data_parameter == "Distribution_by_Headline_Mention")
                    {
                        o.client_name_in_headline = JArray.FromObject(ds.Tables[0]);
                    }
                    else if (parameters_obj.data_parameter == "Distribution_by_Article_Type")
                    {
                        o.article_type = JArray.FromObject(ds.Tables[0]);
                    }
                    else if (parameters_obj.data_parameter == "Heading_stats")
                    {
                        o.counts = new JObject();
                        o.counts.twitter = (JObject)JArray.FromObject(ds.Tables[0])[0];
                        o.counts.online = (JObject)JArray.FromObject(ds.Tables[1])[0];
                        o.counts.print = (JObject)JArray.FromObject(ds.Tables[2])[0];
                        o.counts.youtube = (JObject)JArray.FromObject(ds.Tables[3])[0];
                    }
                    else if (parameters_obj.data_parameter == "Distribution_by_Article_Sentiment")
                    {
                        o.sentiment = JArray.FromObject(ds.Tables[0]);
                    }
                    else if (parameters_obj.data_parameter == "Distribution_Across_DA_Range")
                    {
                        o.distribution_across_da_range = JArray.FromObject(ds.Tables[0]);
                    }
                    else if (parameters_obj.data_parameter == "What_has_happened_Summary")
                    {
                        o.key_highlights_data = JArray.FromObject(ds.Tables[0]);
                    }

                    json.data = o;
                }
                Log("FetchLanding_Online_Optimized_Data_By_Parameter JSON Creation End", "");


                //result = File.ReadAllText(ConfigurationManager.AppSettings["FetchLanding_OnlineArticle"]);

                Log("FetchLanding_Online_Optimized_Data_By_Parameter SerializeObject Creation Start", "");
                result = JsonConvert.SerializeObject(json, setting);
                Log("FetchLanding_Online_Optimized_Data_By_Parameter SerializeObject Creation End", "");
            }
            catch (Exception ex)
            {
                Log("FetchLanding_Online_Optimized_Data_By_Parameter", ex.Message + " ->> " + ex.StackTrace + " Detail : " + new StreamReader(postData).ReadToEnd().ToString());
                dynamic json = new JObject();
                json.status = "Error";
                json.message = "Error Occured";

                var setting = new JsonSerializerSettings
                {
                    MaxDepth = int.MaxValue
                };
                result = JsonConvert.SerializeObject(json, setting);
            }

            return new MemoryStream(Encoding.UTF8.GetBytes(result));

        }


        #endregion

        #region New Landing Print

        [OperationContract]
        [WebInvoke(Method = "POST", UriTemplate = "FetchLanding_PrintArticle_Optimized_StatCards", ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Bare)]
        public Stream FetchLanding_PrintArticle_Optimized_StatCards(Stream postData)
        {
            string result = string.Empty;

            try
            {

                if (HttpContext.Current.Request.Headers["token"] != null && !String.IsNullOrEmpty(HttpContext.Current.Request.Headers["token"]))
                {
                    bool IsValid = ValidateRequest(Convert.ToString(HttpContext.Current.Request.Headers["token"]));
                    if (IsValid == false)
                    {
                        result = "401 Unauthorized";
                        return new MemoryStream(Encoding.UTF8.GetBytes(result));
                    }
                }

                string strDevice = "web";
                if (HttpContext.Current.Request.Headers["APPType"] != null && !String.IsNullOrEmpty(HttpContext.Current.Request.Headers["APPType"]))
                {
                    strDevice = Convert.ToString(HttpContext.Current.Request.Headers["APPType"]);
                }

                WebOperationContext.Current.OutgoingResponse.ContentType = "application/json; charset=utf-8";

                //Converting to stringa and back to Stream, caz Stream losses its memory
                string InputBody = new StreamReader(postData).ReadToEnd().ToString();
                byte[] byteArray = Encoding.UTF8.GetBytes(InputBody);
                MemoryStream stream = new MemoryStream(byteArray);
                postData = stream;

                eParameters parameters_obj = GetParameters(postData, "FetchLanding_PrintArticle_Optimized_StatCards");


                var setting = new JsonSerializerSettings
                {
                    MaxDepth = int.MaxValue,
                    Formatting = Newtonsoft.Json.Formatting.None
                };


                DataSet ds = new DataSet();

                Log("FetchLanding_PrintArticle_Optimized_StatCards DS start", "");
                ds = new Sahadeva.API.DAL.API_V2().ArticlePrint_FetchLanding_Optimized_StatCards(Convert.ToInt32(parameters_obj.TopicID), Convert.ToDateTime(parameters_obj.FromDate), Convert.ToDateTime(parameters_obj.ToDate), Convert.ToDateTime(parameters_obj.BaseDate), parameters_obj.hide_denominator, Convert.ToString(parameters_obj.show_percentage), strDevice);
                Log("FetchLanding_PrintArticle_Optimized_StatCards DS end", "");


                dynamic json = new JObject();
                if (ds.Tables.Count > 0)
                {
                    json.status = "200";
                    json.message = "Success";
                    json.data = new JObject();

                    dynamic o = new JObject();
                    o.incident_id = Convert.ToInt32(parameters_obj.TopicID);
                    o.stats = JArray.FromObject(ds.Tables[0]);

                    json.data = o;
                }


                result = JsonConvert.SerializeObject(json, setting);
            }
            catch (Exception ex)
            {
                Log("FetchLanding_PrintArticle_Optimized_StatCards", ex.Message + " ->> " + ex.StackTrace + " Detail : " + new StreamReader(postData).ReadToEnd().ToString());
                dynamic json = new JObject();
                json.status = "Error";
                json.message = "Error Occured";

                var setting = new JsonSerializerSettings
                {
                    MaxDepth = int.MaxValue,
                    Formatting = Newtonsoft.Json.Formatting.None
                };
                result = JsonConvert.SerializeObject(json, setting);
            }

            return new MemoryStream(Encoding.UTF8.GetBytes(result));

        }

        [OperationContract]
        [WebInvoke(Method = "POST", UriTemplate = "FetchLanding_Print_Optimized_Data_By_Parameter", ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Bare)]
        public Stream FetchLanding_Print_Optimized_Data_By_Parameter(Stream postData)
        {
            string result = string.Empty;

            try
            {

                if (HttpContext.Current.Request.Headers["token"] != null && !String.IsNullOrEmpty(HttpContext.Current.Request.Headers["token"]))
                {
                    bool IsValid = ValidateRequest(Convert.ToString(HttpContext.Current.Request.Headers["token"]));
                    if (IsValid == false)
                    {
                        result = "401 Unauthorized";
                        return new MemoryStream(Encoding.UTF8.GetBytes(result));
                    }
                }

                WebOperationContext.Current.OutgoingResponse.ContentType = "application/json; charset=utf-8";

                //Converting to stringa and back to Stream, caz Stream losses its memory
                string InputBody = new StreamReader(postData).ReadToEnd().ToString();
                byte[] byteArray = Encoding.UTF8.GetBytes(InputBody);
                MemoryStream stream = new MemoryStream(byteArray);
                postData = stream;

                eParameters parameters_obj = GetParameters(postData, "FetchLanding_Print_Optimized_Data_By_Parameter");


                var setting = new JsonSerializerSettings
                {
                    MaxDepth = int.MaxValue
                };

                DataSet ds = new DataSet();


                if (!string.IsNullOrEmpty(parameters_obj.data_parameter))
                {
                    String Parameter = Convert.ToString(parameters_obj.data_parameter);

                    Log("FetchLanding_Print_Optimized_" + Parameter + "DS Start", "");
                    ds = new Sahadeva.API.DAL.API_V2().FetchLanding_Print_Optimized_Data_By_Parameter(Convert.ToInt32(parameters_obj.TopicID), Convert.ToDateTime(parameters_obj.FromDate), Convert.ToDateTime(parameters_obj.ToDate), Convert.ToDateTime(parameters_obj.BaseDate), parameters_obj.data_parameter, parameters_obj.hide_denominator, Convert.ToString(parameters_obj.show_percentage));
                    Log("FetchLanding_Print_Optimized_" + Parameter + "DS End", "");
                }

                Log("FetchLanding_Print_Optimized_Data_By_Parameter JSON Creation start", "");
                dynamic json = new JObject();
                if (ds.Tables.Count > 0)
                {
                    json.status = "200";
                    json.message = "Success";
                    json.data = new JObject();

                    dynamic o = new JObject();
                    o.incident_id = Convert.ToInt32(parameters_obj.TopicID);

                    if (parameters_obj.data_parameter == "Distribution_by_Edition")
                    {
                        o.edition_distribution = JArray.FromObject(ds.Tables[0]);
                    }
                    else if (parameters_obj.data_parameter == "Distribution_by_Publication_Type")
                    {
                        o.publication_type = JArray.FromObject(ds.Tables[0]);
                    }
                    else if (parameters_obj.data_parameter == "Distribution_by_Headline_Sentiment")
                    {
                        o.headline_sentiment = JArray.FromObject(ds.Tables[0]);
                    }
                    else if (parameters_obj.data_parameter == "Distribution_by_Headline_Mention")
                    {
                        o.client_name_in_headline = JArray.FromObject(ds.Tables[0]);
                    }
                    else if (parameters_obj.data_parameter == "Distribution_by_Article_Type")
                    {
                        o.article_type = JArray.FromObject(ds.Tables[0]);
                    }
                    else if (parameters_obj.data_parameter == "Heading_stats")
                    {
                        o.counts = new JObject();
                        o.counts.twitter = (JObject)JArray.FromObject(ds.Tables[0])[0];
                        o.counts.online = (JObject)JArray.FromObject(ds.Tables[1])[0];
                        o.counts.print = (JObject)JArray.FromObject(ds.Tables[2])[0];
                        o.counts.youtube = (JObject)JArray.FromObject(ds.Tables[3])[0];
                    }
                    else if (parameters_obj.data_parameter == "Distribution_by_Article_Sentiment")
                    {
                        o.sentiment = JArray.FromObject(ds.Tables[0]);
                    }
                    else if (parameters_obj.data_parameter == "Distribution_by_Source")
                    {
                        o.percentage_of_source = JArray.FromObject(ds.Tables[0]);
                    }
                    else if (parameters_obj.data_parameter == "What_has_happened_Summary")
                    {
                        o.key_highlights_data = JArray.FromObject(ds.Tables[0]);
                    }
                    else if (parameters_obj.data_parameter == "Top_Contributors")
                    {
                        o.top_10_contributors_list_of_publications = JArray.FromObject(ds.Tables[0]);
                    }
                    else if (parameters_obj.data_parameter == "Top_Stories_by_Circulation")
                    {
                        o.top_stories_by_traffic = JArray.FromObject(ds.Tables[0]);
                    }

                    json.data = o;
                }
                Log("FetchLanding_Print_Optimized_Data_By_Parameter JSON Creation End", "");


                //result = File.ReadAllText(ConfigurationManager.AppSettings["FetchLanding_OnlineArticle"]);

                Log("FetchLanding_Print_Optimized_Data_By_Parameter SerializeObject Creation Start", "");
                result = JsonConvert.SerializeObject(json, setting);
                Log("FetchLanding_Print_Optimized_Data_By_Parameter SerializeObject Creation End", "");
            }
            catch (Exception ex)
            {
                Log("FetchLanding_Print_Optimized_Data_By_Parameter", ex.Message + " ->> " + ex.StackTrace + " Detail : " + new StreamReader(postData).ReadToEnd().ToString());
                dynamic json = new JObject();
                json.status = "Error";
                json.message = "Error Occured";

                var setting = new JsonSerializerSettings
                {
                    MaxDepth = int.MaxValue
                };
                result = JsonConvert.SerializeObject(json, setting);
            }

            return new MemoryStream(Encoding.UTF8.GetBytes(result));

        }


        #endregion

        #region New Landing YouTube

        [OperationContract]
        [WebInvoke(Method = "POST", UriTemplate = "FetchLanding_YouTube_Optimized_StatCards", ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Bare)]
        public Stream FetchLanding_YouTube_Optimized_StatCards(Stream postData)
        {
            string result = string.Empty;

            try
            {

                if (HttpContext.Current.Request.Headers["token"] != null && !String.IsNullOrEmpty(HttpContext.Current.Request.Headers["token"]))
                {
                    bool IsValid = ValidateRequest(Convert.ToString(HttpContext.Current.Request.Headers["token"]));
                    if (IsValid == false)
                    {
                        result = "401 Unauthorized";
                        return new MemoryStream(Encoding.UTF8.GetBytes(result));
                    }
                }

                string strDevice = "web";
                if (HttpContext.Current.Request.Headers["APPType"] != null && !String.IsNullOrEmpty(HttpContext.Current.Request.Headers["APPType"]))
                {
                    strDevice = Convert.ToString(HttpContext.Current.Request.Headers["APPType"]);
                }

                WebOperationContext.Current.OutgoingResponse.ContentType = "application/json; charset=utf-8";

                //Converting to stringa and back to Stream, caz Stream losses its memory
                string InputBody = new StreamReader(postData).ReadToEnd().ToString();
                byte[] byteArray = Encoding.UTF8.GetBytes(InputBody);
                MemoryStream stream = new MemoryStream(byteArray);
                postData = stream;

                eParameters parameters_obj = GetParameters(postData, "FetchLanding_YouTube_Optimized_StatCards");

                if (!String.IsNullOrEmpty(parameters_obj.UserID) && Convert.ToInt32(parameters_obj.UserID) > 0)
                {
                    new Sahadeva.API.DAL.API_V2().UserLog_Insert(Convert.ToInt32(parameters_obj.UserID), "FetchLanding_YouTube_Optimized_StatCards", Convert.ToInt32(parameters_obj.TopicID));
                }

                var setting = new JsonSerializerSettings
                {
                    MaxDepth = int.MaxValue,
                    Formatting = Newtonsoft.Json.Formatting.None
                };


                DataSet ds = new DataSet();

                Log("FetchLanding_YouTube_Optimized_StatCards DS start", "");
                ds = new Sahadeva.API.DAL.API_V2().FetchLanding_YouTube_Optimized_StatCards(Convert.ToInt32(parameters_obj.TopicID), Convert.ToDateTime(parameters_obj.FromDate), Convert.ToDateTime(parameters_obj.ToDate), Convert.ToDateTime(parameters_obj.BaseDate), parameters_obj.hide_denominator, Convert.ToString(parameters_obj.show_percentage), strDevice);
                Log("FetchLanding_YouTube_Optimized_StatCards DS end", "");


                dynamic json = new JObject();
                if (ds.Tables.Count > 0)
                {
                    json.status = "200";
                    json.message = "Success";
                    json.data = new JObject();

                    dynamic o = new JObject();
                    o.incident_id = Convert.ToInt32(parameters_obj.TopicID);
                    o.stats = JArray.FromObject(ds.Tables[0]);

                    json.data = o;
                }


                result = JsonConvert.SerializeObject(json, setting);
            }
            catch (Exception ex)
            {
                Log("FetchLanding_YouTube_Optimized_StatCards", ex.Message + " ->> " + ex.StackTrace + " Detail : " + new StreamReader(postData).ReadToEnd().ToString());
                dynamic json = new JObject();
                json.status = "Error";
                json.message = "Error Occured";

                var setting = new JsonSerializerSettings
                {
                    MaxDepth = int.MaxValue,
                    Formatting = Newtonsoft.Json.Formatting.None
                };
                result = JsonConvert.SerializeObject(json, setting);
            }

            return new MemoryStream(Encoding.UTF8.GetBytes(result));

        }

        [OperationContract]
        [WebInvoke(Method = "POST", UriTemplate = "FetchLanding_YouTube_Optimized_Data_By_Parameter", ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Bare)]
        public Stream FetchLanding_YouTube_Optimized_Data_By_Parameter(Stream postData)
        {
            string result = string.Empty;

            try
            {

                if (HttpContext.Current.Request.Headers["token"] != null && !String.IsNullOrEmpty(HttpContext.Current.Request.Headers["token"]))
                {
                    bool IsValid = ValidateRequest(Convert.ToString(HttpContext.Current.Request.Headers["token"]));
                    if (IsValid == false)
                    {
                        result = "401 Unauthorized";
                        return new MemoryStream(Encoding.UTF8.GetBytes(result));
                    }
                }

                WebOperationContext.Current.OutgoingResponse.ContentType = "application/json; charset=utf-8";

                //Converting to stringa and back to Stream, caz Stream losses its memory
                string InputBody = new StreamReader(postData).ReadToEnd().ToString();
                byte[] byteArray = Encoding.UTF8.GetBytes(InputBody);
                MemoryStream stream = new MemoryStream(byteArray);
                postData = stream;

                eParameters parameters_obj = GetParameters(postData, "FetchLanding_YouTube_Optimized_Data_By_Parameter");

                if (!String.IsNullOrEmpty(parameters_obj.UserID) && Convert.ToInt32(parameters_obj.UserID) > 0)
                {
                    new Sahadeva.API.DAL.API_V2().UserLog_Insert(Convert.ToInt32(parameters_obj.UserID), "FetchLanding_YouTube_Optimized_Data_By_Parameter", Convert.ToInt32(parameters_obj.TopicID));
                }

                var setting = new JsonSerializerSettings
                {
                    MaxDepth = int.MaxValue
                };

                DataSet ds = new DataSet();


                if (!string.IsNullOrEmpty(parameters_obj.data_parameter))
                {
                    String Parameter = Convert.ToString(parameters_obj.data_parameter);

                    Log("FetchLanding_YouTube_Optimized_" + Parameter + "DS Start", "");
                    ds = new Sahadeva.API.DAL.API_V2().FetchLanding_YouTube_Optimized_Data_By_Parameter(Convert.ToInt32(parameters_obj.TopicID), Convert.ToDateTime(parameters_obj.FromDate), Convert.ToDateTime(parameters_obj.ToDate), Convert.ToDateTime(parameters_obj.BaseDate), parameters_obj.data_parameter, parameters_obj.hide_denominator, Convert.ToString(parameters_obj.show_percentage));
                    Log("FetchLanding_YouTube_Optimized_" + Parameter + "DS End", "");
                }

                Log("FetchLanding_YouTube_Optimized_Data_By_Parameter JSON Creation start", "");
                dynamic json = new JObject();
                if (ds.Tables.Count > 0)
                {
                    json.status = "200";
                    json.message = "Success";
                    json.data = new JObject();

                    dynamic o = new JObject();
                    o.incident_id = Convert.ToInt32(parameters_obj.TopicID);

                    if (parameters_obj.data_parameter == "Client_Mentions_In_The_Video")
                    {
                        o.client_mentions_in_the_video = JArray.FromObject(ds.Tables[0]);
                    }
                    else if (parameters_obj.data_parameter == "Distribution_by_Discourse_category")
                    {
                        o.discourse_category = JArray.FromObject(ds.Tables[0]);
                    }
                    else if (parameters_obj.data_parameter == "Distribution_by_Impact_Score")
                    {
                        o.impact_score = JArray.FromObject(ds.Tables[0]);
                    }
                    else if (parameters_obj.data_parameter == "Distribution_by_Language")
                    {
                        o.language = JArray.FromObject(ds.Tables[0]);
                    }
                    else if (parameters_obj.data_parameter == "Distribution_by_Location")
                    {
                        o.location = JArray.FromObject(ds.Tables[0]);
                    }
                    else if (parameters_obj.data_parameter == "Distribution_by_Mention_type")
                    {
                        o.mention_type = JArray.FromObject(ds.Tables[0]);
                    }
                    else if (parameters_obj.data_parameter == "Distribution_by_People_Brands_mentioned")
                    {
                        o.people_brand_mentioned = JArray.FromObject(ds.Tables[0]);
                    }
                    else if (parameters_obj.data_parameter == "Distribution_by_Sentiment")
                    {
                        o.sentimentBreakup = JArray.FromObject(ds.Tables[0]);
                    }
                    else if (parameters_obj.data_parameter == "Distribution_by_Tonality")
                    {
                        o.tonality = JArray.FromObject(ds.Tables[0]);
                    }
                    else if (parameters_obj.data_parameter == "Distribution_by_Top_Channels_by_Subscribers")
                    {
                        o.top_channels_by_subscribers = JArray.FromObject(ds.Tables[0]);
                    }
                    else if (parameters_obj.data_parameter == "Distribution_by_Top_Videos_by_Engagement")
                    {
                        o.top_videos_by_engagement = JArray.FromObject(ds.Tables[0]);
                    }
                    else if (parameters_obj.data_parameter == "Distribution_by_Top_Videos_by_Views")
                    {
                        o.top_videos_by_views = JArray.FromObject(ds.Tables[0]);
                    }
                    else if (parameters_obj.data_parameter == "Distribution_by_Topics_Discussed_In_Video")
                    {
                        o.topics_discussed_in_video = JArray.FromObject(ds.Tables[0]);
                    }
                    else if (parameters_obj.data_parameter == "Heading_stats")
                    {
                        o.counts = new JObject();
                        o.counts.twitter = (JObject)JArray.FromObject(ds.Tables[0])[0];
                        o.counts.online = (JObject)JArray.FromObject(ds.Tables[1])[0];
                        o.counts.print = (JObject)JArray.FromObject(ds.Tables[2])[0];
                        o.counts.youtube = (JObject)JArray.FromObject(ds.Tables[3])[0];
                    }
                    else if (parameters_obj.data_parameter == "Distribution_by_Type_of_video")
                    {
                        o.distribution_by_type_of_video = JArray.FromObject(ds.Tables[0]);
                    }

                    json.data = o;
                }
                Log("FetchLanding_YouTube_Optimized_Data_By_Parameter JSON Creation End", "");


                //result = File.ReadAllText(ConfigurationManager.AppSettings["FetchLanding_OnlineArticle"]);

                Log("FetchLanding_YouTube_Optimized_Data_By_Parameter SerializeObject Creation Start", "");
                result = JsonConvert.SerializeObject(json, setting);
                Log("FetchLanding_YouTube_Optimized_Data_By_Parameter SerializeObject Creation End", "");
            }
            catch (Exception ex)
            {
                Log("FetchLanding_YouTube_Optimized_Data_By_Parameter", ex.Message + " ->> " + ex.StackTrace + " Detail : " + new StreamReader(postData).ReadToEnd().ToString());
                dynamic json = new JObject();
                json.status = "Error";
                json.message = "Error Occured";

                var setting = new JsonSerializerSettings
                {
                    MaxDepth = int.MaxValue
                };
                result = JsonConvert.SerializeObject(json, setting);
            }

            return new MemoryStream(Encoding.UTF8.GetBytes(result));

        }


        #endregion

        #region Download Data

        [OperationContract]
        [WebInvoke(Method = "POST", UriTemplate = "DownloadData_OnlineArticle", ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Bare)]
        public Stream DownloadData_OnlineArticle(Stream postData)
        {
            string result = string.Empty;

            try
            {

                if (HttpContext.Current.Request.Headers["token"] != null && !String.IsNullOrEmpty(HttpContext.Current.Request.Headers["token"]))
                {
                    bool IsValid = ValidateRequest(Convert.ToString(HttpContext.Current.Request.Headers["token"]));
                    if (IsValid == false)
                    {
                        result = "401 Unauthorized";
                        return new MemoryStream(Encoding.UTF8.GetBytes(result));
                    }
                }

                WebOperationContext.Current.OutgoingResponse.ContentType = "application/json; charset=utf-8";

                eParameters parameters_obj = GetParameters(postData, "DownloadData_OnlineArticle");

                if (!String.IsNullOrEmpty(parameters_obj.UserID) && Convert.ToInt32(parameters_obj.UserID) > 0)
                {
                    new Sahadeva.API.DAL.API_V2().UserLog_Insert(Convert.ToInt32(parameters_obj.UserID), "DownloadData_OnlineArticle", Convert.ToInt32(parameters_obj.TopicID));
                }

                var setting = new JsonSerializerSettings
                {
                    MaxDepth = int.MaxValue,
                    Formatting = Newtonsoft.Json.Formatting.None
                };


                DataSet ds = new Sahadeva.API.DAL.API_V2().ArticleOnline_DownloadData(Convert.ToInt32(parameters_obj.TopicID), Convert.ToDateTime(parameters_obj.FromDate), Convert.ToDateTime(parameters_obj.ToDate), parameters_obj.Sentiment, parameters_obj.Publication_Domain, parameters_obj.Publication_Type, parameters_obj.Publication_DA, parameters_obj.Publication_Traffic, parameters_obj.Publication_ImpactScore, parameters_obj.Sort_By, parameters_obj.Sort_Order, parameters_obj.SearchText, parameters_obj.Mention_Type, parameters_obj.client_mention, Convert.ToInt32(parameters_obj.UserID), parameters_obj.headline_sentiment, parameters_obj.Article_Type, parameters_obj.exclude_by_text, parameters_obj.data_tag, parameters_obj.tml_publication_domain, parameters_obj.tml_author, Convert.ToInt32(parameters_obj.tag_id));
                dynamic json = new JObject();
                json.status = "200";
                json.message = "Success";
                json.data = new JArray();
                json.data = JArray.FromObject(ds.Tables[0]);
                json.tml_data = JArray.FromObject(ds.Tables[1]);

                //result = File.ReadAllText(ConfigurationManager.AppSettings["FetchList_OnlineArticle"]);

                result = JsonConvert.SerializeObject(json, setting);
            }
            catch (Exception ex)
            {
                Log("DownloadData_OnlineArticle", ex.Message + " ->> " + ex.StackTrace + " Detail : " + new StreamReader(postData).ReadToEnd().ToString());
                dynamic json = new JObject();
                json.status = "Error";
                json.message = "Error Occured";

                var setting = new JsonSerializerSettings
                {
                    MaxDepth = int.MaxValue,
                    Formatting = Newtonsoft.Json.Formatting.None
                };
                result = JsonConvert.SerializeObject(json, setting);
            }

            return new MemoryStream(Encoding.UTF8.GetBytes(result));

        }

        [OperationContract]
        [WebInvoke(Method = "POST", UriTemplate = "DownloadData_PrintArticle", ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Bare)]
        public Stream DownloadData_PrintArticle(Stream postData)
        {
            string result = string.Empty;

            try
            {

                if (HttpContext.Current.Request.Headers["token"] != null && !String.IsNullOrEmpty(HttpContext.Current.Request.Headers["token"]))
                {
                    bool IsValid = ValidateRequest(Convert.ToString(HttpContext.Current.Request.Headers["token"]));
                    if (IsValid == false)
                    {
                        result = "401 Unauthorized";
                        return new MemoryStream(Encoding.UTF8.GetBytes(result));
                    }
                }

                WebOperationContext.Current.OutgoingResponse.ContentType = "application/json; charset=utf-8";

                eParameters parameters_obj = GetParameters(postData, "DownloadData_PrintArticle");

                if (!String.IsNullOrEmpty(parameters_obj.UserID) && Convert.ToInt32(parameters_obj.UserID) > 0)
                {
                    new Sahadeva.API.DAL.API_V2().UserLog_Insert(Convert.ToInt32(parameters_obj.UserID), "DownloadData_PrintArticle", Convert.ToInt32(parameters_obj.TopicID));
                }

                var setting = new JsonSerializerSettings
                {
                    MaxDepth = int.MaxValue,
                    Formatting = Newtonsoft.Json.Formatting.None
                };


                DataSet ds = new Sahadeva.API.DAL.API_V2().ArticlePrint_DownloadData(Convert.ToInt32(parameters_obj.TopicID), Convert.ToDateTime(parameters_obj.FromDate), Convert.ToDateTime(parameters_obj.ToDate), parameters_obj.Sentiment, parameters_obj.Publication_Name, parameters_obj.Publication_Edition, parameters_obj.Publication_Type, parameters_obj.Publication_Circulation, parameters_obj.Publication_ImpactScore, parameters_obj.Sort_By, parameters_obj.Sort_Order, parameters_obj.SearchText, parameters_obj.Mention_Type, parameters_obj.client_mention, Convert.ToInt32(parameters_obj.UserID), parameters_obj.headline_sentiment, parameters_obj.Article_Type, parameters_obj.Author, parameters_obj.exclude_by_text, parameters_obj.Language, parameters_obj.data_tag, parameters_obj.tml_publication_name, parameters_obj.tml_author, Convert.ToInt32(parameters_obj.tag_id));

                dynamic json = new JObject();
                json.status = "200";
                json.message = "Success";
                json.data = new JArray();
                json.data = JArray.FromObject(ds.Tables[0]);
                json.tml_data = JArray.FromObject(ds.Tables[1]);

                //result = File.ReadAllText(ConfigurationManager.AppSettings["FetchList_PrintArticle"]);

                result = JsonConvert.SerializeObject(json, setting);
            }
            catch (Exception ex)
            {
                Log("DownloadData_PrintArticle", ex.Message + " ->> " + ex.StackTrace + " Detail : " + new StreamReader(postData).ReadToEnd().ToString());
                dynamic json = new JObject();
                json.status = "Error";
                json.message = "Error Occured";

                var setting = new JsonSerializerSettings
                {
                    MaxDepth = int.MaxValue,
                    Formatting = Newtonsoft.Json.Formatting.None
                };
                result = JsonConvert.SerializeObject(json, setting);
            }

            return new MemoryStream(Encoding.UTF8.GetBytes(result));

        }

        [OperationContract]
        [WebInvoke(Method = "POST", UriTemplate = "DownloadData_Twitter", ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Bare)]
        public Stream DownloadData_Twitter(Stream postData)
        {
            string result = string.Empty;

            try
            {

                if (HttpContext.Current.Request.Headers["token"] != null && !String.IsNullOrEmpty(HttpContext.Current.Request.Headers["token"]))
                {
                    bool IsValid = ValidateRequest(Convert.ToString(HttpContext.Current.Request.Headers["token"]));
                    if (IsValid == false)
                    {
                        result = "401 Unauthorized";
                        return new MemoryStream(Encoding.UTF8.GetBytes(result));
                    }
                }

                WebOperationContext.Current.OutgoingResponse.ContentType = "application/json; charset=utf-8";

                eParameters parameters_obj = GetParameters(postData, "DownloadData_Twitter");

                if (!String.IsNullOrEmpty(parameters_obj.UserID) && Convert.ToInt32(parameters_obj.UserID) > 0)
                {
                    new Sahadeva.API.DAL.API_V2().UserLog_Insert(Convert.ToInt32(parameters_obj.UserID), "DownloadData_Twitter", Convert.ToInt32(parameters_obj.TopicID));
                }

                var setting = new JsonSerializerSettings
                {
                    MaxDepth = int.MaxValue,
                    Formatting = Newtonsoft.Json.Formatting.None
                };


                DataSet ds = new Sahadeva.API.DAL.API_V2().Twitter_DownloadData(Convert.ToInt32(parameters_obj.TopicID), Convert.ToDateTime(parameters_obj.BaseDate), Convert.ToDateTime(parameters_obj.FromDate), Convert.ToDateTime(parameters_obj.ToDate), parameters_obj.Sentiment, parameters_obj.Mentioned_Hashtag, parameters_obj.Mentioned_Handle, parameters_obj.Media_Type, parameters_obj.Profile_Category, parameters_obj.Sort_By, parameters_obj.Sort_Order, parameters_obj.Mention_Type, parameters_obj.Profile_Name, parameters_obj.Profile_Handle, parameters_obj.Profile_Followerscount, parameters_obj.Participant_Type, parameters_obj.Profile_VerifiedType, Convert.ToInt32(parameters_obj.UserID), parameters_obj.Tonality, parameters_obj.Eng_Type, parameters_obj.SearchText, parameters_obj.exclude_by_text, parameters_obj.data_tag, parameters_obj.tml_handle);
                Log("DownloadData_Twitter JSON Creation start", "");
                dynamic json = new JObject();
                json.status = "200";
                json.message = "Success";
                json.data = new JArray();
                json.data = JArray.FromObject(ds.Tables[0]);
                json.tml_data = JArray.FromObject(ds.Tables[1]);
                Log("DownloadData_Twitter JSON Creation end", "");

                //result = File.ReadAllText(ConfigurationManager.AppSettings["FetchList_OnlineArticle"]);

                result = JsonConvert.SerializeObject(json, setting);
            }
            catch (Exception ex)
            {
                Log("DownloadData_Twitter", ex.Message + " ->> " + ex.StackTrace + " Detail : " + new StreamReader(postData).ReadToEnd().ToString());
                dynamic json = new JObject();
                json.status = "Error";
                json.message = "Error Occured";

                var setting = new JsonSerializerSettings
                {
                    MaxDepth = int.MaxValue,
                    Formatting = Newtonsoft.Json.Formatting.None
                };
                result = JsonConvert.SerializeObject(json, setting);
            }

            return new MemoryStream(Encoding.UTF8.GetBytes(result));

        }

        [OperationContract]
        [WebInvoke(Method = "POST", UriTemplate = "DownloadData_YouTube", ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Bare)]
        public Stream DownloadData_YouTube(Stream postData)
        {
            string result = string.Empty;

            try
            {

                if (HttpContext.Current.Request.Headers["token"] != null && !String.IsNullOrEmpty(HttpContext.Current.Request.Headers["token"]))
                {
                    bool IsValid = ValidateRequest(Convert.ToString(HttpContext.Current.Request.Headers["token"]));
                    if (IsValid == false)
                    {
                        result = "401 Unauthorized";
                        return new MemoryStream(Encoding.UTF8.GetBytes(result));
                    }
                }

                WebOperationContext.Current.OutgoingResponse.ContentType = "application/json; charset=utf-8";

                eParameters parameters_obj = GetParameters(postData, "DownloadData_YouTube");

                if (!String.IsNullOrEmpty(parameters_obj.UserID) && Convert.ToInt32(parameters_obj.UserID) > 0)
                {
                    new Sahadeva.API.DAL.API_V2().UserLog_Insert(Convert.ToInt32(parameters_obj.UserID), "DownloadData_YouTube", Convert.ToInt32(parameters_obj.TopicID));
                }

                var setting = new JsonSerializerSettings
                {
                    MaxDepth = int.MaxValue,
                    Formatting = Newtonsoft.Json.Formatting.None
                };


                DataSet ds = new Sahadeva.API.DAL.API_V2().YouTube_DownloadData(Convert.ToInt32(parameters_obj.TopicID), Convert.ToDateTime(parameters_obj.BaseDate), Convert.ToDateTime(parameters_obj.FromDate), Convert.ToDateTime(parameters_obj.ToDate),
                    parameters_obj.Video_Tags, parameters_obj.Channel_Handle, parameters_obj.Channel_Name, parameters_obj.Sentiment, parameters_obj.Tonality, parameters_obj.Channel_Category,
                    parameters_obj.Mention_Type, parameters_obj.Profile_VerifiedType, parameters_obj.Participant_Type, parameters_obj.Channel_SubscriberCount, parameters_obj.DurationInMin, parameters_obj.Video_Type,
                    parameters_obj.Discourse_Category, parameters_obj.Mentioned_Topics, parameters_obj.Publication_ImpactScore, parameters_obj.Mentioned_Locations,
                    parameters_obj.Sort_By, parameters_obj.Sort_Order, Convert.ToInt32(parameters_obj.UserID), parameters_obj.People_Brand_Mentions, parameters_obj.Language, parameters_obj.SearchText, parameters_obj.exclude_by_text, parameters_obj.data_tag, parameters_obj.tml_channel);

                dynamic json = new JObject();
                json.status = "200";
                json.message = "Success";
                json.data = new JArray();
                json.data = JArray.FromObject(ds.Tables[0]);
                json.tml_data = JArray.FromObject(ds.Tables[1]);


                result = JsonConvert.SerializeObject(json, setting);

                //result = File.ReadAllText(ConfigurationManager.AppSettings["FetchList_Youtube"]);
            }
            catch (Exception ex)
            {
                Log("DownloadData_YouTube", ex.Message + " ->> " + ex.StackTrace + " Detail : " + new StreamReader(postData).ReadToEnd().ToString());
                dynamic json = new JObject();
                json.status = "Error";
                json.message = "Error Occured";

                var setting = new JsonSerializerSettings
                {
                    MaxDepth = int.MaxValue,
                    Formatting = Newtonsoft.Json.Formatting.None
                };
                result = JsonConvert.SerializeObject(json, setting);
            }

            return new MemoryStream(Encoding.UTF8.GetBytes(result));

        }


        #endregion

        //#region Heading Stats

        //[OperationContract]
        //[WebInvoke(Method = "POST", UriTemplate = "FetchLanding_Optimized_HeadlingStats", ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Bare)]
        //public Stream FetchLanding_Optimized_HeadlingStats(Stream postData)
        //{
        //    string result = string.Empty;

        //    try
        //    {

        //        if (HttpContext.Current.Request.Headers["token"] != null && !String.IsNullOrEmpty(HttpContext.Current.Request.Headers["token"]))
        //        {
        //            bool IsValid = ValidateRequest(Convert.ToString(HttpContext.Current.Request.Headers["token"]));
        //            if (IsValid == false)
        //            {
        //                result = "401 Unauthorized";
        //                return new MemoryStream(Encoding.UTF8.GetBytes(result));
        //            }
        //        }

        //        WebOperationContext.Current.OutgoingResponse.ContentType = "application/json; charset=utf-8";

        //        //Converting to stringa and back to Stream, caz Stream losses its memory
        //        string InputBody = new StreamReader(postData).ReadToEnd().ToString();
        //        byte[] byteArray = Encoding.UTF8.GetBytes(InputBody);
        //        MemoryStream stream = new MemoryStream(byteArray);
        //        postData = stream;

        //        eParameters parameters_obj = GetParameters(postData, "FetchLanding_Optimized_HeadlingStats");

        //        if (!String.IsNullOrEmpty(parameters_obj.UserID) && Convert.ToInt32(parameters_obj.UserID) > 0)
        //        {
        //            new Sahadeva.API.DAL.API_V2().UserLog_Insert(Convert.ToInt32(parameters_obj.UserID), "FetchLanding_Optimized_HeadlingStats", Convert.ToInt32(parameters_obj.TopicID));
        //        }

        //        var setting = new JsonSerializerSettings
        //        {
        //            MaxDepth = int.MaxValue
        //        };

        //        string strDevice = "web";
        //        if (HttpContext.Current.Request.Headers["APPType"] != null && !String.IsNullOrEmpty(HttpContext.Current.Request.Headers["APPType"]))
        //        {
        //            strDevice = Convert.ToString(HttpContext.Current.Request.Headers["APPType"]);
        //        }

        //        DataSet ds = new DataSet();


        //        Log("FetchLanding_Optimized_HeadlingStats DS start", "");
        //        ds = new Sahadeva.API.DAL.API_V2().FetchLanding_Optimized_HeadlingStats(Convert.ToInt32(parameters_obj.TopicID), Convert.ToDateTime(parameters_obj.FromDate), Convert.ToDateTime(parameters_obj.ToDate), Convert.ToDateTime(parameters_obj.BaseDate), parameters_obj.hide_denominator, Convert.ToString(parameters_obj.show_percentage), strDevice);
        //        Log("FetchLanding_Optimized_HeadlingStats DS end", "");


        //        Log("FetchLanding_Optimized_HeadlingStats JSON Creation start", "");
        //        dynamic json = new JObject();
        //        if (ds.Tables.Count > 0)
        //        {
        //            json.status = "200";
        //            json.message = "Success";
        //            json.data = new JObject();

        //            dynamic o = new JObject();
        //            o.incident_id = Convert.ToInt32(parameters_obj.TopicID);
        //            o.counts = new JObject();
        //            o.counts.twitter = (JObject)JArray.FromObject(ds.Tables[0])[0];
        //            o.counts.online = (JObject)JArray.FromObject(ds.Tables[1])[0];
        //            o.counts.print = (JObject)JArray.FromObject(ds.Tables[2])[0];
        //            o.counts.youtube = (JObject)JArray.FromObject(ds.Tables[3])[0];

        //            json.data = o;
        //        }
        //        Log("FetchLanding_Optimized_HeadlingStats JSON Creation End", "");

        //        Log("FetchLanding_Optimized_HeadlingStats SerializeObject Creation Start", "");
        //        result = JsonConvert.SerializeObject(json, setting);
        //        Log("FetchLanding_Optimized_HeadlingStats SerializeObject Creation End", "");
        //    }
        //    catch (Exception ex)
        //    {
        //        Log("FetchLanding_Optimized_HeadlingStats", ex.Message + " ->> " + ex.StackTrace + " Detail : " + new StreamReader(postData).ReadToEnd().ToString());
        //        dynamic json = new JObject();
        //        json.status = "Error";
        //        json.message = "Error Occured";

        //        var setting = new JsonSerializerSettings
        //        {
        //            MaxDepth = int.MaxValue
        //        };
        //        result = JsonConvert.SerializeObject(json, setting);
        //    }

        //    return new MemoryStream(Encoding.UTF8.GetBytes(result));

        //}

        //#endregion

        #region List Pagination

        [OperationContract]
        [WebInvoke(Method = "POST", UriTemplate = "FetchList_OnlineArticle_Pagination", ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Bare)]
        public Stream FetchList_OnlineArticle_Pagination(Stream postData)
        {
            string result = string.Empty;

            try
            {

                if (HttpContext.Current.Request.Headers["token"] != null && !String.IsNullOrEmpty(HttpContext.Current.Request.Headers["token"]))
                {
                    bool IsValid = ValidateRequest(Convert.ToString(HttpContext.Current.Request.Headers["token"]));
                    if (IsValid == false)
                    {
                        result = "401 Unauthorized";
                        return new MemoryStream(Encoding.UTF8.GetBytes(result));
                    }
                }

                WebOperationContext.Current.OutgoingResponse.ContentType = "application/json; charset=utf-8";

                eParameters parameters_obj = GetParameters(postData, "FetchList_OnlineArticle_Pagination");

                if (!String.IsNullOrEmpty(parameters_obj.UserID) && Convert.ToInt32(parameters_obj.UserID) > 0)
                {
                    new Sahadeva.API.DAL.API_V2().UserLog_Insert(Convert.ToInt32(parameters_obj.UserID), "FetchList_OnlineArticle_Pagination", Convert.ToInt32(parameters_obj.TopicID));
                }

                var setting = new JsonSerializerSettings
                {
                    MaxDepth = int.MaxValue,
                    Formatting = Newtonsoft.Json.Formatting.None
                };


                DataSet ds = new Sahadeva.API.DAL.API_V2().ArticleOnline_FetchList_Pagination(Convert.ToInt32(parameters_obj.TopicID), Convert.ToDateTime(parameters_obj.FromDate), Convert.ToDateTime(parameters_obj.ToDate), parameters_obj.Sentiment, parameters_obj.Publication_Domain, parameters_obj.Publication_Type, parameters_obj.Publication_DA, parameters_obj.Publication_Traffic, parameters_obj.Publication_ImpactScore, parameters_obj.Sort_By, parameters_obj.Sort_Order, parameters_obj.SearchText, parameters_obj.Mention_Type, parameters_obj.client_mention, Convert.ToInt32(parameters_obj.UserID), parameters_obj.headline_sentiment, parameters_obj.Article_Type, parameters_obj.exclude_by_text, Convert.ToInt32(parameters_obj.last_seen_id), Convert.ToInt32(parameters_obj.page_size), parameters_obj.data_tag, Convert.ToInt32(parameters_obj.show_ids), parameters_obj.tml_publication_domain, parameters_obj.tml_author, Convert.ToInt32(parameters_obj.tag_id));
                dynamic json = new JObject();

                json.status = "200";
                json.message = "Success";

                if (ds.Tables.Count > 0)
                {
                    //json.pagination = new JArray();
                    //json.pagination = JArray.FromObject(ds.Tables[0]); 
                    json.pagination = new JObject();
                    json.pagination = (JObject)JArray.FromObject(ds.Tables[0])[0];

                    json.data = new JObject();

                    dynamic o = new JObject();
                    //o.pagination = JArray.FromObject(ds.Tables[0]);
                    if (Convert.ToInt32(parameters_obj.show_ids) == 1)
                    {
                        o = JArray.FromObject(ds.Tables[2]);
                    }
                    else
                    {
                        o = JArray.FromObject(ds.Tables[1]);
                    }

                    json.data = o;
                }


                //result = File.ReadAllText(ConfigurationManager.AppSettings["FetchList_OnlineArticle"]);

                result = JsonConvert.SerializeObject(json, setting);
            }
            catch (Exception ex)
            {
                Log("FetchList_OnlineArticle_Pagination", ex.Message + " ->> " + ex.StackTrace + " Detail : " + new StreamReader(postData).ReadToEnd().ToString());
                dynamic json = new JObject();
                json.status = "Error";
                json.message = "Error Occured";

                var setting = new JsonSerializerSettings
                {
                    MaxDepth = int.MaxValue,
                    Formatting = Newtonsoft.Json.Formatting.None
                };
                result = JsonConvert.SerializeObject(json, setting);
            }

            return new MemoryStream(Encoding.UTF8.GetBytes(result));

        }

        [OperationContract]
        [WebInvoke(Method = "POST", UriTemplate = "FetchList_PrintArticle_Pagination", ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Bare)]
        public Stream FetchList_PrintArticle_Pagination(Stream postData)
        {
            string result = string.Empty;

            try
            {

                if (HttpContext.Current.Request.Headers["token"] != null && !String.IsNullOrEmpty(HttpContext.Current.Request.Headers["token"]))
                {
                    bool IsValid = ValidateRequest(Convert.ToString(HttpContext.Current.Request.Headers["token"]));
                    if (IsValid == false)
                    {
                        result = "401 Unauthorized";
                        return new MemoryStream(Encoding.UTF8.GetBytes(result));
                    }
                }

                WebOperationContext.Current.OutgoingResponse.ContentType = "application/json; charset=utf-8";

                eParameters parameters_obj = GetParameters(postData, "FetchList_PrintArticle_Pagination");

                if (!String.IsNullOrEmpty(parameters_obj.UserID) && Convert.ToInt32(parameters_obj.UserID) > 0)
                {
                    new Sahadeva.API.DAL.API_V2().UserLog_Insert(Convert.ToInt32(parameters_obj.UserID), "FetchList_PrintArticle_Pagination", Convert.ToInt32(parameters_obj.TopicID));
                }

                var setting = new JsonSerializerSettings
                {
                    MaxDepth = int.MaxValue,
                    Formatting = Newtonsoft.Json.Formatting.None
                };


                DataSet ds = new Sahadeva.API.DAL.API_V2().ArticlePrint_FetchList_Pagination(Convert.ToInt32(parameters_obj.TopicID), Convert.ToDateTime(parameters_obj.FromDate), Convert.ToDateTime(parameters_obj.ToDate), parameters_obj.Sentiment, parameters_obj.Publication_Name, parameters_obj.Publication_Edition, parameters_obj.Publication_Type, parameters_obj.Publication_Circulation, parameters_obj.Publication_ImpactScore, parameters_obj.Sort_By, parameters_obj.Sort_Order, parameters_obj.SearchText, parameters_obj.Mention_Type, parameters_obj.client_mention, Convert.ToInt32(parameters_obj.UserID), parameters_obj.headline_sentiment, parameters_obj.Article_Type, parameters_obj.Author, parameters_obj.exclude_by_text, parameters_obj.Language, Convert.ToInt32(parameters_obj.last_seen_id), Convert.ToInt32(parameters_obj.page_size), parameters_obj.data_tag, Convert.ToInt32(parameters_obj.show_ids), parameters_obj.tml_publication_name, parameters_obj.tml_author, Convert.ToInt32(parameters_obj.tag_id));

                dynamic json = new JObject();
                json.status = "200";
                json.message = "Success";

                if (ds.Tables.Count > 0)
                {
                    json.pagination = new JObject();
                    json.pagination = (JObject)JArray.FromObject(ds.Tables[0])[0];

                    json.data = new JObject();

                    dynamic o = new JObject();

                    //o.pagination = JArray.FromObject(ds.Tables[0]);
                    if (Convert.ToInt32(parameters_obj.show_ids) == 1)
                    {
                        o = JArray.FromObject(ds.Tables[2]);
                    }
                    else
                    {
                        o = JArray.FromObject(ds.Tables[1]);
                    }

                    json.data = o;
                }

                //result = File.ReadAllText(ConfigurationManager.AppSettings["FetchList_PrintArticle"]);

                result = JsonConvert.SerializeObject(json, setting);
            }
            catch (Exception ex)
            {
                Log("FetchList_PrintArticle_Pagination", ex.Message + " ->> " + ex.StackTrace + " Detail : " + new StreamReader(postData).ReadToEnd().ToString());
                dynamic json = new JObject();
                json.status = "Error";
                json.message = "Error Occured";

                var setting = new JsonSerializerSettings
                {
                    MaxDepth = int.MaxValue,
                    Formatting = Newtonsoft.Json.Formatting.None
                };
                result = JsonConvert.SerializeObject(json, setting);
            }

            return new MemoryStream(Encoding.UTF8.GetBytes(result));

        }


        [OperationContract]
        [WebInvoke(Method = "POST", UriTemplate = "FetchList_Twitter_Pagination", ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Bare)]
        public Stream FetchList_Twitter_Pagination(Stream postData)
        {
            string result = string.Empty;

            try
            {

                if (HttpContext.Current.Request.Headers["token"] != null && !String.IsNullOrEmpty(HttpContext.Current.Request.Headers["token"]))
                {
                    bool IsValid = ValidateRequest(Convert.ToString(HttpContext.Current.Request.Headers["token"]));
                    if (IsValid == false)
                    {
                        result = "401 Unauthorized";
                        return new MemoryStream(Encoding.UTF8.GetBytes(result));
                    }
                }

                WebOperationContext.Current.OutgoingResponse.ContentType = "application/json; charset=utf-8";

                eParameters parameters_obj = GetParameters(postData, "FetchList_Twitter_Pagination");

                if (!String.IsNullOrEmpty(parameters_obj.UserID) && Convert.ToInt32(parameters_obj.UserID) > 0)
                {
                    new Sahadeva.API.DAL.API_V2().UserLog_Insert(Convert.ToInt32(parameters_obj.UserID), "FetchList_Twitter_Pagination", Convert.ToInt32(parameters_obj.TopicID));
                }

                var setting = new JsonSerializerSettings
                {
                    MaxDepth = int.MaxValue,
                    Formatting = Newtonsoft.Json.Formatting.None
                };


                DataSet ds = new Sahadeva.API.DAL.API_V2().Twitter_FetchList_Pagination(Convert.ToInt32(parameters_obj.TopicID), Convert.ToDateTime(parameters_obj.BaseDate), Convert.ToDateTime(parameters_obj.FromDate), Convert.ToDateTime(parameters_obj.ToDate), parameters_obj.Sentiment, parameters_obj.Mentioned_Hashtag, parameters_obj.Mentioned_Handle, parameters_obj.Media_Type, parameters_obj.Profile_Category, parameters_obj.Sort_By, parameters_obj.Sort_Order, parameters_obj.Mention_Type, parameters_obj.Profile_Name, parameters_obj.Profile_Handle, parameters_obj.Profile_Followerscount, parameters_obj.Participant_Type, parameters_obj.Profile_VerifiedType, Convert.ToInt32(parameters_obj.UserID), parameters_obj.Tonality, parameters_obj.Eng_Type, parameters_obj.SearchText, parameters_obj.exclude_by_text, Convert.ToInt32(parameters_obj.last_seen_id), Convert.ToInt32(parameters_obj.page_size), parameters_obj.data_tag, Convert.ToInt32(parameters_obj.show_ids), parameters_obj.tml_handle);
                Log("Twitter_FetchLanding_Pagination JSON Creation start", "");
                dynamic json = new JObject();
                json.status = "200";
                json.message = "Success";

                if (ds.Tables.Count > 0)
                {
                    json.pagination = new JObject();
                    json.pagination = (JObject)JArray.FromObject(ds.Tables[0])[0];

                    json.data = new JObject();

                    dynamic o = new JObject();

                    //o.pagination = JArray.FromObject(ds.Tables[0]);
                    if (Convert.ToInt32(parameters_obj.show_ids) == 1)
                    {
                        o = JArray.FromObject(ds.Tables[2]);
                    }
                    else
                    {
                        o = JArray.FromObject(ds.Tables[1]);
                    }

                    json.data = o;
                }
                Log("Twitter_FetchLanding_Pagination JSON Creation end", "");

                //result = File.ReadAllText(ConfigurationManager.AppSettings["FetchList_OnlineArticle"]);

                result = JsonConvert.SerializeObject(json, setting);
            }
            catch (Exception ex)
            {
                Log("FetchList_Twitter_Pagination", ex.Message + " ->> " + ex.StackTrace + " Detail : " + new StreamReader(postData).ReadToEnd().ToString());
                dynamic json = new JObject();
                json.status = "Error";
                json.message = "Error Occured";

                var setting = new JsonSerializerSettings
                {
                    MaxDepth = int.MaxValue,
                    Formatting = Newtonsoft.Json.Formatting.None
                };
                result = JsonConvert.SerializeObject(json, setting);
            }

            return new MemoryStream(Encoding.UTF8.GetBytes(result));

        }

        [OperationContract]
        [WebInvoke(Method = "POST", UriTemplate = "FetchList_YouTube_Pagination", ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Bare)]
        public Stream FetchList_YouTube_Pagination(Stream postData)
        {
            string result = string.Empty;

            try
            {

                if (HttpContext.Current.Request.Headers["token"] != null && !String.IsNullOrEmpty(HttpContext.Current.Request.Headers["token"]))
                {
                    bool IsValid = ValidateRequest(Convert.ToString(HttpContext.Current.Request.Headers["token"]));
                    if (IsValid == false)
                    {
                        result = "401 Unauthorized";
                        return new MemoryStream(Encoding.UTF8.GetBytes(result));
                    }
                }

                WebOperationContext.Current.OutgoingResponse.ContentType = "application/json; charset=utf-8";

                eParameters parameters_obj = GetParameters(postData, "FetchList_YouTube_Pagination");

                if (!String.IsNullOrEmpty(parameters_obj.UserID) && Convert.ToInt32(parameters_obj.UserID) > 0)
                {
                    new Sahadeva.API.DAL.API_V2().UserLog_Insert(Convert.ToInt32(parameters_obj.UserID), "FetchList_YouTube_Pagination", Convert.ToInt32(parameters_obj.TopicID));
                }

                var setting = new JsonSerializerSettings
                {
                    MaxDepth = int.MaxValue,
                    Formatting = Newtonsoft.Json.Formatting.None
                };


                DataSet ds = new Sahadeva.API.DAL.API_V2().YouTube_FetchList_Pagination(Convert.ToInt32(parameters_obj.TopicID), Convert.ToDateTime(parameters_obj.BaseDate), Convert.ToDateTime(parameters_obj.FromDate), Convert.ToDateTime(parameters_obj.ToDate),
                    parameters_obj.Video_Tags, parameters_obj.Channel_Handle, parameters_obj.Channel_Name, parameters_obj.Sentiment, parameters_obj.Tonality, parameters_obj.Channel_Category,
                    parameters_obj.Mention_Type, parameters_obj.Profile_VerifiedType, parameters_obj.Participant_Type, parameters_obj.Channel_SubscriberCount, parameters_obj.DurationInMin, parameters_obj.Video_Type,
                    parameters_obj.Discourse_Category, parameters_obj.Mentioned_Topics, parameters_obj.Publication_ImpactScore, parameters_obj.Mentioned_Locations,
                    parameters_obj.Sort_By, parameters_obj.Sort_Order, Convert.ToInt32(parameters_obj.UserID), parameters_obj.People_Brand_Mentions, parameters_obj.Language, parameters_obj.SearchText, parameters_obj.exclude_by_text, Convert.ToInt32(parameters_obj.last_seen_id), Convert.ToInt32(parameters_obj.page_size), parameters_obj.data_tag, Convert.ToInt32(parameters_obj.show_ids), parameters_obj.tml_channel);

                dynamic json = new JObject();
                json.status = "200";
                json.message = "Success";

                if (ds.Tables.Count > 0)
                {
                    json.pagination = new JObject();
                    json.pagination = (JObject)JArray.FromObject(ds.Tables[0])[0];

                    json.data = new JObject();

                    dynamic o = new JObject();

                    //o.pagination = JArray.FromObject(ds.Tables[0]);
                    if (Convert.ToInt32(parameters_obj.show_ids) == 1)
                    {
                        o = JArray.FromObject(ds.Tables[2]);
                    }
                    else
                    {
                        o = JArray.FromObject(ds.Tables[1]);
                    }

                    json.data = o;
                }


                result = JsonConvert.SerializeObject(json, setting);

                //result = File.ReadAllText(ConfigurationManager.AppSettings["FetchList_Youtube"]);
            }
            catch (Exception ex)
            {
                Log("FetchList_YouTube_Pagination", ex.Message + " ->> " + ex.StackTrace + " Detail : " + new StreamReader(postData).ReadToEnd().ToString());
                dynamic json = new JObject();
                json.status = "Error";
                json.message = "Error Occured";

                var setting = new JsonSerializerSettings
                {
                    MaxDepth = int.MaxValue,
                    Formatting = Newtonsoft.Json.Formatting.None
                };
                result = JsonConvert.SerializeObject(json, setting);
            }

            return new MemoryStream(Encoding.UTF8.GetBytes(result));

        }

        #endregion

        #region Participant List Pagination

        [OperationContract]
        [WebInvoke(Method = "POST", UriTemplate = "FetchList_Participant_OnlineArticle_Pagination", ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Bare)]
        public Stream FetchList_Participant_OnlineArticle_Pagination(Stream postData)
        {
            string result = string.Empty;

            try
            {

                if (HttpContext.Current.Request.Headers["token"] != null && !String.IsNullOrEmpty(HttpContext.Current.Request.Headers["token"]))
                {
                    bool IsValid = ValidateRequest(Convert.ToString(HttpContext.Current.Request.Headers["token"]));
                    if (IsValid == false)
                    {
                        result = "401 Unauthorized";
                        return new MemoryStream(Encoding.UTF8.GetBytes(result));
                    }
                }

                WebOperationContext.Current.OutgoingResponse.ContentType = "application/json; charset=utf-8";

                eParameters parameters_obj = GetParameters(postData, "FetchList_Participant_OnlineArticle_Pagination");

                if (!String.IsNullOrEmpty(parameters_obj.UserID) && Convert.ToInt32(parameters_obj.UserID) > 0)
                {
                    new Sahadeva.API.DAL.API_V2().UserLog_Insert(Convert.ToInt32(parameters_obj.UserID), "FetchList_Participant_OnlineArticle_Pagination", Convert.ToInt32(parameters_obj.TopicID));
                }

                var setting = new JsonSerializerSettings
                {
                    MaxDepth = int.MaxValue,
                    Formatting = Newtonsoft.Json.Formatting.None
                };


                DataSet ds = new Sahadeva.API.DAL.API_V2().ArticleOnline_FetchParticipant_FetchList_Pagination(Convert.ToInt32(parameters_obj.TopicID), Convert.ToDateTime(parameters_obj.FromDate), Convert.ToDateTime(parameters_obj.ToDate), parameters_obj.Sentiment, parameters_obj.Publication_Domain, parameters_obj.Publication_Type, parameters_obj.Publication_DA, parameters_obj.Publication_Traffic, parameters_obj.Publication_ImpactScore, parameters_obj.Sort_By, parameters_obj.Sort_Order, parameters_obj.SearchText, parameters_obj.Mention_Type, parameters_obj.client_mention, parameters_obj.headline_sentiment, parameters_obj.Article_Type, parameters_obj.exclude_by_text, Convert.ToInt32(parameters_obj.last_seen_id), Convert.ToInt32(parameters_obj.page_size), parameters_obj.data_tag, parameters_obj.tml_publication_domain, parameters_obj.tml_author, Convert.ToInt32(parameters_obj.tag_id));
                dynamic json = new JObject();
                json.status = "200";
                json.message = "Success";

                if (ds.Tables.Count > 0)
                {

                    json.pagination = new JObject();
                    json.pagination = (JObject)JArray.FromObject(ds.Tables[0])[0];

                    DataTable dt = ds.Tables[1];
                    json.data = new JObject();

                    // Initialize array to hold list of data rows
                    JArray dataArray = new JArray();

                    if (dt.Rows.Count > 0)
                    {
                        for (int i = 0; i < dt.Rows.Count; i++)
                        {
                            dynamic o = new JObject();
                            o.Add("incident_id", Convert.ToInt32(parameters_obj.TopicID));
                            o.Add("rn", Convert.ToInt32(dt.Rows[i]["rn"]));
                            o.profile = new JObject();
                            o.activity = new JObject();

                            for (int c = 0; c < 7; c++)
                            {
                                o.profile.Add(dt.Columns[c].ColumnName.ToString(), dt.Rows[i][c].ToString());
                            }
                            for (int c = 7; c < dt.Columns.Count - 1; c++)
                            {
                                o.activity.Add(dt.Columns[c].ColumnName.ToString(), dt.Rows[i][c].ToString());
                            }

                            dataArray.Add(o);
                        }
                    }

                    // Add the actual data array under data object
                    json.data = dataArray;
                }

                //result = File.ReadAllText(ConfigurationManager.AppSettings["FetchList_OnlineArticle"]);

                result = JsonConvert.SerializeObject(json, setting);
            }
            catch (Exception ex)
            {
                Log("FetchList_Participant_OnlineArticle_Pagination", ex.Message + " ->> " + ex.StackTrace + " Detail : " + new StreamReader(postData).ReadToEnd().ToString());
                dynamic json = new JObject();
                json.status = "Error";
                json.message = "Error Occured";

                var setting = new JsonSerializerSettings
                {
                    MaxDepth = int.MaxValue,
                    Formatting = Newtonsoft.Json.Formatting.None
                };
                result = JsonConvert.SerializeObject(json, setting);
            }

            return new MemoryStream(Encoding.UTF8.GetBytes(result));

        }

        [OperationContract]
        [WebInvoke(Method = "POST", UriTemplate = "FetchList_Participant_PrintArticle_Pagination", ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Bare)]
        public Stream FetchList_Participant_PrintArticle_Pagination(Stream postData)
        {
            string result = string.Empty;

            try
            {

                if (HttpContext.Current.Request.Headers["token"] != null && !String.IsNullOrEmpty(HttpContext.Current.Request.Headers["token"]))
                {
                    bool IsValid = ValidateRequest(Convert.ToString(HttpContext.Current.Request.Headers["token"]));
                    if (IsValid == false)
                    {
                        result = "401 Unauthorized";
                        return new MemoryStream(Encoding.UTF8.GetBytes(result));
                    }
                }

                WebOperationContext.Current.OutgoingResponse.ContentType = "application/json; charset=utf-8";

                eParameters parameters_obj = GetParameters(postData, "FetchList_Participant_PrintArticle_Pagination");

                if (!String.IsNullOrEmpty(parameters_obj.UserID) && Convert.ToInt32(parameters_obj.UserID) > 0)
                {
                    new Sahadeva.API.DAL.API_V2().UserLog_Insert(Convert.ToInt32(parameters_obj.UserID), "FetchList_Participant_PrintArticle_Pagination", Convert.ToInt32(parameters_obj.TopicID));
                }

                var setting = new JsonSerializerSettings
                {
                    MaxDepth = int.MaxValue,
                    Formatting = Newtonsoft.Json.Formatting.None
                };


                DataSet ds = new Sahadeva.API.DAL.API_V2().ArticlePrint_FetchParticipant_FetchList_Pagination(Convert.ToInt32(parameters_obj.TopicID), Convert.ToDateTime(parameters_obj.FromDate), Convert.ToDateTime(parameters_obj.ToDate), parameters_obj.Sentiment, parameters_obj.Publication_Name, parameters_obj.Publication_Edition, parameters_obj.Publication_Type, parameters_obj.Publication_Circulation, parameters_obj.Publication_ImpactScore, parameters_obj.Sort_By, parameters_obj.Sort_Order, parameters_obj.SearchText, parameters_obj.Mention_Type, parameters_obj.client_mention, parameters_obj.headline_sentiment, parameters_obj.Article_Type, parameters_obj.Author, parameters_obj.exclude_by_text, parameters_obj.Language, Convert.ToInt32(parameters_obj.last_seen_id), Convert.ToInt32(parameters_obj.page_size), parameters_obj.data_tag, parameters_obj.tml_publication_name, parameters_obj.tml_author, Convert.ToInt32(parameters_obj.tag_id));
                dynamic json = new JObject();
                json.status = "200";
                json.message = "Success";

                if (ds.Tables.Count > 0)
                {

                    json.pagination = new JObject();
                    json.pagination = (JObject)JArray.FromObject(ds.Tables[0])[0];

                    DataTable dt = ds.Tables[1];
                    json.data = new JObject();

                    // Initialize array to hold list of data rows
                    JArray dataArray = new JArray();

                    if (dt.Rows.Count > 0)
                    {
                        for (int i = 0; i < dt.Rows.Count; i++)
                        {
                            dynamic o = new JObject();
                            o.Add("incident_id", Convert.ToInt32(parameters_obj.TopicID));
                            o.Add("rn", Convert.ToInt32(dt.Rows[i]["rn"]));
                            o.profile = new JObject();
                            o.activity = new JObject();

                            for (int c = 0; c < 6; c++)
                            {
                                o.profile.Add(dt.Columns[c].ColumnName.ToString(), dt.Rows[i][c].ToString());
                            }
                            for (int c = 6; c < dt.Columns.Count - 1; c++)
                            {
                                o.activity.Add(dt.Columns[c].ColumnName.ToString(), dt.Rows[i][c].ToString());
                            }

                            dataArray.Add(o);
                        }
                    }

                    // Add the actual data array under data object
                    json.data = dataArray;
                }
                //result = File.ReadAllText(ConfigurationManager.AppSettings["FetchList_OnlineArticle"]);

                result = JsonConvert.SerializeObject(json, setting);
            }
            catch (Exception ex)
            {
                Log("FetchList_Participant_PrintArticle_Pagination", ex.Message + " ->> " + ex.StackTrace + " Detail : " + new StreamReader(postData).ReadToEnd().ToString());
                dynamic json = new JObject();
                json.status = "Error";
                json.message = "Error Occured";

                var setting = new JsonSerializerSettings
                {
                    MaxDepth = int.MaxValue,
                    Formatting = Newtonsoft.Json.Formatting.None
                };
                result = JsonConvert.SerializeObject(json, setting);
            }

            return new MemoryStream(Encoding.UTF8.GetBytes(result));

        }

        [OperationContract]
        [WebInvoke(Method = "POST", UriTemplate = "FetchList_Participant_Twitter_Pagination", ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Bare)]
        public Stream FetchList_Participant_Twitter_Pagination(Stream postData)
        {
            string result = string.Empty;

            try
            {

                if (HttpContext.Current.Request.Headers["token"] != null && !String.IsNullOrEmpty(HttpContext.Current.Request.Headers["token"]))
                {
                    bool IsValid = ValidateRequest(Convert.ToString(HttpContext.Current.Request.Headers["token"]));
                    if (IsValid == false)
                    {
                        result = "401 Unauthorized";
                        return new MemoryStream(Encoding.UTF8.GetBytes(result));
                    }
                }

                WebOperationContext.Current.OutgoingResponse.ContentType = "application/json; charset=utf-8";

                eParameters parameters_obj = GetParameters(postData, "FetchList_Participant_Twitter_Pagination");

                if (!String.IsNullOrEmpty(parameters_obj.UserID) && Convert.ToInt32(parameters_obj.UserID) > 0)
                {
                    new Sahadeva.API.DAL.API_V2().UserLog_Insert(Convert.ToInt32(parameters_obj.UserID), "FetchList_Participant_Twitter_Pagination", Convert.ToInt32(parameters_obj.TopicID));
                }

                var setting = new JsonSerializerSettings
                {
                    MaxDepth = int.MaxValue,
                    Formatting = Newtonsoft.Json.Formatting.None
                };


                DataSet ds = new Sahadeva.API.DAL.API_V2().Twitter_FetchParticipant_FetchList_Pagination(Convert.ToInt32(parameters_obj.TopicID), Convert.ToDateTime(parameters_obj.BaseDate), Convert.ToDateTime(parameters_obj.FromDate), Convert.ToDateTime(parameters_obj.ToDate), parameters_obj.Sentiment, parameters_obj.Mentioned_Hashtag, parameters_obj.Mentioned_Handle, parameters_obj.Media_Type, parameters_obj.Profile_Category, parameters_obj.Sort_By, parameters_obj.Sort_Order, parameters_obj.Mention_Type, parameters_obj.Profile_Name, parameters_obj.Profile_Handle, parameters_obj.Profile_Followerscount, parameters_obj.Participant_Type, parameters_obj.Profile_VerifiedType, parameters_obj.Tonality, parameters_obj.Eng_Type, parameters_obj.SearchText, parameters_obj.exclude_by_text, Convert.ToInt32(parameters_obj.last_seen_id), Convert.ToInt32(parameters_obj.page_size), parameters_obj.data_tag, parameters_obj.tml_handle);
                dynamic json = new JObject();
                json.status = "200";
                json.message = "Success";

                if (ds.Tables.Count > 0)
                {

                    json.pagination = new JObject();
                    json.pagination = (JObject)JArray.FromObject(ds.Tables[0])[0];

                    DataTable dt = ds.Tables[1];
                    json.data = new JObject();

                    // Initialize array to hold list of data rows
                    JArray dataArray = new JArray();

                    if (dt.Rows.Count > 0)
                    {
                        for (int i = 0; i < dt.Rows.Count; i++)
                        {
                            dynamic o = new JObject();
                            o.Add("incident_id", Convert.ToInt32(parameters_obj.TopicID));
                            o.Add("rn", Convert.ToInt32(dt.Rows[i]["rn"]));
                            o.profile = new JObject();
                            o.activity = new JObject();

                            for (int c = 0; c < 13; c++)
                            {
                                o.profile.Add(dt.Columns[c].ColumnName.ToString(), dt.Rows[i][c].ToString());
                            }
                            for (int c = 13; c < dt.Columns.Count - 1; c++)
                            {
                                o.activity.Add(dt.Columns[c].ColumnName.ToString(), dt.Rows[i][c].ToString());
                            }

                            dataArray.Add(o);
                        }
                    }

                    // Add the actual data array under data object
                    json.data = dataArray;
                }

                //result = File.ReadAllText(ConfigurationManager.AppSettings["FetchList_OnlineArticle"]);

                result = JsonConvert.SerializeObject(json, setting);
            }
            catch (Exception ex)
            {
                Log("FetchList_Participant_Twitter_Pagination", ex.Message + " ->> " + ex.StackTrace + " Detail : " + new StreamReader(postData).ReadToEnd().ToString());
                dynamic json = new JObject();
                json.status = "Error";
                json.message = "Error Occured";

                var setting = new JsonSerializerSettings
                {
                    MaxDepth = int.MaxValue,
                    Formatting = Newtonsoft.Json.Formatting.None
                };
                result = JsonConvert.SerializeObject(json, setting);
            }

            return new MemoryStream(Encoding.UTF8.GetBytes(result));

        }

        [OperationContract]
        [WebInvoke(Method = "POST", UriTemplate = "FetchList_Participant_YouTube_Pagination", ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Bare)]
        public Stream FetchList_Participant_YouTube_Pagination(Stream postData)
        {
            string result = string.Empty;

            try
            {

                if (HttpContext.Current.Request.Headers["token"] != null && !String.IsNullOrEmpty(HttpContext.Current.Request.Headers["token"]))
                {
                    bool IsValid = ValidateRequest(Convert.ToString(HttpContext.Current.Request.Headers["token"]));
                    if (IsValid == false)
                    {
                        result = "401 Unauthorized";
                        return new MemoryStream(Encoding.UTF8.GetBytes(result));
                    }
                }

                WebOperationContext.Current.OutgoingResponse.ContentType = "application/json; charset=utf-8";

                eParameters parameters_obj = GetParameters(postData, "FetchList_Participant_YouTube_Pagination");

                if (!String.IsNullOrEmpty(parameters_obj.UserID) && Convert.ToInt32(parameters_obj.UserID) > 0)
                {
                    new Sahadeva.API.DAL.API_V2().UserLog_Insert(Convert.ToInt32(parameters_obj.UserID), "FetchList_Participant_YouTube_Pagination", Convert.ToInt32(parameters_obj.TopicID));
                }

                var setting = new JsonSerializerSettings
                {
                    MaxDepth = int.MaxValue,
                    Formatting = Newtonsoft.Json.Formatting.None
                };


                DataSet ds = new Sahadeva.API.DAL.API_V2().YouTube_FetchParticipant_FetchList_Pagination(Convert.ToInt32(parameters_obj.TopicID), Convert.ToDateTime(parameters_obj.BaseDate), Convert.ToDateTime(parameters_obj.FromDate), Convert.ToDateTime(parameters_obj.ToDate),
                    parameters_obj.Video_Tags, parameters_obj.Channel_Handle, parameters_obj.Channel_Name, parameters_obj.Sentiment, parameters_obj.Tonality, parameters_obj.Channel_Category,
                    parameters_obj.Mention_Type, parameters_obj.Profile_VerifiedType, parameters_obj.Participant_Type, parameters_obj.Channel_SubscriberCount, parameters_obj.DurationInMin, parameters_obj.Video_Type,
                    parameters_obj.Discourse_Category, parameters_obj.Mentioned_Topics, parameters_obj.Publication_ImpactScore, parameters_obj.Mentioned_Locations,
                    parameters_obj.Sort_By, parameters_obj.Sort_Order, Convert.ToInt32(parameters_obj.UserID), parameters_obj.People_Brand_Mentions, parameters_obj.Language, parameters_obj.SearchText, parameters_obj.exclude_by_text, Convert.ToInt32(parameters_obj.last_seen_id), Convert.ToInt32(parameters_obj.page_size), parameters_obj.data_tag, parameters_obj.tml_channel);

                dynamic json = new JObject();
                json.status = "200";
                json.message = "Success";

                if (ds.Tables.Count > 0)
                {

                    json.pagination = new JObject();
                    json.pagination = (JObject)JArray.FromObject(ds.Tables[0])[0];

                    DataTable dt = ds.Tables[1];
                    json.data = new JObject();

                    // Initialize array to hold list of data rows
                    JArray dataArray = new JArray();

                    if (dt.Rows.Count > 0)
                    {
                        for (int i = 0; i < dt.Rows.Count; i++)
                        {
                            dynamic o = new JObject();
                            o.Add("incident_id", Convert.ToInt32(parameters_obj.TopicID));
                            o.Add("rn", Convert.ToInt32(dt.Rows[i]["rn"]));
                            o.channel = new JObject();
                            o.activity = new JObject();

                            for (int c = 0; c < 17; c++)
                            {
                                o.channel.Add(dt.Columns[c].ColumnName.ToString(), dt.Rows[i][c].ToString());
                            }
                            for (int c = 17; c < dt.Columns.Count - 1; c++)
                            {
                                o.activity.Add(dt.Columns[c].ColumnName.ToString(), dt.Rows[i][c].ToString());
                            }

                            dataArray.Add(o);
                        }
                    }

                    // Add the actual data array under data object
                    json.data = dataArray;
                }


                //result = File.ReadAllText(ConfigurationManager.AppSettings["FetchList_Participant_YouTube"]);

                result = JsonConvert.SerializeObject(json, setting);
            }
            catch (Exception ex)
            {
                Log("FetchList_Participant_YouTube_Pagination", ex.Message + " ->> " + ex.StackTrace + " Detail : " + new StreamReader(postData).ReadToEnd().ToString());
                dynamic json = new JObject();
                json.status = "Error";
                json.message = "Error Occured";

                var setting = new JsonSerializerSettings
                {
                    MaxDepth = int.MaxValue,
                    Formatting = Newtonsoft.Json.Formatting.None
                };
                result = JsonConvert.SerializeObject(json, setting);
            }

            return new MemoryStream(Encoding.UTF8.GetBytes(result));

        }

        #endregion

        #region List Page View Chart
        [OperationContract]
        [WebInvoke(Method = "POST", UriTemplate = "FetchList_OnlineArticle_ListPage_ViewChart", ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Bare)]
        public Stream FetchList_OnlineArticle_ListPage_ViewChart(Stream postData)
        {
            string result = string.Empty;

            try
            {

                if (HttpContext.Current.Request.Headers["token"] != null && !String.IsNullOrEmpty(HttpContext.Current.Request.Headers["token"]))
                {
                    bool IsValid = ValidateRequest(Convert.ToString(HttpContext.Current.Request.Headers["token"]));
                    if (IsValid == false)
                    {
                        result = "401 Unauthorized";
                        return new MemoryStream(Encoding.UTF8.GetBytes(result));
                    }
                }

                WebOperationContext.Current.OutgoingResponse.ContentType = "application/json; charset=utf-8";

                eParameters parameters_obj = GetParameters(postData, "FetchList_OnlineArticle_ListPage_ViewChart");

                if (!String.IsNullOrEmpty(parameters_obj.UserID) && Convert.ToInt32(parameters_obj.UserID) > 0)
                {
                    new Sahadeva.API.DAL.API_V2().UserLog_Insert(Convert.ToInt32(parameters_obj.UserID), "FetchList_OnlineArticle_ListPage_ViewChart", Convert.ToInt32(parameters_obj.TopicID));
                }

                var setting = new JsonSerializerSettings
                {
                    MaxDepth = int.MaxValue,
                    Formatting = Newtonsoft.Json.Formatting.None
                };


                DataTable dt = new Sahadeva.API.DAL.API_V2().ArticleOnline_FetchList_ListPage_ViewChart(Convert.ToInt32(parameters_obj.TopicID), Convert.ToDateTime(parameters_obj.FromDate), Convert.ToDateTime(parameters_obj.ToDate), parameters_obj.Sentiment, parameters_obj.Publication_Domain, parameters_obj.Publication_Type, parameters_obj.Publication_DA, parameters_obj.Publication_Traffic, parameters_obj.Publication_ImpactScore, parameters_obj.Sort_By, parameters_obj.Sort_Order, parameters_obj.SearchText, parameters_obj.Mention_Type, parameters_obj.client_mention, Convert.ToInt32(parameters_obj.UserID), parameters_obj.headline_sentiment, parameters_obj.Article_Type, parameters_obj.exclude_by_text, parameters_obj.data_tag, parameters_obj.tml_publication_domain, parameters_obj.tml_author, Convert.ToInt32(parameters_obj.tag_id));
                dynamic json = new JObject();
                json.status = "200";
                json.message = "Success";
                json.data = new JArray();
                json.data = JArray.FromObject(dt);

                //result = File.ReadAllText(ConfigurationManager.AppSettings["FetchList_OnlineArticle"]);

                result = JsonConvert.SerializeObject(json, setting);
            }
            catch (Exception ex)
            {
                Log("FetchList_OnlineArticle_ListPage_ViewChart", ex.Message + " ->> " + ex.StackTrace + " Detail : " + new StreamReader(postData).ReadToEnd().ToString());
                dynamic json = new JObject();
                json.status = "Error";
                json.message = "Error Occured";

                var setting = new JsonSerializerSettings
                {
                    MaxDepth = int.MaxValue,
                    Formatting = Newtonsoft.Json.Formatting.None
                };
                result = JsonConvert.SerializeObject(json, setting);
            }

            return new MemoryStream(Encoding.UTF8.GetBytes(result));

        }

        [OperationContract]
        [WebInvoke(Method = "POST", UriTemplate = "FetchList_PrintArticle_ListPage_ViewChart", ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Bare)]
        public Stream FetchList_PrintArticle_ListPage_ViewChart(Stream postData)
        {
            string result = string.Empty;

            try
            {

                if (HttpContext.Current.Request.Headers["token"] != null && !String.IsNullOrEmpty(HttpContext.Current.Request.Headers["token"]))
                {
                    bool IsValid = ValidateRequest(Convert.ToString(HttpContext.Current.Request.Headers["token"]));
                    if (IsValid == false)
                    {
                        result = "401 Unauthorized";
                        return new MemoryStream(Encoding.UTF8.GetBytes(result));
                    }
                }

                WebOperationContext.Current.OutgoingResponse.ContentType = "application/json; charset=utf-8";

                eParameters parameters_obj = GetParameters(postData, "FetchList_PrintArticle_ListPage_ViewChart");

                if (!String.IsNullOrEmpty(parameters_obj.UserID) && Convert.ToInt32(parameters_obj.UserID) > 0)
                {
                    new Sahadeva.API.DAL.API_V2().UserLog_Insert(Convert.ToInt32(parameters_obj.UserID), "FetchList_PrintArticle_ListPage_ViewChart", Convert.ToInt32(parameters_obj.TopicID));
                }

                var setting = new JsonSerializerSettings
                {
                    MaxDepth = int.MaxValue,
                    Formatting = Newtonsoft.Json.Formatting.None
                };


                DataTable dt = new Sahadeva.API.DAL.API_V2().ArticlePrint_FetchList_ListPage_ViewChart(Convert.ToInt32(parameters_obj.TopicID), Convert.ToDateTime(parameters_obj.FromDate), Convert.ToDateTime(parameters_obj.ToDate), parameters_obj.Sentiment, parameters_obj.Publication_Name, parameters_obj.Publication_Edition, parameters_obj.Publication_Type, parameters_obj.Publication_Circulation, parameters_obj.Publication_ImpactScore, parameters_obj.Sort_By, parameters_obj.Sort_Order, parameters_obj.SearchText, parameters_obj.Mention_Type, parameters_obj.client_mention, Convert.ToInt32(parameters_obj.UserID), parameters_obj.headline_sentiment, parameters_obj.Article_Type, parameters_obj.Author, parameters_obj.exclude_by_text, parameters_obj.Language, parameters_obj.data_tag, parameters_obj.tml_publication_name, parameters_obj.tml_author, Convert.ToInt32(parameters_obj.tag_id));

                dynamic json = new JObject();
                json.status = "200";
                json.message = "Success";
                json.data = new JArray();
                json.data = JArray.FromObject(dt);

                //result = File.ReadAllText(ConfigurationManager.AppSettings["FetchList_PrintArticle"]);

                result = JsonConvert.SerializeObject(json, setting);
            }
            catch (Exception ex)
            {
                Log("FetchList_PrintArticle_ListPage_ViewChart", ex.Message + " ->> " + ex.StackTrace + " Detail : " + new StreamReader(postData).ReadToEnd().ToString());
                dynamic json = new JObject();
                json.status = "Error";
                json.message = "Error Occured";

                var setting = new JsonSerializerSettings
                {
                    MaxDepth = int.MaxValue,
                    Formatting = Newtonsoft.Json.Formatting.None
                };
                result = JsonConvert.SerializeObject(json, setting);
            }

            return new MemoryStream(Encoding.UTF8.GetBytes(result));

        }

        [OperationContract]
        [WebInvoke(Method = "POST", UriTemplate = "FetchList_Twitter_ListPage_ViewChart", ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Bare)]
        public Stream FetchList_Twitter_ListPage_ViewChart(Stream postData)
        {
            string result = string.Empty;

            try
            {

                if (HttpContext.Current.Request.Headers["token"] != null && !String.IsNullOrEmpty(HttpContext.Current.Request.Headers["token"]))
                {
                    bool IsValid = ValidateRequest(Convert.ToString(HttpContext.Current.Request.Headers["token"]));
                    if (IsValid == false)
                    {
                        result = "401 Unauthorized";
                        return new MemoryStream(Encoding.UTF8.GetBytes(result));
                    }
                }

                WebOperationContext.Current.OutgoingResponse.ContentType = "application/json; charset=utf-8";

                eParameters parameters_obj = GetParameters(postData, "FetchList_Twitter_ListPage_ViewChart");

                if (!String.IsNullOrEmpty(parameters_obj.UserID) && Convert.ToInt32(parameters_obj.UserID) > 0)
                {
                    new Sahadeva.API.DAL.API_V2().UserLog_Insert(Convert.ToInt32(parameters_obj.UserID), "FetchList_Twitter_ListPage_ViewChart", Convert.ToInt32(parameters_obj.TopicID));
                }

                var setting = new JsonSerializerSettings
                {
                    MaxDepth = int.MaxValue,
                    Formatting = Newtonsoft.Json.Formatting.None
                };


                DataTable dt = new Sahadeva.API.DAL.API_V2().Twitter_FetchList_ListPage_ViewChart(Convert.ToInt32(parameters_obj.TopicID), Convert.ToDateTime(parameters_obj.BaseDate), Convert.ToDateTime(parameters_obj.FromDate), Convert.ToDateTime(parameters_obj.ToDate), parameters_obj.Sentiment, parameters_obj.Mentioned_Hashtag, parameters_obj.Mentioned_Handle, parameters_obj.Media_Type, parameters_obj.Profile_Category, parameters_obj.Sort_By, parameters_obj.Sort_Order, parameters_obj.Mention_Type, parameters_obj.Profile_Name, parameters_obj.Profile_Handle, parameters_obj.Profile_Followerscount, parameters_obj.Participant_Type, parameters_obj.Profile_VerifiedType, Convert.ToInt32(parameters_obj.UserID), parameters_obj.Tonality, parameters_obj.Eng_Type, parameters_obj.SearchText, parameters_obj.exclude_by_text, parameters_obj.data_tag, parameters_obj.tml_handle);
                Log("Twitter_FetchList_ListPage_ViewChart JSON Creation start", "");
                dynamic json = new JObject();
                json.status = "200";
                json.message = "Success";
                json.data = new JArray();
                json.data = JArray.FromObject(dt);
                Log("Twitter_FetchList_ListPage_ViewChart JSON Creation end", "");

                //result = File.ReadAllText(ConfigurationManager.AppSettings["FetchList_OnlineArticle"]);

                result = JsonConvert.SerializeObject(json, setting);
            }
            catch (Exception ex)
            {
                Log("FetchList_Twitter_ListPage_ViewChart", ex.Message + " ->> " + ex.StackTrace + " Detail : " + new StreamReader(postData).ReadToEnd().ToString());
                dynamic json = new JObject();
                json.status = "Error";
                json.message = "Error Occured";

                var setting = new JsonSerializerSettings
                {
                    MaxDepth = int.MaxValue,
                    Formatting = Newtonsoft.Json.Formatting.None
                };
                result = JsonConvert.SerializeObject(json, setting);
            }

            return new MemoryStream(Encoding.UTF8.GetBytes(result));

        }

        [OperationContract]
        [WebInvoke(Method = "POST", UriTemplate = "FetchList_YouTube_ListPage_ViewChart", ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Bare)]
        public Stream FetchList_YouTube_ListPage_ViewChart(Stream postData)
        {
            string result = string.Empty;

            try
            {

                if (HttpContext.Current.Request.Headers["token"] != null && !String.IsNullOrEmpty(HttpContext.Current.Request.Headers["token"]))
                {
                    bool IsValid = ValidateRequest(Convert.ToString(HttpContext.Current.Request.Headers["token"]));
                    if (IsValid == false)
                    {
                        result = "401 Unauthorized";
                        return new MemoryStream(Encoding.UTF8.GetBytes(result));
                    }
                }

                WebOperationContext.Current.OutgoingResponse.ContentType = "application/json; charset=utf-8";

                eParameters parameters_obj = GetParameters(postData, "FetchList_YouTube_ListPage_ViewChart");

                if (!String.IsNullOrEmpty(parameters_obj.UserID) && Convert.ToInt32(parameters_obj.UserID) > 0)
                {
                    new Sahadeva.API.DAL.API_V2().UserLog_Insert(Convert.ToInt32(parameters_obj.UserID), "FetchList_YouTube", Convert.ToInt32(parameters_obj.TopicID));
                }

                var setting = new JsonSerializerSettings
                {
                    MaxDepth = int.MaxValue,
                    Formatting = Newtonsoft.Json.Formatting.None
                };


                DataTable dt = new Sahadeva.API.DAL.API_V2().YouTube_FetchList_ListPage_ViewChart(Convert.ToInt32(parameters_obj.TopicID), Convert.ToDateTime(parameters_obj.BaseDate), Convert.ToDateTime(parameters_obj.FromDate), Convert.ToDateTime(parameters_obj.ToDate),
                    parameters_obj.Video_Tags, parameters_obj.Channel_Handle, parameters_obj.Channel_Name, parameters_obj.Sentiment, parameters_obj.Tonality, parameters_obj.Channel_Category,
                    parameters_obj.Mention_Type, parameters_obj.Profile_VerifiedType, parameters_obj.Participant_Type, parameters_obj.Channel_SubscriberCount, parameters_obj.DurationInMin, parameters_obj.Video_Type,
                    parameters_obj.Discourse_Category, parameters_obj.Mentioned_Topics, parameters_obj.Publication_ImpactScore, parameters_obj.Mentioned_Locations,
                    parameters_obj.Sort_By, parameters_obj.Sort_Order, Convert.ToInt32(parameters_obj.UserID), parameters_obj.People_Brand_Mentions, parameters_obj.Language, parameters_obj.SearchText, parameters_obj.exclude_by_text, parameters_obj.data_tag, parameters_obj.tml_channel);

                dynamic json = new JObject();
                json.status = "200";
                json.message = "Success";
                json.data = new JArray();
                json.data = JArray.FromObject(dt);


                result = JsonConvert.SerializeObject(json, setting);

                //result = File.ReadAllText(ConfigurationManager.AppSettings["FetchList_Youtube"]);
            }
            catch (Exception ex)
            {
                Log("FetchList_YouTube_ListPage_ViewChart", ex.Message + " ->> " + ex.StackTrace + " Detail : " + new StreamReader(postData).ReadToEnd().ToString());
                dynamic json = new JObject();
                json.status = "Error";
                json.message = "Error Occured";

                var setting = new JsonSerializerSettings
                {
                    MaxDepth = int.MaxValue,
                    Formatting = Newtonsoft.Json.Formatting.None
                };
                result = JsonConvert.SerializeObject(json, setting);
            }

            return new MemoryStream(Encoding.UTF8.GetBytes(result));

        }
        #endregion

        #region User Marked Irrelevant

        [OperationContract]
        [WebInvoke(Method = "POST", UriTemplate = "MarkRelevancy", ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Bare)]
        public Stream MarkRelevancy(Stream postData)
        {
            string result = string.Empty;

            try
            {

                if (HttpContext.Current.Request.Headers["token"] != null && !String.IsNullOrEmpty(HttpContext.Current.Request.Headers["token"]))
                {
                    bool IsValid = ValidateRequest(Convert.ToString(HttpContext.Current.Request.Headers["token"]));
                    if (IsValid == false)
                    {
                        result = "401 Unauthorized";
                        return new MemoryStream(Encoding.UTF8.GetBytes(result));
                    }
                }

                WebOperationContext.Current.OutgoingResponse.ContentType = "application/json; charset=utf-8";

                //eParameters parameters_obj = GetParameters(postData, "CreateIncident");

                var setting = new JsonSerializerSettings
                {
                    MaxDepth = int.MaxValue,
                    Formatting = Newtonsoft.Json.Formatting.None
                };

                string InputBody = new StreamReader(postData).ReadToEnd().ToString();

                Int32 RecordID_Output = 0;
                dynamic stuff = JObject.Parse(InputBody);

                Log("MarkRelevancy", InputBody);

                string strDevice = "web";
                if (HttpContext.Current.Request.Headers["APPType"] != null && !String.IsNullOrEmpty(HttpContext.Current.Request.Headers["APPType"]))
                {
                    strDevice = Convert.ToString(HttpContext.Current.Request.Headers["APPType"]);
                }

                List<int> recIds = new List<int>();
                Int32 UserID = Convert.ToInt32(Convert.ToString(stuff.user_id));
                string platform = Convert.ToString(Convert.ToString(stuff.platform));
                //string RecordIDs = Convert.ToString(Convert.ToString(stuff.record_ids));
                string Reason = Convert.ToString(stuff.reason);
                Int32 PlatformID = 0;
                Int32 IsRelevant = Convert.ToBoolean(Convert.ToString(stuff.is_relevant)) ? 1 : 0;
                Int32 IncidentID = Convert.ToInt32(Convert.ToString(stuff.incident_id));

                if (platform == "online") { PlatformID = 1; }
                if (platform == "print") { PlatformID = 2; }
                if (platform == "twitter") { PlatformID = 3; }
                if (platform == "youtube") { PlatformID = 4; }

                if (strDevice != "web")
                {
                    recIds = ((JArray)stuff.record_ids).ToObject<List<int>>();
                }
                else
                {
                    List<int> Seleected_recIds = ((JArray)stuff.record_ids).ToObject<List<int>>();

                    List<int> UnSelected_recIds = ((JArray)stuff.user_unselected_records).ToObject<List<int>>();

                    Int32 is_user_selected_all = Convert.ToInt32(Convert.ToString(stuff.is_user_selected_all));
                    Int32 is_user_unselected = Convert.ToInt32(Convert.ToString(stuff.is_user_unselected));

                    #region fetch IDs for select all
                    if (is_user_selected_all == 1 || is_user_unselected == 1)
                    {
                        #region Online
                        if (PlatformID == 1)
                        {
                            dynamic payload = stuff.list_page_payload;

                            int TopicID = Convert.ToInt32(payload.incident_id.ToString());
                            int PayloadUserID = Convert.ToInt32(payload.UserID.ToString());
                            DateTime FromDate = Convert.ToDateTime(payload.from_date.ToString());
                            DateTime ToDate = Convert.ToDateTime(payload.to_date.ToString());
                            string Sentiment = payload.sentiment.ToString();
                            string PublicationDomain = payload.publication_domain.ToString();
                            string PublicationType = payload.publication_type.ToString();
                            string PublicationImpactScore = payload.publication_impactscore.ToString();
                            string PublicationDA = payload.publication_da.ToString();
                            string PublicationTraffic = payload.publication_traffic.ToString();
                            string SortBy = payload.sort_by.ToString();
                            string SortOrder = payload.sort_order.ToString();
                            string SearchText = payload.search_text.ToString();
                            string MentionType = payload.mention_type.ToString();
                            string ClientMention = payload.client_mention.ToString();
                            string HeadlineSentiment = payload.headline_sentiment.ToString();
                            string ArticleType = payload.article_type.ToString();
                            string ExcludeByText = payload.exclude_by_text.ToString();
                            int LastSeenId = Convert.ToInt32(payload.last_seen_id.ToString());
                            int PageSize = Convert.ToInt32(payload.page_size.ToString());
                            string data_tag = payload.data_tag.ToString();
                            string TML_Publication_Domain = payload.tml_publication_domain.ToString();
                            string TML_Author = payload.tml_author.ToString();
                            int show_ids = 1;
                            int TagID = Convert.ToInt32(payload.tag_id.ToString());

                            DataSet ds = new Sahadeva.API.DAL.API_V2().ArticleOnline_FetchList_Pagination(TopicID, FromDate, ToDate, Sentiment, PublicationDomain, PublicationType, PublicationDA, PublicationTraffic, PublicationImpactScore, SortBy, SortOrder, SearchText, MentionType, ClientMention, PayloadUserID, HeadlineSentiment, ArticleType, ExcludeByText, LastSeenId, PageSize, data_tag, show_ids, TML_Publication_Domain, TML_Author, TagID);

                            if (ds != null && ds.Tables.Count > 1 && ds.Tables[2].Rows.Count > 0)
                            {
                                recIds = ds.Tables[2].AsEnumerable().Select(row => Convert.ToInt32(row["article_id"])).ToList();
                            }

                            if (is_user_unselected == 1 && UnSelected_recIds != null)
                            {
                                recIds = recIds.Where(x => !UnSelected_recIds.Contains(x)).ToList();
                            }
                        }
                        #endregion

                        #region Print
                        if (PlatformID == 2)
                        {
                            dynamic payload = stuff.list_page_payload;

                            int TopicID = Convert.ToInt32(payload.incident_id.ToString());
                            int PayloadUserID = Convert.ToInt32(payload.UserID.ToString());
                            int LastSeenId = Convert.ToInt32(payload.last_seen_id.ToString());
                            int PageSize = Convert.ToInt32(payload.page_size.ToString());


                            DateTime FromDate = Convert.ToDateTime(payload.from_date.ToString());
                            DateTime ToDate = Convert.ToDateTime(payload.to_date.ToString());

                            string Sentiment = Convert.ToString(payload.sentiment);
                            string HeadlineSentiment = Convert.ToString(payload.headline_sentiment);
                            string PublicationName = Convert.ToString(payload.publication_name);
                            string PublicationType = Convert.ToString(payload.publication_type);
                            string PublicationImpactScore = Convert.ToString(payload.publication_impactscore);
                            string PublicationEdition = Convert.ToString(payload.publication_edition);
                            string PublicationCirculation = Convert.ToString(payload.publication_circulation);
                            string SearchText = Convert.ToString(payload.search_text);
                            string ExcludeByText = Convert.ToString(payload.exclude_by_text);
                            string ClientMention = Convert.ToString(payload.client_mention);
                            string MentionType = Convert.ToString(payload.mention_type);
                            string ArticleType = Convert.ToString(payload.article_type);
                            string Author = Convert.ToString(payload.author);
                            string SortBy = Convert.ToString(payload.sort_by);
                            string SortOrder = Convert.ToString(payload.sort_order);
                            string Language = Convert.ToString(payload.language);
                            string DataTag = Convert.ToString(payload.data_tag);
                            int show_ids = 1;
                            string TML_Publication_Name = payload.tml_publication_name.ToString();
                            string TML_Author = payload.tml_author.ToString();
                            int TagID = Convert.ToInt32(payload.tag_id.ToString());

                            DataSet ds = new Sahadeva.API.DAL.API_V2().ArticlePrint_FetchList_Pagination(TopicID, FromDate, ToDate, Sentiment, PublicationName, PublicationEdition, PublicationType, PublicationCirculation, PublicationImpactScore, SortBy, SortOrder, SearchText, MentionType, ClientMention, PayloadUserID, HeadlineSentiment, ArticleType, Author, ExcludeByText, Language, LastSeenId, PageSize, DataTag, show_ids, TML_Publication_Name, TML_Author, TagID);

                            if (ds != null && ds.Tables.Count > 1 && ds.Tables[2].Rows.Count > 0)
                            {
                                recIds = ds.Tables[2].AsEnumerable().Select(row => Convert.ToInt32(row["article_id"])).ToList();
                            }

                            if (is_user_unselected == 1 && UnSelected_recIds != null)
                            {
                                recIds = recIds.Where(x => !UnSelected_recIds.Contains(x)).ToList();
                            }

                        }

                        #endregion

                        #region Twitter
                        if (PlatformID == 3)
                        {
                            dynamic payload = stuff.list_page_payload;

                            int TopicID = Convert.ToInt32(payload.incident_id.ToString());
                            int PayloadUserID = Convert.ToInt32(payload.UserID.ToString());

                            DateTime BaseDate = Convert.ToDateTime(payload.base_date.ToString());
                            DateTime FromDate = Convert.ToDateTime(payload.from_date.ToString());
                            DateTime ToDate = Convert.ToDateTime(payload.to_date.ToString());

                            string Sentiment = Convert.ToString(payload.sentiment);
                            string MentionedHashtag = Convert.ToString(payload.mentioned_hashtag);
                            string MentionedHandle = Convert.ToString(payload.mentioned_handle);
                            string MediaType = Convert.ToString(payload.media_type);
                            string ProfileCategory = Convert.ToString(payload.profile_category);
                            string SortBy = Convert.ToString(payload.sort_by);
                            string SortOrder = Convert.ToString(payload.sort_order);
                            string MentionType = Convert.ToString(payload.mention_type);
                            string ProfileName = Convert.ToString(payload.profile_name);
                            string ProfileHandle = Convert.ToString(payload.profile_handle);
                            string ProfileFollowersCount = Convert.ToString(payload.profile_followerscount);
                            string ParticipantType = Convert.ToString(payload.participant_type);
                            string ProfileVerifiedType = Convert.ToString(payload.profile_verifiedtype);
                            string Tonality = Convert.ToString(payload.tonality);
                            string EngType = Convert.ToString(payload.eng_type);
                            string SearchText = Convert.ToString(payload.search_text);
                            string ExcludeByText = Convert.ToString(payload.exclude_by_text);

                            int LastSeenId = Convert.ToInt32(payload.last_seen_id.ToString());
                            int PageSize = Convert.ToInt32(payload.page_size.ToString());
                            string data_tag = payload.data_tag.ToString();
                            int show_ids = 1;
                            string TML_Handle = payload.tml_handle.ToString();

                            DataSet ds = new Sahadeva.API.DAL.API_V2().Twitter_FetchList_Pagination(TopicID, BaseDate, FromDate, ToDate, Sentiment, MentionedHashtag, MentionedHandle, MediaType, ProfileCategory, SortBy, SortOrder, MentionType, ProfileName, ProfileHandle, ProfileFollowersCount, ParticipantType, ProfileVerifiedType, PayloadUserID, Tonality, EngType, SearchText, ExcludeByText, LastSeenId, PageSize, data_tag, show_ids, TML_Handle);

                            if (ds != null && ds.Tables.Count > 1 && ds.Tables[2].Rows.Count > 0)
                            {
                                recIds = ds.Tables[2].AsEnumerable()
                                    .Select(row => Convert.ToInt32(row["twitter_id"]))
                                    .ToList();
                            }

                            if (is_user_unselected == 1 && UnSelected_recIds != null)
                            {
                                recIds = recIds.Where(x => !UnSelected_recIds.Contains(x)).ToList();
                            }

                        }
                        #endregion

                        #region YT
                        if (PlatformID == 4)
                        {
                            dynamic payload = stuff.list_page_payload;

                            int TopicID = Convert.ToInt32(payload.incident_id.ToString());
                            int PayloadUserID = Convert.ToInt32(payload.UserID.ToString());
                            int LastSeenId = Convert.ToInt32(payload.last_seen_id.ToString());
                            int PageSize = Convert.ToInt32(payload.page_size.ToString());

                            DateTime BaseDate = Convert.ToDateTime(payload.base_date.ToString());
                            DateTime FromDate = Convert.ToDateTime(payload.from_date.ToString());
                            DateTime ToDate = Convert.ToDateTime(payload.to_date.ToString());

                            string VideoTags = Convert.ToString(payload.video_tags);
                            string ChannelHandle = Convert.ToString(payload.channel_handle);
                            string ChannelName = Convert.ToString(payload.channel_name);
                            string Sentiment = Convert.ToString(payload.sentiment);
                            string Tonality = Convert.ToString(payload.tonality);
                            string ChannelCategory = Convert.ToString(payload.channel_category);
                            string MentionType = Convert.ToString(payload.mention_type);
                            string ProfileVerifiedType = Convert.ToString(payload.profile_verifiedtype);
                            string ParticipantType = Convert.ToString(payload.participant_type);
                            string ChannelSubscriberCount = Convert.ToString(payload.channel_subscriber_count);
                            string DurationInMin = Convert.ToString(payload.duration_in_min);
                            string VideoType = Convert.ToString(payload.video_type);
                            string DiscourseCategory = Convert.ToString(payload.discourse_category);
                            string MentionedTopics = Convert.ToString(payload.mentioned_topics);
                            string MentionedLocations = Convert.ToString(payload.mentioned_locations);
                            string PeopleBrandMentions = Convert.ToString(payload.people_brand_mentions);
                            string PublicationImpactScore = Convert.ToString(payload.publication_impactscore);
                            string Language = Convert.ToString(payload.language);
                            string SortBy = Convert.ToString(payload.sort_by);
                            string SortOrder = Convert.ToString(payload.sort_order);
                            string ExcludeByText = Convert.ToString(payload.exclude_by_text);
                            string SearchText = Convert.ToString(payload.search_text);
                            string DataTag = Convert.ToString(payload.data_tag);
                            int show_ids = 1;
                            string TML_Channel = Convert.ToString(payload.tml_channel);

                            DataSet ds = new Sahadeva.API.DAL.API_V2().YouTube_FetchList_Pagination(TopicID, BaseDate, FromDate, ToDate, VideoTags, ChannelHandle, ChannelName, Sentiment, Tonality, ChannelCategory, MentionType, ProfileVerifiedType, ParticipantType, ChannelSubscriberCount, DurationInMin, VideoType, DiscourseCategory, MentionedTopics, PublicationImpactScore, MentionedLocations, SortBy, SortOrder, PayloadUserID, PeopleBrandMentions, Language, SearchText, ExcludeByText, LastSeenId, PageSize, DataTag, show_ids, TML_Channel);

                            if (ds != null && ds.Tables.Count > 1 && ds.Tables[2].Rows.Count > 0)
                            {
                                recIds = ds.Tables[2].AsEnumerable().Select(row => Convert.ToInt32(row["video_id"])).ToList();
                            }

                            if (is_user_unselected == 1 && UnSelected_recIds != null)
                            {
                                recIds = recIds.Where(x => !UnSelected_recIds.Contains(x)).ToList();
                            }
                        }
                        #endregion

                    }
                    else
                    {
                        recIds = Seleected_recIds;
                    }
                    #endregion
                }

                string RecordIDs = string.Join(",", recIds);

                Log("MarkRelevancy", RecordIDs);
                Log("MarkRelevancy", Reason);
                Log("MarkRelevancy", Convert.ToString(IsRelevant));

                if (Convert.ToInt32(UserID) > 0)
                {
                    new Sahadeva.API.DAL.API_V2().UserLog_Insert(Convert.ToInt32(UserID), "MarkRelevancy", Convert.ToInt32(IncidentID));
                }

                RecordID_Output = new Sahadeva.API.DAL.API_V2().MarkRelevancy(UserID, PlatformID, RecordIDs, Reason, IsRelevant, IncidentID);

                dynamic json = new JObject();
                json.status = "Successful";
                json.message = "Updated Successfully.";


                result = JsonConvert.SerializeObject(json, setting);
            }
            catch (Exception ex)
            {
                Log("MarkRelevancy", ex.Message + " ->> " + ex.StackTrace + " Detail : " + new StreamReader(postData).ReadToEnd().ToString());
                dynamic json = new JObject();
                json.status = "Error";
                json.message = "Error Occured";

                var setting = new JsonSerializerSettings
                {
                    MaxDepth = int.MaxValue,
                    Formatting = Newtonsoft.Json.Formatting.None
                };
                result = JsonConvert.SerializeObject(json, setting);
            }

            return new MemoryStream(Encoding.UTF8.GetBytes(result));

        }

        [OperationContract]
        [WebInvoke(Method = "POST", UriTemplate = "Fetch_User_Marked_Irrelevant_List", ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Bare)]
        public Stream Fetch_User_Marked_Irrelevant_List(Stream postData)
        {
            string result = string.Empty;

            try
            {

                if (HttpContext.Current.Request.Headers["token"] != null && !String.IsNullOrEmpty(HttpContext.Current.Request.Headers["token"]))
                {
                    bool IsValid = ValidateRequest(Convert.ToString(HttpContext.Current.Request.Headers["token"]));
                    if (IsValid == false)
                    {
                        result = "401 Unauthorized";
                        return new MemoryStream(Encoding.UTF8.GetBytes(result));
                    }
                }

                WebOperationContext.Current.OutgoingResponse.ContentType = "application/json; charset=utf-8";

                //eParameters parameters_obj = GetParameters(postData, "CreateIncident");

                var setting = new JsonSerializerSettings
                {
                    MaxDepth = int.MaxValue,
                    Formatting = Newtonsoft.Json.Formatting.None
                };

                string InputBody = new StreamReader(postData).ReadToEnd().ToString();

                Int32 RecordID_Output = 0;
                dynamic stuff = JObject.Parse(InputBody);

                Log("Fetch_User_Marked_Irrelevant_List", InputBody);
                //eParameters parameters_obj = GetParameters(null, "UserBookmark", InputBody);


                Int32 UserID = Convert.ToInt32(Convert.ToString(stuff.user_id));
                string platform = Convert.ToString(Convert.ToString(stuff.platform));
                Int32 PlatformID = 0;
                Int32 IncidentID = Convert.ToInt32(Convert.ToString(stuff.incident_id));

                if (Convert.ToInt32(UserID) > 0)
                {
                    new Sahadeva.API.DAL.API_V2().UserLog_Insert(Convert.ToInt32(UserID), "Fetch_User_Marked_Irrelevant_List", Convert.ToInt32(IncidentID));
                }

                if (platform == "online") { PlatformID = 1; }
                if (platform == "print") { PlatformID = 2; }
                if (platform == "twitter") { PlatformID = 3; }
                if (platform == "youtube") { PlatformID = 4; }


                DataTable dt = new Sahadeva.API.DAL.API_V2().Fetch_User_Marked_Irrelevant_List(UserID, PlatformID, IncidentID);

                dynamic json = new JObject();
                json.status = "Successful";
                json.message = "Successful";
                json.data = new JArray();
                json.data = JArray.FromObject(dt);


                result = JsonConvert.SerializeObject(json, setting);
            }
            catch (Exception ex)
            {
                Log("Fetch_User_Marked_Irrelevant_List", ex.Message + " ->> " + ex.StackTrace + " Detail : " + new StreamReader(postData).ReadToEnd().ToString());
                dynamic json = new JObject();
                json.status = "Error";
                json.message = "Error Occured";

                var setting = new JsonSerializerSettings
                {
                    MaxDepth = int.MaxValue,
                    Formatting = Newtonsoft.Json.Formatting.None
                };
                result = JsonConvert.SerializeObject(json, setting);
            }

            return new MemoryStream(Encoding.UTF8.GetBytes(result));

        }


        #endregion

        [OperationContract]
        [WebInvoke(Method = "POST", UriTemplate = "DataTag_Fetch_List", ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Bare)]
        public Stream DataTag_Fetch_List(Stream postData)
        {
            string result = string.Empty;

            try
            {

                if (HttpContext.Current.Request.Headers["token"] != null && !String.IsNullOrEmpty(HttpContext.Current.Request.Headers["token"]))
                {
                    bool IsValid = ValidateRequest(Convert.ToString(HttpContext.Current.Request.Headers["token"]));
                    if (IsValid == false)
                    {
                        result = "401 Unauthorized";
                        return new MemoryStream(Encoding.UTF8.GetBytes(result));
                    }
                }

                WebOperationContext.Current.OutgoingResponse.ContentType = "application/json; charset=utf-8";

                eParameters parameters_obj = GetParameters(postData, "DataTag_Fetch_List");

                if (!String.IsNullOrEmpty(parameters_obj.UserID) && Convert.ToInt32(parameters_obj.UserID) > 0)
                {
                    new Sahadeva.API.DAL.API_V2().UserLog_Insert(Convert.ToInt32(parameters_obj.UserID), "DataTag_Fetch_List", Convert.ToInt32(parameters_obj.TopicID));
                }

                var setting = new JsonSerializerSettings
                {
                    MaxDepth = int.MaxValue,
                    Formatting = Newtonsoft.Json.Formatting.None
                };


                DataTable dt = new Sahadeva.API.DAL.API_V2().DataTag_Fetch_List(Convert.ToInt32(parameters_obj.TopicID), Convert.ToInt32(parameters_obj.platform_id));
                dynamic json = new JObject();
                json.status = "200";
                json.message = "Success";
                json.data = new JArray();
                json.data = JArray.FromObject(dt);

                //result = File.ReadAllText(ConfigurationManager.AppSettings["FetchList_OnlineArticle"]);

                result = JsonConvert.SerializeObject(json, setting);
            }
            catch (Exception ex)
            {
                Log("DataTag_Fetch_List", ex.Message + " ->> " + ex.StackTrace + " Detail : " + new StreamReader(postData).ReadToEnd().ToString());
                dynamic json = new JObject();
                json.status = "Error";
                json.message = "Error Occured";

                var setting = new JsonSerializerSettings
                {
                    MaxDepth = int.MaxValue,
                    Formatting = Newtonsoft.Json.Formatting.None
                };
                result = JsonConvert.SerializeObject(json, setting);
            }

            return new MemoryStream(Encoding.UTF8.GetBytes(result));

        }

        private JArray BuildConditional(DataTable dt)
        {
            JArray result = new JArray();

            if (dt == null || dt.Rows.Count == 0)
                return result;

            foreach (DataRow dr in dt.Rows)
            {
                JObject cond = new JObject();

                cond["condition_name"] = dr.Table.Columns.Contains("condition_name") ? Convert.ToString(dr["condition_name"]) : "";

                cond["condition_id"] = dr.Table.Columns.Contains("condition_id") ? Convert.ToInt32(dr["condition_id"]) : 0;

                cond["is_active"] = dr.Table.Columns.Contains("is_active") ? Convert.ToInt32(dr["is_active"]) : 0;

                cond["is_deleted"] = dr.Table.Columns.Contains("is_deleted") ? Convert.ToInt32(dr["is_deleted"]) : 0;

                string raw = dr.Table.Columns.Contains("criteria") && dr["criteria"] != DBNull.Value
                    ? Convert.ToString(dr["criteria"])
                    : null;

                if (string.IsNullOrWhiteSpace(raw))
                {
                    cond["criteria"] = new JArray();
                    result.Add(cond);
                    continue;
                }

                raw = raw.Trim();

                try
                {
                    JToken parsed = JToken.Parse(raw);

                    switch (parsed.Type)
                    {
                        case JTokenType.Array:
                            cond["criteria"] = parsed;
                            break;

                        case JTokenType.Object:
                            var obj = (JObject)parsed;

                            if (obj["criteria"] != null && obj["criteria"].Type == JTokenType.Array)
                                cond["criteria"] = obj["criteria"];
                            else
                                cond["criteria"] = new JArray(obj);

                            break;

                        default:
                            cond["criteria"] = new JArray();
                            break;
                    }
                }
                catch
                {
                    cond["criteria"] = new JArray();
                }

                result.Add(cond);
            }

            return result;
        }
        
    }
}